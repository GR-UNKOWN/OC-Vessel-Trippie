import { randomInt, randomUUID } from 'node:crypto';
import { checkStorage, roomCommand, storageConfigured } from '../server/room-store.js';
import { maxSprite, spriteValue, stateValue } from '../server/game-state.js';

const alphabet = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
const pinPattern = new RegExp(`^[${alphabet}]{8}$`);
const idPattern = /^[a-f0-9-]{36}$/;
const maxRequest = maxSprite + 8192;
const reply = (body, status = 200) => Response.json(body, {
  status, headers: { 'Cache-Control': 'no-store' },
});
const invalid = () => reply({ error: 'invalid-request' }, 400);
const isPin = value => typeof value === 'string' && pinPattern.test(value);
const isId = value => typeof value === 'string' && idPattern.test(value);

function isOriginAllowed(request) {
  const origin = request.headers.get('origin');
  const url = new URL(request.url);
  return !origin || origin === url.origin || (
    process.env.VERCEL && origin === 'https://' + request.headers.get('x-forwarded-host')
  );
}

async function readPacket(request) {
  if (!request.body) return null;
  const reader = request.body.getReader();
  const chunks = [];
  let size = 0;
  for (;;) {
    const { value, done } = await reader.read();
    if (done) break;
    size += value.length;
    if (size > maxRequest) {
      await reader.cancel();
      return null;
    }
    chunks.push(value);
  }
  return JSON.parse(Buffer.concat(chunks).toString('utf8'));
}

async function enter(packet) {
  const create = packet.op === 'create';
  const id = randomUUID(), token = randomUUID();
  if (!create && !isPin(packet.pin)) return reply({ error: 'unknown-room' }, 404);
  let pin = packet.pin;
  for (let i = 0; i < 4; i++) {
    if (create) pin = Array.from({ length: 8 }, () => alphabet[randomInt(alphabet.length)]).join('');
    const [status] = await roomCommand(pin, packet.op, { id, token });
    if (status === 'collision') continue;
    if (status === 'ok') return reply({ id, token, pin, host: create });
    return reply({ error: status }, status === 'room-full' ? 409 : 404);
  }
  return reply({ error: 'storage-unavailable' }, 503);
}

async function reconcile(packet) {
  if (!isPin(packet.pin) || !isId(packet.id) || !isId(packet.token)) return invalid();
  const args = { id: packet.id, token: packet.token };
  if (packet.op === 'sync') {
    const state = stateValue(packet.state, packet.pin);
    const sprite = spriteValue(packet.state?.sp);
    args.state = state || undefined;
    if (state && sprite !== undefined) args.sprite = sprite || '';
    args.known = Object.fromEntries(Object.entries(packet.known || {}).slice(0, 12)
      .filter(([id, versions]) => isId(id) && Array.isArray(versions) &&
        versions.length === 2 && versions.every(Number.isSafeInteger)));
  }

  const [status, payload] = await roomCommand(packet.pin, packet.op, args);
  if (status !== 'ok') return reply({ error: status }, 404);
  if (packet.op === 'leave') return reply({ ok: true });

  const [present, changed] = JSON.parse(payload);
  return reply({
    present: Object.values(present),
    updated: Object.values(changed).map(([id, raw, sprite]) => {
      const { revision, spriteVersion, ...state } = JSON.parse(raw);
      if (sprite !== null) state.sp = sprite || null;
      return { id, revision, spriteVersion, state };
    }),
  });
}

export default {
  async fetch(request) {
    if (request.method === 'GET') {
      const ready = await checkStorage().catch(() => false);
      return reply({ storage: ready ? 'ready' : storageConfigured() ? 'unreachable' : 'setup-required' }, ready ? 200 : 503);
    }
    if (request.method !== 'POST') return reply({ error: 'invalid-request' }, 405);
    if (!isOriginAllowed(request)) return reply({ error: 'invalid-request' }, 403);
    if (!storageConfigured()) return reply({ error: 'setup-required' }, 503);

    const packet = await readPacket(request).catch(() => null);
    if (!packet || typeof packet !== 'object') return invalid();
    try {
      if (packet.op === 'create' || packet.op === 'join') return await enter(packet);
      if (packet.op === 'sync' || packet.op === 'leave') return await reconcile(packet);
      return invalid();
    } catch {
      return reply({ error: 'storage-unavailable' }, 503);
    }
  },
};
