// Twin-engine medium helicopter (5-blade main rotor) — sprite traced from the side-profile reference,
// 2-D rigid-body flight model (thrust vector, attitude dynamics, rotor spool, drag, ground effect, deck contact)
// with an autopilot (cascaded speed/attitude + vertical-speed control) and delivery / transfer missions.
import { makeCanvas, clamp, lerp, Bus } from './util.js';

export const PPM = 12.7;               // pixels per metre (sprite traced at 15.7 m fuselage = 200 px)
const G0 = 9.81, MASS = 7000, TMAX = 1.5 * MASS * G0, R_MAIN = 7.4 * PPM, R_TAIL = 15;
const S = 0.0935, OX = 100, OY = 520, PADC = 2;      // image-space → sprite-space mapping
const P = (x, y) => [(x - OX) * S + PADC, (y - OY) * S + PADC];
const ANCHOR = P(900, 1290);                          // mast axis at wheel contact
const HUB = [0, (470 - 1290) * S];                    // rotor hub relative to anchor
const TAIL = [(2232 - 900) * S, (592 - 1290) * S];    // tail-rotor hub relative to anchor
const DOOR = (1040 - 900) * S;                        // sliding cabin door centre, toward tail
export const LIVERIES = {
  skyblue: { th: 'ขาว–ฟ้า', frame: '#5fb3df', frameHi: '#9fd4ef' },
  reference: { th: 'ขาว (กรอบหน้าต่างแดง ตามภาพอ้างอิง)', frame: '#d6433a', frameHi: '#f07a70' },
  white: { th: 'ขาวล้วน', frame: '#b9c1c8', frameHi: '#dde2e6' },
};

/* ---------------- sprite ---------------- */
const FUS = [[128, 1050], [150, 1012], [200, 986], [270, 966], [335, 952], [420, 866], [500, 806], [565, 772], [640, 758], [720, 752], [900, 750], [1200, 752], [1420, 760], [1520, 795], [1600, 812], [1800, 825], [1990, 838], [2000, 836], [2060, 760], [2110, 690], [2150, 640], [2200, 602], [2262, 608], [2272, 640], [2245, 760], [2205, 880], [2190, 905], [2140, 922], [1900, 935], [1700, 960], [1550, 1000], [1450, 1045], [1400, 1085], [1300, 1125], [1000, 1142], [700, 1150], [560, 1135], [450, 1116], [330, 1104], [230, 1090], [170, 1074]];
const COWL = [[700, 752], [715, 690], [760, 630], [840, 595], [1000, 585], [1150, 598], [1260, 640], [1360, 700], [1440, 745], [1520, 795], [1420, 760], [1200, 752]];
const WSCREEN = [[300, 966], [345, 930], [430, 862], [520, 802], [572, 775], [548, 800], [540, 955], [330, 968]];
const WINDOWS = [[[548, 790], [642, 790], [642, 952], [540, 952]], [[765, 790], [905, 790], [905, 946], [765, 946]], [[945, 790], [1145, 790], [1145, 946], [945, 946]], [[1160, 790], [1278, 790], [1278, 934], [1160, 934]]];
function path(c, pts) { c.beginPath(); pts.forEach(([x, y], i) => { const [a, b] = P(x, y); i ? c.lineTo(a, b) : c.moveTo(a, b); }); c.closePath(); }
function circ(c, x, y, r, col) { const [a, b] = P(x, y); c.fillStyle = col; c.beginPath(); c.arc(a, b, r * S, 0, Math.PI * 2); c.fill(); }
function rr(c, pts, rad, col) { // rounded quad
  const q = pts.map(([x, y]) => P(x, y)); const r = rad * S; c.beginPath();
  for (let i = 0; i < 4; i++) { const p0 = q[(i + 3) % 4], p1 = q[i], p2 = q[(i + 1) % 4]; const a = [p1[0] + (p0[0] - p1[0]) * Math.min(0.4, r / Math.hypot(p0[0] - p1[0], p0[1] - p1[1])), p1[1] + (p0[1] - p1[1]) * Math.min(0.4, r / Math.hypot(p0[0] - p1[0], p0[1] - p1[1]))]; const b = [p1[0] + (p2[0] - p1[0]) * Math.min(0.4, r / Math.hypot(p2[0] - p1[0], p2[1] - p1[1])), p1[1] + (p2[1] - p1[1]) * Math.min(0.4, r / Math.hypot(p2[0] - p1[0], p2[1] - p1[1]))]; i ? c.lineTo(...a) : c.moveTo(...a); c.quadraticCurveTo(p1[0], p1[1], ...b); }
  c.closePath(); c.fillStyle = col; c.fill();
}
const spriteCache = {};
export function heliSprite(livery = 'skyblue') {
  if (spriteCache[livery]) return spriteCache[livery];
  const L = LIVERIES[livery] || LIVERIES.skyblue;
  const W = Math.ceil((2300 - OX) * S + 4), H = Math.ceil((1300 - OY) * S + 4);
  const [cv, c] = makeCanvas(W, H); c.imageSmoothingEnabled = true;
  const body = '#f5f6f7', shadeA = '#dfe3e7', shadeB = '#c6ccd2', glass = '#27323b', grey = '#aab2b9';
  // body + cowling
  path(c, FUS); c.fillStyle = body; c.fill(); path(c, COWL); c.fill();
  // underside shading (lower third of the fuselage) and upper highlight
  c.save(); path(c, FUS); c.clip();
  const [, y1] = P(0, 1040), [, y2] = P(0, 1150); const g = c.createLinearGradient(0, y1, 0, y2); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(0.5, shadeA); g.addColorStop(1, shadeB);
  c.fillStyle = g; c.fillRect(0, y1, W, y2 - y1 + 4);
  c.fillStyle = shadeA; const [bx] = P(1550, 0); c.fillRect(bx, P(0, 905)[1], W, 30); // under-boom
  c.restore();
  c.save(); path(c, COWL); c.clip(); c.fillStyle = '#ffffff'; c.fillRect(0, 0, W, P(0, 640)[1]); c.restore();
  // grey sponson strip + lower nose panel
  path(c, [[690, 1102], [1395, 1094], [1385, 1122], [690, 1134]]); c.fillStyle = '#c3c9cf'; c.fill();
  path(c, [[450, 1064], [700, 1090], [700, 1106], [450, 1094]]); c.fillStyle = '#cdd3d8'; c.fill();
  // nose vent / sensor bay
  rr(c, [[355, 1000], [495, 995], [500, 1075], [360, 1080]], 30, '#3a4046'); rr(c, [[380, 1015], [470, 1012], [474, 1060], [384, 1062]], 18, '#59626a');
  // windshield (dark, one centre post)
  path(c, WSCREEN); c.fillStyle = glass; c.fill();
  c.strokeStyle = '#b9c0c6'; c.lineWidth = 1; c.beginPath(); c.moveTo(...P(440, 856)); c.lineTo(...P(452, 960)); c.stroke();
  // engine intake + exhaust + round ports
  const [ix, iy] = P(915, 626); c.fillStyle = '#3a4046'; c.beginPath(); c.ellipse(ix, iy, 70 * S, 32 * S, -0.08, 0, Math.PI * 2); c.fill();
  path(c, [[1150, 650], [1255, 648], [1265, 700], [1250, 760], [1170, 760], [1150, 700]]); c.fillStyle = '#b5bcc2'; c.fill();
  path(c, [[1182, 666], [1244, 666], [1248, 738], [1186, 738]]); c.fillStyle = '#6f7880'; c.fill();
  circ(c, 852, 718, 14, '#59626a'); circ(c, 1332, 728, 12, '#59626a'); circ(c, 1440, 930, 10, '#9aa3ab');
  // mast fairing
  path(c, [[860, 600], [940, 600], [935, 560], [865, 560]]); c.fillStyle = grey; c.fill();
  // windows: coloured frames per livery, dark glass inset
  for (const w of WINDOWS) { rr(c, w, 36, L.frame); const ins = w.map(([x, y], i) => [x + (i === 0 || i === 3 ? 14 : -14), y + (i < 2 ? 14 : -14)]); rr(c, ins, 26, glass); const [hx, hy] = P(ins[0][0] + 6, ins[0][1] + 6); c.fillStyle = 'rgba(255,255,255,0.16)'; c.fillRect(hx, hy, 3, 1); }
  rr(c, [[648, 800], [690, 800], [690, 940], [648, 940]], 20, glass);
  // door / panel lines
  c.strokeStyle = '#b3bbc2'; c.lineWidth = 0.8;
  for (const [a, b, w2, h2] of [[535, 782, 187, 266], [915, 776, 253, 290], [1370, 845, 128, 120], [985, 640, 100, 100]]) { const [x, y] = P(a, b); c.strokeRect(x, y, w2 * S, h2 * S); }
  // horizontal stabiliser + end plate
  path(c, [[2120, 880], [2296, 845], [2296, 866], [2125, 900]]); c.fillStyle = body; c.fill(); path(c, [[2276, 826], [2296, 822], [2296, 890], [2280, 892]]); c.fillStyle = shadeA; c.fill();
  // tail-rotor gearbox
  circ(c, 2232, 595, 30, '#d8dde1');
  // landing gear: nose (twin) + near main
  c.strokeStyle = '#7d868e'; c.lineWidth = 14 * S; c.beginPath(); c.moveTo(...P(540, 1135)); c.lineTo(...P(532, 1232)); c.moveTo(...P(990, 1140)); c.lineTo(...P(982, 1238)); c.stroke();
  circ(c, 532, 1246, 44, '#1f2327'); circ(c, 532, 1246, 16, '#9aa4ac'); // nose gear (twin wheels coincide in a true side view)
  circ(c, 982, 1240, 50, '#1f2327'); circ(c, 982, 1240, 18, '#9aa4ac');
  // pixel pass: hard alpha + 1px dark outline
  const id = c.getImageData(0, 0, W, H), d = id.data, out = new Uint8ClampedArray(d.length);
  for (let i = 0; i < d.length; i += 4) { if (d[i + 3] > 110) { out[i] = d[i]; out[i + 1] = d[i + 1]; out[i + 2] = d[i + 2]; out[i + 3] = 255; } }
  const o2 = new Uint8ClampedArray(out);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) { const i = (y * W + x) * 4; if (out[i + 3]) continue; if ([[1, 0], [-1, 0], [0, 1], [0, -1]].some(([a, b]) => { const X = x + a, Y = y + b; return X >= 0 && Y >= 0 && X < W && Y < H && out[(Y * W + X) * 4 + 3]; })) { o2[i] = 0x6d; o2[i + 1] = 0x78; o2[i + 2] = 0x82; o2[i + 3] = 255; } }
  c.putImageData(new ImageData(o2, W, H), 0, 0);
  return (spriteCache[livery] = { cv, ax: ANCHOR[0], ay: ANCHOR[1] });
}

/* ---------------- flight model ---------------- */
export class Heli {
  constructor(pad, opts = {}) {
    this.pad = pad; this.facing = pad.face; this.livery = opts.livery || 'skyblue';
    this.x = pad.cx; this.y = pad.y; this.vx = 0; this.vy = 0; this.th = 0; this.om = 0; this.rpm = 0; this.coll = 0; this.cyc = 0;
    this.engines = false; this.onGround = true; this.psi = 0; this.psiT = 0; this.turn = 0; this.turnTarget = this.facing;
    this.mode = 'auto'; this.phase = 'parked'; this.mission = null; this.timer = 0; this.particles = []; this.events = [];
    this.manual = { up: 0, down: 0, left: 0, right: 0, assist: true };
    this.cargo = []; this.passengers = []; this.lastBump = 0; this.hardT = 0;
  }
  get doorX() { return this.x - this.facing * DOOR; }
  get altM() { return (this.surfaceY - this.y) / PPM; }
  // spawn airborne, inbound from the pad's approach side
  spawnInbound() {
    const p = this.pad; this.facing = -p.from; this.turnTarget = this.facing; this.x = p.cx + p.from * 3200; this.y = p.y - 300;
    this.vx = -p.from * 25 * PPM; this.vy = 0; this.th = this.facing * -0.0; this.rpm = 1; this.engines = true; this.onGround = false; this.phase = 'inbound'; this.mode = 'auto';
  }
  setTargets() {
    const p = this.pad;
    switch (this.phase) {
      case 'inbound': return { x: p.cx + p.from * 160, y: p.y - 110, vmax: 30, brake: 1.6 };
      case 'approach': return { x: p.cx, y: p.y - 34, vmax: 10, brake: 1.4 };
      case 'descend': return { x: p.cx, y: p.y + 4, vmax: 3, brake: 1.2, vdown: 0.7 };
      case 'liftoff': case 'turning': return { x: p.cx, y: p.y - 46, vmax: 2, brake: 1.2 };
      case 'depart': return { x: p.cx + p.from * 4200, y: p.y - 420, vmax: 45, brake: 2, vup: 7 };
      default: return null;
    }
  }
  // autopilot → collective + cyclic commands
  autopilot(dt, tgt) {
    const vx = this.vx / PPM, vyUp = -this.vy / PPM;
    const dx = (tgt.x - this.x) / PPM, dyUp = (this.y - tgt.y) / PPM;
    const vxd = Math.sign(dx) * Math.min(tgt.vmax, Math.sqrt(2 * tgt.brake * Math.abs(dx)), Math.abs(dx) * 0.6 + 0.2);
    const ax = clamp(0.7 * (vxd - vx), -3.2, 3.2);
    this.cyc = clamp(Math.atan2(ax, G0) * this.facing, -0.3, 0.3);
    const vyd = clamp(dyUp * 0.45, -(tgt.vdown ?? 4), tgt.vup ?? 5);
    return this.hold(vyd, vyUp);
  }
  hold(vyd, vyUp) { const need = MASS * (G0 + 1.4 * (vyd - vyUp)) + 22 * vyUp * Math.abs(vyUp) * Math.sign(vyUp); const avail = TMAX * this.rpm * this.rpm * Math.cos(this.th) * this.ge; this.coll = clamp(avail > 1 ? need / avail : 0, 0, 1); }
  step(dt, world) {
    // world: { surfaces:[{x1,x2,y}], WL, solid(x,y) }
    // rotor speed
    const tr = this.engines ? 1 : 0; this.rpm += (tr - this.rpm) * dt / (this.engines ? 4.5 : 9);
    this.psi += this.rpm * 27 * dt; this.psiT += this.rpm * 140 * dt;
    // surface below for ground effect
    let below = world.WL; for (const s of world.surfaces) if (this.x >= s.x1 && this.x <= s.x2 && s.y >= this.y - 1 && s.y < below) below = s.y;
    this.surfaceY = below; const hRotor = (below - this.y) / PPM + 4.6; this.ge = 1 + 0.14 * clamp(1 - hRotor / 14.8, 0, 1);
    // control
    if (this.mode === 'manual') this.manualControl(dt);
    else { const t = this.setTargets(); if (t) this.autopilot(dt, t); else { this.coll = 0; this.cyc = 0; } }
    // pedal turn (yaw 180° in hover, shown as a horizontal flip)
    if (this.turnTarget !== this.facing) { this.turn += dt / 2.2; if (this.turn >= 1) { this.turn = 0; this.facing = this.turnTarget; } }
    // attitude dynamics (2nd order, limited)
    const alpha = 9 * (this.cyc - this.th) - 5 * this.om; this.om += alpha * dt; this.th = clamp(this.th + this.om * dt, -0.36, 0.36);
    // forces
    const T = this.coll * TMAX * this.rpm * this.rpm * this.ge;
    const vx = this.vx / PPM, vyUp = -this.vy / PPM;
    const gust = Math.sin(performance.now() / 1700) * 300 + Math.sin(performance.now() / 530) * 150;
    let ax = (this.facing * T * Math.sin(this.th) - 5.5 * vx * Math.abs(vx) + (this.onGround ? 0 : gust)) / MASS;
    let ay = (T * Math.cos(this.th) - MASS * G0 - 22 * vyUp * Math.abs(vyUp) - MASS * 0.15 * vyUp) / MASS;
    if (this.onGround) { if (ay <= 0.05) { ay = 0; ax = 0; this.vx *= 0.85; this.vy = 0; this.th *= 0.9; this.om = 0; return this.integrateGround(dt); } this.onGround = false; this.events.push('liftoff'); }
    const px = this.x, py = this.y;
    this.vx += ax * PPM * dt; this.vy -= ay * PPM * dt;
    this.x += this.vx * dt; this.y += this.vy * dt;
    // deck contact
    for (const s of world.surfaces) if (this.x >= s.x1 && this.x <= s.x2 && py <= s.y + 0.5 && this.y >= s.y) {
      const imp = this.vy / PPM; this.y = s.y; this.vy = 0; this.vx *= 0.3; this.onGround = true; this.th *= 0.5;
      this.events.push(imp > 2.8 ? 'hard' : 'touchdown'); break;
    }
    // structure collision (fuselage samples against the yacht's solid pixels)
    if (!this.onGround && world.solid) {
      for (const [lx, ly] of [[-60, -24], [-30, -40], [0, -46], [40, -36], [90, -30], [118, -52], [20, -16]]) {
        const ca = Math.cos(this.th * this.facing), sa = Math.sin(this.th * this.facing); const fx = -this.facing * lx; // native nose-left
        const wx = this.x + fx * ca - ly * sa, wy = this.y + fx * sa + ly * ca;
        if (world.solid(wx, wy)) { this.x = px; this.y = py; this.vx *= -0.25; this.vy *= -0.25; if (performance.now() - this.lastBump > 1500) { this.lastBump = performance.now(); this.events.push('bump'); } break; }
      }
    }
    if (this.y > world.WL - 2 && !this.onGround) { this.events.push('water'); }
  }
  integrateGround(dt) { this.x += this.vx * dt; }
  manualControl(dt) {
    const m = this.manual;
    if (m.assist) {
      const vyUp = -this.vy / PPM; const vyd = m.up ? 4 : m.down ? -2.5 : 0; const vx = this.vx / PPM;
      const vxd = m.right ? 22 : m.left ? -22 : 0; const ax = clamp(0.8 * (vxd - vx), -3, 3);
      this.cyc = clamp(Math.atan2(ax, G0) * this.facing, -0.3, 0.3);
      if (!this.engines || this.rpm < 0.85) { this.coll = 0; return; }
      this.hold(vyd, vyUp);
    } else {
      this.coll = clamp(this.coll + ((m.up ? 0.35 : 0) - (m.down ? 0.35 : 0)) * dt, 0, 1);
      const wt = (m.right ? 1 : 0) - (m.left ? 1 : 0); this.cyc = clamp(wt * 0.26 * this.facing, -0.3, 0.3);
    }
  }
  /* ---------- drawing (yacht-local coordinates) ---------- */
  draw(c, t) {
    // pure side view: the sprite is never rotated or squashed, so pixels stay square; facing flips at mid-turn
    const spr = heliSprite(this.livery);
    const face = this.turnTarget !== this.facing && this.turn > 0.5 ? this.turnTarget : this.facing;
    const X = Math.round(this.x), Y = Math.round(this.y);
    c.save(); c.translate(X, Y); if (face === 1) c.scale(-1, 1);
    c.drawImage(spr.cv, -Math.round(spr.ax), -Math.round(spr.ay));
    // tail rotor on the fin is seen face-on in a side view
    const tx = Math.round(TAIL[0]), ty = Math.round(TAIL[1]);
    if (this.rpm > 0.45) { c.fillStyle = 'rgba(120,130,140,0.14)'; c.beginPath(); c.arc(tx, ty, R_TAIL, 0, Math.PI * 2); c.fill(); c.strokeStyle = 'rgba(70,78,86,0.3)'; c.lineWidth = 1; c.beginPath(); c.arc(tx + 0.5, ty + 0.5, R_TAIL, 0, Math.PI * 2); c.stroke(); }
    c.fillStyle = this.rpm > 0.45 ? 'rgba(60,66,72,0.4)' : '#4a525a';
    for (let k = 0; k < 5; k++) { const a = this.psiT + k * Math.PI * 2 / 5; for (let r = 2; r < R_TAIL; r++) c.fillRect(Math.round(tx + Math.cos(a) * r), Math.round(ty + Math.sin(a) * r), 1, 1); }
    c.fillStyle = '#9aa4ac'; c.fillRect(tx - 1, ty - 1, 3, 3);
    // main rotor: edge-on, flat disc line; blade length follows cos(azimuth)
    const hy = Math.round(HUB[1]);
    c.fillStyle = '#aab2b9'; c.fillRect(-3, hy, 6, 6); c.fillStyle = '#cfd5da'; c.fillRect(-6, hy - 1, 12, 3); c.fillStyle = '#e9ecef'; c.fillRect(-3, hy - 3, 6, 2);
    const droop = Math.round((1 - this.rpm) * 4);
    if (this.rpm > 0.55) { c.fillStyle = `rgba(80,88,96,${(0.18 + 0.12 * this.rpm).toFixed(2)})`; c.fillRect(-Math.round(R_MAIN), hy, Math.round(R_MAIN * 2), 1); }
    for (let k = 0; k < 5; k++) {
      const ex = Math.round(Math.cos(this.psi + k * Math.PI * 2 / 5) * R_MAIN);
      c.fillStyle = this.rpm > 0.55 ? `rgba(55,60,66,${(0.6 - 0.35 * this.rpm).toFixed(2)})` : '#3f474f';
      if (!ex) continue; const inner = Math.round(ex * 0.55);
      c.fillRect(Math.min(0, inner), hy, Math.abs(inner), 2); c.fillRect(Math.min(inner, ex), hy + droop, Math.abs(ex - inner), 2);
    }
    c.restore();
    for (const cr of this.cargo) { c.fillStyle = '#b8935f'; c.fillRect(Math.round(cr.x - 5), Math.round(cr.y - 8), 10, 8); c.fillStyle = '#8a6a42'; c.fillRect(Math.round(cr.x - 5), Math.round(cr.y - 8), 10, 1); c.fillRect(Math.round(cr.x - 1), Math.round(cr.y - 8), 2, 8); }
    for (const p of this.particles) { c.globalAlpha = clamp(p.life, 0, 1) * 0.7; c.fillStyle = p.col; c.fillRect(Math.round(p.x), Math.round(p.y), 2, 1); }
    c.globalAlpha = 1;
  }
  updateParticles(dt, WL) {
    const h = (this.surfaceY - this.y) / PPM;
    if (this.rpm > 0.6 && h < 28 && this.coll > 0.2) {
      const n = Math.round(4 * (1 - h / 28) * this.rpm); const overWater = this.surfaceY >= WL - 1;
      for (let i = 0; i < n; i++) { const dir = Math.random() < 0.5 ? -1 : 1; this.particles.push({ x: this.x + dir * Math.random() * 20, y: this.surfaceY - 1 - Math.random() * 2, vx: dir * (40 + Math.random() * 80) * (1 - h / 30), vy: -Math.random() * (overWater ? 30 : 8), life: 0.6 + Math.random() * 0.6, col: overWater ? '#ffffff' : '#d8dde1' }); }
    }
    this.particles = this.particles.filter(p => (p.life -= dt) > 0); for (const p of this.particles) { p.x += p.vx * dt; p.y += p.vy * dt; p.vy += 40 * dt; }
    if (this.particles.length > 260) this.particles.splice(0, this.particles.length - 260);
  }
  telemetry(WL) {
    return { alt: (WL - this.y) / PPM, agl: (this.surfaceY - this.y) / PPM, vs: -this.vy / PPM, ias: Math.abs(this.vx / PPM) * 1.944, rpm: this.rpm * 100, pitch: -this.th * 57.3, coll: this.coll * 100, phase: this.phase, ground: this.onGround };
  }
}
