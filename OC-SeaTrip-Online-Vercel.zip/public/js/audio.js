// Audio: synthesized ocean/ambient beds (WebAudio), UI clicks, and a music player that embeds YouTube
// through their official embed players, plus local audio files.
import { Bus, clamp } from './util.js';

const clamp01 = v => Math.max(0.05, Math.min(1, v));
export const Audio = {
  ctx: null, started: false,
  vol: { master: 0.8, ambient: 0.5, ocean: 0.6, ui: 0.5, music: 0.7 }, muted: false,
  nodes: {},
  wake() { const c = this.ctx; if (c && c.state !== 'running' && c.state !== 'closed') c.resume?.().catch(() => { }); },
  start() {
    if (this.started) { this.ctx?.resume?.(); return; }
    try {
      const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return;
      const ctx = this.ctx = new AC(); this.started = true;
      const master = ctx.createGain(); master.connect(ctx.destination);
      const mk = () => { const g = ctx.createGain(); g.connect(master); return g; };
      this.nodes = { master, ocean: mk(), ambient: mk(), ui: mk() };
      // ocean: brown noise -> lowpass with slow swell LFO
      const len = ctx.sampleRate * 4; const buf = ctx.createBuffer(1, len, ctx.sampleRate); const d = buf.getChannelData(0); let last = 0;
      for (let i = 0; i < len; i++) { const w = Math.random() * 2 - 1; last = (last + 0.02 * w) / 1.02; d[i] = last * 3.2; }
      const src = ctx.createBufferSource(); src.buffer = buf; src.loop = true;
      const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 520;
      const swell = ctx.createGain(); swell.gain.value = 0.7;
      const lfo = ctx.createOscillator(); lfo.frequency.value = 0.11; const lfoG = ctx.createGain(); lfoG.gain.value = 0.3; lfo.connect(lfoG); lfoG.connect(swell.gain); lfo.start();
      const lfo2 = ctx.createOscillator(); lfo2.frequency.value = 0.07; const lfo2G = ctx.createGain(); lfo2G.gain.value = 220; lfo2.connect(lfo2G); lfo2G.connect(lp.frequency); lfo2.start();
      src.connect(lp); lp.connect(swell); swell.connect(this.nodes.ocean); src.start();
      // ambient: soft wind (bandpassed white noise) + occasional gull-like chirp
      const wb = ctx.createBuffer(1, ctx.sampleRate * 3, ctx.sampleRate); const wd = wb.getChannelData(0); for (let i = 0; i < wd.length; i++) wd[i] = Math.random() * 2 - 1;
      const ws = ctx.createBufferSource(); ws.buffer = wb; ws.loop = true; const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 900; bp.Q.value = 0.6; const wg = ctx.createGain(); wg.gain.value = 0.05;
      ws.connect(bp); bp.connect(wg); wg.connect(this.nodes.ambient); ws.start();
      this.apply();
    } catch (e) { console.warn('audio init failed', e); }
  },
  apply() {
    if (!this.ctx) return; const m = this.muted ? 0 : this.vol.master; const t = this.ctx.currentTime;
    this.nodes.master.gain.setTargetAtTime(m, t, 0.1);
    this.nodes.ocean.gain.setTargetAtTime(this.vol.ocean * 0.5, t, 0.2);
    this.nodes.ambient.gain.setTargetAtTime(this.vol.ambient, t, 0.2);
    this.nodes.ui.gain.setTargetAtTime(this.vol.ui * 0.4, t, 0.05);
    Music.applyVolume();
  },
  // ship's engine-order telegraph bell: a bright brass 'ding-ding'
  telegraph(vol = 1) {
    if (!this.ctx || this.muted) return; const ctx = this.ctx, t0 = ctx.currentTime;
    for (const dt of [0, 0.16]) for (const [f, g0] of [[1320, 0.22], [2650, 0.08], [3960, 0.04]]) {
      const o = ctx.createOscillator(), g = ctx.createGain(); o.type = 'sine'; o.frequency.value = f; const t = t0 + dt;
      g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(g0 * vol, t + 0.005); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.9);
      o.connect(g); g.connect(this.nodes.ui); o.start(t); o.stop(t + 0.95);
    }
  },
  click(f = 880) {
    if (!this.ctx || this.muted) return; const o = this.ctx.createOscillator(), g = this.ctx.createGain(); o.type = 'triangle'; o.frequency.value = f;
    g.gain.setValueAtTime(0.0001, this.ctx.currentTime); g.gain.exponentialRampToValueAtTime(0.4, this.ctx.currentTime + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + 0.12);
    o.connect(g); g.connect(this.nodes.ui); o.start(); o.stop(this.ctx.currentTime + 0.15);
  },
  // horror sting for the shark: falling bass growl + noise burst + shrill stab
  sting() {
    if (!this.ctx || this.muted) return; const ctx = this.ctx, t = ctx.currentTime, out = this.nodes.ui;
    const o = ctx.createOscillator(), g = ctx.createGain(); o.type = 'sawtooth'; o.frequency.setValueAtTime(140, t); o.frequency.exponentialRampToValueAtTime(38, t + 1.4);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.9, t + 0.03); g.gain.exponentialRampToValueAtTime(0.0001, t + 1.6); o.connect(g); g.connect(out); o.start(t); o.stop(t + 1.7);
    const s = ctx.createOscillator(), sg = ctx.createGain(); s.type = 'square'; s.frequency.setValueAtTime(1800, t); s.frequency.linearRampToValueAtTime(2300, t + 0.25);
    sg.gain.setValueAtTime(0.0001, t); sg.gain.exponentialRampToValueAtTime(0.25, t + 0.02); sg.gain.exponentialRampToValueAtTime(0.0001, t + 0.45); s.connect(sg); sg.connect(out); s.start(t); s.stop(t + 0.5);
    const nb = ctx.createBuffer(1, ctx.sampleRate * 0.6, ctx.sampleRate), d = nb.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / d.length);
    const n = ctx.createBufferSource(), lp = ctx.createBiquadFilter(), ng = ctx.createGain(); n.buffer = nb; lp.type = 'lowpass'; lp.frequency.value = 900; ng.gain.value = 0.8; n.connect(lp); lp.connect(ng); ng.connect(out); n.start(t);
  },
  // jump-scare kit: rush (sub-bass swell + sting), chomp (hard bite), drag (underwater roar + bubbles)
  rush() { this.sting(); },
  // tender outboard: buzzy two-stroke-ish drone whose pitch follows planing speed
  motor(level, on) {
    if (!this.ctx) return; const ctx = this.ctx;
    if (!this._mot) { if (!on) return; const o = ctx.createOscillator(), o2 = ctx.createOscillator(), f = ctx.createBiquadFilter(), g = ctx.createGain(); o.type = 'sawtooth'; o2.type = 'square'; f.type = 'lowpass'; f.frequency.value = 700; g.gain.value = 0; o.connect(f); o2.connect(f); f.connect(g); g.connect(this.nodes.ui); o.start(); o2.start(); this._mot = { o, o2, f, g }; }
    const m = this._mot, t = ctx.currentTime; const tgt = on && !this.muted ? 0.05 + level * 0.09 : 0;
    m.g.gain.setTargetAtTime(tgt, t, 0.15); m.o.frequency.setTargetAtTime(55 + level * 95, t, 0.2); m.o2.frequency.setTargetAtTime(110 + level * 190, t, 0.2); m.f.frequency.setTargetAtTime(500 + level * 1400, t, 0.2);
  },
  // main diesels: low drone + firing pulse, pitch and level follow shaft revs (heard faintly everywhere aboard)
  engine(rev, on) {
    if (!this.ctx || !this.started) return; const ctx = this.ctx;
    if (!this._eng) { if (!on || rev < 0.01) return; const o = ctx.createOscillator(), o2 = ctx.createOscillator(), f = ctx.createBiquadFilter(), g = ctx.createGain(), am = ctx.createGain(), lfo = ctx.createOscillator();
      o.type = 'sawtooth'; o2.type = 'triangle'; f.type = 'lowpass'; f.frequency.value = 220; g.gain.value = 0; am.gain.value = 0.5; lfo.type = 'square'; lfo.frequency.value = 8; const lg = ctx.createGain(); lg.gain.value = 0.25; lfo.connect(lg); lg.connect(am.gain);
      o.connect(f); o2.connect(f); f.connect(am); am.connect(g); g.connect(this.nodes.ambient); o.start(); o2.start(); lfo.start(); this._eng = { o, o2, f, g, lfo }; }
    const e = this._eng, t = ctx.currentTime, lvl = on && !this.muted ? 0.03 + rev * 0.09 : 0;
    e.g.gain.setTargetAtTime(lvl, t, 0.4); e.o.frequency.setTargetAtTime(32 + rev * 30, t, 0.6); e.o2.frequency.setTargetAtTime(64 + rev * 60, t, 0.6); e.lfo.frequency.setTargetAtTime(6 + rev * 14, t, 0.6); e.f.frequency.setTargetAtTime(160 + rev * 260, t, 0.6);
  },
  // weather bed: hiss of rain on the sea, a low roar when it pours, and gusting wind
  weather(rain, wind) {
    if (!this.ctx || !this.started) return; const ctx = this.ctx;
    if (!this._wx) {
      if (rain < 0.01 && wind < 0.2) return;
      const noise = (sec, brown) => { const b = ctx.createBuffer(1, ctx.sampleRate * sec, ctx.sampleRate), d = b.getChannelData(0); let l = 0; for (let i = 0; i < d.length; i++) { const w = Math.random() * 2 - 1; if (brown) { l = (l + 0.02 * w) / 1.02; d[i] = l * 3.5; } else d[i] = w; } const s = ctx.createBufferSource(); s.buffer = b; s.loop = true; s.start(); return s; };
      const hiss = noise(3, false), hp = ctx.createBiquadFilter(), lp = ctx.createBiquadFilter(), hg = ctx.createGain(); hp.type = 'highpass'; hp.frequency.value = 1200; lp.type = 'lowpass'; lp.frequency.value = 7500; hg.gain.value = 0; hiss.connect(hp); hp.connect(lp); lp.connect(hg); hg.connect(this.nodes.ambient);
      const roar = noise(4, true), rl = ctx.createBiquadFilter(), rg = ctx.createGain(); rl.type = 'lowpass'; rl.frequency.value = 500; rg.gain.value = 0; roar.connect(rl); rl.connect(rg); rg.connect(this.nodes.ambient);
      const wn = noise(3, false), wb = ctx.createBiquadFilter(), wg = ctx.createGain(); wb.type = 'bandpass'; wb.Q.value = 1.4; wb.frequency.value = 500; wg.gain.value = 0; wn.connect(wb); wb.connect(wg); wg.connect(this.nodes.ambient);
      const lfo = ctx.createOscillator(), lg = ctx.createGain(); lfo.frequency.value = 0.18; lg.gain.value = 0; lfo.connect(lg); lg.connect(wg.gain); lfo.start();
      const lfo2 = ctx.createOscillator(), lg2 = ctx.createGain(); lfo2.frequency.value = 0.09; lg2.gain.value = 250; lfo2.connect(lg2); lg2.connect(wb.frequency); lfo2.start();
      this._wx = { hg, rg, wg, wb, lg };
    }
    const w = this._wx, t = ctx.currentTime;
    w.hg.gain.setTargetAtTime(rain * 0.32, t, 0.6); w.rg.gain.setTargetAtTime(rain * rain * 0.5, t, 0.8);
    w.wg.gain.setTargetAtTime(Math.max(0, wind - 0.15) * 0.22, t, 0.8); w.lg.gain.setTargetAtTime(Math.max(0, wind - 0.3) * 0.14, t, 0.8); w.wb.frequency.setTargetAtTime(380 + wind * 700, t, 1);
  },
  // thunder: a sharp crack when close, a long rolling rumble when far
  thunder(near = 0.5) {
    if (!this.ctx || this.muted) return; const ctx = this.ctx, t = ctx.currentTime, out = this.nodes.ambient;
    const len = 3 + (1 - near) * 2; const b = ctx.createBuffer(1, ctx.sampleRate * len, ctx.sampleRate), d = b.getChannelData(0); let l = 0;
    for (let i = 0; i < d.length; i++) { const w = Math.random() * 2 - 1; l = (l + 0.04 * w) / 1.04; const env = Math.pow(1 - i / d.length, 1.6) * (0.6 + 0.4 * Math.sin(i / ctx.sampleRate * (3 + Math.random()))); d[i] = l * 4 * env; }
    const s = ctx.createBufferSource(), lp = ctx.createBiquadFilter(), g = ctx.createGain(); s.buffer = b; lp.type = 'lowpass'; lp.frequency.value = 160 + near * 500; g.gain.value = 0.6 + near * 0.9; s.connect(lp); lp.connect(g); g.connect(out); s.start(t);
    if (near > 0.6) { const c = ctx.createBuffer(1, ctx.sampleRate * 0.3, ctx.sampleRate), cd = c.getChannelData(0); for (let i = 0; i < cd.length; i++) cd[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / cd.length, 5); const cs = ctx.createBufferSource(), cg = ctx.createGain(); cs.buffer = c; cg.gain.value = 0.9; cs.connect(cg); cg.connect(out); cs.start(t); }
  },
  // glass giving way under pressure
  crack() {
    if (!this.ctx || this.muted) return; const ctx = this.ctx, t = ctx.currentTime, out = this.nodes.ui;
    const nb = ctx.createBuffer(1, ctx.sampleRate * 0.4, ctx.sampleRate), d = nb.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / d.length, 4);
    const n = ctx.createBufferSource(), hp = ctx.createBiquadFilter(), g = ctx.createGain(); n.buffer = nb; hp.type = 'highpass'; hp.frequency.value = 2500; g.gain.value = 0.7; n.connect(hp); hp.connect(g); g.connect(out); n.start(t);
    const nb2 = ctx.createBuffer(1, ctx.sampleRate * 1.2, ctx.sampleRate), d2 = nb2.getChannelData(0); for (let i = 0; i < d2.length; i++) d2[i] = (Math.random() * 2 - 1) * (1 - i / d2.length);
    const w = ctx.createBufferSource(), lp = ctx.createBiquadFilter(), g2 = ctx.createGain(); w.buffer = nb2; lp.type = 'lowpass'; lp.frequency.value = 600; g2.gain.value = 0.5; w.connect(lp); lp.connect(g2); g2.connect(out); w.start(t + 0.05);
  },
  // deep implosion / final plunge
  boom() {
    if (!this.ctx || this.muted) return; const ctx = this.ctx, t = ctx.currentTime, out = this.nodes.ui;
    const o = ctx.createOscillator(), g = ctx.createGain(); o.type = 'sine'; o.frequency.setValueAtTime(70, t); o.frequency.exponentialRampToValueAtTime(22, t + 1.5); g.gain.setValueAtTime(1.1, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 1.8); o.connect(g); g.connect(out); o.start(t); o.stop(t + 1.9);
    const nb = ctx.createBuffer(1, ctx.sampleRate * 1.5, ctx.sampleRate), d = nb.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / d.length, 2);
    const n = ctx.createBufferSource(), lp = ctx.createBiquadFilter(), ng = ctx.createGain(); n.buffer = nb; lp.type = 'lowpass'; lp.frequency.value = 250; ng.gain.value = 1.2; n.connect(lp); lp.connect(ng); ng.connect(out); n.start(t);
  },
  // hull groans and creaks while she floods
  creak(k = 1) {
    if (!this.ctx || this.muted) return; const ctx = this.ctx, t = ctx.currentTime, out = this.nodes.ui;
    const o = ctx.createOscillator(), g = ctx.createGain(), f = ctx.createBiquadFilter(); o.type = 'sawtooth'; const base = 45 + Math.random() * 30;
    o.frequency.setValueAtTime(base, t); o.frequency.linearRampToValueAtTime(base * (0.6 + Math.random() * 0.8), t + 1.8); f.type = 'bandpass'; f.frequency.value = 180 + Math.random() * 200; f.Q.value = 6;
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.25 * clamp01(k), t + 0.4); g.gain.exponentialRampToValueAtTime(0.0001, t + 2.2); o.connect(f); f.connect(g); g.connect(out); o.start(t); o.stop(t + 2.3);
  },
  chomp() {
    if (!this.ctx || this.muted) return; const ctx = this.ctx, t = ctx.currentTime, out = this.nodes.ui;
    const nb = ctx.createBuffer(1, ctx.sampleRate * 0.25, ctx.sampleRate), d = nb.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / d.length, 3);
    const n = ctx.createBufferSource(); n.buffer = nb; const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 1400; bp.Q.value = 0.8; const ng = ctx.createGain(); ng.gain.value = 1.6; n.connect(bp); bp.connect(ng); ng.connect(out); n.start(t);
    const k = ctx.createOscillator(), kg = ctx.createGain(); k.type = 'sine'; k.frequency.setValueAtTime(160, t); k.frequency.exponentialRampToValueAtTime(40, t + 0.25);
    kg.gain.setValueAtTime(1.2, t); kg.gain.exponentialRampToValueAtTime(0.0001, t + 0.35); k.connect(kg); kg.connect(out); k.start(t); k.stop(t + 0.4);
    for (const dt of [0, 0.09]) { const c = ctx.createOscillator(), cg = ctx.createGain(); c.type = 'square'; c.frequency.value = 2600; cg.gain.setValueAtTime(0.0001, t + dt); cg.gain.exponentialRampToValueAtTime(0.35, t + dt + 0.003); cg.gain.exponentialRampToValueAtTime(0.0001, t + dt + 0.03); c.connect(cg); cg.connect(out); c.start(t + dt); c.stop(t + dt + 0.05); }
  },
  drag() {
    if (!this.ctx || this.muted) return; const ctx = this.ctx, t = ctx.currentTime, out = this.nodes.ui;
    const nb = ctx.createBuffer(1, ctx.sampleRate * 1.6, ctx.sampleRate), d = nb.getChannelData(0); let last = 0; for (let i = 0; i < d.length; i++) { last = (last + 0.05 * (Math.random() * 2 - 1)) / 1.05; d[i] = last * 6; }
    const n = ctx.createBufferSource(); n.buffer = nb; const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.setValueAtTime(900, t); lp.frequency.exponentialRampToValueAtTime(120, t + 1.5);
    const g = ctx.createGain(); g.gain.setValueAtTime(0.9, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 1.6); n.connect(lp); lp.connect(g); g.connect(out); n.start(t);
    for (let i = 0; i < 9; i++) { const b = ctx.createOscillator(), bg = ctx.createGain(), s = t + i * 0.13 + Math.random() * 0.06; b.type = 'sine'; b.frequency.setValueAtTime(300 + Math.random() * 300, s); b.frequency.exponentialRampToValueAtTime(900 + Math.random() * 600, s + 0.06); bg.gain.setValueAtTime(0.0001, s); bg.gain.exponentialRampToValueAtTime(0.12, s + 0.01); bg.gain.exponentialRampToValueAtTime(0.0001, s + 0.08); b.connect(bg); bg.connect(out); b.start(s); b.stop(s + 0.1); }
  },
  gull() {
    if (!this.ctx || this.muted) return; const t = this.ctx.currentTime; const o = this.ctx.createOscillator(), g = this.ctx.createGain(); o.type = 'sine';
    o.frequency.setValueAtTime(1500, t); o.frequency.exponentialRampToValueAtTime(900, t + 0.25); o.frequency.exponentialRampToValueAtTime(1300, t + 0.35);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.05, t + 0.05); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.4); o.connect(g); g.connect(this.nodes.ambient); o.start(); o.stop(t + 0.45);
  },
  rotor(level, rpm) {
    if (!this.ctx || !this.started) return;
    if (!this.rot) {
      if (level <= 0.001) return;
      const ctx = this.ctx, len = ctx.sampleRate * 2, b = ctx.createBuffer(1, len, ctx.sampleRate), d = b.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      const src = ctx.createBufferSource(); src.buffer = b; src.loop = true;
      const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 380;
      const am = ctx.createGain(); am.gain.value = 0.45; const lfo = ctx.createOscillator(); lfo.type = 'sawtooth'; lfo.frequency.value = 20; const lg = ctx.createGain(); lg.gain.value = 0.55; lfo.connect(lg); lg.connect(am.gain);
      const out = ctx.createGain(); out.gain.value = 0; src.connect(lp); lp.connect(am); am.connect(out); out.connect(this.nodes.ambient);
      const wh = ctx.createOscillator(); wh.type = 'triangle'; wh.frequency.value = 1500; const wg = ctx.createGain(); wg.gain.value = 0.012; wh.connect(wg); wg.connect(out);
      src.start(); lfo.start(); wh.start(); this.rot = { out, lfo, wh };
    }
    const t = this.ctx.currentTime;
    this.rot.out.gain.setTargetAtTime(clamp(level, 0, 1) * 1.6, t, 0.25);
    this.rot.lfo.frequency.setTargetAtTime(4 + 18 * rpm, t, 0.4); this.rot.wh.frequency.setTargetAtTime(400 + 1300 * rpm, t, 0.6);
  },
  setOceanIntensity(k) { if (this.nodes.ocean && this.ctx) this.nodes.ocean.gain.setTargetAtTime(this.vol.ocean * (0.35 + 0.35 * clamp(k, 0, 1)), this.ctx.currentTime, 0.5); },
};
Bus.on('ui:click', () => Audio.click());

/* ---------------- Music ---------------- */
// Streaming music is YouTube only, played ONLY through YouTube's official iframe embed player (the same <iframe>
// its Share → Embed button gives you). We never fetch, download or remote-control the audio: the user plays,
// pauses and seeks with the embed's own buttons. Accepts a normal share URL or a pasted <iframe …> embed code;
// from embed code we only read the src attribute and rebuild a clean iframe (no raw HTML is inserted).
const YT_ALLOW = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share';
export function parseMusicURL(raw) {
  raw = String(raw || '').trim();
  const src = raw.match(/<iframe[^>]*\ssrc\s*=\s*["']([^"']+)["']/i); if (src) raw = src[1].replace(/&amp;/g, '&');
  else if (/^<|<script/i.test(raw)) return { ok: false, err: 'โค้ดฝังต้องเป็น <iframe> ของ YouTube' };
  let u; try { u = new URL(raw); } catch { return { ok: false, err: 'ลิงก์ไม่ถูกต้อง — วางลิงก์แชร์ หรือโค้ด Embed (<iframe>)' }; }
  if (u.protocol !== 'https:') return { ok: false, err: 'รองรับเฉพาะลิงก์ https' };
  const host = u.hostname.replace(/^(www|m|music)\./, '');
  if (host === 'youtube.com' || host === 'youtu.be' || host === 'youtube-nocookie.com') {
    let id = null, list = u.searchParams.get('list');
    if (host === 'youtu.be') id = u.pathname.slice(1).split('/')[0];
    else if (u.pathname === '/watch') id = u.searchParams.get('v');
    else { const m = u.pathname.match(/^\/(shorts|embed|live|v)\/([\w-]{6,})/); if (m && m[2] !== 'videoseries') id = m[2]; }
    if (id && !/^[\w-]{11}$/.test(id)) return { ok: false, err: 'รหัสวิดีโอ YouTube ไม่ถูกต้อง' };
    if (list && !/^[\w-]{10,64}$/.test(list)) list = null;
    if (!id && !list) return { ok: false, err: 'ไม่พบรหัสวิดีโอหรือเพลย์ลิสต์ในลิงก์ YouTube' };
    const start = parseInt(u.searchParams.get('t') || u.searchParams.get('start') || '', 10);
    const q = new URLSearchParams(); if (list) q.set('list', list); if (start > 0) q.set('start', start);
    const embed = 'https://www.youtube.com/embed/' + (id || 'videoseries') + (q.toString() ? '?' + q : '');
    return { ok: true, kind: 'youtube', id: id || list, embed, url: id ? `https://www.youtube.com/watch?v=${id}${list ? '&list=' + list : ''}` : `https://www.youtube.com/playlist?list=${list}`, title: (id ? 'YouTube · ' + id : 'YouTube · เพลย์ลิสต์'), tall: false };
  }
  if (/spotify\.com$/.test(host)) return { ok: false, err: 'ไม่รองรับ Spotify — ใช้ได้เฉพาะลิงก์ YouTube เท่านั้น' };
  return { ok: false, err: 'รองรับเฉพาะลิงก์หรือโค้ด Embed ของ YouTube เท่านั้น' };
}

export const Music = {
  playlist: [], index: -1, frame: null, audioEl: null, dock: null, playing: false, compact: false,
  // the player lives in a dock attached to <body>, so it keeps playing when the music window is closed.
  // (an iframe that is moved in the DOM or set to display:none reloads/stops, so we only resize it.)
  ensureDock() {
    if (this.dock) return this.dock;
    const d = this.dock = document.createElement('div'); d.className = 'music-dock empty';
    d.innerHTML = '<div class="md-bar"><span class="md-title"></span><a class="md-open" target="_blank" rel="noopener noreferrer">เปิดลิงก์ต้นฉบับ ↗</a><button class="md-size" type="button" title="ย่อ/ขยาย">▁</button><button class="md-close" type="button" title="ปิดเครื่องเล่น">✕</button></div><div class="md-body"></div><div class="md-note"></div>';
    d.querySelector('.md-size').onclick = () => { this.compact = !this.compact; d.classList.toggle('compact', this.compact); };
    d.querySelector('.md-close').onclick = () => this.unload();
    document.body.append(d); return d;
  },
  mount() { this.ensureDock(); },
  load(i) {
    const item = this.playlist[i]; if (!item) return; this.index = i;
    const d = this.ensureDock(), body = d.querySelector('.md-body');
    this.stopLocal(); body.innerHTML = ''; this.frame = null; d.classList.remove('empty');
    d.querySelector('.md-title').textContent = item.title;
    const open = d.querySelector('.md-open'); open.style.display = item.url ? '' : 'none'; if (item.url) open.href = item.url;
    d.querySelector('.md-note').textContent = '';
    if (item.kind === 'local') {
      const a = this.audioEl = new window.Audio(item.blobUrl); a.onended = () => this.next(); this.applyVolume();
      const p = document.createElement('div'); p.className = 'md-local'; p.textContent = '♪ ไฟล์ในเครื่อง: ' + item.title; body.append(p);
      d.classList.remove('yt'); Bus.emit('music:state'); return;
    }
    // official embed iframe — attributes exactly as YouTube's own embed code
    const f = this.frame = document.createElement('iframe');
    f.src = item.embed; f.title = item.title; f.className = 'music-frame ' + item.kind; f.setAttribute('frameborder', '0');
    f.allow = YT_ALLOW; f.allowFullscreen = true;
    f.referrerPolicy = 'strict-origin-when-cross-origin'; f.loading = 'eager';
    d.classList.add('yt');
    body.append(f);
    // some hosts (e.g. the claude.ai preview frame) refuse iframes from other sites: tell the user and offer the link
    if (/claude|anthropic/i.test(location.hostname) || window.__embedBlocked) d.querySelector('.md-note').textContent = 'หน้านี้ถูกเปิดในกรอบที่บล็อกเครื่องเล่นฝังจากเว็บอื่น ถ้าเครื่องเล่นว่าง ให้กด "เปิดลิงก์ต้นฉบับ" หรือเล่นเกมจากเว็บที่โฮสต์เอง';
    this.playing = false; Bus.emit('music:state');
  },
  unload() { this.stopLocal(); if (this.dock) { this.dock.querySelector('.md-body').innerHTML = ''; this.dock.classList.add('empty'); } this.frame = null; this.index = -1; this.playing = false; Bus.emit('music:state'); },
  embedActive() { return this.playlist[this.index]?.kind === 'youtube'; },
  // play/pause only drive local files; embeds are controlled with their own buttons
  play() {
    const item = this.playlist[this.index]; if (!item) return;
    if (item.kind === 'local') this.audioEl?.play().then(() => { this.playing = true; Bus.emit('music:state'); }).catch(() => Bus.emit('toast', 'เบราว์เซอร์ต้องการให้กดเล่นอีกครั้ง'));
    else Bus.emit('toast', 'กดปุ่ม ▶ ในเครื่องเล่น YouTube ที่ฝังไว้');
  },
  pause() { const item = this.playlist[this.index]; if (item?.kind === 'local') { this.audioEl?.pause(); this.playing = false; Bus.emit('music:state'); } },
  next() { if (!this.playlist.length) return; this.load((this.index + 1) % this.playlist.length); if (this.playlist[this.index].kind === 'local') this.play(); },
  stopLocal() { if (this.audioEl) { this.audioEl.pause(); this.audioEl = null; } },
  applyVolume() { const v = Audio.muted ? 0 : Audio.vol.master * Audio.vol.music; if (this.audioEl) this.audioEl.volume = clamp(v, 0, 1); },
};
