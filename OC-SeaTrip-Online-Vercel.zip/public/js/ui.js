// Screens (loading, account gateway, menu, slots, saves) + in-game HUD and windows.
import { el, $, Bus, clamp, fmtTime, fmtDate, fmtDuration, sleep, makeCanvas, uid } from './util.js';
import { icon } from './icons.js';
import { btn, iconBtn, toast, modal, confirmBox, openWindow, getWindow, closeAllWindows, field, slider, select, toggle, tabs } from './uikit.js';
import * as Store from './store.js';
import { G, enterMenu, startGame, saveGame, quitToMenu, logout, setPlayer, tenderCmd, liferaftCmd, lifeboatCmd, repaint, toggleRoomLights, zoomBy, floorNav, capturePhoto, placeDecor, decorPreview, defaultVerb, saveUIPrefs, serialize, switchYacht, startHeliMission, startManualFlight, endManualFlight, setMenuYacht, roomScale } from './main.js';
import { heliSprite, LIVERIES, PPM } from './heli.js';
import { filePicker, checkImageFile, decodeImage } from './imageio.js';
import { BASE_OC } from './baseoc.js';
import { PERSONAS, relLabel, lineFor } from './persona.js';
import { Coop, coopSpeakers } from './coop.js';
import { MAX_PLAYERS, PIN_LENGTH, cleanPin, invitedPin, inviteLink, validPin } from './net.js';
import { Weather, WEATHER } from './weather.js';
import { Helm, DETENTS, detentOf } from './helm.js';
import { drawHelm, GEO, leverValue, PW, PH } from './helmpix.js';
import { Perf } from './main.js';
import { openEditor } from './editor.js';
import { PARTS, OBJECTS, ROOMS, FIXTURES, LEVELS, PADS, SPEC, YACHTS, roomById, drawProfileThumb, defaultPaint, roomAt } from './yacht.js';
import { SPRITE_PRESETS, PREFS, buildSprites } from './chars.js';
import { PRESETS, TIME_MODES, periodName, lightCondition } from './timesys.js';
import { PORTS, portById, COUNTRY_TH, Geo, MapView, distNm } from './navmap.js';
import { Audio, Music, parseMusicURL } from './audio.js';
import { DECOR_TYPES } from './scene.js';
import { authBackend, storageMode } from './store.js';

const screens = () => $('#screens');
const TIPS = [
  'คลิกพื้นเพื่อเดิน คลิกเฟอร์นิเจอร์เพื่อเดินไปใช้งาน กดค้างเพื่อเปิดเมนูเพิ่มเติม',
  'เปิดแผนที่จากห้องควบคุมเรือ แล้วเลือกจุดหมายเพื่อเปิด Autopilot',
  'ปิดไฟห้องตอนกลางคืน ห้องจะมืดลงแต่ยังเห็นเงาจากแสงภายนอก',
  'โหมดจัดฉากช่วยให้ลากตัวละครและของตกแต่งไปวางบนพื้นได้',
  'OC ที่เป็นบอทจะเลือกกิจกรรมเองตามพลังงาน ความหิว และความชอบ',
  'นำเข้าภาพ PNG/WebP พื้นหลังโปร่งใสเพื่อสร้าง OC ของคุณเอง',
  'กด C เพื่อเปิดผนังทุกห้อง (Cutaway) และกด Tab เพื่อสลับตัวละคร',
];

/* ---------------- SVG logo yacht (hand-drawn vector, same profile as the game sprite) ---------------- */
export function yachtSVG(cls = '') {
  return `<svg class="yacht-svg ${cls}" viewBox="0 0 700 280" aria-hidden="true">
  <path d="M244 104h226l12 4-18 5H244z" fill="#fbfaf7"/>
  <rect x="330" y="34" width="14" height="70" fill="#f3f1ec"/><rect x="312" y="52" width="52" height="3" fill="#f3f1ec"/><rect x="300" y="88" width="70" height="4" fill="#f3f1ec"/>
  <circle cx="337" cy="28" r="7" fill="#fff"/><circle cx="362" cy="64" r="6" fill="#fff"/>
  <path d="M286 112h166l-12 40H286z" fill="#353b42"/><path d="M250 112h36v40h-36z" fill="#f3f1ec"/>
  <path d="M300 118h14l-1 22h-12zM318 118h14l-1 22h-12zM336 118h14l-1 22h-12zM354 118h14l-1 22h-12zM372 118h14l-1 22h-12zM390 118h14l-1 22h-12zM408 118h14l-1 22h-12z" fill="#3e5260"/>
  <rect x="34" y="152" width="266" height="8" fill="#f3f1ec"/><rect x="150" y="160" width="100" height="36" fill="#353b42"/><rect x="250" y="160" width="36" height="36" fill="#f3f1ec"/>
  <path d="M30 196h232l38-46h350l22-4v10l-8 2 2 88-26 6H60l-20-6-10-10z" fill="#c48a5c"/>
  <rect x="304" y="162" width="254" height="22" fill="#353b42"/><rect x="120" y="204" width="180" height="20" fill="#353b42"/>
  <rect x="560" y="157" width="104" height="19" fill="#c9e7f2" opacity=".0"/>
  <path d="M30 238h642v2H30z" fill="#f6f4ef"/><path d="M30 240h636l-26 12H60l-20-6z" fill="#2f3439"/>
  <path d="M36 186h114M40 143h210M250 95h178" stroke="#e9ecef" stroke-width="2"/>
  </svg>`;
}

/* ---------------- busy overlay ---------------- */
let busyEl = null;
export function busy(msg) {
  if (!msg) { busyEl?.remove(); busyEl = null; return; }
  if (!busyEl) { busyEl = el('div', { class: 'busy' }, el('div', { class: 'spinner' }), el('span')); document.body.append(busyEl); }
  busyEl.querySelector('span').textContent = msg;
}

/* ---------------- loading ---------------- */
export async function loadingScreen(tasks) {
  const s = screens(); s.innerHTML = '';
  const list = el('ul', { class: 'res-list' });
  const bar = el('div', { class: 'bar-fill' }); const pct = el('b', {}, '0%');
  const tip = el('p', { class: 'tip' }, TIPS[0]);
  const err = el('div', { class: 'load-err', hidden: true });
  const scr = el('div', { class: 'screen loading' },
    el('div', { class: 'load-card' },
      el('div', { class: 'logo', html: `ทริปท่องทะเล <span>ของเหล่าOC</span>`, 'aria-label': 'ทริปท่องทะเล ของเหล่าOC' }),
      el('div', { class: 'load-yacht', html: yachtSVG('bob') + '<div class="load-sea"></div>' }),
      el('div', { class: 'bar' }, bar), el('div', { class: 'row between' }, el('span', { class: 'muted' }, 'กำลังโหลดทรัพยากร'), pct),
      list, err, tip));
  s.append(scr);
  let ti = 0; const tipT = setInterval(() => { tip.textContent = TIPS[++ti % TIPS.length]; }, 3500);
  const items = tasks.map(t => { const li = el('li', { html: icon('clock', 14) + `<span>${t.th}</span>` }); list.append(li); return li; });
  let i = 0;
  return new Promise(resolve => {
    const run = async () => {
      err.hidden = true;
      for (; i < tasks.length; i++) {
        items[i].className = 'doing'; items[i].innerHTML = icon('retry', 14, 'spin') + `<span>${tasks[i].th}</span>`;
        try { await Promise.race([tasks[i].run(), sleep(20000).then(() => { throw new Error('หมดเวลา'); })]); }
        catch (e) {
          console.error(e); items[i].className = 'fail'; items[i].innerHTML = icon('close', 14) + `<span>${tasks[i].th}</span>`;
          err.hidden = false; err.innerHTML = ''; err.append(el('p', {}, 'โหลดไม่สำเร็จ: ' + (e.message || e)), btn('ลองใหม่', { icon: 'retry', cls: 'primary', onclick: run }));
          return;
        }
        items[i].className = 'done'; items[i].innerHTML = icon('check', 14) + `<span>${tasks[i].th}</span>`;
        const p = Math.round((i + 1) / tasks.length * 100); bar.style.width = p + '%'; pct.textContent = p + '%';
        await sleep(60);
      }
      clearInterval(tipT); scr.classList.add('fade-out'); await sleep(450); resolve(true);
    };
    run();
  });
}

/* ---------------- account gateway ---------------- */
// start screen: no login / sign-up — just pick the name other players will see, then play
export function gateway() {
  closeAllWindows(); $('#hud').innerHTML = '';
  const s = screens(); s.innerHTML = '';
  const name = el('input', { type: 'text', maxLength: 20, placeholder: 'เช่น กัปตันมะปราง', autocomplete: 'nickname', 'aria-label': 'ชื่อของคุณ', required: true });
  const msg = el('div', { class: 'form-msg', role: 'alert' });
  Store.kvGet('lastName').then(n => { if (n && !name.value) name.value = n; else if (G.session?.username && G.session.username !== 'Guest') name.value = G.session.username; name.focus(); name.select(); });
  const go = btn('เริ่มเล่น', { icon: 'play', cls: 'primary wide' }); go.type = 'submit';
  const f = el('form', { class: 'form' }, field('ตั้งชื่อของคุณ', name), go,
    el('p', { class: 'muted' }, 'เล่นได้ทันที ไม่ต้องสมัครสมาชิก ตัวละคร เซฟ และการตั้งค่าบันทึกไว้ในเบราว์เซอร์นี้ · เปลี่ยนชื่อได้ทุกเมื่อจากเมนูหลัก'));
  f.addEventListener('submit', async e => {
    e.preventDefault(); msg.textContent = '';
    if (!name.value.trim()) { msg.textContent = 'ตั้งชื่อก่อนเริ่มเล่น'; msg.className = 'form-msg bad'; name.focus(); return; }
    try { G.session = await Store.Auth.player(name.value); toast('ยินดีต้อนรับ ' + G.session.username, 'ok'); await enterMenu(); } catch (er) { msg.textContent = er.message; msg.className = 'form-msg bad'; }
  });
  const card = el('div', { class: 'gate-card' }, el('div', { class: 'logo sm', html: `ทริปท่องทะเล <span>ของเหล่าOC</span>`, 'aria-label': 'ทริปท่องทะเล ของเหล่าOC' }), f, msg);
  if (storageMode() === 'memory') card.append(el('p', { class: 'form-msg bad' }, 'เบราว์เซอร์ไม่อนุญาต IndexedDB — ข้อมูลจะหายเมื่อปิดหน้า'));
  s.append(el('div', { class: 'screen gate' }, card));
}

/* ---------------- main menu ---------------- */
export function mainMenu() {
  closeAllWindows(); $('#hud').innerHTML = ''; G.photo = false; document.body.classList.remove('photo');
  const s = screens(); s.innerHTML = '';
  const sess = G.session;
  const acct = el('div', { class: 'acct', html: icon('user', 16) + `<span></span>` }); acct.querySelector('span').textContent = sess.username; acct.title = 'เปลี่ยนชื่อ'; acct.style.cursor = 'pointer'; acct.onclick = () => gateway();
  const items = [
    ['เล่นเกม', 'play', async () => { const ocs = await Store.listOCs(sess.id); if (!ocs.length) { toast('ยังไม่มีตัวละคร — สร้าง OC ตัวแรกก่อนออกเรือ'); return slotsScreen('crew'); } const auto = await Store.readSave(sess.id, 'auto'); if (auto && auto.fleet && Object.values(auto.fleet).some(f => f.roster?.some(s => ocs.some(o => o.slot === s)))) startGame('auto'); else slotsScreen('crew'); }],
    ['เลือกเซฟ', 'load', savesScreen], ['สร้างตัวละคร OC', 'character', () => slotsScreen('manage')], ['จัดการเรือ', 'yacht', () => yachtWindow()],
    ['ตั้งค่า', 'settings', settingsWindow], ['เครดิต', 'star', creditsWindow], ['เปลี่ยนชื่อ', 'user', () => gateway()],
  ];
  const nav = el('nav', { class: 'menu-list' });
  items.forEach(([t, ic, fn], i) => nav.append(btn(t, { icon: ic, cls: 'menu-btn' + (i === 0 ? ' primary' : ''), onclick: fn })));
  s.append(el('div', { class: 'screen menu' },
    el('div', { class: 'menu-card' }, el('div', { class: 'logo', html: `ทริปท่องทะเล <span>ของเหล่าOC</span>`, 'aria-label': 'ทริปท่องทะเล ของเหล่าOC' }), el('p', { class: 'sub' }, 'ใช้ชีวิตบนเรือยอร์ช SouthCozy SeaLife'), nav, acct),
    el('div', { class: 'menu-corner' }, iconBtn('fullscreen', 'เต็มหน้าจอ', toggleFullscreen))));
}

/* ---------------- character slots ---------------- */
export async function slotsScreen(mode = 'manage') {
  closeAllWindows();
  const s = screens(); s.innerHTML = '';
  const acc = G.session.id; let ocs = await Store.listOCs(acc);
  const board = new Set(ocs.slice(0, 3).map(o => o.slot)); let main = ocs[0]?.slot ?? null;
  const listEl = el('div', { class: 'slot-list' });
  const yachtSel = select(Object.values(YACHTS).map(y => [y.id, 'ขึ้นเรือ ' + y.name + ' (' + y.th + ')']), SPEC.id, () => { });
  const startB = btn('ออกเรือกับลูกเรือที่เลือก', { icon: 'anchor', cls: 'primary', onclick: async () => { if (!board.size) return toast('เลือก OC อย่างน้อย 1 ตัว', 'error'); if (!board.has(main)) main = [...board][0]; startGame('auto', true, [...board], main, yachtSel.value); } });
  const hero = el('div', { class: 'empty-hero' });
  const quickBase = async (slot = 0) => { await Store.saveOC(acc, { slot, name: 'OC ใหม่', preset: 'custom', customAR: BASE_OC.w / BASE_OC.h, image: BASE_OC.url, transform: { scale: 1, width: 0, height: 34, lockAspect: true, rotation: 0, flip: false, groundOffset: 0, autoGround: true, colW: 10, colH: 30, speed: 1, pivotX: 0.5, pivotY: 1, z: 0 }, pref: 'view', mode: 'bot', sheet: null }); board.add(slot); main = main ?? slot; toast('สร้าง OC จากตัวเบสแล้ว', 'ok'); render(); };
  const render = async () => {
    ocs = await Store.listOCs(acc); listEl.innerHTML = '';
    for (const s of [...board]) if (!ocs.some(o => o.slot === s)) board.delete(s); if (main != null && !ocs.some(o => o.slot === main)) main = ocs[0]?.slot ?? null;
    startB.disabled = !ocs.length; hero.innerHTML = '';
    if (!ocs.length) hero.append(el('img', { src: BASE_OC.url, class: 'pix base-img', alt: 'ตัวละครเบส' }), el('div', {}, el('h3', {}, 'ยังไม่มีตัวละคร'), el('p', {}, 'เริ่มจากตัวเบส "OC HERE" แล้ววาดทับ นำเข้าภาพของคุณเอง หรือใช้ตัวเบสออกเรือได้ทันที'),
      el('div', { class: 'row wrap' }, btn('สร้าง OC จากตัวเบส', { icon: 'edit', cls: 'primary', onclick: () => openEditor(null, 0, async o => { await Store.saveOC(acc, o); board.add(o.slot); main = main ?? o.slot; render(); }) }), btn('ใช้ตัวเบสทันที', { icon: 'character', onclick: () => quickBase(0) }))));
    // older saves may hold OCs in slots 5+: they stay playable/editable/deletable, but no new OC can be made past 4
    const lastSlot = Math.max(Store.MAX_OC_SLOTS, ...ocs.map(o => o.slot + 1));
    for (let i = 0; i < lastSlot; i++) {
      const oc = ocs.find(o => o.slot === i);
      if (!oc && (i >= Store.MAX_OC_SLOTS || ocs.length >= Store.MAX_OC_SLOTS)) continue;
      if (!oc) { listEl.append(el('div', { class: 'slot empty' }, el('div', { class: 'slot-num' }, String(i + 1).padStart(2, '0')), el('div', { class: 'slot-info muted' }, 'ช่องว่าง'), btn('สร้าง OC', { icon: 'add', cls: 'small', onclick: () => openEditor(null, i, async o => { await Store.saveOC(acc, o); render(); }) }))); continue; }
      const img = el('img', { src: oc.image, alt: oc.name, class: 'pix' });
      const cb = el('input', { type: 'checkbox', title: 'พาขึ้นเรือ', 'aria-label': 'พาขึ้นเรือ' }); cb.checked = board.has(i); cb.onchange = () => { cb.checked ? board.add(i) : board.delete(i); render(); };
      const rb = el('input', { type: 'radio', name: 'mainoc', title: 'ตัวละครหลัก', 'aria-label': 'ตัวละครหลัก' }); rb.checked = main === i; rb.onchange = () => { main = i; board.add(i); render(); };
      const status = board.has(i) ? (main === i ? 'ตัวหลัก (ผู้เล่นควบคุม)' : 'บนเรือ · ' + ({ bot: 'บอท', assisted: 'ช่วยควบคุม', player: 'บอท' }[oc.mode] || 'บอท')) : 'พักบนฝั่ง';
      listEl.append(el('div', { class: 'slot' + (board.has(i) ? ' on' : '') },
        el('div', { class: 'slot-num' }, String(i + 1).padStart(2, '0')), el('div', { class: 'slot-img' }, img),
        el('div', { class: 'slot-info' }, el('b', {}, oc.name), el('small', {}, (SPRITE_PRESETS[oc.preset]?.th || oc.preset) + (oc.sheet ? ' · Sprite Sheet' : '')), el('small', { class: 'muted' }, 'บันทึก ' + fmtDate(oc.updatedAt)), el('small', { class: 'status' }, status)),
        el('div', { class: 'slot-pick' }, el('label', { class: 'chk' }, cb, 'บนเรือ'), el('label', { class: 'chk' }, rb, 'ตัวหลัก')),
        el('div', { class: 'slot-act' },
          iconBtn('edit', 'แก้ไข', () => openEditor(oc, i, async o => { await Store.saveOC(acc, o); render(); })),
          iconBtn('copy', 'ทำสำเนา', async () => { const free = ocs.length >= Store.MAX_OC_SLOTS ? null : [...Array(Store.MAX_OC_SLOTS).keys()].find(k => !ocs.some(o => o.slot === k)); if (free == null) return toast(`สร้าง OC ได้ไม่เกิน ${Store.MAX_OC_SLOTS} ตัว`, 'error'); const c = structuredClone(oc); c.slot = free; c.name = oc.name + ' (สำเนา)'; await Store.saveOC(acc, c); toast('ทำสำเนาไปช่อง ' + (free + 1), 'ok'); render(); }),
          iconBtn('delete', 'ลบ', async () => { if (await confirmBox('ลบตัวละคร', `ลบ "${oc.name}" ถาวร? ไม่สามารถกู้คืนได้`, 'ลบ', true)) { await Store.deleteOC(acc, i); board.delete(i); render(); toast('ลบแล้ว'); } }))));
    }
  };
  await render();
  s.append(el('div', { class: 'screen slots' }, el('div', { class: 'panel-card wide' },
    el('div', { class: 'card-head' }, iconBtn('back', 'กลับ', mainMenu), el('h2', { html: icon('character', 22) + (mode === 'crew' ? ' เลือกลูกเรือ OC' : ' ช่องตัวละคร OC') }), el('div', { class: 'grow' }), yachtSel, startB),
    el('p', { class: 'muted' }, `สร้าง OC ได้ไม่เกิน ${Store.MAX_OC_SLOTS} ตัวต่อผู้เล่น — ติ๊ก "บนเรือ" เพื่อพาหลายตัวขึ้นเรือลำเดียวกัน ตัวหลักผู้เล่นควบคุม ตัวอื่นเป็นบอท`), hero, listEl)));
}

/* ---------------- saves ---------------- */
export async function savesScreen() {
  closeAllWindows();
  const s = screens(); s.innerHTML = '';
  const acc = G.session.id; const listEl = el('div', { class: 'save-list' });
  const render = async () => {
    listEl.innerHTML = '';
    for (const slot of ['auto', 'm1', 'm2', 'm3']) {
      const sv = await Store.readSave(acc, slot);
      const name = slot === 'auto' ? 'บันทึกอัตโนมัติ' : 'ช่องบันทึก ' + slot.slice(1);
      const row = el('div', { class: 'save-row' + (sv ? '' : ' empty') }, el('div', { class: 'save-ic', html: icon(slot === 'auto' ? 'clock' : 'save', 22) }),
        el('div', { class: 'save-info' }, el('b', {}, name), el('small', {}, sv ? `${fmtDate(sv.savedAt)} · ${sv.location || ''}` : 'ว่าง'), sv ? el('small', { class: 'muted' }, 'ลูกเรือ: ' + (sv.oc_names || []).join(', ') + ` · เวอร์ชันเซฟ v${sv.version}`) : ''));
      const act = el('div', { class: 'save-act' });
      if (sv) act.append(btn('โหลด', { icon: 'play', cls: 'small primary', onclick: () => startGame(slot) }), iconBtn('download', 'ส่งออกไฟล์เซฟ', () => exportSave(sv)), iconBtn('delete', 'ลบ', async () => { if (await confirmBox('ลบเซฟ', `ลบ "${name}"?`, 'ลบ', true)) { await Store.deleteSave(acc, slot); render(); } }));
      else act.append(btn('เริ่มใหม่ในช่องนี้', { icon: 'add', cls: 'small', onclick: () => { G.saveSlot = slot; slotsScreen('crew'); } }));
      row.append(act); listEl.append(row);
    }
  };
  await render();
  const impPick = filePicker('นำเข้าไฟล์เซฟ', { icon: 'upload', cls: 'small', accept: 'application/json,.json' }, f => importSave(f, render));
  s.append(el('div', { class: 'screen slots' }, el('div', { class: 'panel-card' },
    el('div', { class: 'card-head' }, iconBtn('back', 'กลับ', mainMenu), el('h2', { html: icon('load', 22) + ' เลือกเซฟ' }), el('div', { class: 'grow' }), impPick),
    listEl, el('p', { class: 'muted' }, 'เซฟถูกเก็บในเครื่อง (IndexedDB) พร้อมหมายเลขเวอร์ชันเพื่อรองรับการอัปเดตเกม'))));
}
async function exportSave(sv) {
  const ocs = (await Store.listOCs(G.session.id)).filter(o => (sv.onboard || []).includes(o.slot)).map(({ key, accountId, ...o }) => o);
  const data = JSON.stringify({ format: 'oc-openseas-save', version: Store.SAVE_VERSION, exportedAt: Date.now(), save: { ...sv, key: undefined, accountId: undefined }, ocs });
  const blob = new Blob([data], { type: 'application/json' }); const url = URL.createObjectURL(blob);
  const ta = el('textarea', { readonly: true, rows: 6, class: 'mono' }); ta.value = data.length > 200000 ? data.slice(0, 200000) + '\n…(ตัดการแสดงผล ใช้ปุ่มดาวน์โหลด/คัดลอก)' : data;
  modal({ title: 'ส่งออกไฟล์เซฟ', body: el('div', {}, el('p', {}, `ขนาด ${(data.length / 1024).toFixed(0)} KB (รวมภาพ OC บนเรือ)`), el('a', { class: 'btn primary', href: url, download: 'oc-openseas-save.json' }, 'ดาวน์โหลด .json'), ta, el('p', { class: 'muted' }, 'หากการดาวน์โหลดถูกบล็อก ให้กดคัดลอกแล้ววางลงไฟล์ .json')),
    actions: [{ label: 'คัดลอกข้อความ', icon: 'copy', cls: 'ghost', onclick: () => { navigator.clipboard?.writeText(data).then(() => toast('คัดลอกแล้ว', 'ok')).catch(() => toast('คัดลอกไม่ได้', 'error')); return false; } }, { label: 'ปิด' }], onClose: () => URL.revokeObjectURL(url) });
}
async function importSave(file, after) {
  try {
    if (file.size > 60 * 1024 * 1024) throw new Error('ไฟล์ใหญ่เกินไป');
    const j = JSON.parse(await file.text()); if (j.format !== 'oc-openseas-save' || !j.save) throw new Error('ไม่ใช่ไฟล์เซฟของเกมนี้');
    const slot = await new Promise(res => modal({ title: 'นำเข้าไปที่ช่องใด', body: el('p', {}, 'ข้อมูลเดิมในช่องที่เลือกจะถูกแทนที่'), onClose: () => res(null), actions: ['m1', 'm2', 'm3'].map(s => ({ label: 'ช่อง ' + s.slice(1), onclick: () => res(s) })) }));
    if (!slot) return;
    const acc = G.session.id; const existing = await Store.listOCs(acc); const map = {};
    for (const oc of j.ocs || []) { let free = [...Array(Store.MAX_OC_SLOTS).keys()].find(k => !existing.some(o => o.slot === k)); if (free == null) { toast('ช่อง OC เต็ม ข้ามบางตัว', 'error'); continue; } map[oc.slot] = free; oc.slot = free; await Store.saveOC(acc, oc); existing.push(oc); }
    const sv = Store.migrateSave(j.save); sv.onboard = (sv.onboard || []).map(s => map[s] ?? s); if (sv.main != null) sv.main = map[sv.main] ?? sv.main;
    sv.chars = Object.fromEntries(Object.entries(sv.chars || {}).map(([k, v]) => [map[k] ?? k, v]));
    await Store.writeSave(acc, slot, sv); toast('นำเข้าเซฟสำเร็จ', 'ok'); after?.();
  } catch (e) { toast('นำเข้าไม่สำเร็จ: ' + e.message, 'error'); }
}

/* ---------------- HUD ---------------- */
let hudRefs = {}; let coopBadgeT = 0;
export function hud() {
  screens().innerHTML = ''; const h = $('#hud'); h.innerHTML = '';
  const tl = el('div', { class: 'hud-tl' }, el('div', { class: 'hud-name', html: icon('yacht', 18) + '<b></b>' }), el('div', { class: 'hud-time' }), el('div', { class: 'hud-cond', title: 'สภาพอากาศ', onclick: () => weatherWindow() }), el('div', { class: 'hud-loc' }), hudRefs.coop = el('div', { class: 'hud-coop', hidden: true, onclick: () => coopWindow() }));
  const more = iconBtn('more', 'เมนูเพิ่มเติม', () => tr.classList.toggle('open')); more.classList.add('hud-more');
  const tr = el('div', { class: 'hud-tr' }, more, iconBtn('map', 'แผนที่ (M)', mapWindow), iconBtn('save', 'บันทึกเกม', () => saveGame(G.saveSlot === 'auto' ? 'auto' : G.saveSlot)), iconBtn('settings', 'ตั้งค่า', settingsWindow), iconBtn('fullscreen', 'เต็มหน้าจอ (F)', toggleFullscreen), iconBtn('home', 'กลับเมนูหลัก', async () => { if (await confirmBox('กลับเมนูหลัก', 'บันทึกอัตโนมัติแล้วกลับเมนูหลัก?', 'กลับเมนู')) quitToMenu(); }));
  const side = el('div', { class: 'hud-side' },
    iconBtn('floorup', 'ขึ้นชั้น (W)', () => floorNav(1)), iconBtn('floordown', 'ลงชั้น (S)', () => floorNav(-1)),
    iconBtn('zoomin', 'ซูมเข้า', () => zoomBy(1)), iconBtn('zoomout', 'ซูมออก', () => zoomBy(-1)),
    hudRefs.cut = iconBtn('cutaway', 'มุมมองอัตโนมัติ (C): อยู่ในเรือเห็นทุกห้อง · อยู่ข้างนอกเห็นภายนอกเรือ', () => { G.autoView = !G.autoView; G.settings.autoView = G.autoView; refreshHudToggles(); toast(G.autoView ? 'มุมมองอัตโนมัติ: เปิด — ในเรือเห็นทุกห้อง / นอกเรือเห็นภายนอก' : 'มุมมองอัตโนมัติ: ปิด — เปิดเฉพาะห้องที่อยู่'); }),
    hudRefs.stage = iconBtn('hand', 'โหมดจัดฉาก (ลากตัวละคร/ของตกแต่ง)', () => { G.staging = !G.staging; refreshHudToggles(); toast(G.staging ? 'โหมดจัดฉาก: ลากตัวละครหรือของตกแต่งเพื่อย้าย' : 'ปิดโหมดจัดฉาก'); }),
    iconBtn('target', 'กลับมุมมองห้องที่ตัวละครอยู่', () => { G.cam.follow = true; G.cam.scale = roomScale(); G.settings.zoom = G.cam.scale; G.heliCam = false; }));
  const bar = el('nav', { class: 'hud-bar' },
    btn('Co-op', { icon: 'user', onclick: () => coopWindow() }), btn('เรือเล็ก', { icon: 'tender', onclick: () => tenderWindow() }), btn('OC', { icon: 'character', onclick: ocWindow }), btn('พูด', { icon: 'chat', onclick: () => sayBar() }), btn('โต้ตอบ', { icon: 'hand', onclick: interactWindow }), btn('ของตกแต่ง', { icon: 'inventory', onclick: inventoryWindow }),
    btn('เรือ', { icon: 'yacht', onclick: () => yachtWindow() }), btn('ฮ.', { icon: 'heli', onclick: heliWindow }), btn('เพลง', { icon: 'music', onclick: musicWindow }), btn('ถ่ายภาพ', { icon: 'camera', onclick: () => photoMode(true) }));
  const collapse = iconBtn(G.settings.uiCollapsed ? 'show' : 'hide', 'ย่อ/ขยาย UI', () => { G.settings.uiCollapsed = !G.settings.uiCollapsed; h.classList.toggle('collapsed', G.settings.uiCollapsed); collapse.innerHTML = icon(G.settings.uiCollapsed ? 'show' : 'hide', 20); });
  const nav = el('div', { class: 'hud-nav' });
  const sleepBox = el('div', { class: 'hud-sleep', hidden: true });
  h.append(tl, tr, side, el('div', { class: 'hud-bottom' }, collapse, bar), nav, sleepBox);
  tr.addEventListener('click', e => { if (e.target.closest('button') && !e.target.closest('.hud-more')) tr.classList.remove('open'); });
  tl.addEventListener('click', e => { if (!e.target.closest('.hud-cond')) tl.classList.toggle('open'); });
  watchHudLayout(h);
  h.classList.toggle('collapsed', !!G.settings.uiCollapsed);
  tl.querySelector('.hud-name b').textContent = SPEC.name;
  hudRefs = { ...hudRefs, time: tl.querySelector('.hud-time'), cond: tl.querySelector('.hud-cond'), loc: tl.querySelector('.hud-loc'), nav, sleepBox };
  refreshHudToggles();
}
// keep CSS informed of how much room the HUD takes, so side buttons and windows fit between top and bottom bars
let hudRO = null;
function watchHudLayout(h) {
  const root = document.documentElement;
  const measure = () => {
    if (!h.isConnected) return;
    const b = h.querySelector('.hud-bottom'), tl = h.querySelector('.hud-tl'), tr = h.querySelector('.hud-tr');
    const vh = innerHeight, vis = e => e && e.offsetParent !== null;
    const barH = vis(b) ? Math.max(0, vh - b.getBoundingClientRect().top) : 0;
    const trH = vis(tr) ? tr.querySelector('.btn:not(.hud-more)') ? Math.max(...[...tr.children].filter(vis).slice(0, 1).map(e => e.getBoundingClientRect().bottom)) : 0 : 0;
    const tlH = vis(tl) ? tl.getBoundingClientRect().bottom : 0;
    root.style.setProperty('--bar-h', Math.round(barH) + 'px'); root.style.setProperty('--tr-h', Math.round(trH) + 'px'); root.style.setProperty('--tl-h', Math.round(tlH) + 'px');
  };
  hudRO?.disconnect(); hudRO = new ResizeObserver(measure);
  for (const e of h.querySelectorAll('.hud-bottom, .hud-tl, .hud-tr')) hudRO.observe(e);
  measure(); setTimeout(measure, 300);
}
addEventListener('resize', () => { const h = document.getElementById('hud'); if (h && hudRO) { const b = h.querySelector('.hud-bottom'); if (b) hudRO.observe(b); } });
function refreshHudToggles() { hudRefs.cut?.classList.toggle('on', G.autoView); hudRefs.stage?.classList.toggle('on', G.staging); }
Bus.on('hud', refreshHudToggles);
let tickT = 0;
// crisp DOM speech bubbles (pixel Thai font) positioned over the characters every frame
let speechLayer = null; const speechEls = new Map();
function updateSpeech() {
  if (!speechLayer || !speechLayer.isConnected) { speechLayer = el('div', { class: 'speech-layer' }); document.body.append(speechLayer); speechEls.clear(); }
  const live = new Set(); let shown = 0; const placed = [];
  if (G.screen === 'game' && G.chars && !G.photo) for (const ch of [...G.chars, ...coopSpeakers()]) {
    if (!ch.text || ch.inHeli || !ch.bounds || shown >= 8 || (G.coopSolo && G.chars.includes(ch) && ch !== G.player)) continue;
    const [x] = ch.pos(); const [cx, cy] = G.worldToCss(x, ch.bounds[1] - 3);
    if (cx < -100 || cy < -50 || cx > innerWidth + 100 || cy > innerHeight + 50) continue;
    shown++; live.add(ch.id); let e = speechEls.get(ch.id);
    if (!e) { e = el('div', { class: 'speech' }); speechLayer.append(e); speechEls.set(ch.id, e); }
    if (e.__tid !== ch.text.id) { e.__tid = ch.text.id; e.innerHTML = ''; e.append(el('b', {}, ch.name), document.createTextNode(ch.text.s)); e.classList.toggle('me', ch === G.player); }
    placed.push({ e, x: cx, y: cy - 6 });
  }
  // keep neighbouring bubbles from covering each other: lift later ones above earlier ones
  placed.sort((a, b) => b.y - a.y);
  for (let i = 0; i < placed.length; i++) { const a = placed[i]; a.w = a.e.offsetWidth || 120; a.h = a.e.offsetHeight || 44;
    for (let j = 0; j < i; j++) { const b = placed[j]; if (Math.abs(a.x - b.x) < (a.w + b.w) / 2 + 4 && a.y > b.y - b.h - 4 && a.y - a.h < b.y + 4) a.y = b.y - b.h - 6; }
    a.e.style.left = Math.round(a.x) + 'px'; a.e.style.top = Math.round(a.y) + 'px'; }
  for (const [id, e] of speechEls) if (!live.has(id)) { e.remove(); speechEls.delete(id); }
}
// type-to-speak: the controlled OC says your text; someone close by answers in character
export function sayBar(speaker = G.player) {
  if (!speaker || document.querySelector('.say-bar')) { document.querySelector('.say-bar input')?.focus(); return; }
  const inp = el('input', { type: 'text', maxlength: 80, placeholder: 'พิมพ์ให้ ' + speaker.name + ' พูด… (Enter ส่ง / Esc ปิด)' });
  const close = () => bar.remove();
  const send = () => { const t = inp.value.trim(); if (!t) return close(); speaker.speak(t, clamp(2 + t.length * 0.12, 3, 8)); inp.value = '';
    const near = G.chars.filter(c => c !== speaker && !c.inHeli && c.state !== 'sleep' && c.level === speaker.level && Math.abs(c.x - speaker.x) < 60).sort((a, b) => Math.abs(a.x - speaker.x) - Math.abs(b.x - speaker.x))[0];
    if (near) { near.facing = Math.sign(speaker.x - near.x) || 1; setTimeout(() => near.speak(lineFor(near, 'reply', speaker, G.rel)), 1600); } };
  const bar = el('div', { class: 'say-bar' }, inp, btn('พูด', { icon: 'chat', cls: 'primary small', onclick: send }), iconBtn('close', 'ปิด', close));
  inp.addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Enter') send(); if (e.key === 'Escape') close(); });
  document.body.append(bar); inp.focus();
}
// on-screen throttle while driving the tender (keyboard: ← →)
let drivePad = null;
function updateDrivePad() {
  const on = G.screen === 'game' && G.tender?.rider === G.player?.id && (G.tender.state === 'drive' || G.tender.state === 'homing');
  if (!on) { if (drivePad) { drivePad.remove(); drivePad = null; G.driveTouch = 0; } return; }
  if (!drivePad) {
    const hold = (dir, label, ic) => { const b = btn(label, { icon: ic, cls: 'drive-btn' }); const dn = e => { e.preventDefault(); G.driveTouch = dir; }, up = () => { if (G.driveTouch === dir) G.driveTouch = 0; };
      b.addEventListener('pointerdown', dn); b.addEventListener('pointerup', up); b.addEventListener('pointerleave', up); b.addEventListener('pointercancel', up); return b; };
    drivePad = el('div', { class: 'drive-pad' }, hold(-1, 'ซ้าย', 'back'), el('div', { class: 'drive-speed' }), hold(1, 'ขวา', 'play'), btn('จอดเทียบ', { icon: 'anchor', cls: 'small', onclick: () => tenderCmd('disembark') }));
    document.body.append(drivePad);
  }
  const kn = Math.round(Math.abs(G.tender.vx || 0) / 20 * 1.94); drivePad.querySelector('.drive-speed').textContent = kn + ' kn';
}
export function tick(dt) {
  try { updateSpeech(); } catch (e) { }
  try { updateDrivePad(); } catch (e) { }
  if (hudRefs.coop) { const on = Coop.active; hudRefs.coop.hidden = !on; if (on && (coopBadgeT -= dt) <= 0) { coopBadgeT = 0.5; const p = Coop.host ? null : Coop.rtt; hudRefs.coop.innerHTML = icon('user', 14) + ` <b>Co-op ${Coop.pin}</b> · ${Coop.count}/${MAX_PLAYERS} คน` + (Coop.host ? ' · โฮสต์' : p ? ` · ปิง ${p} ms` : ''); hudRefs.coop.classList.toggle('bad', !!p && p > 250); } }
  if (G.screen !== 'game' || !hudRefs.time) return;
  if ((tickT -= dt) > 0) return; tickT = 0.4;
  const h = G.clock.localHour();
  hudRefs.time.innerHTML = icon(G.env.sunElev > -4 ? 'sun' : 'moon', 16) + `<b>${fmtTime(h)}</b><small>${periodName(h)} · ${G.clock.tzLabel()}</small>`;
  { const wl = Weather.label(); hudRefs.cond.innerHTML = icon('lamp', 14) + `<small>แสง: ${lightCondition(G.env.sunElev)} (ดวงอาทิตย์ ${G.env.sunElev.toFixed(0)}°)</small>` + (wl ? `<br>${icon('rain', 14)}<small>อากาศ: ${wl}</small>` : ''); }
  const j = G.journey.s; const np = G.journey.nearestPort();
  hudRefs.loc.innerHTML = icon('compass', 14) + `<small>${j.status === 'docked' ? 'จอดที่ ' + portById[j.dockedAt]?.th : `${j.speed.toFixed(1)} kn · ${j.heading.toFixed(0)}° · ใกล้${np.port.th}`}</small>`;
  if (j.waypoints.length && j.status !== 'docked') {
    const rem = G.journey.remaining(); const pct = j.distTotal ? clamp(1 - rem / j.distTotal, 0, 1) : 0;
    hudRefs.nav.hidden = false; hudRefs.nav.innerHTML = `${icon(j.autopilot ? 'autopilot' : 'steering', 16)}<span>${j.autopilot ? 'Autopilot' : 'Manual'} → ${portById[j.dest]?.th || '-'} · ${rem.toFixed(1)} nm · ETA ${fmtDuration(G.journey.eta() / (j.timeMult || 1))}</span><div class="mini-bar"><i style="width:${(pct * 100).toFixed(1)}%"></i></div>`;
  } else if (j.status !== 'docked' && j.speed > 0.2) { hudRefs.nav.hidden = false; hudRefs.nav.innerHTML = `${icon('steering', 16)}<span>บังคับเรือเอง · ${j.speed.toFixed(1)} kn · ${j.heading.toFixed(0)}°</span>`; }
  else hudRefs.nav.hidden = true;
  for (const w of liveWindows) w();
}
const liveWindows = new Set();

/* ---------------- popups ---------------- */
function popup(e, title, items) {
  document.querySelector('.popup')?.remove();
  const p = el('div', { class: 'popup', role: 'menu' }, el('div', { class: 'popup-title' }, title));
  for (const [label, ic, fn] of items) p.append(btn(label, { icon: ic, cls: 'popup-item', onclick: () => { p.remove(); fn(); } }));
  document.body.append(p);
  const x = clamp(e.clientX, 8, innerWidth - p.offsetWidth - 8), y = clamp(e.clientY, 8, innerHeight - p.offsetHeight - 8);
  p.style.left = x + 'px'; p.style.top = y + 'px';
  setTimeout(() => addEventListener('pointerdown', function off(ev) { if (!p.contains(ev.target)) { p.remove(); removeEventListener('pointerdown', off, true); } }, true), 0);
}
export function charMenu(ch, e) {
  const p = G.player; const items = [];
  if (ch !== p) {
    items.push(['คุยกับ ' + ch.name, 'chat', () => G.party.goto(p, ch.level, ch.x + (ch.x > p.x ? -14 : 14), { talkTo: ch.id })]);
    items.push(['ควบคุมตัวนี้', 'character', () => setPlayer(ch)]);
  }
  items.push(['ให้ ' + ch.name + ' พูด…', 'chat', () => sayBar(ch)]);
  { const r = !ch.stair && roomAt(ch.level, ch.x); if (ch === G.player && !ch.swim && (ch.level === 'swim' || (r && r.id === ROOMS.find(k => k.kind === 'aftdeck')?.id))) items.push(['กระโดดลงน้ำ', 'liferaft', () => G.fallOverboard(ch)]); }
  if (ch.state === 'sleep') items.push(['ปลุก', 'sun', () => G.party.wake(ch)]);
  if (ch !== p) items.push([ch.mode === 'bot' ? 'หยุดบอท (ยืนรอ)' : 'เปิดโหมดบอท', 'bot', () => { ch.mode = ch.mode === 'bot' ? 'assisted' : 'bot'; ch.idleT = 0; toast(ch.name + ': ' + (ch.mode === 'bot' ? 'บอทอัตโนมัติ' : 'รอคำสั่ง')); }]);
  items.push(['ดูสถานะ', 'info', ocWindow]);
  const rt = p && ch !== p ? G.rel?.of(ch.slot_, p.slot_) : null;
  popup(e, ch.name + ' · ' + (PERSONAS[ch.oc?.persona]?.th || 'ปกติ') + (rt ? ' · ' + relLabel(rt) + 'ของ ' + p.name : ''), items);
}
export function objectMenu(o, e) {
  const p = G.player; const go = v => G.party.interact(p, o, v);
  const items = { bed: [['นอนหลับ', 'bed', () => go('sleep')], ['นั่งบนเตียง', 'hand', () => go('sit')]], sofa: [['นั่ง', 'hand', () => go('sit')], ['นอนเล่น', 'bed', () => go('lie')]], lounger: [['นั่ง', 'hand', () => go('sit')], ['นอนอาบแดด', 'sun', () => go('lie')]], dining: [['นั่งรับประทานอาหาร', 'hand', () => go('eat')]] }[o.kind] || [['ใช้งาน: ' + o.th, 'hand', () => go('use')]];
  if (o.kind === 'svcpanel') items.push(['เปิดแผง', 'settings', () => go('use')]);
  if (o.kind === 'logbook') items.push(['อ่าน', 'info', () => go('use')]);
  const room = roomById[o.room];
  const sw = OBJECTS.find(k => k.kind === 'switch' && k.room === room.id); if (sw) items.push(['สลับไฟห้อง ' + room.th, 'lamp', () => G.party.interact(p, sw)]);
  const occ = G.party.occupants(o).filter(Boolean); if (occ.length) items.push([`มีคนใช้ ${occ.length}/${o.slots || 1}`, 'info', () => { }]);
  popup(e, o.th, items);
}
export function floorMenu(lv, x, e) {
  const L = LEVELS[lv]; const room = ROOMS.find(r => r.level === lv && x >= r.x1 && x < r.x2);
  popup(e, (room?.th || L.name), [['เดินไปที่นี่', 'target', () => G.party.goto(G.player, lv, clamp(x, L.x1, L.x2))], ...(room?.type === 'in' ? [['สลับไฟห้องนี้', 'lamp', () => toggleRoomLights(room.id)]] : []), ['วางของตกแต่ง', 'inventory', inventoryWindow]]);
}
export function decorMenu(d) {
  popup({ clientX: innerWidth / 2, clientY: innerHeight / 2 }, DECOR_TYPES[d.type].th, [['เก็บกลับเข้าคลัง', 'inventory', () => { G.decor = G.decor.filter(k => k !== d); G.inventory[d.type] = (G.inventory[d.type] || 0) + 1; Bus.emit('inventory'); }]]);
}
export function sleepPrompt() {
  const b = hudRefs.sleepBox; if (!b) return;
  const can = G.clock.s.mode !== 'real' && G.clock.s.mode !== 'local';
  b.hidden = false; b.innerHTML = '';
  b.append(el('span', { html: icon('moon', 16) + ' ' + G.player.name + ' กำลังหลับ' }),
    can ? btn('ข้ามเวลาถึงเช้า 07:00', { icon: 'sun', cls: 'small primary', onclick: () => { const h = G.clock.localHour(); const skip = ((7 - h) + 24) % 24 || 24; G.clock.advance(skip); for (const c of G.chars) { c.needs.energy = Math.min(100, c.needs.energy + skip * 12); c.needs.sleepiness = Math.max(0, c.needs.sleepiness - skip * 12); c.needs.hunger = Math.min(100, c.needs.hunger + skip * 3); } G.party.wake(G.player); b.hidden = true; toast('อรุณสวัสดิ์'); } }) : el('small', { class: 'muted' }, '(โหมดเวลาจริงไม่สามารถข้ามเวลา)'),
    btn('ตื่น', { cls: 'small', onclick: () => { G.party.wake(G.player); b.hidden = true; } }));
  const t = setInterval(() => { if (G.player?.state !== 'sleep') { b.hidden = true; clearInterval(t); } }, 500);
}
export function resumePrompt(j) {
  setTimeout(() => modal({ title: 'ทำการเดินทางต่อ?', body: el('p', {}, `การเดินทางไปยัง ${portById[j.dest]?.th || 'จุดหมาย'} หยุดไว้ตอนออกจากเกม (เกมไม่จำลองการแล่นต่อขณะปิดเกม) ต้องการเดินทางต่อด้วย Autopilot หรือไม่?`),
    actions: [{ label: 'ยังไม่ต้อง', cls: 'ghost' }, { label: 'เดินทางต่อ', icon: 'autopilot', cls: 'primary', onclick: () => { if (G.journey.s.dest) { G.journey.plan(G.journey.s.dest); G.journey.start(j.targetSpeed || 12); } } }] }), 600);
}

/* ---------------- OC window ---------------- */
function ocWindow() {
  openWindow('oc', 'ตัวละครบนเรือ', (body, w) => {
    const list = el('div', { class: 'oc-list' }); body.append(toggle('Auto Walk (ตัวหลักเดินเองเมื่อว่าง)', G.settings.autoWalk, v => { G.settings.autoWalk = v; G.player.mode = v ? 'assisted' : 'player'; }), list);
    const bars = {};
    const build = () => {
      list.innerHTML = '';
      for (const ch of G.chars) {
        const img = el('img', { src: ch.oc.image, class: 'pix', alt: ch.name });
        const needs = el('div', { class: 'needs' }); bars[ch.id] = {};
        for (const [k, t] of [['energy', 'พลังงาน'], ['comfort', 'ความสบาย'], ['hunger', 'ความหิว'], ['social', 'อยากคุย'], ['curiosity', 'อยากรู้'], ['sleepiness', 'ง่วง']]) { const i = el('i'); bars[ch.id][k] = i; needs.append(el('div', { class: 'need' }, el('span', {}, t), el('div', { class: 'nb' }, i))); }
        const modeSel = select([['player', 'ผู้เล่นควบคุม'], ['assisted', 'ช่วยควบคุม'], ['bot', 'บอทอัตโนมัติ']], ch === G.player ? 'player' : ch.mode, v => { if (v === 'player') setPlayer(ch); else { if (ch === G.player) { toast('เลือกตัวอื่นเป็นตัวควบคุมก่อน'); modeSel.value = 'player'; return; } ch.mode = v; } build(); });
        const st = el('small', { class: 'st' }); bars[ch.id].st = st;
        list.append(el('div', { class: 'oc-row' + (ch === G.player ? ' on' : '') }, el('div', { class: 'slot-img sm' }, img), el('div', { class: 'grow' }, el('b', {}, ch.name), st, needs),
          el('div', { class: 'col' }, modeSel, btn('ไปหา', { icon: 'target', cls: 'small', onclick: () => { G.cam.follow = false; const [x, y] = ch.pos(); G.cam.tx = x; G.cam.ty = y - 20; } }), ch.state === 'sleep' ? btn('ปลุก', { icon: 'sun', cls: 'small', onclick: () => { G.party.wake(ch); build(); } }) : '')));
      }
      const nameOf = s => G.ocs.find(o => o.slot === s)?.name || '?';
      const links = []; for (const o of G.ocs || []) for (const l of o.links || []) links.push(`${o.name} เป็น${relLabel(l.type)}ของ ${nameOf(l.to)}`);
      const rel = Object.entries(G.relationships);
      if (links.length || rel.length) list.append(el('h4', {}, 'ความสัมพันธ์'), ...links.map(t => el('div', { class: 'rel' }, t)), ...rel.map(([k, v]) => { const [a, b] = k.split('|').map(id => G.chars.find(c => c.id === id)?.name || '?'); return el('div', { class: 'rel muted' }, `${a} กับ ${b}`, el('b', {}, ' คุยกัน ' + v + ' ครั้ง')); }));
    };
    const STATE_TH = { idle: 'ยืนพัก', walk: 'กำลังเดิน', sit: 'นั่ง', lie: 'นอนเล่น', sleep: 'หลับ', look: 'มองวิว', interact: 'กำลังใช้งาน', talk: 'กำลังคุย' };
    const live = () => { for (const ch of G.chars) { const b = bars[ch.id]; if (!b) continue; for (const k in ch.needs) if (b[k]) b[k].style.width = ch.needs[k].toFixed(0) + '%'; b.st.textContent = `${STATE_TH[ch.stair ? 'walk' : ch.state] || ch.state} · ${ch.room?.th || 'บันได'} · ชอบ${PREFS[ch.pref] || ''}`; } };
    build(); liveWindows.add(live); w.refresh = build;
    const oc = w.close; w.close = () => { liveWindows.delete(live); oc(); };
    Bus.on('player:changed', () => getWindow('oc') && build());
  }, { icon: 'character', w: 440, h: 520 });
}

/* ---------------- interaction window ---------------- */
function interactWindow() {
  openWindow('interact', 'โต้ตอบ & ไฟ', body => {
    const p = G.player;
    const grp = (t, list) => el('div', { class: 'igroup' }, el('h4', {}, t), el('div', { class: 'ilist' }, ...list));
    const act = (o, v, label, ic) => btn(label || o.th, { icon: ic || 'hand', cls: 'small', onclick: () => { G.party.interact(G.player, o, v); G.cam.follow = true; } });
    const by = (...k) => OBJECTS.filter(o => k.includes(o.kind));
    const rn = o => ` (${roomById[o.room]?.th || ''})`;
    body.append(toggle('ไฟอัตโนมัติ: เปิดตอนค่ำ ปิดตอนเช้า (ห้องที่มีคนหลับจะปิดให้)', G.settings.autoLights !== false, v => { G.settings.autoLights = v; G.autoLightState = {}; saveUIPrefs?.(); }));
    const groups = [
      ['พักผ่อน', [...by('bed').map(o => act(o, 'sleep', 'นอน: ' + o.th + rn(o), 'bed')), ...by('sofa', 'cinema', 'desk').map(o => act(o, 'sit', 'นั่ง: ' + o.th + rn(o), 'hand')), ...by('lounger').map(o => act(o, 'lie', 'อาบแดด: ' + o.th + rn(o), 'sun'))]],
      ['ชมวิว', [...by('view').map(o => act(o, 'use', o.th + rn(o), 'eye')), ...by('window').map(o => act(o, 'use', o.th + rn(o), 'window'))]],
      ['อาหาร สปา & ฟิตเนส', [...by('dining', 'bar').map(o => act(o, 'eat', o.th + rn(o), 'hand')), ...by('stove').map(o => act(o, 'use', 'ทำอาหาร' + rn(o))), ...by('fridge').map(o => act(o, 'use', 'หยิบของว่าง' + rn(o))), ...by('pool').map(o => act(o, 'use', 'ว่ายน้ำ' + rn(o), 'liferaft')), ...by('gym').map(o => act(o, 'use', 'ออกกำลังกาย' + rn(o), 'hand')), ...by('shower').map(o => act(o, 'use', 'อาบน้ำ' + rn(o)))]],
      ['เรือเล็ก (Tender)', [btn('เปิดหน้าต่างเรือเล็ก', { icon: 'tender', cls: 'small', onclick: () => tenderWindow() }), ...by('garage').map(o => act(o, 'use', 'เดินไปโรงเก็บเรือเล็ก', 'tender'))]],
      ['ระบบเรือ', [...by('wheel').map(o => act(o, 'use', 'พวงมาลัย', 'steering')), ...by('mapscreen').map(o => act(o, 'use', 'จอแผนที่', 'map')), ...by('helipanel').map(o => act(o, 'use', 'วิทยุ ฮ.', 'heli')),  ...by('liferaft', 'lifeboat').map(o => act(o, 'use', o.th + rn(o), 'liferaft')), ...by('engine').slice(0, 1).map(o => act(o, 'use', 'ตรวจเครื่องยนต์', 'settings'))]],
    ];
    body.append(...groups.filter(g => g[1].length).map(([t, l]) => grp(t, l)));
    const lightsBox = el('div', { class: 'lights' });
    const build = () => {
      lightsBox.innerHTML = '';
      for (const r of ROOMS) {
        const fx = FIXTURES.filter(f => f.room === r.id); if (!fx.length) continue;
        lightsBox.append(el('div', { class: 'lrow' }, el('b', {}, r.th), ...fx.map(f => toggle(f.th, G.lights[f.id], v => { G.lights[f.id] = v; })),
          OBJECTS.some(o => o.kind === 'switch' && o.room === r.id) ? btn('ให้ OC เดินไปกดสวิตช์', { icon: 'hand', cls: 'tiny', onclick: () => G.player && G.party.interact(G.player, OBJECTS.find(o => o.kind === 'switch' && o.room === r.id)) }) : ''));
      }
    };
    build(); body.append(el('h4', {}, 'ไฟแต่ละห้อง'), el('div', { class: 'row' }, btn('เปิดทั้งหมด', { cls: 'small', onclick: () => { for (const f of FIXTURES) G.lights[f.id] = true; build(); } }), btn('ปิดทั้งหมด', { cls: 'small', onclick: () => { for (const f of FIXTURES) if (f.kind !== 'nav') G.lights[f.id] = false; build(); } })), lightsBox);
    Bus.on('lights', () => getWindow('interact') && build());
  }, { icon: 'hand', w: 460, h: 560 });
}

/* ---------------- inventory ---------------- */
function inventoryWindow() {
  openWindow('inv', 'ของตกแต่ง (ลากไปวางบนพื้นเรือ)', body => {
    const grid = el('div', { class: 'inv-grid' });
    const build = () => {
      grid.innerHTML = '';
      for (const [type, d] of Object.entries(DECOR_TYPES)) {
        const n = G.inventory[type] || 0; const cell = el('div', { class: 'inv-cell' + (n ? '' : ' none'), title: d.th });
        const [cv] = makeCanvas(d.w, d.h); const prev = el('canvas', { width: d.w, height: d.h, class: 'pix' }); prev.getContext('2d').drawImage(spriteOf(type), 0, 0);
        cell.append(prev, el('small', {}, d.th), el('b', {}, '×' + n));
        if (n) cell.addEventListener('pointerdown', e => startDrag(e, type, prev));
        grid.append(cell);
      }
    };
    build(); Bus.on('inventory', () => getWindow('inv') && build());
    body.append(el('p', { class: 'muted' }, 'กดค้างแล้วลากไอเท็มไปปล่อยบนพื้นห้องหรือดาดฟ้า ใช้โหมดจัดฉากเพื่อย้ายของที่วางแล้ว และคลิกของในโหมดจัดฉากเพื่อเก็บกลับ'), grid);
  }, { icon: 'inventory', w: 420, h: 420 });
}
function spriteOf(type) { const sc = window.__scene; return sc?.decorSprite({ type, color: '#7fb7c9' }) || document.createElement('canvas'); }
function startDrag(e, type, prev) {
  e.preventDefault(); const ghost = prev.cloneNode(); ghost.getContext('2d').drawImage(prev, 0, 0); ghost.className = 'drag-ghost pix'; document.body.append(ghost);
  const mv = ev => { ghost.style.left = ev.clientX + 'px'; ghost.style.top = ev.clientY + 'px'; const overCanvas = document.elementFromPoint(ev.clientX, ev.clientY)?.id === 'game'; decorPreview(overCanvas ? ev : null); };
  const up = ev => { removeEventListener('pointermove', mv); removeEventListener('pointerup', up); ghost.remove(); decorPreview(null); if (document.elementFromPoint(ev.clientX, ev.clientY)?.id === 'game') placeDecor(type, ev); };
  mv(e); addEventListener('pointermove', mv); addEventListener('pointerup', up);
}

/* ---------------- yacht customization + systems ---------------- */
export function yachtWindow(tab) {
  openWindow('yacht', 'จัดการเรือ ' + SPEC.name, (body, w) => {
    const hist = [JSON.stringify(G.paint)]; let hi = 0;
    const commit = () => { hist.splice(hi + 1); hist.push(JSON.stringify(G.paint)); hi = hist.length - 1; if (hist.length > 60) { hist.shift(); hi--; } repaint(); saveUIPrefs(); thumb(); };
    const prevBox = el('div', { class: 'yacht-prev' });
    const thumb = () => { prevBox.innerHTML = ''; const c = drawProfileThumb(G.paint, 360); c.className = 'pix'; prevBox.append(c); };
    let part = 'hull';
    const partSel = select(PARTS.map(p => [p.id, p.th]), part, v => { part = v; syncPart(); });
    const c1 = el('input', { type: 'color' }), c2 = el('input', { type: 'color' });
    const patSel = select([['solid', 'สีเดียว (Solid)'], ['twotone', 'สองโทน (Two-Tone)'], ['stripe', 'แถบแนวนอน (Stripe)'], ['geo', 'ลายเรขาคณิต (Geometric)'], ['custom', 'ลายวาดเอง 8×8 (Custom)'], ['image', 'นำเข้าลาย PNG']], 'solid', v => { G.paint[part].pattern = v; if (v === 'custom' && !G.paint[part].tile) G.paint[part].tile = '0'.repeat(64); syncPart(); commit(); });
    const tileGrid = el('div', { class: 'tile-grid' });
    const imp = el('span');
    const impBtn = filePicker('เลือกไฟล์ภาพลาย', { icon: 'upload', cls: 'small' }, async f => { const bad = checkImageFile(f); if (bad) return toast(bad, 'error'); try { const b = await decodeImage(f); const [t, tx] = makeCanvas(16, 16); tx.imageSmoothingEnabled = true; tx.imageSmoothingQuality = 'high'; tx.drawImage(b, 0, 0, 16, 16); delete G.paint[part].tileCanvas; G.paint[part].pattern = 'image'; G.paint[part].tileData = t.toDataURL(); await hydrateTiles(); syncPart(); commit(); toast('นำเข้าลายแล้ว', 'ok'); } catch (e) { toast(e.message || 'โหลดลายไม่สำเร็จ', 'error'); } });
    c1.addEventListener('input', () => { G.paint[part].color = c1.value; repaint(); thumb(); }); c1.addEventListener('change', commit);
    c2.addEventListener('input', () => { G.paint[part].color2 = c2.value; repaint(); thumb(); }); c2.addEventListener('change', commit);
    const pal = el('div', { class: 'swatches' });
    for (const c of ['#c48a5c', '#f3f1ec', '#353b42', '#7cc8b8', '#8BC6D7', '#C9E7F2', '#CBE8D6', '#F4D7C5', '#F8F2E6', '#2f5b76', '#e46b4a', '#f2c94c', '#8a5a3c', '#efe6d6', '#c9a77c', '#38434A']) { const s = el('button', { type: 'button', class: 'sw', style: { background: c }, 'aria-label': c }); s.onclick = () => { G.paint[part].color = c; c1.value = c; commit(); }; pal.append(s); }
    function syncPart() {
      const p = G.paint[part]; c1.value = p.color; c2.value = p.color2 || p.color; patSel.value = p.pattern || 'solid';
      tileGrid.hidden = p.pattern !== 'custom'; impBtn.hidden = p.pattern !== 'image';
      tileGrid.innerHTML = ''; if (p.pattern === 'custom') { const t = (p.tile || '0'.repeat(64)).split(''); t.forEach((v, i) => { const c = el('button', { type: 'button', class: 'tc' + (v === '1' ? ' on' : ''), style: { background: v === '1' ? p.color2 : p.color } }); c.onclick = () => { t[i] = t[i] === '1' ? '0' : '1'; p.tile = t.join(''); syncPart(); commit(); }; tileGrid.append(c); }); }
    }
    const undoB = iconBtn('undo', 'ย้อนกลับ', () => { if (hi > 0) { hi--; G.paint = JSON.parse(hist[hi]); hydrateTiles().then(() => { repaint(); syncPart(); thumb(); }); } });
    const redoB = iconBtn('redo', 'ทำซ้ำ', () => { if (hi < hist.length - 1) { hi++; G.paint = JSON.parse(hist[hi]); hydrateTiles().then(() => { repaint(); syncPart(); thumb(); }); } });
    const presetsBox = el('div', { class: 'presets' });
    const buildPresets = () => {
      presetsBox.innerHTML = '';
      for (let i = 0; i < 10; i++) {
        const pr = G.paintPresets[i];
        presetsBox.append(el('div', { class: 'preset' }, el('span', { class: 'pv', style: { background: pr ? `linear-gradient(${pr.paint.hull.color} 55%, ${pr.paint.super.color} 55%)` : 'transparent' } }), el('small', {}, pr ? pr.name : 'ว่าง ' + (i + 1)),
          btn('บันทึก', { cls: 'tiny', onclick: () => { G.paintPresets[i] = { name: 'ชุดสี ' + (i + 1), paint: structuredClone(G.paint) }; saveUIPrefs(); buildPresets(); toast('บันทึกชุดสีแล้ว', 'ok'); } }),
          pr ? btn('ใช้', { cls: 'tiny primary', onclick: () => { G.paint = structuredClone(pr.paint); hydrateTiles().then(() => { commit(); syncPart(); }); } }) : ''));
      }
    };
    buildPresets(); syncPart(); thumb();
    body.append(prevBox, tabs([
      { label: 'สีและลาย', icon: 'palette', build: p => p.append(el('div', { class: 'row' }, undoB, redoB, btn('คืนค่าเริ่มต้น', { cls: 'small ghost', onclick: () => { G.paint = defaultPaint(SPEC.id); commit(); syncPart(); } })), field('ส่วนของเรือ', partSel), field('สีหลัก', el('div', { class: 'row' }, c1, pal)), field('สีรอง', c2), field('รูปแบบลาย', patSel), tileGrid, impBtn, imp, el('p', { class: 'muted' }, 'สีถูกจำกัดด้วย Mask ของแต่ละส่วน ไม่ล้นไปส่วนอื่น และอัปเดตทันทีโดยไม่ต้องโหลดเกมใหม่')) },
      { label: 'ชุดสีที่บันทึก', icon: 'save', build: p => p.append(presetsBox) },
      { label: 'อุปกรณ์ชูชีพ', icon: 'liferaft', build: p => buildSystems(p) },
      { label: 'กองเรือ', icon: 'fleet', build: p => buildFleet(p, w) },
    ]));
  }, { icon: 'yacht', w: 460, h: 620 });
}
export async function hydrateTiles() { for (const k in G.paint) { const p = G.paint[k]; if (p.pattern === 'image' && p.tileData && !p.tileCanvas) { let b; try { b = await decodeImage(p.tileData); } catch { continue; } const [t, tx] = makeCanvas(16, 16); tx.drawImage(b, 0, 0); Object.defineProperty(p, 'tileCanvas', { value: t, enumerable: false, configurable: true }); } } }
Bus.on('paint:hydrate', hydrateTiles);
function buildSystems(p) {
  const st = el('div', { class: 'sys-state' });
  const LS = { stowed: 'เก็บบนแท่นรองรับ', outboard: 'เดวิทกำลังยื่นออก', lowering: 'กำลังหย่อนลงน้ำ', afloat: 'ลอยอยู่ข้างเรือ', raising: 'กำลังกว้านขึ้น', inboard: 'กำลังเก็บเข้าที่' };
  const upd = () => {
    let h = '';
    if (SPEC.liferaft) h += `<div>${icon('liferaft', 16)} แพชูชีพ: <b>${{ stowed: 'พร้อมใช้งาน (เก็บอยู่)', deploying: 'กำลังกาง (จำลอง)', deployed: 'กางแล้ว (จำลอง)', packing: 'กำลังเก็บ' }[G.liferaft.state] || '-'}</b></div>`;
    for (const b of G.lifeboats) h += `<div>${icon('liferaft', 16)} ${b.th}: <b>${LS[b.state] || b.state}</b></div>`;
    st.innerHTML = h || '<div class="muted">—</div>';
  };
  upd(); const lv = () => upd(); liveWindows.add(lv);
  const inGame = G.screen === 'game';
  p.append(st, el('p', { class: 'muted' }, 'เรือเล็ก (Tender) แยกไปอยู่ที่ปุ่ม "เรือเล็ก" ในแถบล่างแล้ว'), btn('เปิดหน้าต่างเรือเล็ก', { icon: 'tender', cls: 'small', onclick: () => tenderWindow() }));
  if (SPEC.liferaft) p.append(el('div', { class: 'row wrap' }, btn('จำลองการกางแพชูชีพ', { icon: 'liferaft', cls: 'small', disabled: !inGame, onclick: () => liferaftCmd('deploy') }), btn('เก็บแพกลับ', { icon: 'back', cls: 'small', disabled: !inGame, onclick: () => liferaftCmd('pack') })));
  for (const b of SPEC.lifeboats) p.append(el('div', { class: 'row wrap' }, el('b', {}, b.th), btn('หย่อนลงน้ำ', { icon: 'floordown', cls: 'small', disabled: !inGame, onclick: () => lifeboatCmd(b.id, 'lower') }), btn('กว้านขึ้นเก็บ', { icon: 'floorup', cls: 'small', disabled: !inGame, onclick: () => lifeboatCmd(b.id, 'raise') })));
  p.append(el('h4', {}, 'รายการตรวจอุปกรณ์ช่วยชีวิต'), el('ul', { class: 'checklist' }, ...[SPEC.liferaft ? 'แพชูชีพ 3 ถัง — ยึดแน่นบนแท่น' : 'เรือชูชีพแบบปิด 2 ลำบนเดวิท — ตรวจลวดสลิงและเบรกกว้าน', 'เสื้อชูชีพครบจำนวนลูกเรือ', 'ห่วงชูชีพพร้อมไฟ — ท้ายเรือ', 'ถังดับเพลิง — ห้องเครื่อง / ครัว', 'วิทยุ VHF & EPIRB — ห้องควบคุมเรือ'].map(t => el('li', { html: icon('check', 14) + `<span>${t}</span>` }))),
    el('p', { class: 'muted' }, inGame ? 'ต้องหยุดเรือใหญ่ก่อนใช้แพชูชีพหรือเรือเดวิท' : 'เข้าเกมเพื่อใช้งานอุปกรณ์ชูชีพ'));
}
function buildFleet(p, w) {
  for (const y of Object.values(YACHTS)) {
    const F = G.fleet?.[y.id]; const names = (F?.roster || []).map(s => G.ocs.find(o => o.slot === s)?.name).filter(Boolean);
    const th = drawProfileThumb(y.id === SPEC.id ? G.paint : (F?.paint ? Object.assign(defaultPaint(y.id), F.paint) : defaultPaint(y.id)), 400, y.id); th.className = 'pix';
    const here = y.id === SPEC.id;
    p.append(el('div', { class: 'fleet-card' + (here ? ' on' : '') }, el('div', { class: 'yacht-prev' }, th),
      el('div', {}, el('b', {}, y.name + (here ? ' (กำลังแสดง)' : '')), el('small', { class: 'muted', style: { display: 'block' } }, `${y.th} · ยาวประมาณ ${y.lengthM} ม. · ${Object.keys(y.levels).length - 1} ชั้น · ลานจอด ฮ. ${y.pads.length} จุด`),
        G.screen === 'game' ? el('small', { style: { display: 'block' } }, 'ลูกเรือ: ' + (names.join(', ') || 'ยังไม่มี')) : ''),
      here ? '' : btn(G.screen === 'game' ? 'ไปที่เรือลำนี้' : 'แสดงเรือลำนี้', { icon: 'fleet', cls: 'small primary', onclick: async () => { w.close(); if (G.screen === 'game') await switchYacht(y.id); else await setMenuYacht(y.id); } })));
  }
  p.append(el('p', { class: 'muted' }, 'เรือทั้งสองลำเดินทางเป็นกองเรือเดียวกัน ย้ายตัวละครระหว่างเรือด้วยเฮลิคอปเตอร์ (ปุ่ม ฮ.)'));
}

/* ---------------- helicopter ---------------- */
const PHASE_TH = { parked: 'จอดดับเครื่อง', inbound: 'กำลังบินเข้าหาเรือ', approach: 'ลดความเร็ว/เข้าลานจอด', descend: 'กำลังลดระดับลงจอด', landed: 'จอดบนลานจอด (เครื่องยนต์ทำงาน)', spool: 'กำลังเร่งรอบโรเตอร์', liftoff: 'กำลังยกตัว', turning: 'หมุนลำตัวกลางอากาศ', depart: 'กำลังบินออก', manual: 'บังคับเอง' };
export function heliWindow() {
  openWindow('heli', 'เฮลิคอปเตอร์', (body, w) => {
    const st = el('div', { class: 'sys-state' });
    const prev = el('canvas', { class: 'pix heli-prev', width: 220, height: 90 });
    const drawPrev = () => { const s = heliSprite(G.settings.heliLivery || 'skyblue'); const c = prev.getContext('2d'); c.imageSmoothingEnabled = false; c.clearRect(0, 0, 220, 90); c.drawImage(s.cv, 4, 6); c.fillStyle = '#3f474f'; c.fillRect(Math.round(4 + s.ax - 94), Math.round(6 + s.ay - 77), 188, 2); };
    drawPrev();
    const live = () => { const h = G.heli; if (!getWindow('heli')) { liveWindows.delete(live); return; } if (!h) { st.innerHTML = `<div>${icon('heli', 16)} สถานะ: <b>ไม่อยู่บนเรือ (รอเรียก)</b></div>`; return; } const t = h.telemetry(SPEC.WL); st.innerHTML = `<div>${icon('heli', 16)} สถานะ: <b>${PHASE_TH[h.phase] || h.phase}</b></div><div class="tele"><span>ความสูง ${t.alt.toFixed(0)} ม.</span><span>ความเร็ว ${t.ias.toFixed(0)} kn</span><span>V/S ${t.vs.toFixed(1)} ม./วิ</span><span>รอบโรเตอร์ ${t.rpm.toFixed(0)}%</span><span>Pitch ${t.pitch.toFixed(1)}°</span><span>Collective ${t.coll.toFixed(0)}%</span></div>`; };
    live(); liveWindows.add(live);
    const other = Object.keys(YACHTS).find(k => k !== SPEC.id);
    const pick = (list, label) => { const box = el('div', { class: 'pick-list' }); const sel = new Set(); if (!list.length) box.append(el('small', { class: 'muted' }, 'ไม่มี')); for (const [key, name] of list) { const cb = el('input', { type: 'checkbox' }); cb.onchange = () => cb.checked ? sel.add(key) : sel.delete(key); box.append(el('label', { class: 'chk' }, cb, name)); } box.sel = sel; return box; };
    const here = pick(G.chars.filter(c => !c.inHeli).map(c => [c.id, c.name + (c === G.player ? ' (ตัวหลัก)' : '')]));
    const there = pick((G.fleet[other]?.roster || []).map(s => [s, G.ocs.find(o => o.slot === s)?.name || '?']));
    const onAny = new Set(Object.values(G.fleet).flatMap(f => f.roster)); for (const c of G.chars) onAny.add(c.slot_);
    const shore = pick(G.ocs.filter(o => !onAny.has(o.slot)).map(o => [o.slot, o.name]));
    const padSel = PADS.length > 1 ? field('ลานจอด', select(PADS.map(p => [p.id, p.th]), G.heliPad, v => G.heliPad = v)) : '';
    const toPads = YACHTS[other].pads; let toPad = toPads[0].id;
    body.append(el('div', { class: 'row' }, prev, el('div', { class: 'grow' }, field('ลายเครื่อง (Livery)', select(Object.entries(LIVERIES).map(([k, v]) => [k, v.th]), G.settings.heliLivery || 'skyblue', v => { G.settings.heliLivery = v; if (G.heli) G.heli.livery = v; drawPrev(); saveUIPrefs(); })), padSel)), st,
      tabs([
        { label: 'ภารกิจ', icon: 'heli', build: p => p.append(
          btn('เรียก ฮ. ส่งเสบียง & ของตกแต่ง', { icon: 'inventory', cls: 'small primary', onclick: () => startHeliMission('supply') }),
          el('h4', {}, 'ส่ง OC จากเรือนี้ไป ' + YACHTS[other].name), here, toPads.length > 1 ? field('ลงจอดที่', select(toPads.map(p => [p.id, p.th]), toPad, v => toPad = v)) : '',
          btn('ส่งด้วยเฮลิคอปเตอร์', { icon: 'fleet', cls: 'small', onclick: () => { const chars = G.chars.filter(c => here.sel.has(c.id)); if (!chars.length) return toast('เลือก OC ก่อน'); startHeliMission('pickup', { chars, to: other, toPad }); w.close(); } }),
          el('h4', {}, 'รับ OC จาก ' + YACHTS[other].name), there, btn('รับมาเรือนี้', { icon: 'character', cls: 'small', onclick: () => { const slots = [...there.sel]; if (!slots.length) return toast('เลือก OC ก่อน'); startHeliMission('drop', { slots, from: other }); w.close(); } }),
          el('h4', {}, 'รับ OC จากฝั่ง (ยังไม่ได้อยู่บนเรือลำใด)'), shore, btn('รับขึ้นเรือ', { icon: 'add', cls: 'small', onclick: () => { const slots = [...shore.sel]; if (!slots.length) return toast('เลือก OC ก่อน'); startHeliMission('drop', { slots }); w.close(); } }),
          el('div', { class: 'row wrap' }, toggle('กล้องติดตาม ฮ.', G.heliCam, v => { G.heliCam = v; if (!v) G.cam.follow = true; }), G.heli?.phase === 'parked' ? btn('ส่ง ฮ. กลับฐาน', { icon: 'back', cls: 'small', onclick: () => startHeliMission('return') }) : '')) },
        { label: 'บินเอง', icon: 'steering', build: p => p.append(
          el('p', {}, 'ควบคุมด้วยระบบฟิสิกส์: แรงยกจาก Collective × รอบโรเตอร์², เอียงจานใบพัด (Cyclic) เพื่อเร่ง/เบรก, แรงต้านอากาศ, Ground Effect ใกล้ลานจอด และการสัมผัสพื้น'),
          el('ul', { class: 'keys' }, ...[['W / ↑', 'เพิ่ม Collective (ไต่ระดับ)'], ['S / ↓', 'ลด Collective (ลดระดับ)'], ['A D / ← →', 'Cyclic เอียงไปซ้าย/ขวา'], ['Q / E', 'หมุนลำตัว 180° (ต้องลอยนิ่ง)'], ['Esc', 'ออกจากโหมดบิน (Autopilot พากลับลงจอด)']].map(([a, b]) => el('li', {}, el('kbd', {}, a), ' ' + b))),
          btn('เริ่มบินเอง', { icon: 'steering', cls: 'primary', onclick: () => { w.close(); startManualFlight(); } })) },
      ]),
      el('p', { class: 'muted' }, 'สัดส่วนอ้างอิงเฮลิคอปเตอร์ขนาดกลางสองเครื่องยนต์ ใบพัดหลัก 5 ใบ: ลำตัว ~15.7 ม. จานใบพัด ~14.8 ม. น้ำหนัก ~7 ตัน · ระบบบินเป็นการจำลองในเกม'));
  }, { icon: 'heli', w: 460, h: 640 });
}
let flightEl = null;
export function heliPedal() { const h = G.heli; if (!h) return; if (h.onGround) return toast('ยกตัวขึ้นก่อนจึงหมุนลำตัวได้'); if (Math.abs(h.vx / PPM) > 5) return toast('ลดความเร็วให้ต่ำกว่า 5 ม./วิ ก่อนหมุนลำตัว'); if (h.turnTarget === h.facing) h.turnTarget = -h.facing; }
export function flightHUD(on) {
  flightEl?.remove(); flightEl = null; if (!on) return;
  const tele = el('div', { class: 'fl-tele' });
  const hold = (label, ic, key) => { const b = btn(label, { icon: ic, cls: 'fl-btn' }); const set = v => { if (G.heli) G.heli.manual[key] = v; b.classList.toggle('on', !!v); }; b.addEventListener('pointerdown', e => { e.preventDefault(); b.setPointerCapture(e.pointerId); set(1); }); for (const ev of ['pointerup', 'pointercancel', 'lostpointercapture']) b.addEventListener(ev, () => set(0)); return b; };
  const eng = btn('', { icon: 'settings', cls: 'fl-btn', onclick: () => { const h = G.heli; if (!h) return; h.engines = !h.engines; toast(h.engines ? 'สตาร์ทเครื่องยนต์ — รอรอบโรเตอร์ถึง 100%' : 'ดับเครื่องยนต์'); upd(); } });
  const assist = toggle('ช่วยรักษาระดับ (Assist)', true, v => { if (G.heli) G.heli.manual.assist = v; });
  const upd = () => { eng.querySelector('span') ? eng.querySelector('span').textContent = (G.heli?.engines ? 'ดับเครื่อง' : 'สตาร์ทเครื่อง') : eng.append(el('span', {}, G.heli?.engines ? 'ดับเครื่อง' : 'สตาร์ทเครื่อง')); };
  upd();
  flightEl = el('div', { class: 'flight-hud' }, tele,
    el('div', { class: 'fl-pad' }, el('div', { class: 'fl-col' }, hold('ขึ้น', 'floorup', 'up'), hold('ลง', 'floordown', 'down')), el('div', { class: 'fl-col' }, el('div', { class: 'row' }, hold('ซ้าย', 'left', 'left'), hold('ขวา', 'right', 'right')), btn('หมุนลำตัว', { icon: 'retry', cls: 'fl-btn', onclick: heliPedal }))),
    el('div', { class: 'fl-col' }, eng, assist, btn('ออกจากการบิน', { icon: 'close', cls: 'fl-btn danger', onclick: endManualFlight })));
  document.body.append(flightEl);
  const live = () => { if (!flightEl) { liveWindows.delete(live); return; } const h = G.heli; if (!h) return; upd(); const t = h.telemetry(SPEC.WL); tele.innerHTML = `<b>${PHASE_TH[h.phase] || ''}${t.ground ? ' · บนพื้น' : ''}</b><span>ALT ${t.alt.toFixed(0)} ม. · AGL ${t.agl.toFixed(1)} ม.</span><span>V/S ${t.vs >= 0 ? '+' : ''}${t.vs.toFixed(1)} ม./วิ · ${t.ias.toFixed(0)} kn</span><span>RPM ${t.rpm.toFixed(0)}% · COLL ${t.coll.toFixed(0)}% · PITCH ${t.pitch.toFixed(1)}°</span>`; };
  liveWindows.add(live);
}

/* ---------------- object panels ---------------- */
export function objectPanel(o) {
  if (o.kind === 'wheel') return helmWindow();
  if (o.kind === 'mapscreen') return mapWindow();
  if (o.kind === 'garage') return tenderWindow();
  if (o.kind === 'liferaft' || o.kind === 'lifeboat') return yachtWindow();
  if (o.kind === 'helipanel' && G.Sink?.active) return sosWindow();
  if (o.kind === 'helipad' || o.kind === 'helipanel') return heliWindow();
  if (o.kind === 'navlights') { G.lights.nav = !G.lights.nav; toast('ไฟนำร่อง ' + (G.lights.nav ? 'เปิด' : 'ปิด')); return; }
  if (o.kind === 'engine') { const j = G.journey.s; modal({ title: 'ห้องเครื่องยนต์', body: el('div', {}, el('p', {}, `สถานะเครื่องยนต์: ${j.engine ? 'ทำงาน' : 'ดับ'} · ความเร็วปัจจุบัน ${j.speed.toFixed(1)} kn`), el('p', {}, `ระยะทางที่แล่นสะสม: ${j.distDone.toFixed(1)} nm · ชั่วโมงเดินเรือ ${j.hours.toFixed(1)} ชม.`), el('p', { class: 'muted' }, 'ค่าจำลองภายในเกม')), actions: [{ label: j.engine ? 'ดับเครื่อง' : 'ติดเครื่อง', icon: 'settings', onclick: () => { j.engine = !j.engine; if (!j.engine) j.targetSpeed = 0; } }, { label: 'ปิด' }] }); return; }
  if (o.kind === 'utility') { modal({ title: 'ห้องเก็บอุปกรณ์', body: el('p', {}, 'อุปกรณ์ทำความสะอาด เครื่องซักผ้า เชือก และอะไหล่ ถูกจัดเก็บเรียบร้อย'), actions: [{ label: 'ปิด' }] }); return; }
}

/* ---------------- map & navigation ---------------- */
export function mapWindow() {
  if (!Geo.ready) return toast('แผนที่ยังโหลดไม่เสร็จ');
  openWindow('map', 'แผนที่การเดินเรือ', (body, w) => {
    const cv = el('canvas', { class: 'map-canvas', width: 640, height: 420 });
    const mv = new MapView(cv, G.journey); mv.center();
    const info = el('div', { class: 'nav-info' }); const selInfo = el('div', { class: 'sel-info' });
    const speedS = slider(2, 18, 1, G.journey.s.targetSpeed || 12, v => { if (G.journey.s.status !== 'docked') G.journey.s.targetSpeed = v; });
    const mult = select([[1, 'เวลาจริง (Realistic)'], [2, '2×'], [5, '5×'], [10, '10×'], [60, '60× (ทดสอบ)']], G.journey.s.timeMult, v => G.journey.s.timeMult = +v);
    const wpBtn = btn('เพิ่ม Waypoint', { icon: 'add', cls: 'small', onclick: () => { mv.mode = mv.mode === 'waypoint' ? 'select' : 'waypoint'; wpBtn.classList.toggle('on', mv.mode === 'waypoint'); toast(mv.mode === 'waypoint' ? 'คลิกบนทะเลเพื่อวาง Waypoint' : 'ปิดการวาง Waypoint'); } });
    let sel = null;
    const showSel = p => {
      sel = p; selInfo.innerHTML = ''; if (!p) return;
      const d = distNm(G.journey.pos, [p.lat, p.lon]); const route = Geo.route(G.journey.pos, [p.lat, p.lon]);
      let rd = 0; if (route) for (let i = 1; i < route.length; i++) rd += distNm(route[i - 1], route[i]);
      mv.preview = route; mv.draw();
      const spd = speedS.input.value; const disc = G.journey.s.discovered.includes(p.id);
      selInfo.append(el('b', {}, `${p.th} · ${COUNTRY_TH[p.c]}`), el('small', {}, route ? `ระยะตามเส้นทาง ${rd.toFixed(1)} nm (เส้นตรง ${d.toFixed(1)} nm) · ที่ ${spd} kn ใช้เวลา ~${fmtDuration(rd / spd)}` : 'ไม่พบเส้นทางทางน้ำ'),
        el('div', { class: 'row wrap' }, btn('ตั้งเป็นจุดหมาย', { icon: 'target', cls: 'small primary', disabled: !route, onclick: () => { if (G.journey.plan(p.id, mv.extra)) { mv.extra = []; mv.preview = null; mv.draw(); toast('วางเส้นทางไป ' + p.th + ' แล้ว', 'ok'); upd(); } else toast('วางเส้นทางไม่สำเร็จ', 'error'); } }),
          btn('Fast Travel', { icon: 'play', cls: 'small', disabled: !disc || G.journey.s.dockedAt === p.id, title: disc ? '' : 'ต้องเคยไปถึงก่อน', onclick: () => { if (G.journey.fastTravel(p.id)) { mv.center(); upd(); } } })));
    };
    Bus.on('map:select', p => getWindow('map') && showSel(p));
    const upd = () => {
      const s = G.journey.s; const rem = G.journey.remaining(); const pct = s.distTotal ? clamp(1 - rem / s.distTotal, 0, 1) : 0;
      info.innerHTML = `<div><span>ตำแหน่ง</span><b>${s.lat.toFixed(3)}°, ${s.lon.toFixed(3)}°</b></div><div><span>Heading</span><b>${s.heading.toFixed(0)}°</b></div><div><span>ความเร็ว</span><b>${s.speed.toFixed(1)} kn</b></div>
      <div><span>จุดหมาย</span><b>${s.dest ? portById[s.dest].th : '-'}</b></div><div><span>ระยะคงเหลือ</span><b>${rem.toFixed(1)} nm</b></div><div><span>ETA</span><b>${s.waypoints.length ? fmtDuration(G.journey.eta() / s.timeMult) + (s.timeMult > 1 ? ` (เกม ${fmtDuration(G.journey.eta())})` : '') : '-'}</b></div>
      <div><span>Autopilot</span><b class="${s.autopilot ? 'ok' : ''}">${s.autopilot ? 'เปิด' : 'ปิด'}</b></div><div><span>สถานะ</span><b>${{ docked: 'จอดเทียบท่า', sailing: 'กำลังแล่น' }[s.status] || s.status}</b></div>
      <div class="full"><span>ความคืบหน้า</span><div class="mini-bar"><i style="width:${(pct * 100).toFixed(1)}%"></i></div></div>`;
    };
    const live = () => { upd(); mv.draw(); }; liveWindows.add(live);
    const oc = w.close; w.close = () => { liveWindows.delete(live); oc(); };
    body.append(el('div', { class: 'map-wrap' }, cv, el('div', { class: 'map-zoom' }, iconBtn('zoomin', 'ซูมเข้า', () => mv.zoom(1.3)), iconBtn('zoomout', 'ซูมออก', () => mv.zoom(1 / 1.3)), iconBtn('target', 'ไปที่ตำแหน่งเรือ', () => mv.center()))),
      selInfo, info,
      el('div', { class: 'row wrap' },
        btn('เริ่มเดินทาง (Autopilot)', { icon: 'autopilot', cls: 'small primary', onclick: () => { if (!G.journey.start(+speedS.input.value)) toast('ยังไม่มีจุดหมาย เลือกท่าเรือบนแผนที่ก่อน', 'error'); upd(); } }),
        btn('หยุดเรือ', { icon: 'stop', cls: 'small', onclick: () => { G.journey.stop(); upd(); } }),
        btn('บังคับเอง', { icon: 'steering', cls: 'small', onclick: () => { G.journey.manual(); steeringWindow(); } }), wpBtn,
        btn('ล้างเส้นทาง', { icon: 'delete', cls: 'small ghost', onclick: () => { Object.assign(G.journey.s, { waypoints: [], wp: 0, dest: null, autopilot: false }); mv.extra = []; mv.preview = null; mv.draw(); upd(); } })),
      field('ความเร็วเฉลี่ย (knots)', speedS), field('อัตราเวลาเดินทาง', mult),
      el('p', { class: 'muted' }, 'Travel Time (ชม.) = ระยะทาง (nm) ÷ ความเร็วเฉลี่ย (kn) · เส้นทางหลบแผ่นดินด้วย A* บนกริด 0.1° · ระบบนำทางในเกมเท่านั้น ไม่ใช่อุปกรณ์เดินเรือจริง และไม่มีข้อมูลร่องน้ำหรือความลึก'));
    upd(); mv.draw();
    w.onResize = () => mv.draw();
  }, { icon: 'map', w: 680, h: 720 });
}
export function steeringWindow() { return helmWindow(); }
// Helm console: twin telegraphs, wheel, bow thruster, instruments. Keyboard while open:
// W/S or ↑/↓ = telegraph step · A/D or ←/→ = wheel · Q/E = bow thruster (hold) · Space = all stop · H = heading hold
export function helmWindow() {
  const guest = !!G.coop?.guest;
  openWindow('steer', 'สะพานเดินเรือ — แท่นบังคับเรือ (Helm)', (body, w) => {
    // one pixel-art canvas (200×140) scaled with nearest-neighbour: instruments, both telegraphs and the wheel
    const cv = el('canvas', { class: 'helm-pix', width: PW, height: PH, tabIndex: 0, 'aria-label': 'แท่นบังคับเรือ: ลากคันเร่งซ้าย/ขวา หมุนพวงมาลัยตรงกลาง' });
    const ctx = cv.getContext('2d');
    const toLocal = e => { const r = cv.getBoundingClientRect(); return [(e.clientX - r.left) / r.width * PW, (e.clientY - r.top) / r.height * PH]; };
    let drag = null;
    cv.addEventListener('pointerdown', e => {
      if (guest) return; const [x, y] = toLocal(e); cv.setPointerCapture(e.pointerId);
      const W = GEO.wheel;
      if (Math.hypot(x - W.x, y - W.y) <= W.r + 8) drag = { kind: 'wheel', a: Math.atan2(y - W.y, x - W.x), v: Helm.wheel };
      else if (y >= 50 && y <= 124 && x >= 4 && x < 46) drag = { kind: 'lever', i: 0 };
      else if (y >= 50 && y <= 124 && x >= 154 && x < 198) drag = { kind: 'lever', i: 1 };
      if (drag?.kind === 'lever') setLever(drag.i, y);
    });
    cv.addEventListener('pointermove', e => {
      if (!drag) return; const [x, y] = toLocal(e);
      if (drag.kind === 'lever') setLever(drag.i, y);
      else { const W = GEO.wheel, a = Math.atan2(y - W.y, x - W.x); let d = a - drag.a; if (d > Math.PI) d -= 2 * Math.PI; if (d < -Math.PI) d += 2 * Math.PI; drag.a = a; drag.v = clamp(drag.v + d / (Math.PI * 3), -1, 1); Helm.setWheel(drag.v); }
    });
    const end = () => { drag = null; }; cv.addEventListener('pointerup', end); cv.addEventListener('pointercancel', end);
    function setLever(i, y) { const v = leverValue(y); if (v !== (Helm.linked ? (Helm.thr[0] + Helm.thr[1]) / 2 : Helm.thr[i])) Helm.setThr(i, v); }
    const hold = (label, v) => { const b = btn(label, { cls: 'small' }); const on = () => { if (!guest) { Helm.thruster = v; Helm.takeControl(); } }, off = () => { Helm.thruster = 0; }; b.addEventListener('pointerdown', on); b.addEventListener('pointerup', off); b.addEventListener('pointerleave', off); b.addEventListener('pointercancel', off); return b; };
    const link = el('label', { class: 'chk' }, el('input', { type: 'checkbox', checked: Helm.linked, onchange: e => Helm.linked = e.target.checked }), ' คันเร่งคู่');
    const hdgB = btn('HDG HOLD', { cls: 'small', onclick: () => { Helm.holdHeading(Helm.hold == null); } });
    const dockB = btn('เทียบท่า', { icon: 'anchor', cls: 'small primary', onclick: () => { if (Helm.dock()) toast('เทียบท่าเรียบร้อย ผูกเชือกแล้ว', 'ok'); } });
    const engB = btn('', { cls: 'small', onclick: () => { const s = G.journey.s; s.engine = !s.engine; toast(s.engine ? 'ติดเครื่องยนต์' : 'ดับเครื่องยนต์'); } });
    const msg = el('div', { class: 'helm-msg' });
    body.append(el('div', { class: 'helm-frame' }, cv),
      el('div', { class: 'row wrap helm-btns' }, btn('หางเสือตรง', { cls: 'small', onclick: () => !guest && Helm.setWheel(0) }), hdgB, hold('◀ หัวเรือ', -1), hold('หัวเรือ ▶', 1)),
      el('div', { class: 'row wrap helm-btns' }, btn('ALL STOP', { icon: 'stop', cls: 'small danger', onclick: () => !guest && Helm.allStop() }), dockB, engB, link),
      msg,
      el('p', { class: 'muted small' }, guest ? 'คุณเป็นแขกในห้อง Co-op — ดูแผงได้ แต่คนขับเรือคือเจ้าของห้อง' : 'ลากคันเร่ง PORT/STBD ขึ้น-ลง · หมุนพวงมาลัยด้วยการลากเป็นวง · คีย์บอร์ด: W/S คันเร่ง · A/D พวงมาลัย · Q/E bow thruster · Space หยุดเครื่อง · H ล็อกเข็มทิศ. เรือใหญ่ตอบสนองช้า เครื่องต้องค่อย ๆ เร่งรอบ ต้องผ่านเกียร์ว่างก่อนสลับเดินหน้า/ถอยหลัง (ห้องเครื่องจะตอบรับคำสั่งด้วยเสียงกระดิ่ง) หางเสือแทบไม่มีผลถ้าเรือไม่เคลื่อนที่'));
    const keys = {};
    const kd = e => { if (guest || /INPUT|TEXTAREA|SELECT/.test(document.activeElement?.tagName)) return; const k = e.key.toLowerCase(); const map = { w: 1, arrowup: 1, s: -1, arrowdown: -1 };
      if (k in map) { if (!e.repeat) Helm.stepThr('both', map[k]); } else if (['a', 'd', 'arrowleft', 'arrowright', 'q', 'e'].includes(k)) keys[k] = true; else if (k === ' ') Helm.allStop(); else if (k === 'h') Helm.holdHeading(Helm.hold == null); else return;
      e.preventDefault(); e.stopImmediatePropagation(); };
    const ku = e => { const k = e.key.toLowerCase(); if (k in keys) { delete keys[k]; if (k === 'q' || k === 'e') Helm.thruster = 0; e.stopImmediatePropagation(); } };
    addEventListener('keydown', kd, true); addEventListener('keyup', ku, true);
    let raf = 0, last = performance.now();
    const fit = () => { const avail = Math.max(160, body.clientWidth - 4); const k = avail / PW; const s = k >= 2 ? Math.min(4, Math.floor(k)) : Math.max(1, k); cv.style.width = Math.round(PW * s) + 'px'; cv.style.height = Math.round(PH * s) + 'px'; };
    const frame = () => {
      const now = performance.now(), dt = Math.min(0.1, (now - last) / 1000); last = now; const s = G.journey.s;
      if (keys.a || keys.arrowleft) Helm.setWheel(Helm.wheel - dt * 0.6); if (keys.d || keys.arrowright) Helm.setWheel(Helm.wheel + dt * 0.6);
      if (keys.q || keys.e) { Helm.thruster = keys.q ? -1 : 1; Helm.takeControl(); }
      fit(); drawHelm(ctx, s, now / 1000);
      hdgB.classList.toggle('on', Helm.hold != null); hdgB.textContent = Helm.hold != null ? `HDG ${String(Helm.hold).padStart(3, '0')}°` : 'HDG HOLD';
      const dp = Helm.dockable(); dockB.style.display = dp ? '' : 'none'; if (dp) dockB.lastChild.textContent = 'เทียบท่า ' + dp.th;
      engB.textContent = s.engine ? 'ดับเครื่อง' : 'ติดเครื่อง';
      msg.textContent = s.autopilot ? 'ออโต้ไพลอตเส้นทางกำลังขับ — แตะคันเร่งหรือพวงมาลัยเพื่อรับช่วงควบคุม' : s.status === 'docked' ? `จอดเทียบท่าอยู่ที่ ${G.journey.nearestPort().port.th} — ดันคันเร่งเพื่อออกจากท่า` : Helm.alarm ? '⚠ มีแผ่นดิน/ที่ตื้นข้างหน้า ลดความเร็วหรือเปลี่ยนทิศ' : '';
      msg.classList.toggle('warn', !!Helm.alarm);
      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);
    const oc = w.close; w.close = () => { cancelAnimationFrame(raf); removeEventListener('keydown', kd, true); removeEventListener('keyup', ku, true); Helm.thruster = 0; oc(); };
  }, { icon: 'steering', w: 640, h: 700 });
}

/* ---------------- music ---------------- */
function musicWindow() {
  openWindow('music', 'เครื่องเล่นเพลง', (body, w) => {
    Music.mount();
    const urlIn = el('textarea', { rows: 2, class: 'music-in', placeholder: 'วางลิงก์ YouTube หรือโค้ด Embed (<iframe …>) จากปุ่ม แชร์ → ฝัง' }); const msg = el('small', { class: 'hint' });
    const list = el('div', { class: 'playlist' });
    const fileIn = filePicker('ไฟล์เสียงในเครื่อง', { icon: 'upload', cls: 'small', accept: 'audio/*,.mp3,.m4a,.ogg,.wav,.aac,.flac' }, f => { if (!(f.type.startsWith('audio/') || /\.(mp3|m4a|ogg|wav|aac|flac)$/i.test(f.name))) return toast('ไม่ใช่ไฟล์เสียง', 'error'); Music.playlist.push({ kind: 'local', title: f.name, blobUrl: URL.createObjectURL(f) }); build(); });
    const localCtl = el('div', { class: 'row wrap' });
    const build = () => {
      list.innerHTML = '';
      Music.playlist.forEach((it, i) => list.append(el('div', { class: 'pl-row' + (i === Music.index ? ' on' : '') },
        el('span', { class: 'pl-kind ' + it.kind }, it.kind === 'youtube' ? 'YT' : '♪'), el('span', { class: 'grow' }, it.title),
        iconBtn('play', 'เปิดในเครื่องเล่น', () => { Audio.start(); Music.load(i); if (it.kind === 'local') Music.play(); build(); }),
        iconBtn('delete', 'ลบ', () => { Music.playlist.splice(i, 1); if (Music.index === i) Music.unload(); else if (Music.index > i) Music.index--; build(); saveUIPrefs(); }))));
      if (!Music.playlist.length) list.append(el('p', { class: 'muted' }, 'ยังไม่มีเพลงในเพลย์ลิสต์'));
      localCtl.style.display = Music.playlist[Music.index]?.kind === 'local' ? '' : 'none';
    };
    const add = () => { const r = parseMusicURL(urlIn.value); if (!r.ok) { msg.textContent = r.err; msg.className = 'hint bad'; return; } Music.playlist.push(r); msg.textContent = 'เพิ่มแล้ว: ' + r.title + ' — กด ▶ ในเครื่องเล่นที่มุมจอเพื่อเล่น'; msg.className = 'hint ok'; urlIn.value = ''; Music.load(Music.playlist.length - 1); build(); saveUIPrefs(); };
    urlIn.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); add(); } });
    const vol = (k, t) => field(t, slider(0, 100, 5, Math.round(Audio.vol[k] * 100), v => { Audio.vol[k] = v / 100; Audio.apply(); }));
    localCtl.append(btn('เล่น', { icon: 'play', cls: 'small', onclick: () => { Audio.start(); Music.play(); } }), btn('หยุดชั่วคราว', { icon: 'pause', cls: 'small', onclick: () => Music.pause() }), btn('ถัดไป', { icon: 'right', cls: 'small', onclick: () => { Music.next(); build(); } }));
    body.append(el('div', { class: 'row' }, urlIn, btn('เพิ่ม', { icon: 'add', cls: 'small primary', onclick: add })), msg,
      el('div', { class: 'row wrap' }, fileIn), localCtl, list, vol('music', 'ระดับเสียงไฟล์ในเครื่อง'), vol('master', 'ระดับเสียงหลักของเกม'),
      el('p', { class: 'muted' }, 'เพลงออนไลน์รองรับเฉพาะ YouTube ผ่านเครื่องเล่น iframe Embed ทางการ (เหมือนโค้ดจากปุ่ม แชร์ → ฝัง) เครื่องเล่นอยู่มุมจอและเล่นต่อแม้ปิดหน้าต่างนี้ ควบคุมเล่น/หยุด/ระดับเสียงด้วยปุ่มในเครื่องเล่น YouTube · วิดีโอที่เจ้าของปิดการฝังจะเล่นในเกมไม่ได้ · หรือเพิ่มไฟล์เสียงจากเครื่องก็ได้'));
    build();
  }, { icon: 'music', w: 440, h: 560 });
}

/* ---------------- photo mode ---------------- */
export function photoMode(on) {
  G.photo = on; document.body.classList.toggle('photo', on);
  document.querySelector('.photo-bar')?.remove();
  if (!on) return;
  const bar = el('div', { class: 'photo-bar' }, btn('ถ่ายภาพ', { icon: 'camera', cls: 'primary', onclick: () => { const url = capturePhoto(); if (!url) return; modal({ title: 'ภาพถ่าย', body: el('div', { class: 'export-png' }, el('img', { src: url, alt: 'ภาพถ่ายจากเกม' }), el('a', { class: 'btn primary', href: url, download: 'southcozy-photo.png' }, 'ดาวน์โหลด PNG'), el('p', { class: 'muted' }, 'หากดาวน์โหลดถูกบล็อก ให้คลิกขวา/กดค้างที่ภาพเพื่อบันทึก')) }); } }),
    iconBtn('cutaway', 'เปิด/ปิดผนัง', () => { G.cutawayAll = !G.cutawayAll; }), iconBtn('zoomin', 'ซูมเข้า', () => zoomBy(1)), iconBtn('zoomout', 'ซูมออก', () => zoomBy(-1)), btn('ออก', { icon: 'close', onclick: () => photoMode(false) }));
  document.body.append(bar);
}

/* ---------------- settings ---------------- */
export function settingsWindow() {
  openWindow('settings', 'ตั้งค่า', body => {
    const S = G.settings; const save = () => saveUIPrefs();
    const tm = G.clock.s;
    const timeBox = el('div');
    const buildTime = () => {
      timeBox.innerHTML = '';
      if (G.coop?.guest) {
        timeBox.append(el('p', { class: 'muted' }, 'เวลาในห้องอิงตามโฮสต์'));
        return;
      }
      timeBox.append(field('โหมดเวลา', select(TIME_MODES.map(m => [m.id, m.th]), tm.mode, v => { G.clock.setMode(v); buildTime(); })));
      if (tm.mode === 'custom') timeBox.append(field('เวลาที่ต้องการ (ชั่วโมง)', slider(0, 23.5, 0.5, tm.customHour, v => G.clock.setMode('custom', { customHour: v }))));
      if (tm.mode === 'preset') timeBox.append(field('ช่วงเวลา', select(PRESETS.map(p => [p.id, p.th]), tm.preset, v => G.clock.setMode('preset', { preset: v }))));
      if (tm.mode === 'accel') timeBox.append(field('อัตราเร่งเวลา', select([[10, '10×'], [30, '30×'], [60, '60× (1 นาที = 1 ชม.)'], [120, '120×'], [300, '300×']], tm.speed, v => G.clock.setMode('accel', { speed: +v }))));
      timeBox.append(el('p', { class: 'muted' }, 'ตำแหน่งดวงอาทิตย์คำนวณจากวันที่ เวลา UTC และพิกัดเรือ (Solar Elevation Model) · โหมดท้องถิ่นใช้เขตเวลาของท่าเรือที่ใกล้ที่สุด'));
    };
    buildTime();
    const vol = (k, t) => field(t, slider(0, 100, 5, Math.round(Audio.vol[k] * 100), v => { Audio.vol[k] = v / 100; Audio.apply(); save(); }));
    const acctBox = el('div');
    const sess = G.session;
    acctBox.append(el('p', {}, 'ชื่อผู้เล่น: ', el('b', {}, sess.username)), el('p', { class: 'muted' }, 'เล่นแบบอิสระ ไม่มีบัญชี — ตัวละคร เซฟ และการตั้งค่าบันทึกในเบราว์เซอร์นี้'),
      btn('เปลี่ยนชื่อ', { icon: 'user', cls: 'small', onclick: async () => { if (G.screen === 'game') await quitToMenu(); closeAllWindows(); gateway(); } }));
    const saveBox = el('div', { class: 'row wrap' });
    if (G.screen === 'game') for (const s of ['m1', 'm2', 'm3']) saveBox.append(btn('บันทึกลงช่อง ' + s.slice(1), { icon: 'save', cls: 'small', onclick: () => saveGame(s) }));
    saveBox.append(btn('จัดการเซฟ', { icon: 'load', cls: 'small', onclick: async () => { if (G.screen === 'game') await quitToMenu(); savesScreen(); } }));
    body.append(tabs([
      { label: 'กราฟิก', icon: 'image', build: p => p.append(field('คุณภาพกราฟิก', select([[-1, 'อัตโนมัติตามสเปคเครื่อง (แนะนำ)'], [0, 'ต่ำ (Low) — มือถือสเปคต่ำ'], [1, 'กลาง (Medium)'], [2, 'สูง (High)']], S.quality, v => { S.quality = +v; save(); })), field('จำกัด FPS', select([[0, 'อัตโนมัติ'], [30, '30 FPS'], [60, '60 FPS']], S.fps, v => { S.fps = +v; save(); })), el('p', { class: 'muted' }, `ระดับเครื่องที่ตรวจพบ: ${['เริ่มต้น', 'กลาง', 'สูง'][Perf.tier]} · คุณภาพที่ใช้อยู่: ${['ต่ำ', 'กลาง', 'สูง'][G.quality]}${Perf.gpu ? ' · GPU: ' + Perf.gpu.slice(0, 60) : ''} — ระบบอัตโนมัติจะลดหรือเพิ่มคุณภาพตามความลื่นจริงระหว่างเล่น`),
        btn('สภาพอากาศ…', { icon: 'rain', cls: 'small', onclick: () => weatherWindow() }),
        toggle('ระบบลับ (แผงในห้องเครื่อง) — เฉพาะเจ้าของห้อง', S.secretSink !== false, v => { S.secretSink = v; save(); }),
        toggle('เปิด/ปิดไฟอัตโนมัติตามกลางวัน–กลางคืน', S.autoLights !== false, v => { S.autoLights = v; G.autoLightState = {}; save(); }),
        toggle('ลดการเคลื่อนไหว (Reduce Motion)', S.reduceMotion, v => { S.reduceMotion = v; save(); }), toggle('ปิดเงาสะท้อนน้ำ', S.noReflection, v => { S.noReflection = v; save(); }), toggle('ปิดอนุภาคเพิ่มเติม', S.noParticles, v => { S.noParticles = v; save(); }), toggle('เงาแบบเรียบง่าย', S.simpleShadows, v => { S.simpleShadows = v; save(); }), toggle('โหมดประหยัดแบตเตอรี่ (30 FPS + คุณภาพต่ำ)', S.battery, v => { S.battery = v; save(); }),
        el('p', { class: 'muted' }, 'เรนเดอร์: ' + (document.getElementById('game').getContext ? 'WebGL' : '') + ' · ภาพพิกเซลถูกขยายแบบจำนวนเต็มเพื่อความคมชัด')) },
      { label: 'เวลา', icon: 'clock', build: p => p.append(timeBox) },
      { label: 'เสียง', icon: 'volume', build: p => p.append(vol('master', 'Master Volume'), vol('ambient', 'Ambient Volume'), vol('ocean', 'Ocean Volume'), vol('ui', 'UI Volume'), vol('music', 'Music Volume')) },
      { label: 'ผู้เล่น & เซฟ', icon: 'user', build: p => p.append(acctBox, el('h4', {}, 'เซฟเกม'), saveBox) },
      { label: 'ปุ่มลัด', icon: 'info', build: p => p.append(el('ul', { class: 'keys' }, ...[['คลิก/แตะพื้น', 'เดิน'], ['คลิกวัตถุ', 'เดินไปใช้งาน'], ['กดค้าง', 'เมนูโต้ตอบ'], ['ลากหน้าจอ', 'เลื่อนกล้อง'], ['ล้อเมาส์ / หยิก 2 นิ้ว', 'ซูม'], ['A / D หรือ ← →', 'เดินซ้าย/ขวา'], ['W / S', 'ดูชั้นบน/ล่าง'], ['Tab', 'สลับตัวละคร'], ['C', 'เปิดผนังทุกห้อง'], ['M', 'แผนที่'], ['F', 'เต็มหน้าจอ']].map(([a, b]) => el('li', {}, el('kbd', {}, a), ' ' + b)))) },
    ]));
  }, { icon: 'settings', w: 440, h: 600 });
}
function creditsWindow() {
  openWindow('credits', 'เครดิต', body => body.append(el('div', { class: 'credits' },
    el('div', { class: 'logo sm', html: `ทริปท่องทะเล <span>ของเหล่าOC</span>`, 'aria-label': 'ทริปท่องทะเล ของเหล่าOC' }),
    el('p', {}, 'ภาพทั้งหมดในเกม (เรือ ห้อง ท้องฟ้า เมฆ ต้นไม้ ทะเล ตัวละครเริ่มต้น และไอคอน) วาดด้วยโค้ด Canvas / SVG / WebGL ไม่มีภาพจาก Generative AI'),
    el('p', {}, 'แนวชายฝั่ง: Natural Earth 1:50m Land (สาธารณสมบัติ) ผ่านแพ็กเกจ world-atlas'),
    el('p', {}, 'ฟอนต์: Mitr และ Noto Sans Thai (Google Fonts, SIL Open Font License)'),
    el('p', {}, 'บอทใช้ Utility AI + Finite State Machine ที่เขียนด้วยโค้ด ไม่ใช้ API ภายนอก'),
    el('p', { class: 'muted' }, 'ระบบนำทางในเกมเป็นการจำลองเพื่อความบันเทิง ไม่ใช่ข้อมูลเดินเรือจริง'))), { icon: 'star', w: 420, h: 420 });
}

/* ---------------- fullscreen ---------------- */
export function toggleFullscreen() {
  const d = document; const req = d.documentElement.requestFullscreen || d.documentElement.webkitRequestFullscreen;
  try {
    if (d.fullscreenElement || d.webkitFullscreenElement) (d.exitFullscreen || d.webkitExitFullscreen).call(d);
    else if (req) { const p = req.call(d.documentElement); p?.catch?.(() => toast('เบราว์เซอร์/หน้าต่างนี้ไม่อนุญาตโหมดเต็มหน้าจอ')); }
    else toast('อุปกรณ์นี้ไม่รองรับโหมดเต็มหน้าจอ');
  } catch { toast('เบราว์เซอร์/หน้าต่างนี้ไม่อนุญาตโหมดเต็มหน้าจอ'); }
}

// region banner: shown when the yacht enters a new coastal biome
let regionEl = null, regionT = 0, lastRegion = '';
Bus.on('region', ({ port, biome }) => {
  const key = port ? port.id : 'open'; if (key === lastRegion) return; lastRegion = key;
  if (!document.querySelector('.hud-tl')) return;
  if (!regionEl) { regionEl = el('div', { class: 'region-banner' }); document.body.append(regionEl); }
  regionEl.innerHTML = '';
  regionEl.append(el('small', {}, port ? 'เข้าสู่เขต' : 'ออกสู่'), el('b', {}, biome.th), el('small', {}, port ? `${port.th} · ${port.rg || COUNTRY_TH[port.c] || ''}` : 'ไม่มีแผ่นดินในสายตา'));
  regionEl.classList.add('show'); clearTimeout(regionT); regionT = setTimeout(() => regionEl.classList.remove('show'), 4200);
});


/* ---------------- Co-op window ---------------- */
let invitationOpened = false;
export function openRoomInvitation() {
  if (invitationOpened || !validPin(invitedPin())) return;
  invitationOpened = true;
  coopWindow();
}

async function copyRoomField(input) {
  try {
    if (navigator.clipboard) {
      await navigator.clipboard.writeText(input.value);
      toast('คัดลอกแล้ว', 'ok');
      return;
    }
  } catch { }
  input.focus();
  input.select();
  input.setSelectionRange(0, input.value.length);
  if (document.execCommand('copy')) toast('คัดลอกแล้ว', 'ok');
  else toast('เลือกลิงก์ไว้แล้ว กดค้างแล้วเลือกคัดลอก');
}

export function coopWindow() {
  if (G.screen !== 'game' || !G.player) return toast('เข้าเกมและเลือกตัวละครก่อนเปิด Co-op');
  let off;
  let refreshTimer;
  openWindow('coop', 'เล่นด้วยกัน (Co-op 2–' + MAX_PLAYERS + ' คน)', body => {
    const draw = () => {
      clearInterval(refreshTimer);
      body.replaceChildren();
      if (!Coop.active) {
        const pinIn = el('input', {
          class: 'pin-input', maxlength: '12', placeholder: 'PIN ' + PIN_LENGTH + ' ตัว',
          autocomplete: 'off', spellcheck: 'false', autocapitalize: 'characters',
          value: invitedPin(), 'aria-label': 'PIN ห้อง',
        });
        pinIn.addEventListener('input', () => {
          pinIn.value = cleanPin(pinIn.value).replace(/[^A-Z0-9]/g, '').slice(0, PIN_LENGTH);
        });
        const status = el('p', { class: 'muted', role: 'status' });
        const run = async host => {
          create.disabled = join.disabled = pinIn.disabled = true;
          status.textContent = host ? 'กำลังสร้างห้อง…' : 'กำลังเข้าห้อง…';
          try {
            if (!await (host ? Coop.create() : Coop.join(pinIn.value))) {
              status.textContent = '';
            } else if (!host && validPin(invitedPin())) {
              history.replaceState(history.state, '', location.pathname + location.search);
            }
          } finally {
            create.disabled = join.disabled = pinIn.disabled = false;
          }
        };
        const create = btn('สร้างห้องส่วนตัว', { icon: 'add', cls: 'primary', onclick: () => run(true) });
        const join = btn('เข้าร่วม', { icon: 'play', cls: 'primary' });
        join.type = 'submit';
        const form = el('form', { class: 'row wrap', onsubmit: event => { event.preventDefault(); run(false); } }, pinIn, join);
        body.append(
          el('p', { class: 'muted' }, 'เล่นกับเพื่อนผ่านอินเทอร์เน็ต ทุกคนจะควบคุม OC ของตัวเองบนเรือของโฮสต์'),
          el('h4', {}, 'สร้างห้องใหม่'), create,
          el('h4', {}, 'เข้าห้องเพื่อน'), form, status);
        return;
      }

      const pinBox = el('input', { class: 'pin-big', readonly: true, value: Coop.pin, 'aria-label': 'PIN ห้อง' });
      body.append(pinBox, el('div', { class: 'row wrap' },
        btn('คัดลอก PIN', { icon: 'copy', cls: 'small', onclick: () => copyRoomField(pinBox) }),
        btn(Coop.host ? 'ปิดห้อง' : 'ออกจากห้อง', { icon: 'logout', cls: 'small', onclick: () => Coop.leave() })));
      if (Coop.host) {
        const input = el('input', { readonly: true, value: inviteLink(Coop.pin), 'aria-label': 'ลิงก์เชิญเพื่อน' });
        body.append(el('h4', {}, 'ลิงก์เชิญเพื่อน'),
          el('div', { class: 'coop-invites' }, el('div', { class: 'row' }, input,
            btn('คัดลอกลิงก์', { icon: 'copy', cls: 'small', onclick: () => copyRoomField(input) }))));
      }
      const connection = el('p', { class: 'muted', role: 'status' });
      body.append(connection);
      const heading = el('h4');
      const list = el('div', { class: 'coop-list' });
      body.append(heading, list);
      const fill = () => {
        const status = Coop.t?.connected() ? 'เชื่อมต่อแล้ว' : 'กำลังเชื่อมต่อกลับเข้าห้อง…';
        if (connection.textContent !== status) connection.textContent = status;
        heading.textContent = 'ผู้เล่น ' + Coop.count + '/' + MAX_PLAYERS;
        list.replaceChildren(...Coop.list().map(p => el('div', { class: 'coop-row' + (p.me ? ' me' : '') },
          el('span', {}, p.name + (p.me ? ' (คุณ)' : p.oc ? ' · ' + p.oc : '')),
          el('small', { class: p.ping > 250 ? 'bad' : '' }, p.host ? 'โฮสต์' : p.ping ? p.ping + ' ms' : '—'))));
      };
      fill();
      refreshTimer = setInterval(fill, 750);
    };
    draw();
    off = Bus.on('coop', draw);
  }, { onClose: () => { off?.(); clearInterval(refreshTimer); } });
}

/* ---------------- hidden: engine-room keypad + captain's logbook ---------------- */
export function keypad(check) {
  let code = '';
  const disp = el('div', { class: 'kp-disp' }, '····');
  const show = () => { disp.textContent = (code + '····').slice(0, 4).replace(/\d/g, '•'); };
  const pad = el('div', { class: 'kp-grid' });
  let m;
  const press = d => { Audio.click?.(1300 + d * 40); if (code.length < 4) code += d; show(); if (code.length === 4) setTimeout(submit, 160); };
  const submit = () => {
    const r = check(code);
    if (r === true) { Audio.click?.(520); m?.close?.(); return; }           // accepted: closes without a word
    disp.textContent = r === 'locked' ? 'LOCK' : 'ERR'; disp.classList.add('err'); Audio.click?.(180);
    setTimeout(() => { code = ''; disp.classList.remove('err'); show(); }, 700);
  };
  for (const d of [1, 2, 3, 4, 5, 6, 7, 8, 9, 'C', 0, '⏎']) pad.append(el('button', { class: 'kp-key', onclick: () => d === 'C' ? (code = '', show()) : d === '⏎' ? (code.length === 4 && submit()) : press(d) }, String(d)));
  const body = el('div', { class: 'kp' }, el('div', { class: 'kp-label' }, 'SERVICE'), disp, pad);
  const onKey = e => { if (/^[0-9]$/.test(e.key)) { e.stopPropagation(); e.preventDefault(); press(+e.key); } else if (e.key === 'Backspace') { e.stopPropagation(); code = code.slice(0, -1); show(); } else if (e.key === 'Enter') { e.stopPropagation(); if (code.length === 4) submit(); } };
  addEventListener('keydown', onKey, true);
  m = modal({ title: 'แผงบริการ', body, onClose: () => removeEventListener('keydown', onKey, true) });
  if (G.settings.secretSink === false) { disp.textContent = 'OFF'; pad.querySelectorAll('button').forEach(b => b.disabled = true); }
}
export function logbook() {
  const pages = [
    'วันที่ 3 — ลมสงบ ทะเลเรียบ ลูกเรืออารมณ์ดี',
    'วันที่ 9 — ช่างเครื่องติดแผงบริการใหม่ในห้องเครื่อง เขาตั้งรหัสเป็น "ปีที่เรือซึ่งใครๆ ว่าไม่มีวันจม ได้จมลงในเที่ยวแรก"',
    'วันที่ 9 (ต่อ) — ผมบอกเขาว่าอย่ากดเล่นเด็ดขาด เขาหัวเราะ',
    'วันที่ 14 — ………',
  ];
  modal({ title: 'สมุดบันทึกกัปตัน', body: el('div', { class: 'logbook' }, ...pages.map(p => el('p', {}, p))) });
}


/* ---------------- Tender: its own system, independent of the big yacht's controls ---------------- */
const TENDER_TH = { standoff: 'ลอยรอห่างจากเรือใหญ่ (โหมดชูชีพ)', return_all: 'กำลังพาทุกคนกลับ', stowed: 'เก็บในโรงเก็บ', opening: 'กำลังเปิดประตูโรงเก็บ', sliding: 'กำลังเลื่อนออก', lowering: 'กำลังปล่อยลงน้ำ', floating: 'ลอยรออยู่ท้ายเรือ', cruise: 'กำลังล่องเรือ', drive: 'กำลังขับ', homing: 'กำลังกลับไปจอด', back: 'กำลังเทียบท่า', returning: 'กำลังเก็บกลับ', closing: 'กำลังปิดประตูโรงเก็บ' };
export function tenderWindow() {
  if (G.screen !== 'game') return toast('เข้าเกมก่อนจึงจะใช้เรือเล็กได้');
  openWindow('tender', 'เรือเล็ก (Tender)', body => {
    const st = el('div', { class: 'sys-state' }), acts = el('div', { class: 'tender-acts' });
    const rowB = (...b) => el('div', { class: 'row wrap' }, ...b);
    let last = '';
    const draw = () => {
      const t = G.tender, n = (t.pax?.length || 0) + (t.rider ? 1 : 0), me = t.rider === G.player?.id;
      const kn = Math.round(Math.abs(t.vx || 0) / 20 * 1.94);
      st.innerHTML = `<div>${icon('tender', 16)} สถานะ: <b>${TENDER_TH[t.state] || t.state}</b></div><div>คนบนเรือ: <b>${n}/7</b>${me ? ' · คุณเป็นคนขับ' : ''}</div>` + (t.state === 'drive' ? `<div>ความเร็ว: <b>${kn} kn</b></div>` : '');
      const sig = [t.state, me, !!t.muster, !!G.sink].join('|'); if (sig === last) return; last = sig;
      acts.innerHTML = '';
      const inGarage = ['stowed', 'opening', 'sliding', 'returning', 'closing', 'lowering'].includes(t.state);
      if (t.state === 'stowed') acts.append(rowB(btn('ปล่อยเรือเล็กลงน้ำ', { icon: 'tender', cls: 'primary', onclick: () => tenderCmd('launch') })));
      if (t.state === 'floating') acts.append(rowB(btn('ขึ้นเรือเล็ก & ขับ', { icon: 'character', cls: 'primary', onclick: () => tenderCmd('board') }), btn('เก็บเรือเล็กเข้าโรง', { icon: 'back', cls: 'small', onclick: () => tenderCmd('recall') })));
      if (me && (t.state === 'drive' || t.state === 'homing')) acts.append(rowB(btn('จอดเทียบท้ายเรือใหญ่', { icon: 'anchor', cls: 'primary', onclick: () => tenderCmd('disembark') })), el('p', { class: 'muted' }, 'ขับด้วยปุ่ม ← → หรือปุ่มบนจอ · เร็วสุดราว 27 นอต'));
      if (!inGarage && !me) acts.append(rowB(t.muster ? btn('พาทุกคนกลับขึ้นเรือใหญ่', { icon: 'back', cls: 'small', onclick: () => tenderCmd('unmuster') }) : btn('อพยพทุกคนขึ้นเรือเล็ก (โหมดชูชีพ)', { icon: 'liferaft', cls: 'small', onclick: () => tenderCmd('muster') })));
      if (t.state === 'stowed') acts.append(rowB(btn('อพยพทุกคนขึ้นเรือเล็ก (โหมดชูชีพ)', { icon: 'liferaft', cls: 'small', onclick: () => tenderCmd('muster') })));
      if (inGarage && t.state !== 'stowed') acts.append(el('p', { class: 'muted' }, 'รอสักครู่…'));
    };
    draw(); liveWindows.add(draw);
    body.append(st, acts, el('p', { class: 'muted' }, 'เรือเล็กเป็นระบบแยกจากเรือใหญ่: มีสถานะ ปุ่มสั่ง และการขับของตัวเอง ใช้ได้ทั้งเป็นเรือรับส่งและเรือชูชีพ (จุ 7 คน)'));
  }, { icon: 'tender', w: 380, h: 340 });
}


/* ---------------- emergency radio (only while the yacht is foundering) ---------------- */
export function sosWindow() {
  const disp = el('div', { class: 'kp-disp sos' }, 'VHF 16');
  const b = el('button', { class: 'kp-key sos-btn' }, 'MAYDAY · SOS');
  let m;
  const st = el('div', { class: 'sos-status' });
  const tick = () => { if (!document.body.contains(st)) return; st.textContent = G.Sink.rescueStatus?.() || ''; setTimeout(tick, 500); };
  b.onclick = () => { const r = G.Sink.sos(); Audio.click?.(r === true ? 900 : 200); disp.textContent = r === true ? 'ACK · ETA 0:18' : r === 'dead' ? '— NO POWER —' : '———'; disp.classList.toggle('err', r !== true); if (r === true) { b.disabled = true; setTimeout(tick, 50); } };
  if (G.Sink.rescue) { b.disabled = true; disp.textContent = 'ACK'; setTimeout(tick, 50); }
  m = modal({ title: 'วิทยุฉุกเฉิน', body: el('div', { class: 'kp' }, el('div', { class: 'kp-label' }, 'DISTRESS'), disp, b, st) });
}


/* ---------------- weather ---------------- */
export function weatherWindow() {
  openWindow('weather', 'สภาพอากาศ', body => {
    const S = G.settings; const save = () => { saveUIPrefs?.(); draw(); };
    const info = el('div', { class: 'sys-state', style: 'display:block' });
    const modes = el('div', { class: 'chips' }), types = el('div', { class: 'chips' });
    const draw = () => {
      const m = S.weatherMode || 'off'; modes.innerHTML = ''; types.innerHTML = '';
      for (const [k, th] of [['off', 'ปิด (อากาศดีตลอด)'], ['custom', 'กำหนดเอง'], ['real', 'ตามจริง ณ ตำแหน่งเรือ']]) modes.append(el('button', { class: 'chip' + (m === k ? ' on' : ''), onclick: () => { S.weatherMode = k; save(); } }, th));
      for (const [k, w] of Object.entries(WEATHER)) types.append(el('button', { class: 'chip' + ((S.weatherType || 'rain') === k ? ' on' : ''), disabled: m !== 'custom', onclick: () => { S.weatherType = k; save(); } }, w.th));
    };
    const live = () => { const l = Weather.label(); const i = Weather.info; info.innerHTML = `<div>ตอนนี้: <b>${l || WEATHER.clear.th}</b></div>` + (S.weatherMode === 'real' ? `<div class="muted">${Weather.src === 'live' ? 'ข้อมูลอากาศจริงจาก Open-Meteo ณ พิกัดเรือ (อัปเดตทุก 15 นาที)' : 'ดึงข้อมูลออนไลน์ไม่ได้ ใช้แบบจำลองภูมิอากาศของ' + (i?.area ? ' ' + i.area : 'พื้นที่นี้') + ' ตามวัน–เวลาจริง (มรสุม ฤดูไต้ฝุ่น พายุช่วงบ่าย หมอกเช้า)'}</div>` : ''); };
    draw(); live(); liveWindows.add(live);
    body.append(el('h4', {}, 'โหมด'), modes, el('h4', {}, 'เลือกสภาพอากาศ (โหมดกำหนดเอง)'), types, info,
      el('p', { class: 'muted' }, 'ฝนและลมมีเสียงจริง พายุมีฟ้าแลบและฟ้าร้อง ยิ่งพายุแรงคลื่นยิ่งสูงและเรือโคลงมากขึ้น ถ้าเปิดไฟอัตโนมัติไว้ ไฟจะติดเองตอนฟ้ามืดเพราะพายุ'));
  }, { icon: 'rain', w: 440, h: 460 });
}

export { ocWindow, interactWindow, inventoryWindow, musicWindow, creditsWindow };
