// Regional maritime map (Natural Earth coastlines), land-aware A* routing, autopilot / manual steering journey model.
import { clamp, makeCanvas, Bus } from './util.js';

export const PORTS = [
  // Thailand — Andaman
  { id: 'phuket', th: 'ภูเก็ต', c: 'TH', lat: 7.82, lon: 98.36, tz: 7, bi: 'andaman' , rg: 'ภาคใต้ฝั่งอันดามัน', lm: ['buddha', 'temple'], town: 'shophouse', boats: ['longtail', 'speed'] },
  { id: 'khaolak', th: 'เขาหลัก', c: 'TH', lat: 8.64, lon: 98.24, tz: 7, bi: 'andaman' , rg: 'ภาคใต้ฝั่งอันดามัน (พังงา)', lm: ['lighthouse'], boats: ['longtail'] },
  { id: 'phangnga', th: 'อ่าวพังงา (เกาะยาว)', c: 'TH', lat: 8.10, lon: 98.58, tz: 7, bi: 'andaman' , rg: 'ภาคใต้ฝั่งอันดามัน (อ่าวพังงา)', lm: [], town: 'stilt', boats: ['longtail', 'longtail'] },
  { id: 'krabi', th: 'กระบี่ (อ่าวนาง)', c: 'TH', lat: 8.02, lon: 98.80, tz: 7, bi: 'andaman' , rg: 'ภาคใต้ฝั่งอันดามัน (กระบี่)', lm: ['temple'], boats: ['longtail', 'longtail'] },
  { id: 'phiphi', th: 'เกาะพีพี', c: 'TH', lat: 7.73, lon: 98.77, tz: 7, bi: 'andaman' , rg: 'ภาคใต้ฝั่งอันดามัน (หมู่เกาะพีพี)', lm: [], boats: ['longtail', 'speed', 'speed'] },
  { id: 'lipe', th: 'เกาะหลีเป๊ะ', c: 'TH', lat: 6.48, lon: 99.30, tz: 7, bi: 'andaman' , rg: 'ภาคใต้ฝั่งอันดามัน (สตูล)', lm: [], boats: ['longtail'] },
  // Thailand — Gulf
  { id: 'samui', th: 'เกาะสมุย', c: 'TH', lat: 9.50, lon: 100.02, tz: 7, bi: 'gulf' , rg: 'ภาคใต้ฝั่งอ่าวไทย (สุราษฎร์ธานี)', lm: ['buddha', 'chedi'], boats: ['speed', 'longtail'] },
  { id: 'phangan', th: 'เกาะพะงัน', c: 'TH', lat: 9.71, lon: 100.01, tz: 7, bi: 'gulf' , rg: 'ภาคใต้ฝั่งอ่าวไทย (สุราษฎร์ธานี)', lm: [], boats: ['longtail'] },
  { id: 'kohtao', th: 'เกาะเต่า', c: 'TH', lat: 10.08, lon: 99.82, tz: 7, bi: 'gulf' , rg: 'ภาคใต้ฝั่งอ่าวไทย (เกาะเต่า)', lm: [], boats: ['longtail', 'speed'] },
  { id: 'chumphon', th: 'ชุมพร', c: 'TH', lat: 10.45, lon: 99.30, tz: 7, bi: 'gulf' , rg: 'ภาคใต้ตอนบน (ชุมพร)', lm: ['temple'], boats: ['squid', 'trawler'] },
  { id: 'huahin', th: 'หัวหิน', c: 'TH', lat: 12.57, lon: 99.97, tz: 7, bi: 'resort' , rg: 'ภาคตะวันตก (ประจวบคีรีขันธ์)', lm: ['royalstation', 'temple'], town: 'shophouse', boats: ['squid', 'sail'] },
  { id: 'songkhla', th: 'สงขลา', c: 'TH', lat: 7.21, lon: 100.60, tz: 7, bi: 'gulf' , rg: 'ภาคใต้ฝั่งอ่าวไทย (สงขลา)', lm: ['mermaid', 'chedi'], town: 'shophouse', boats: ['squid', 'trawler'] },
  { id: 'pattaya', th: 'พัทยา', c: 'TH', lat: 12.92, lon: 100.85, tz: 7, bi: 'resort' , rg: 'ภาคตะวันออก (ชลบุรี)', lm: ['sanctuary', 'pattayasign', 'buddha'], boats: ['speed', 'ferry'] },
  { id: 'sattahip', th: 'สัตหีบ', c: 'TH', lat: 12.65, lon: 100.90, tz: 7, bi: 'gulf' , rg: 'ภาคตะวันออก (ฐานทัพเรือสัตหีบ)', lm: ['carrier', 'temple'], boats: ['tug', 'trawler'] },
  { id: 'samet', th: 'เกาะเสม็ด (ระยอง)', c: 'TH', lat: 12.56, lon: 101.46, tz: 7, bi: 'gulf' , rg: 'ภาคตะวันออก (ระยอง)', lm: ['mermaid'], boats: ['speed', 'ferry'] },
  { id: 'kohchang', th: 'เกาะช้าง', c: 'TH', lat: 12.05, lon: 102.31, tz: 7, bi: 'gulf' , rg: 'ภาคตะวันออก (ตราด)', lm: [], town: 'stilt', boats: ['longtail', 'ferry'] },
  // Malaysia / Singapore / Indonesia
  { id: 'langkawi', th: 'ลังกาวี', c: 'MY', lat: 6.28, lon: 99.72, tz: 8, bi: 'andaman' , rg: 'รัฐเกอดะฮ์ มาเลเซีย', lm: ['eagle', 'skybridge'], boats: ['speed', 'ferry'] },
  { id: 'penang', th: 'ปีนัง', c: 'MY', lat: 5.40, lon: 100.36, tz: 8, bi: 'metro' , rg: 'รัฐปีนัง มาเลเซีย', lm: ['kekloksi', 'bridge'], town: 'shophouse', boats: ['ferry', 'trawler'] },
  { id: 'portklang', th: 'พอร์ตกลัง', c: 'MY', lat: 2.98, lon: 101.30, tz: 8, bi: 'metro' , rg: 'รัฐสลังงอร์ มาเลเซีย (ใกล้กัวลาลัมเปอร์)', lm: ['cranes', 'mosque'], lf: ['petronas', 'tower'], boats: ['cargo', 'tug'] },
  { id: 'tioman', th: 'เกาะติโอมัน', c: 'MY', lat: 2.82, lon: 104.17, tz: 8, bi: 'borneo' , rg: 'รัฐปะหัง มาเลเซีย', lm: [], far: 'kinabalu', boats: ['speed'] },
  { id: 'singapore', th: 'สิงคโปร์', c: 'SG', lat: 1.25, lon: 103.84, tz: 8, bi: 'metro' , rg: 'สิงคโปร์ (อ่าวมารีนา)', lm: ['mbs', 'supertree', 'merlion', 'ferris'], boats: ['cargo', 'ferry', 'tug'] },
  { id: 'bintan', th: 'เกาะบินตัน', c: 'ID', lat: 1.16, lon: 104.45, tz: 7, bi: 'philippine' , rg: 'หมู่เกาะเรียว อินโดนีเซีย', lm: ['granite'], boats: ['ferry', 'speed'] },
  { id: 'belitung', th: 'เกาะเบลีตุง', c: 'ID', lat: -2.55, lon: 107.64, tz: 7, bi: 'philippine' , rg: 'บังกาเบลีตุง อินโดนีเซีย', lm: ['granite', 'lighthouse'], boats: ['bangka'] },
  { id: 'jakarta', th: 'จาการ์ตา', c: 'ID', lat: -6.08, lon: 106.82, tz: 7, bi: 'metro' , rg: 'ชวาตะวันตก อินโดนีเซีย (จาการ์ตา)', lm: ['monas', 'mosque'], boats: ['phinisi', 'cargo'] },
  { id: 'bali', th: 'บาหลี (เบอนัว)', c: 'ID', lat: -8.76, lon: 115.24, tz: 8, bi: 'volcanic' , rg: 'บาหลี อินโดนีเซีย', lm: ['tanahlot', 'candi', 'meru'], far: 'agung', boats: ['bangka', 'phinisi'] },
  { id: 'lombok', th: 'ลอมบอก', c: 'ID', lat: -8.49, lon: 116.03, tz: 8, bi: 'volcanic' , rg: 'นูซาเติงการาตะวันตก (ลอมบอก)', lm: ['mosque'], far: 'rinjani', boats: ['bangka'] },
  { id: 'labuanbajo', th: 'ลาบวนบาโจ (โคโมโด)', c: 'ID', lat: -8.49, lon: 119.86, tz: 8, bi: 'volcanic' , rg: 'นูซาเติงการาตะวันออก (โคโมโด)', lm: [], boats: ['phinisi', 'phinisi', 'bangka'] },
  // Cambodia / Vietnam
  { id: 'sihanouk', th: 'สีหนุวิลล์', c: 'KH', lat: 10.62, lon: 103.48, tz: 7, bi: 'gulf' , rg: 'กัมพูชา (พระสีหนุ)', lm: ['khmer'], boats: ['trawler', 'squid'] },
  { id: 'phuquoc', th: 'ฟู้โกว๊ก', c: 'VN', lat: 10.21, lon: 103.95, tz: 7, bi: 'gulf' , rg: 'ภาคใต้เวียดนาม (เกียนซาง)', lm: ['cablecar'], boats: ['basket', 'squid'] },
  { id: 'vungtau', th: 'หวุงเต่า', c: 'VN', lat: 10.32, lon: 107.08, tz: 7, bi: 'vietcoast' , rg: 'ภาคใต้เวียดนาม (บ่าเสียะ–หวุงเต่า)', lm: ['christ', 'tubehouses'], boats: ['basket', 'trawler'] },
  { id: 'nhatrang', th: 'ญาจาง', c: 'VN', lat: 12.22, lon: 109.22, tz: 7, bi: 'vietcoast' , rg: 'ภาคกลางตอนใต้เวียดนาม (คั้ญฮหวา)', lm: ['cham', 'cablecar'], town: 'tubehouses', boats: ['basket', 'trawler'] },
  { id: 'danang', th: 'ดานัง', c: 'VN', lat: 16.08, lon: 108.25, tz: 7, bi: 'vietcoast' , rg: 'ภาคกลางเวียดนาม (ดานัง)', lm: ['dragonbridge', 'goldenhands', 'buddha'], town: 'tubehouses', boats: ['basket'] },
  { id: 'halong', th: 'อ่าวฮาลอง', c: 'VN', lat: 20.88, lon: 107.12, tz: 7, bi: 'halong' , rg: 'ภาคเหนือเวียดนาม (กว๋างนิญ)', lm: [], boats: ['junk', 'junk'] },
  // Borneo / Philippines
  { id: 'kk', th: 'โกตาคินาบาลู', c: 'MY', lat: 5.99, lon: 116.04, tz: 8, bi: 'borneo' , rg: 'รัฐซาบาห์ (เกาะบอร์เนียว)', lm: ['mosque'], far: 'kinabalu', town: 'nipa', boats: ['sampan'] },
  { id: 'muara', th: 'มัวรา (บรูไน)', c: 'BN', lat: 5.03, lon: 115.06, tz: 8, bi: 'borneo' , rg: 'บรูไนดารุสซาลาม', lm: ['goldmosque', 'stilt'], boats: ['sampan', 'speed'] },
  { id: 'elnido', th: 'เอลนีโด', c: 'PH', lat: 11.18, lon: 119.38, tz: 8, bi: 'philippine' , rg: 'ปาลาวัน ฟิลิปปินส์ (เอลนีโด)', lm: [], town: 'nipa', boats: ['bangka', 'bangka'] },
  { id: 'coron', th: 'โครอน', c: 'PH', lat: 12.00, lon: 120.20, tz: 8, bi: 'philippine' , rg: 'ปาลาวัน ฟิลิปปินส์ (บูซวงกา)', lm: [], town: 'nipa', boats: ['bangka'] },
  { id: 'puertoprincesa', th: 'ปวยร์โตปรินเซซา', c: 'PH', lat: 9.74, lon: 118.74, tz: 8, bi: 'philippine' , rg: 'ปาลาวัน ฟิลิปปินส์', lm: ['tower'], town: 'nipa', boats: ['bangka'] },
  { id: 'boracay', th: 'โบราไกย์', c: 'PH', lat: 11.95, lon: 121.90, tz: 8, bi: 'philippine' , rg: 'วิซายัสตะวันตก ฟิลิปปินส์ (โบราไกย์)', lm: [], town: 'nipa', boats: ['paraw', 'paraw', 'bangka'] },
  { id: 'cebu', th: 'เซบู', c: 'PH', lat: 10.29, lon: 123.92, tz: 8, bi: 'metro' , rg: 'วิซายัสกลาง ฟิลิปปินส์ (เซบู)', lm: ['bridge', 'tower'], boats: ['bangka', 'ferry'] },
  { id: 'siargao', th: 'เซียร์เกา', c: 'PH', lat: 9.85, lon: 126.05, tz: 8, bi: 'philippine' , rg: 'มินดาเนา ฟิลิปปินส์ (เซียร์เกา)', lm: ['cloud9'], town: 'nipa', boats: ['bangka'] },
  { id: 'manila', th: 'มะนิลา', c: 'PH', lat: 14.56, lon: 120.93, tz: 8, bi: 'metro' , rg: 'ลูซอน ฟิลิปปินส์ (อ่าวมะนิลา)', lm: ['tower'], lf: ['ifc', 'landmark'], boats: ['cargo', 'bangka'] },
  // China / Taiwan
  { id: 'sanya', th: 'ซานย่า (ไหหลำ)', c: 'CN', lat: 18.22, lon: 109.50, tz: 8, bi: 'ryukyu' , rg: 'มณฑลไหหลำ จีน', lm: ['guanyin'], boats: ['ferry', 'redjunk'] },
  { id: 'hongkong', th: 'ฮ่องกง', c: 'CN', lat: 22.26, lon: 114.17, tz: 8, bi: 'china' , rg: 'ฮ่องกง (อ่าววิกตอเรีย)', lm: ['ifc', 'ferris'], lf: ['ifc', 'landmark', 'tower'], boats: ['redjunk', 'ferry', 'ferry'] },
  { id: 'xiamen', th: 'เซียะเหมิน', c: 'CN', lat: 24.43, lon: 118.07, tz: 8, bi: 'china' , rg: 'มณฑลฝูเจี้ยน จีน (เซียะเหมิน)', lm: ['gulangyu', 'pagoda'], boats: ['ferry', 'redjunk'] },
  { id: 'shanghai', th: 'เซี่ยงไฮ้', c: 'CN', lat: 31.30, lon: 121.75, tz: 8, bi: 'china' , rg: 'นครเซี่ยงไฮ้ จีน (ผู่ตง)', lm: ['pearl', 'shtower'], lf: ['shtower', 'ifc', 'landmark'], boats: ['cargo', 'ferry'] },
  { id: 'qingdao', th: 'ชิงเต่า', c: 'CN', lat: 36.06, lon: 120.33, tz: 8, bi: 'china' , rg: 'มณฑลซานตง จีน (ชิงเต่า)', lm: ['zhanqiao', 'redroofs'], boats: ['trawler', 'ferry'] },
  { id: 'kaohsiung', th: 'เกาสง', c: 'TW', lat: 22.60, lon: 120.26, tz: 8, bi: 'taiwan' , rg: 'ไต้หวันตอนใต้ (เกาสง)', lm: ['sky85', 'dragontiger'], boats: ['trawler', 'cargo'] },
  { id: 'penghu', th: 'เผิงหู', c: 'TW', lat: 23.57, lon: 119.58, tz: 8, bi: 'ryukyu' , rg: 'หมู่เกาะเผิงหู ไต้หวัน', lm: ['basalt', 'lighthouse'], boats: ['trawler'] },
  { id: 'keelung', th: 'จีหลง (ไทเป)', c: 'TW', lat: 25.16, lon: 121.75, tz: 8, bi: 'taiwan' , rg: 'ไต้หวันตอนเหนือ (จีหลง)', lm: ['pagoda', 'lighthouse'], boats: ['trawler', 'ferry'] },
  // Japan / Korea
  { id: 'ishigaki', th: 'อิชิงากิ', c: 'JP', lat: 24.34, lon: 124.16, tz: 9, bi: 'ryukyu' , rg: 'หมู่เกาะยาเอยามะ โอกินาวา', lm: [], boats: ['sail', 'ferry'] },
  { id: 'naha', th: 'นาฮะ (โอกินาวา)', c: 'JP', lat: 26.21, lon: 127.65, tz: 9, bi: 'ryukyu' , rg: 'โอกินาวา ญี่ปุ่น', lm: ['shuri'], boats: ['ferry', 'sail'] },
  { id: 'kagoshima', th: 'คาโกชิมะ', c: 'JP', lat: 31.58, lon: 130.57, tz: 9, bi: 'japan' , rg: 'คิวชูตอนใต้ ญี่ปุ่น (คาโกชิมะ)', lm: ['torii'], far: 'sakurajima', boats: ['ferry', 'trawler'] },
  { id: 'nagasaki', th: 'นางาซากิ', c: 'JP', lat: 32.73, lon: 129.85, tz: 9, bi: 'japan' , rg: 'คิวชูตะวันตก ญี่ปุ่น (นางาซากิ)', lm: ['megane', 'pagoda', 'bridge'], boats: ['ferry', 'trawler'] },
  { id: 'fukuoka', th: 'ฟุกุโอกะ', c: 'JP', lat: 33.61, lon: 130.38, tz: 9, bi: 'japanmetro' , rg: 'คิวชูตอนเหนือ ญี่ปุ่น (ฟุกุโอกะ)', lm: ['fukuokatower'], boats: ['ferry', 'sail'] },
  { id: 'miyajima', th: 'มิยาจิมะ (ฮิโรชิมา)', c: 'JP', lat: 34.28, lon: 132.32, tz: 9, bi: 'japan' , rg: 'ภูมิภาคชูโงกุ ญี่ปุ่น (ฮิโรชิมา)', lm: ['torii', 'pagoda'], boats: ['ferry', 'sail'] },
  { id: 'kobe', th: 'โกเบ', c: 'JP', lat: 34.66, lon: 135.20, tz: 9, bi: 'japanmetro' , rg: 'ภูมิภาคคันไซ ญี่ปุ่น (เฮียวโงะ)', lm: ['porttower', 'bridge'], boats: ['ferry', 'cargo'] },
  { id: 'osaka', th: 'โอซาก้า', c: 'JP', lat: 34.62, lon: 135.40, tz: 9, bi: 'japanmetro' , rg: 'ภูมิภาคคันไซ ญี่ปุ่น (โอซาก้า)', lm: ['osakacastle', 'ferris'], boats: ['ferry', 'cargo'] },
  { id: 'yokohama', th: 'โยโกฮามา (โตเกียว)', c: 'JP', lat: 35.44, lon: 139.66, tz: 9, bi: 'japanmetro' , rg: 'ภูมิภาคคันโต ญี่ปุ่น (คานางาวะ)', lm: ['landmark', 'ferris'], boats: ['ferry', 'cargo', 'tug'] },
  { id: 'busan', th: 'ปูซาน', c: 'KR', lat: 35.08, lon: 129.06, tz: 9, bi: 'korea' , rg: 'เกาหลีใต้ฝั่งตะวันออกเฉียงใต้ (ปูซาน)', lm: ['haeundae', 'bridge'], boats: ['trawler', 'ferry'] },
  { id: 'jeju', th: 'เชจู', c: 'KR', lat: 33.52, lon: 126.52, tz: 9, bi: 'volcanic' , rg: 'เกาะเชจู เกาหลีใต้', lm: ['seongsan'], far: 'hallasan', boats: ['trawler', 'sail'] },
  { id: 'incheon', th: 'อินชอน', c: 'KR', lat: 37.45, lon: 126.60, tz: 9, bi: 'korea' , rg: 'เกาหลีใต้ฝั่งตะวันตก (อินชอน)', lm: ['bridge', 'haeundae'], boats: ['cargo', 'ferry'] },
];
export const portById = Object.fromEntries(PORTS.map(p => [p.id, p]));
export const COUNTRY_TH = { TH: 'ไทย', MY: 'มาเลเซีย', SG: 'สิงคโปร์', ID: 'อินโดนีเซีย', VN: 'เวียดนาม', PH: 'ฟิลิปปินส์', BN: 'บรูไน', KH: 'กัมพูชา', JP: 'ญี่ปุ่น', KR: 'เกาหลีใต้', TW: 'ไต้หวัน', CN: 'จีน (ชายฝั่ง)' };

const R_NM = 3440.065;
export function distNm(a, b) {
  const t = Math.PI / 180; const dLat = (b[0] - a[0]) * t, dLon = (b[1] - a[1]) * t;
  const s = Math.sin(dLat / 2) ** 2 + Math.cos(a[0] * t) * Math.cos(b[0] * t) * Math.sin(dLon / 2) ** 2;
  return 2 * R_NM * Math.asin(Math.min(1, Math.sqrt(s)));
}
export function bearing(a, b) {
  const t = Math.PI / 180; const y = Math.sin((b[1] - a[1]) * t) * Math.cos(b[0] * t);
  const x = Math.cos(a[0] * t) * Math.sin(b[0] * t) - Math.sin(a[0] * t) * Math.cos(b[0] * t) * Math.cos((b[1] - a[1]) * t);
  return (Math.atan2(y, x) / t + 360) % 360;
}

/* ---------------- Land grid ---------------- */
// Real line-of-sight scan of the horizon: for 72 bearings (5° each), distance in nm to the first land along that
// bearing, out to `maxNm`. Uses the coastline raster plus every port as a small island/town disc (the 0.1° raster
// misses many small islands). Infinity = open water on that bearing.
export function scanHorizon(lat, lon, maxNm = 45) {
  const N = 72, out = new Float32Array(N).fill(Infinity), t = Math.PI / 180, cl = Math.cos(lat * t);
  const near = PORTS.map(p => { const dy = (p.lat - lat) * 60, dx = (p.lon - lon) * 60 * cl, d = Math.hypot(dx, dy); return { d, b: (Math.atan2(dx, dy) / t + 360) % 360, r: p.town ? 2.2 : 1.6 }; }).filter(p => p.d < maxNm + 3);
  for (let i = 0; i < N; i++) {
    const b = i * 5, sb = Math.sin(b * t), cb = Math.cos(b * t);
    if (Geo.ready) for (let d = 0.5; d <= maxNm; d += d < 6 ? 0.5 : d < 20 ? 1 : 2) { if (Geo.isLand(lat + d / 60 * cb, lon + d / 60 * sb / cl)) { out[i] = d; break; } }
    for (const p of near) { const half = Math.atan2(p.r, Math.max(p.d, 0.3)) / t, rel = Math.abs(((b - p.b + 540) % 360) - 180); if (rel <= half + 2.5) out[i] = Math.min(out[i], Math.max(0.3, p.d - p.r)); }
  }
  let min = Infinity; for (const d of out) min = Math.min(min, d);
  return { bins: out, min };
}
export const Geo = {
  polys: null, bbox: null, res: 0.1, cols: 0, rows: 0, land: null, ready: false,
  async load() {
    const r = await fetch('data/coast.json'); if (!r.ok) throw new Error('โหลดข้อมูลแนวชายฝั่งไม่สำเร็จ (' + r.status + ')');
    const j = await r.json(); this.polys = j.polys; this.bbox = j.bbox; this.source = j.source;
    this.cols = Math.round((this.bbox.e - this.bbox.w) / this.res); this.rows = Math.round((this.bbox.n - this.bbox.s) / this.res);
    const [cv, c] = makeCanvas(this.cols, this.rows); c.fillStyle = '#000';
    for (const p of this.polys) { c.beginPath(); for (let i = 0; i < p.length; i += 2) { const x = (p[i] - this.bbox.w) / this.res, y = (this.bbox.n - p[i + 1]) / this.res; i ? c.lineTo(x, y) : c.moveTo(x, y); } c.closePath(); c.fill(); }
    const d = c.getImageData(0, 0, this.cols, this.rows).data;
    this.land = new Uint8Array(this.cols * this.rows);
    for (let i = 0; i < this.land.length; i++) this.land[i] = d[i * 4 + 3] > 110 ? 1 : 0;
    this.ready = true;
  },
  cell(lat, lon) { return [Math.floor((lon - this.bbox.w) / this.res), Math.floor((this.bbox.n - lat) / this.res)]; },
  cellLL(cx, cy) { return [this.bbox.n - (cy + 0.5) * this.res, this.bbox.w + (cx + 0.5) * this.res]; },
  isLand(lat, lon) { const [x, y] = this.cell(lat, lon); if (x < 0 || y < 0 || x >= this.cols || y >= this.rows) return false; return this.land[y * this.cols + x] === 1; },
  inRegion(lat, lon) { return lon >= this.bbox.w && lon <= this.bbox.e && lat >= this.bbox.s && lat <= this.bbox.n; },
  nearestSea(cx, cy) {
    if (!this.land[cy * this.cols + cx]) return [cx, cy];
    for (let r = 1; r < 40; r++) for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) {
      if (Math.max(Math.abs(dx), Math.abs(dy)) !== r) continue; const x = cx + dx, y = cy + dy;
      if (x >= 0 && y >= 0 && x < this.cols && y < this.rows && !this.land[y * this.cols + x]) return [x, y];
    }
    return [cx, cy];
  },
  los(a, b) { // line of sight between cells over sea
    let [x0, y0] = a; const [x1, y1] = b; const dx = Math.abs(x1 - x0), dy = Math.abs(y1 - y0), sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1; let err = dx - dy;
    for (; ;) { if (this.land[y0 * this.cols + x0]) return false; if (x0 === x1 && y0 === y1) return true; const e2 = 2 * err; if (e2 > -dy) { err -= dy; x0 += sx; } if (e2 < dx) { err += dx; y0 += sy; } }
  },
  route(from, to) { // from/to [lat,lon] -> array of [lat,lon] waypoints avoiding land
    const C = this.cols, Rw = this.rows, N = C * Rw;
    const s = this.nearestSea(...this.cell(...from)), g = this.nearestSea(...this.cell(...to));
    const si = s[1] * C + s[0], gi = g[1] * C + g[0];
    const gS = new Float32Array(N).fill(Infinity), came = new Int32Array(N).fill(-1), closed = new Uint8Array(N);
    const heap = []; const push = (i, f) => { heap.push([f, i]); let k = heap.length - 1; while (k > 0) { const p = (k - 1) >> 1; if (heap[p][0] <= heap[k][0]) break; [heap[p], heap[k]] = [heap[k], heap[p]]; k = p; } };
    const pop = () => { const top = heap[0], last = heap.pop(); if (heap.length) { heap[0] = last; let k = 0; for (; ;) { const l = 2 * k + 1, r = l + 1; let m = k; if (l < heap.length && heap[l][0] < heap[m][0]) m = l; if (r < heap.length && heap[r][0] < heap[m][0]) m = r; if (m === k) break; [heap[m], heap[k]] = [heap[k], heap[m]]; k = m; } } return top; };
    const latOf = y => this.bbox.n - (y + 0.5) * this.res;
    const h = i => { const x = i % C, y = (i / C) | 0; const cl = Math.cos(latOf(y) * Math.PI / 180); return Math.hypot((x - g[0]) * cl, y - g[1]) * this.res * 60; };
    gS[si] = 0; push(si, h(si));
    const D = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];
    let found = false, iter = 0;
    while (heap.length) {
      const [, i] = pop(); if (closed[i]) continue; closed[i] = 1; if (i === gi) { found = true; break; }
      if (++iter > 600000) break;
      const x = i % C, y = (i / C) | 0; const cl = Math.cos(latOf(y) * Math.PI / 180);
      for (const [dx, dy] of D) {
        const nx = x + dx, ny = y + dy; if (nx < 0 || ny < 0 || nx >= C || ny >= Rw) continue;
        const ni = ny * C + nx; if (this.land[ni] || closed[ni]) continue;
        if (dx && dy && (this.land[y * C + nx] || this.land[ny * C + x])) continue; // no corner cutting
        // small penalty hugging the coast keeps routes off the beach
        let pen = 0; for (const [ex, ey] of D) { const q = (ny + ey) * C + nx + ex; if (this.land[q]) { pen = 0.6; break; } }
        const cost = Math.hypot(dx * cl, dy) * this.res * 60 * (1 + pen);
        const ng = gS[i] + cost; if (ng < gS[ni]) { gS[ni] = ng; came[ni] = i; push(ni, ng + h(ni)); }
      }
    }
    if (!found) return null;
    const cells = []; for (let i = gi; i !== -1; i = came[i]) cells.push([i % C, (i / C) | 0]); cells.reverse();
    // string pulling
    const pts = [cells[0]]; let k = 0;
    while (k < cells.length - 1) { let j = cells.length - 1; while (j > k + 1 && !this.los(cells[k], cells[j])) j--; pts.push(cells[j]); k = j; }
    const out = pts.map(([x, y]) => this.cellLL(x, y));
    out[0] = from.slice(); out[out.length - 1] = this.land[gi] ? out[out.length - 1] : to.slice();
    return out;
  },
};

/* ---------------- Journey model ---------------- */
export function defaultJourney() {
  const p = portById.phuket;
  return { lat: p.lat - 0.02, lon: p.lon - 0.06, heading: 180, speed: 0, targetSpeed: 0, autopilot: false, dest: null, waypoints: [], wp: 0, distTotal: 0, distDone: 0, timeMult: 1, status: 'docked', dockedAt: 'phuket', discovered: ['phuket'], hours: 0, engine: true, rudder: 0 };
}

export class Journey {
  constructor(state) { this.s = Object.assign(defaultJourney(), state || {}); }
  toJSON() { return { ...this.s }; }
  get pos() { return [this.s.lat, this.s.lon]; }
  remaining() {
    const s = this.s; if (!s.waypoints.length) return 0;
    let d = distNm(this.pos, s.waypoints[s.wp] || this.pos);
    for (let i = s.wp; i < s.waypoints.length - 1; i++) d += distNm(s.waypoints[i], s.waypoints[i + 1]);
    return d;
  }
  eta() { const sp = this.s.speed > 0.5 ? this.s.speed : this.s.targetSpeed; return sp > 0 ? this.remaining() / sp : Infinity; }
  plan(destId, extraWaypoints = []) {
    const port = portById[destId]; if (!port) return false;
    let pts = [this.pos]; let legStart = this.pos;
    for (const w of [...extraWaypoints, [port.lat, port.lon]]) {
      const r = Geo.route(legStart, w); if (!r) return false;
      pts = pts.concat(r.slice(1)); legStart = w;
    }
    this.s.dest = destId; this.s.waypoints = pts.slice(1); this.s.wp = 0;
    this.s.distTotal = this.remaining(); this.s.distDone = 0;
    Bus.emit('journey:planned', this.s);
    return true;
  }
  start(speed = 12) { if (!this.s.waypoints.length) return false; this.s.autopilot = true; this.s.engine = true; this.s.targetSpeed = speed; this.s.status = 'sailing'; this.s.dockedAt = null; Bus.emit('journey:start'); return true; }
  stop() { this.s.targetSpeed = 0; this.s.autopilot = false; Bus.emit('journey:stop'); }
  manual() { this.s.autopilot = false; if (this.s.status === 'docked') { this.s.status = 'sailing'; this.s.dockedAt = null; } }
  fastTravel(destId) {
    const p = portById[destId]; if (!p || !this.s.discovered.includes(destId)) return false;
    Object.assign(this.s, { lat: p.lat, lon: p.lon, speed: 0, targetSpeed: 0, autopilot: false, waypoints: [], wp: 0, dest: null, status: 'docked', dockedAt: destId });
    Bus.emit('journey:arrived', p); return true;
  }
  nearestPort() { let best = null, bd = 1e9; for (const p of PORTS) { const d = distNm(this.pos, [p.lat, p.lon]); if (d < bd) { bd = d; best = p; } } return { port: best, dist: bd }; }
  update(dtReal) {
    const s = this.s;
    // speed ramp (knots per real second)
    const handOn = !s.autopilot && this.manualStep;
    if (!handOn) { const ramp = 1.2 * dtReal * Math.max(1, s.timeMult * 0.5); if (!s.engine) s.targetSpeed = 0; s.speed += clamp(s.targetSpeed - s.speed, -ramp, ramp); }
    if (s.status === 'docked') { s.speed = 0; return; }
    const hours = dtReal / 3600 * s.timeMult;
    if (s.autopilot && s.waypoints.length) {
      const tgt = s.waypoints[s.wp]; const brg = bearing(this.pos, tgt);
      let diff = ((brg - s.heading + 540) % 360) - 180; s.heading = (s.heading + clamp(diff, -30 * dtReal * s.timeMult, 30 * dtReal * s.timeMult) + 360) % 360;
      const dleft = distNm(this.pos, tgt);
      if (dleft < Math.max(0.3, s.speed * hours * 1.5)) {
        s.wp++;
        if (s.wp >= s.waypoints.length) { // arrived
          const p = portById[s.dest];
          Object.assign(s, { lat: p.lat, lon: p.lon, speed: 0, targetSpeed: 0, autopilot: false, waypoints: [], wp: 0, status: 'docked', dockedAt: p.id });
          if (!s.discovered.includes(p.id)) s.discovered.push(p.id);
          Bus.emit('journey:arrived', p); return;
        }
      }
    } else if (!s.autopilot) {
      if (this.manualStep) this.manualStep(s, dtReal); // full ship-handling model (helm.js)
      else s.heading = (s.heading + s.rudder * 12 * dtReal + 360) % 360;
    }
    const d = s.speed * hours;
    if (d !== 0) {
      const t = Math.PI / 180;
      const nlat = s.lat + (d / 60) * Math.cos(s.heading * t);
      const nlon = s.lon + (d / 60) * Math.sin(s.heading * t) / Math.cos(s.lat * t);
      if (Geo.ready && Geo.isLand(nlat, nlon)) { s.speed = 0; s.targetSpeed = 0; s.autopilot = false; if (this.onAground) this.onAground(); else Bus.emit('toast', 'หยุดเรือ: ด้านหน้าเป็นแผ่นดิน'); return; }
      if (!Geo.inRegion(nlat, nlon)) { s.speed = 0; s.targetSpeed = 0; Bus.emit('toast', 'ถึงขอบเขตพื้นที่เดินเรือของเกมแล้ว'); return; }
      s.lat = nlat; s.lon = nlon; s.distDone += Math.abs(d); s.hours += hours;
      // discover nearby ports
      const np = this.nearestPort(); if (np.dist < 8 && !s.discovered.includes(np.port.id)) { s.discovered.push(np.port.id); Bus.emit('toast', 'ค้นพบ ' + np.port.th); }
    }
  }
}

/* ---------------- Map view (canvas in a panel) ---------------- */
export class MapView {
  constructor(canvas, journey) {
    this.cv = canvas; this.ctx = canvas.getContext('2d'); this.j = journey;
    this.view = { lon: 115, lat: 16, scale: 9 }; // px per degree
    this.mode = 'select'; this.extra = []; this.hover = null; this.selected = null;
    let drag = null;
    canvas.addEventListener('pointerdown', e => { canvas.setPointerCapture(e.pointerId); drag = { x: e.clientX, y: e.clientY, lon: this.view.lon, lat: this.view.lat, moved: false }; });
    canvas.addEventListener('pointermove', e => {
      const r = canvas.getBoundingClientRect(); const mx = (e.clientX - r.left) * canvas.width / r.width, my = (e.clientY - r.top) * canvas.height / r.height;
      this.hover = this.pick(mx, my);
      if (drag) { const dx = e.clientX - drag.x, dy = e.clientY - drag.y; if (Math.hypot(dx, dy) > 4) drag.moved = true; const k = canvas.width / r.width; this.view.lon = drag.lon - dx * k / this.view.scale; this.view.lat = drag.lat + dy * k / this.view.scale; }
      this.draw();
    });
    canvas.addEventListener('pointerup', e => {
      if (drag && !drag.moved) { const r = canvas.getBoundingClientRect(); this.click((e.clientX - r.left) * canvas.width / r.width, (e.clientY - r.top) * canvas.height / r.height); }
      drag = null;
    });
    canvas.addEventListener('wheel', e => { e.preventDefault(); this.zoom(e.deltaY < 0 ? 1.2 : 1 / 1.2); }, { passive: false });
    this.pinch = null;
  }
  zoom(f) { this.view.scale = clamp(this.view.scale * f, 6, 120); this.draw(); }
  center() { this.view.lat = this.j.s.lat; this.view.lon = this.j.s.lon; this.view.scale = Math.max(this.view.scale, 20); this.draw(); }
  toXY(lat, lon) { const W = this.cv.width, H = this.cv.height; return [W / 2 + (lon - this.view.lon) * this.view.scale, H / 2 - (lat - this.view.lat) * this.view.scale]; }
  toLL(x, y) { const W = this.cv.width, H = this.cv.height; return [this.view.lat - (y - H / 2) / this.view.scale, this.view.lon + (x - W / 2) / this.view.scale]; }
  pick(x, y) { for (const p of PORTS) { const [px, py] = this.toXY(p.lat, p.lon); if (Math.hypot(px - x, py - y) < 9) return p; } return null; }
  click(x, y) {
    const p = this.pick(x, y);
    if (this.mode === 'waypoint' && !p) { const ll = this.toLL(x, y); if (Geo.isLand(...ll)) { Bus.emit('toast', 'ไม่สามารถวาง Waypoint บนแผ่นดิน'); return; } this.extra.push(ll); this.draw(); Bus.emit('map:changed'); return; }
    if (p) { this.selected = p; Bus.emit('map:select', p); this.draw(); }
  }
  draw() {
    const c = this.ctx, W = this.cv.width, H = this.cv.height;
    c.fillStyle = '#bfe3ef'; c.fillRect(0, 0, W, H);
    // graticule
    c.strokeStyle = 'rgba(80,130,160,0.18)'; c.lineWidth = 1;
    for (let lon = 90; lon <= 150; lon += 5) { const [x] = this.toXY(0, lon); c.beginPath(); c.moveTo(x, 0); c.lineTo(x, H); c.stroke(); }
    for (let lat = -10; lat <= 45; lat += 5) { const [, y] = this.toXY(lat, 0); c.beginPath(); c.moveTo(0, y); c.lineTo(W, y); c.stroke(); }
    if (Geo.polys) {
      c.fillStyle = '#f3ead6'; c.strokeStyle = '#c9b48a';
      for (const p of Geo.polys) { c.beginPath(); for (let i = 0; i < p.length; i += 2) { const [x, y] = this.toXY(p[i + 1], p[i]); i ? c.lineTo(x, y) : c.moveTo(x, y); } c.closePath(); c.fill(); c.stroke(); }
    }
    // route
    const s = this.j.s;
    if (s.waypoints.length) {
      c.strokeStyle = '#e46b4a'; c.lineWidth = 2; c.setLineDash([6, 4]); c.beginPath();
      let [x, y] = this.toXY(s.lat, s.lon); c.moveTo(x, y);
      for (let i = s.wp; i < s.waypoints.length; i++) { [x, y] = this.toXY(...s.waypoints[i]); c.lineTo(x, y); }
      c.stroke(); c.setLineDash([]);
      c.fillStyle = '#e46b4a'; for (let i = s.wp; i < s.waypoints.length - 1; i++) { [x, y] = this.toXY(...s.waypoints[i]); c.fillRect(x - 2, y - 2, 4, 4); }
    }
    if (this.preview) { c.strokeStyle = '#3e86a8'; c.lineWidth = 2; c.setLineDash([3, 3]); c.beginPath(); this.preview.forEach((pt, i) => { const [x, y] = this.toXY(...pt); i ? c.lineTo(x, y) : c.moveTo(x, y); }); c.stroke(); c.setLineDash([]); }
    for (const w of this.extra) { const [x, y] = this.toXY(...w); c.strokeStyle = '#3e86a8'; c.lineWidth = 2; c.strokeRect(x - 4, y - 4, 8, 8); }
    // ports
    c.font = '16px PixelThai, "Noto Sans Thai", sans-serif';
    for (const p of PORTS) {
      const [x, y] = this.toXY(p.lat, p.lon); if (x < -20 || y < -20 || x > W + 20 || y > H + 20) continue;
      const disc = s.discovered.includes(p.id);
      c.fillStyle = disc ? '#2f7ea6' : '#ffffff'; c.strokeStyle = '#2f5b76'; c.lineWidth = 1.5;
      c.beginPath(); c.arc(x, y, (this.selected === p || this.hover === p) ? 6 : 4, 0, Math.PI * 2); c.fill(); c.stroke();
      if (this.view.scale > 12 || this.hover === p || this.selected === p || s.dest === p.id) { c.fillStyle = '#38434A'; c.fillText(p.th, x + 7, y + 4); }
    }
    // boat
    const [bx, by] = this.toXY(s.lat, s.lon);
    c.save(); c.translate(bx, by); c.rotate(s.heading * Math.PI / 180);
    c.fillStyle = '#c48a5c'; c.strokeStyle = '#38434A'; c.lineWidth = 1.5; c.beginPath(); c.moveTo(0, -9); c.lineTo(5, 6); c.lineTo(0, 3); c.lineTo(-5, 6); c.closePath(); c.fill(); c.stroke();
    c.restore();
    c.fillStyle = 'rgba(56,67,74,0.7)'; c.font = '16px PixelThai, sans-serif'; c.fillText('แนวชายฝั่ง: Natural Earth 1:50m (สาธารณสมบัติ) — ไม่มีข้อมูลความลึก/ร่องน้ำ', 8, H - 8);
  }
}
