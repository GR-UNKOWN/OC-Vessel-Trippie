// WebGL2 presenter: uploads the low-res pixel scene + per-room light map and composites with nearest sampling.
// Falls back to WebGL1, then to Canvas2D multiply.
const VS2 = `#version 300 es
in vec2 p; out vec2 uv;
void main(){ uv = vec2(p.x*0.5+0.5, 0.5-p.y*0.5); gl_Position = vec4(p,0.,1.); }`;
const FS2 = `#version 300 es
precision mediump float;
in vec2 uv; out vec4 o;
uniform sampler2D uScene, uLight; uniform vec3 uTint; uniform float uVig, uSat;
void main(){
  vec3 c = texture(uScene, uv).rgb;
  vec3 l = texture(uLight, uv).rgb * 2.0;
  vec3 col = c * l;
  // gentle highlight roll-off so emissive windows bloom slightly warm
  col = col / (1.0 + max(col - 1.0, 0.0) * 0.6);
  float g = dot(col, vec3(0.299,0.587,0.114));
  col = mix(vec3(g), col, uSat) * uTint;
  vec2 d = uv - 0.5; col *= 1.0 - dot(d,d) * uVig;
  o = vec4(col, 1.0);
}`;
const VS1 = `attribute vec2 p; varying vec2 uv; void main(){ uv = vec2(p.x*0.5+0.5, 0.5-p.y*0.5); gl_Position = vec4(p,0.,1.); }`;
const FS1 = `precision mediump float; varying vec2 uv; uniform sampler2D uScene, uLight; uniform vec3 uTint; uniform float uVig, uSat;
void main(){ vec3 c=texture2D(uScene,uv).rgb; vec3 l=texture2D(uLight,uv).rgb*2.0; vec3 col=c*l; col=col/(1.0+max(col-1.0,0.0)*0.6);
float g=dot(col,vec3(0.299,0.587,0.114)); col=mix(vec3(g),col,uSat)*uTint; vec2 d=uv-0.5; col*=1.0-dot(d,d)*uVig; gl_FragColor=vec4(col,1.0);}`;

export class Presenter {
  constructor(canvas) {
    this.canvas = canvas; this.mode = 'none';
    let gl = canvas.getContext('webgl2', { antialias: false, alpha: false, preserveDrawingBuffer: true, powerPreference: 'low-power' });
    if (gl) this.mode = 'webgl2';
    else { gl = canvas.getContext('webgl', { antialias: false, alpha: false, preserveDrawingBuffer: true }); if (gl) this.mode = 'webgl1'; }
    if (!gl) { this.ctx = canvas.getContext('2d'); this.mode = 'canvas2d'; return; }
    this.gl = gl;
    const v2 = this.mode === 'webgl2';
    const prog = this.prog = this._program(v2 ? VS2 : VS1, v2 ? FS2 : FS1);
    gl.useProgram(prog);
    const buf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
    const loc = gl.getAttribLocation(prog, 'p'); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
    this.tScene = this._tex(); this.tLight = this._tex();
    this.u = {};
    for (const n of ['uScene', 'uLight', 'uTint', 'uVig', 'uSat']) this.u[n] = gl.getUniformLocation(prog, n);
    gl.uniform1i(this.u.uScene, 0); gl.uniform1i(this.u.uLight, 1);
    gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
  }
  _program(vs, fs) {
    const gl = this.gl;
    const mk = (t, s) => { const sh = gl.createShader(t); gl.shaderSource(sh, s); gl.compileShader(sh); if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(sh)); return sh; };
    const p = gl.createProgram(); gl.attachShader(p, mk(gl.VERTEX_SHADER, vs)); gl.attachShader(p, mk(gl.FRAGMENT_SHADER, fs)); gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p));
    return p;
  }
  _tex() {
    const gl = this.gl, t = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, t);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    return t;
  }
  resize(w, h) { if (this.canvas.width !== w || this.canvas.height !== h) { this.canvas.width = w; this.canvas.height = h; } }
  // vw/vh = used region of scene canvas
  present(scene, light, vw, vh, grade = { tint: [1, 1, 1], vig: 0.35, sat: 1 }) {
    if (this.mode === 'canvas2d') {
      const c = this.ctx; c.imageSmoothingEnabled = false;
      c.drawImage(scene, 0, 0, vw, vh, 0, 0, this.canvas.width, this.canvas.height);
      c.globalCompositeOperation = 'multiply'; c.drawImage(light, 0, 0, vw, vh, 0, 0, this.canvas.width, this.canvas.height);
      c.globalCompositeOperation = 'source-over'; return;
    }
    const gl = this.gl;
    gl.viewport(0, 0, this.canvas.width, this.canvas.height);
    gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, this.tScene);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, scene);
    gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, this.tLight);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, light);
    gl.uniform3fv(this.u.uTint, grade.tint); gl.uniform1f(this.u.uVig, grade.vig); gl.uniform1f(this.u.uSat, grade.sat);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
  }
}
