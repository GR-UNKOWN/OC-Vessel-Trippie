// OC Creator & Sprite Editor — layered drawing canvas, real file import (picker + drag/drop), transform & animation setup.
import { el, makeCanvas, clamp, hexToRgb, rgbToHex, Bus } from './util.js';
import { icon } from './icons.js';
import { btn, iconBtn, toast, modal, field, slider, select, toggle, tabs, confirmBox } from './uikit.js';
import { SPRITE_PRESETS, ANIMS, ANIM_TH, PREFS, defaultTransform, buildSprites, HEIGHT_PRESETS, CHAR_MIN, CHAR_MAX, CHAR_STD, pxToM } from './chars.js';
import { filePicker, checkImageFile, decodeImage, hasTransparency, removeBackground, detectPixelScale, scaleCanvas, trimCanvas } from './imageio.js';
import { BASE_OC } from './baseoc.js';
import { PERSONAS, REL_TYPES, LINE_CATS, lineFor } from './persona.js';
import * as Store from './store.js';
import { G } from './main.js';

const MAX_EDGE = 1024;
const PALETTE = ['#38434A', '#777A80', '#ffffff', '#F8F2E6', '#F4D7C5', '#f6d8c4', '#e9c2a6', '#c98a5c', '#8a5a3c', '#5a4034', '#C9E7F2', '#8BC6D7', '#5d8fb8', '#2f5b76', '#CBE8D6', '#86b866', '#3f7a4f', '#f2c94c', '#e9a23c', '#e46b4a', '#d8463c', '#e46b8a', '#b48ac8', '#2c2a33'];

export function openEditor(existing, slot, onSave) {
  const root = el('div', { class: 'editor-screen' });
  document.getElementById('overlay').append(root);
  const oc = existing ? structuredClone(existing) : { slot, name: 'OC ' + (slot + 1), preset: 'custom', customAR: BASE_OC.w / BASE_OC.h, transform: { ...defaultTransform(), height: 34 }, pref: 'view', mode: 'bot', sheet: null };
  oc.transform = Object.assign(defaultTransform(), oc.transform || {});
  // ---------- document ----------
  const doc = { w: 288, h: 512, layers: [], active: 0 };
  const view = { zoom: 1, ox: 0, oy: 0 };
  const tool = { name: 'brush', color: '#38434A', size: 8, opacity: 1, pressure: true, mirror: false };
  let presetSel, resSel, lastFile = null, importMode = 'fit', animTimer = null, bgMode = 'auto', scaleMode = 'auto', hRead, hSlider;
  let undo = [], redo = [], sel = null, floating = null, ref = null, refOn = true, refAlpha = 0.35;
  const sizeFor = (preset, res) => { const p = SPRITE_PRESETS[preset]; const ar = p.ar || (oc.customAR || 0.6); return [Math.max(8, Math.round(res * ar)), res]; };
  function newLayer(name, src, pixel = false) {
    const [cv, cx] = makeCanvas(doc.w, doc.h); cx.imageSmoothingEnabled = !pixel; if (src) cx.drawImage(src, 0, 0, doc.w, doc.h); cx.imageSmoothingEnabled = true;
    return { name, cv, cx, visible: true, opacity: 1 };
  }
  function resizeDoc(w, h, scaleContent = true) {
    for (const L of doc.layers) { const [cv, cx] = makeCanvas(w, h); cx.imageSmoothingEnabled = true; if (scaleContent) { const s = Math.min(w / doc.w, h / doc.h); const dw = doc.w * s, dh = doc.h * s; cx.drawImage(L.cv, (w - dw) / 2, h - dh, dw, dh); } L.cv = cv; L.cx = cx; }
    doc.w = w; doc.h = h; undo = []; redo = []; sel = null; fit(); render(); preview();
  }
  // ---------- layout ----------
  const top = el('div', { class: 'ed-top' });
  const nameIn = el('input', { type: 'text', value: oc.name, maxlength: 24, 'aria-label': 'ชื่อตัวละคร' }); nameIn.addEventListener('input', () => oc.name = nameIn.value);
  top.append(iconBtn('back', 'กลับ', () => tryClose()), el('h2', { html: icon('character', 20) + ' สร้าง / แก้ไข OC' }), nameIn, el('div', { class: 'grow' }),
    btn('ส่งออก PNG', { icon: 'download', cls: 'ghost', onclick: exportPNG }), btn('บันทึก OC', { icon: 'save', cls: 'primary', onclick: save }));
  const tools = el('div', { class: 'ed-tools', role: 'toolbar' });
  const TOOLS = [['brush', 'แปรง (B)'], ['pencil', 'ดินสอพิกเซล (P)'], ['eraser', 'ยางลบ (E)'], ['fill', 'ถังสี (G)'], ['picker', 'ดูดสี (I)'], ['select', 'เลือกพื้นที่ (M)'], ['transform', 'ย้าย/แปลง (V)'], ['pan', 'เลื่อนมุมมอง (H)']];
  const toolBtns = {};
  for (const [n, t] of TOOLS) { const b = iconBtn(n, t, () => setTool(n)); toolBtns[n] = b; tools.append(b); }
  tools.append(el('hr'));
  const mirrorB = iconBtn('mirror', 'วาดสมมาตร (Mirror)', () => { tool.mirror = !tool.mirror; mirrorB.classList.toggle('on', tool.mirror); });
  tools.append(mirrorB, iconBtn('flip', 'พลิกแนวนอน (Flip)', () => flipLayer()), iconBtn('undo', 'ย้อนกลับ (Ctrl+Z)', doUndo), iconBtn('redo', 'ทำซ้ำ (Ctrl+Y)', doRedo),
    iconBtn('zoomin', 'ซูมเข้า', () => zoomAt(1.25)), iconBtn('zoomout', 'ซูมออก', () => zoomAt(0.8)), iconBtn('target', 'พอดีจอ', () => { fit(); render(); }));
  const stage = el('div', { class: 'ed-stage' });
  const [vc, vx] = makeCanvas(10, 10); vc.className = 'ed-canvas'; vc.tabIndex = 0; stage.append(vc);
  const side = el('div', { class: 'ed-side' });
  const main = el('div', { class: 'ed-main' }, tools, stage, side);
  root.append(top, main);

  // ---------- side panels ----------
  let layerList, prevCanvas, importInfo, animPrev;
  const colorIn = el('input', { type: 'color', value: tool.color, 'aria-label': 'สี' }); colorIn.addEventListener('input', () => tool.color = colorIn.value);
  const sw = el('div', { class: 'swatches' }); for (const c of PALETTE) { const s = el('button', { class: 'sw', type: 'button', style: { background: c }, title: c, 'aria-label': 'สี ' + c }); s.onclick = () => { tool.color = c; colorIn.value = c; }; sw.append(s); }
  const sizeS = slider(1, 64, 1, tool.size, v => tool.size = v), opS = slider(5, 100, 5, 100, v => tool.opacity = v / 100);
  side.append(tabs([
    { label: 'แปรง', icon: 'brush', build: p => p.append(field('สี', el('div', { class: 'row' }, colorIn, sw)), field('ขนาดแปรง', sizeS), field('ความทึบ (Opacity)', opS), toggle('ใช้แรงกดปากกา (Pressure)', true, v => tool.pressure = v),
      el('div', { class: 'row' }, btn('ล้างเลเยอร์', { icon: 'delete', cls: 'ghost small', onclick: () => { pushUndo(); L().cx.clearRect(0, 0, doc.w, doc.h); render(); preview(); } }),
        btn('หมุน 90°', { icon: 'retry', cls: 'ghost small', onclick: rotateLayer })),
      field('ปรับขนาดเลเยอร์/พื้นที่ที่เลือก (%)', (() => { const i = el('input', { type: 'number', min: 10, max: 400, value: 100, style: { width: '80px' } }); return el('div', { class: 'row' }, i, btn('ใช้', { cls: 'small', onclick: () => scaleLayer(+i.value / 100) })); })())) },
    { label: 'เลเยอร์', icon: 'layers', build: p => { layerList = el('div', { class: 'layer-list' }); p.append(el('div', { class: 'row' }, btn('เพิ่มเลเยอร์', { icon: 'add', cls: 'small', onclick: () => { if (doc.layers.length >= 8) return toast('สูงสุด 8 เลเยอร์'); doc.layers.push(newLayer('เลเยอร์ ' + (doc.layers.length + 1))); doc.active = doc.layers.length - 1; refreshLayers(); } })), layerList, el('h4', {}, 'ภาพอ้างอิง (Reference)'), el('div', { class: 'row' }, fileButton('นำเข้าภาพอ้างอิง', 'image', f => loadRef(f)), toggle('แสดง', true, v => { refOn = v; render(); })), field('ความทึบภาพอ้างอิง', slider(5, 90, 5, 35, v => { refAlpha = v / 100; render(); }))); } },
    { label: 'นำเข้า', icon: 'upload', build: p => buildImport(p) },
    { label: 'ปรับ OC', icon: 'transform', build: p => buildTransform(p) },
    { label: 'แอนิเมชัน', icon: 'play', build: p => buildAnim(p) },
    { label: 'นิสัย', icon: 'bot', build: p => buildPersona(p) },
  ]));
  prevCanvas = el('canvas', { class: 'ed-preview', width: 160, height: 90, title: 'ขนาดจริงในเกม: เส้นแดง = เพดานห้อง, เงา = ผู้ใหญ่มาตรฐาน 1.70 ม., ขีดซ้าย = ทุก 0.5 ม.' });
  side.append(el('div', { class: 'prevbox' }, el('span', { class: 'muted' }, 'ตัวอย่างขนาดในเกม · เส้นแดง = เพดานห้อง · เงา = ผู้ใหญ่ 1.70 ม.'), prevCanvas));

  function fileButton(label, ic, onfile) { return filePicker(label, { icon: ic, cls: 'small' }, onfile); }
  // ----- import tab -----
  function buildImport(p) {
    const drop = el('div', { class: 'dropzone', html: icon('upload', 32) + '<b>ลากไฟล์ภาพมาวางที่นี่</b><small>PNG · WebP · JPG · GIF · BMP · AVIF (สูงสุด 25 MB)</small>' });
    for (const ev of ['dragenter', 'dragover']) drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add('hot'); });
    for (const ev of ['dragleave', 'drop']) drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove('hot'); });
    drop.addEventListener('drop', e => { const f = e.dataTransfer?.files?.[0]; if (f) importFile(f); });
    const pick = filePicker('เลือกไฟล์ภาพจากอุปกรณ์', { icon: 'image', cls: 'primary wide' }, importFile);
    drop.append(pick);
    importInfo = el('div', { class: 'import-info' });
    p.append(drop,
      field('การจัดวาง (Crop & Fit)', select([['fit', 'พอดีกรอบ รักษาสัดส่วน (Fit)'], ['fill', 'เต็มกรอบ ครอปส่วนเกิน (Crop)'], ['trim', 'ตัดขอบโปร่งใส + พอดีกรอบ'], ['canvas', 'ปรับขนาดผืนผ้าใบตามภาพ (Custom)']], importMode, v => importMode = v)),
      field('พื้นหลัง', select([['auto', 'อัตโนมัติ (ลบพื้นหลังถ้าภาพไม่มีความโปร่งใส)'], ['remove', 'ลบพื้นหลังสีเดียวกับมุมภาพ'], ['keep', 'คงพื้นหลังไว้']], bgMode, v => bgMode = v)),
      field('การย่อ/ขยาย', select([['auto', 'อัตโนมัติ (ตรวจจับพิกเซลอาร์ต)'], ['pixel', 'พิกเซลคมชัด (Nearest)'], ['smooth', 'ภาพวาดนุ่ม (Smooth)']], scaleMode, v => scaleMode = v)),
      importInfo);
  }
  async function importFile(file) {
    lastFile = file; importInfo.innerHTML = '';
    const fail = msg => { importInfo.innerHTML = ''; importInfo.append(el('div', { class: 'err', html: icon('info', 16) + `<span></span>` }), filePicker('เลือกไฟล์ใหม่', { icon: 'image', cls: 'small' }, importFile), btn('ลองไฟล์เดิมอีกครั้ง', { icon: 'retry', cls: 'small', onclick: () => importFile(lastFile) })); importInfo.querySelector('.err span').textContent = msg; toast(msg, 'error'); };
    const bad = checkImageFile(file); if (bad) return fail(bad);
    importInfo.append(el('div', { class: 'muted' }, 'กำลังอ่านไฟล์...'));
    let src;
    try { src = await decodeImage(file); } catch (e) { return fail(e.message); }
    importInfo.innerHTML = '';
    const ow = src.width, oh = src.height;
    const pxk = detectPixelScale(src); const pixel = scaleMode === 'pixel' || (scaleMode === 'auto' && (pxk > 1 || Math.max(ow, oh) <= 256));
    if (pxk > 1 && scaleMode !== 'smooth') src = scaleCanvas(src, ow / pxk, oh / pxk, true); // back to native pixel size
    if (Math.max(src.width, src.height) > MAX_EDGE) { const s = MAX_EDGE / Math.max(src.width, src.height); src = scaleCanvas(src, src.width * s, src.height * s, false); }
    let removed = false; if (bgMode === 'remove' || (bgMode === 'auto' && !hasTransparency(src))) { removeBackground(src); removed = true; }
    if (importMode === 'trim' || removed) src = trimCanvas(src);
    const thumb = el('img', { src: src.toDataURL(), class: 'thumb pix', alt: 'ตัวอย่างภาพที่นำเข้า' });
    importInfo.append(thumb, el('div', { class: 'ok', html: icon('check', 16) + `<span></span>` }));
    importInfo.querySelector('.ok span').textContent = `${file.name} — ${ow}×${oh}px${pxk > 1 ? ` · พิกเซลอาร์ต ×${pxk}` : ''}${removed ? ' · ลบพื้นหลังแล้ว' : ''}`;
    pushUndo(true);
    if (importMode === 'canvas') { oc.preset = 'custom'; oc.customAR = src.width / src.height; if (presetSel) presetSel.value = 'custom'; const k = pixel ? Math.max(1, Math.floor(512 / Math.max(src.width, src.height))) : 1; doc.layers = [newLayer('Sprite')]; resizeDoc(src.width * k, src.height * k, false); }
    const Ln = newLayer('นำเข้า: ' + file.name.slice(0, 14));
    const dw = doc.w, dh = doc.h; let k = importMode === 'fill' ? Math.max(dw / src.width, dh / src.height) : Math.min(dw / src.width, dh / src.height);
    if (pixel && k >= 1) k = Math.floor(k); // integer scaling keeps pixels square
    const iw = Math.round(src.width * k), ih = Math.round(src.height * k);
    Ln.cx.clearRect(0, 0, dw, dh); Ln.cx.imageSmoothingEnabled = !pixel; Ln.cx.imageSmoothingQuality = 'high';
    Ln.cx.drawImage(pixel || k >= 1 ? src : scaleCanvas(src, iw, ih, false), Math.round((dw - iw) / 2), dh - ih, iw, ih); Ln.cx.imageSmoothingEnabled = true;
    if (importMode === 'canvas') doc.layers = [Ln]; else doc.layers.push(Ln);
    doc.active = doc.layers.length - 1; refreshLayers(); render(); preview(); dirty = true; toast('นำเข้าภาพสำเร็จ', 'ok');
  }
  async function loadRef(file) { const bad = checkImageFile(file); if (bad) return toast(bad, 'error'); try { ref = await decodeImage(file); render(); toast('เพิ่มภาพอ้างอิงแล้ว (ไม่ถูกส่งออก)'); } catch (e) { toast(e.message, 'error'); } }

  // ----- transform tab -----
  // standard-height picker: presets in metres (20 px ≈ 1 m) + slider clamped to the cabin-safe range

  function heightBlock(t, hIn) {
    const cur = () => clamp(Math.round((t.height || CHAR_STD) * (t.scale || 1)), CHAR_MIN, CHAR_MAX);
    const sel = select([['', 'กำหนดเอง'], ...HEIGHT_PRESETS.map(h => [h.id, `${h.th} · ${pxToM(h.px)} ม.`])], HEIGHT_PRESETS.find(h => h.px === t.height)?.id || '', v => { const h = HEIGHT_PRESETS.find(x => x.id === v); if (!h) return; t.height = h.px; t.scale = 1; hIn.value = h.px; sync(); });
    hRead = el('div', { class: 'h-read' });
    hSlider = slider(CHAR_MIN, CHAR_MAX, 1, t.height, v => { t.height = v; hIn.value = v; sel.value = HEIGHT_PRESETS.find(h => h.px === v)?.id || ''; sync(); });
    hIn.addEventListener('change', () => { t.height = clamp(+hIn.value || CHAR_STD, CHAR_MIN, CHAR_MAX); hIn.value = t.height; sync(); });
    function sync() { const want = Math.round((t.height || CHAR_STD) * (t.scale || 1)), h = cur(); hRead.textContent = `สูงในเกม ${h} px ≈ ${pxToM(h)} ม. (มาตรฐานผู้ใหญ่ ${CHAR_STD} px = ${pxToM(CHAR_STD)} ม.)` + (want !== h ? ' — ถูกจำกัดไม่ให้เกินเพดานห้อง' : ''); hRead.classList.toggle('warn', want !== h); preview(); }
    setTimeout(sync, 0);
    return el('div', { class: 'h-block' }, field('มาตรฐานความสูง', sel), field(`ความสูง (${CHAR_MIN}–${CHAR_MAX} px)`, hSlider), hRead);
  }
  // ----- personality / relationships / dialogue tab -----
  function buildPersona(p) {
    oc.persona = PERSONAS[oc.persona] ? oc.persona : 'normal'; oc.links = oc.links || []; oc.lines = oc.lines || {};
    const sample = el('div', { class: 'persona-sample' });
    const showSample = () => { const fake = { name: oc.name, oc, slot_: oc.slot }; const other = { name: 'เพื่อน', slot_: -1 }; sample.textContent = '“' + lineFor(fake, 'greet', other) + '”  “' + lineFor(fake, 'chat', other) + '”'; };
    const chips = el('div', { class: 'chips' });
    const drawChips = () => { chips.innerHTML = ''; for (const [k, v] of Object.entries(PERSONAS)) chips.append(el('button', { class: 'chip' + (oc.persona === k ? ' on' : ''), onclick: () => { oc.persona = k; drawChips(); showSample(); } }, v.th)); };
    drawChips(); showSample();
    p.append(field('นิสัยตัวละคร', chips), el('div', { class: 'row' }, sample, btn('สุ่มตัวอย่าง', { cls: 'small', onclick: showSample })),
      field('กิจกรรมที่ชอบ (Preferred Activity)', select(Object.entries(PREFS), oc.pref, v => oc.pref = v)),
      field('โหมดเริ่มต้นบนเรือ', select([['player', 'ผู้เล่นควบคุม'], ['assisted', 'ช่วยควบคุม (Assisted)'], ['bot', 'บอทอัตโนมัติ (Autonomous)']], oc.mode, v => oc.mode = v)));
    // relationships
    const relBox = el('div', { class: 'rel-box' });
    p.append(el('h4', {}, 'ความสัมพันธ์'), el('p', { class: 'muted' }, `อ่านว่า "${oc.name || 'OC นี้'} เป็น ___ ของ …" ระบบจะตั้งฝั่งตรงข้ามให้อัตโนมัติ (เช่น เป็นพ่อ ↔ อีกฝ่ายเป็นลูก)`), relBox);
    (async () => {
      let others = [];
      try { others = (await Store.listOCs(G.session?.id)).filter(o => o.slot !== oc.slot); } catch (e) { }
      const draw = () => {
        relBox.innerHTML = '';
        if (!others.length) { relBox.append(el('p', { class: 'muted' }, 'ยังไม่มี OC ตัวอื่น — สร้าง OC เพิ่มก่อนจึงจะเชื่อมความสัมพันธ์ได้')); return; }
        oc.links = oc.links.filter(l => others.some(o => o.slot === l.to));
        oc.links.forEach((l, i) => relBox.append(el('div', { class: 'row rel-row' },
          el('span', {}, 'เป็น'), select(Object.entries(REL_TYPES).map(([k, v]) => [k, v.th]), l.type, v => l.type = v), el('span', {}, 'ของ'),
          select(others.map(o => [o.slot, o.name]), l.to, v => l.to = +v), iconBtn('delete', 'ลบ', () => { oc.links.splice(i, 1); draw(); }))));
        const free = others.filter(o => !oc.links.some(l => l.to === o.slot));
        if (free.length) relBox.append(btn('เพิ่มความสัมพันธ์', { icon: 'add', cls: 'small', onclick: () => { oc.links.push({ to: free[0].slot, type: 'friend' }); draw(); } }));
        const back = others.flatMap(o => (o.links || []).filter(l => l.to === oc.slot).map(l => `${o.name} เป็น${REL_TYPES[l.type]?.th || ''}ของ ${oc.name}`));
        if (back.length) relBox.append(el('p', { class: 'muted' }, 'จากฝั่ง OC อื่น: ' + back.join(' · ')));
      };
      draw();
    })();
    // custom dialogue
    p.append(el('h4', {}, 'บทพูดของตัวเอง'), el('p', { class: 'muted' }, 'พิมพ์ได้หลายประโยค บรรทัดละ 1 ประโยค ระบบจะสุ่มใช้แทนบทพูดของนิสัย · ใช้ {เรียก} = คำที่ใช้เรียกอีกฝ่าย (พ่อ/พี่/ที่รัก/ชื่อ), {ชื่อ} = ชื่ออีกฝ่าย, {ฉัน} = ชื่อตัวเอง'));
    for (const [k, th] of Object.entries(LINE_CATS)) {
      const ta = el('textarea', { rows: 2, maxlength: 600, placeholder: th + ' เช่น ' + (k === 'greet' ? 'หวัดดี {เรียก}!' : k === 'idle' ? 'วันนี้อยากกินหมูกระทะ' : 'พิมพ์บทพูด...') });
      ta.value = (oc.lines[k] || []).join('\n');
      ta.addEventListener('input', () => { oc.lines[k] = ta.value.split('\n').map(s => s.trim().slice(0, 80)).filter(Boolean).slice(0, 20); dirty = true; });
      p.append(field(th, ta));
    }
    p.append(el('p', { class: 'muted' }, 'บอทใช้ Utility AI + State Machine ภายในเกม ไม่ใช้ API ภายนอก'));
  }
  function buildTransform(p) {
    const t = oc.transform;
    presetSel = select(Object.entries(SPRITE_PRESETS).map(([k, v]) => [k, v.th]), oc.preset, v => { oc.preset = v; const [w, h] = sizeFor(v, +resSel.value); resizeDoc(w, h); });
    resSel = select([[64, '64 px (พิกเซลอาร์ต)'], [128, '128 px'], [256, '256 px'], [512, '512 px (แนะนำ)'], [1024, '1024 px']], doc.h <= 64 ? 64 : doc.h <= 128 ? 128 : doc.h <= 256 ? 256 : doc.h <= 512 ? 512 : 1024, v => { const [w, h] = sizeFor(oc.preset, +v); resizeDoc(w, h); });
    const arIn = el('input', { type: 'number', step: 0.05, min: 0.2, max: 3, value: oc.customAR || 0.6, style: { width: '80px' } }); arIn.addEventListener('change', () => { oc.customAR = +arIn.value; if (oc.preset === 'custom') { const [w, h] = sizeFor('custom', +resSel.value); resizeDoc(w, h); } });
    const num = (k, step, min, max) => { const i = el('input', { type: 'number', step, min, max, value: t[k] }); i.addEventListener('change', () => { t[k] = +i.value; preview(); }); return i; };
    if (!t.height) t.height = CHAR_STD; t.height = clamp(t.height, CHAR_MIN, CHAR_MAX); if (t.scale > 1.5) t.scale = 1.5;
    const wIn = num('width', 1, 0, 46), hIn = num('height', 1, CHAR_MIN, CHAR_MAX);
    hIn.addEventListener('change', () => { if (t.lockAspect && t.height) { t.width = Math.round(t.height * doc.w / doc.h); wIn.value = t.width; } });
    wIn.addEventListener('change', () => { if (t.lockAspect && t.width) { t.height = Math.round(t.width * doc.h / doc.w); hIn.value = t.height; } });
    p.append(field('ประเภท Sprite (Preset)', presetSel), field('ความละเอียดผืนผ้าใบ', resSel), field('อัตราส่วน Custom (กว้าง/สูง)', arIn),
      heightBlock(t, hIn),
      field('Scale (ถูกจำกัดตามมาตรฐานความสูง)', slider(0.5, 1.5, 0.05, Math.min(1.5, t.scale), v => { t.scale = v; preview(); })),
      el('div', { class: 'grid2' }, field('ความสูงในเกม (px)', hIn), field('ความกว้างในเกม (px, 0=ตามสัดส่วน)', wIn)),
      toggle('ล็อกอัตราส่วน (Lock Aspect Ratio)', t.lockAspect, v => { t.lockAspect = v; preview(); }),
      field('หมุน (Rotation °)', slider(-30, 30, 1, t.rotation, v => { t.rotation = v; preview(); })),
      toggle('พลิกภาพ (Flip)', t.flip, v => { t.flip = v; preview(); }),
      toggle('จัดเท้าให้ตรงพื้นอัตโนมัติ (Auto Ground Alignment)', t.autoGround, v => { t.autoGround = v; preview(); }),
      field('Ground Offset (px)', slider(-10, 10, 1, t.groundOffset, v => { t.groundOffset = v; preview(); })),
      el('div', { class: 'grid2' }, field('Collision กว้าง', num('colW', 1, 2, 60)), field('Collision สูง', num('colH', 1, 4, 100))),
      field('ความเร็วเดิน (Movement Speed)', slider(0.4, 2, 0.1, t.speed, v => t.speed = v)),
      el('div', { class: 'grid2' }, field('Pivot X (0–1)', num('pivotX', 0.05, 0, 1)), field('Z-Index', num('z', 1, -5, 5))));
  }
  // ----- animation tab -----
  function buildAnim(p) {
    const sh = oc.sheet || (oc.sheet = { cols: 0, rows: 0, fps: 6, anims: {} });
    const total = () => Math.max(1, sh.cols * sh.rows);
    const n = (k, v, on) => { const i = el('input', { type: 'number', min: 0, max: 16, value: v, style: { width: '64px' } }); i.addEventListener('change', () => on(+i.value)); return i; };
    const rows = el('div', { class: 'anim-rows' });
    const rebuild = () => { rows.innerHTML = ''; for (const a of ANIMS) { const r = sh.anims[a] || (sh.anims[a] = [0, 0]); rows.append(el('div', { class: 'row' }, el('span', { class: 'lab', style: { minWidth: '120px' } }, ANIM_TH[a]), n('s', r[0], v => r[0] = clamp(v, 0, total() - 1)), el('span', {}, 'ถึง'), n('e', r[1], v => r[1] = clamp(v, 0, total() - 1)))); } };
    rebuild();
    animPrev = el('canvas', { width: 120, height: 120, class: 'anim-prev' });
    p.append(el('p', { class: 'muted' }, 'ถ้าภาพเป็น Sprite Sheet ให้ระบุจำนวนคอลัมน์และแถว แล้วกำหนดช่วงเฟรมของแต่ละท่า (เริ่มจาก 0) — ตั้งเป็น 0 เพื่อใช้ภาพเดียว ระบบจะขยับตำแหน่งเล็กน้อยแทนการบิดภาพ'),
      el('div', { class: 'grid2' }, field('คอลัมน์', n('c', sh.cols, v => { sh.cols = v; })), field('แถว', n('r', sh.rows, v => { sh.rows = v; }))),
      field('ความเร็ว (FPS)', slider(1, 16, 1, sh.fps, v => sh.fps = v)), rows,
      btn('พรีวิวท่าเดิน', { icon: 'play', cls: 'small', onclick: () => playAnim('walk') }), animPrev);
  }
  function playAnim(name) {
    clearInterval(animTimer); const sh = oc.sheet; const comp = composite(); const cx = animPrev.getContext('2d'); cx.imageSmoothingEnabled = false;
    if (!sh || !sh.cols || !sh.rows) { cx.clearRect(0, 0, 120, 120); const k = Math.min(120 / comp.width, 120 / comp.height); let t = 0; animTimer = setInterval(() => { cx.clearRect(0, 0, 120, 120); const b = (t++ % 2) * 2; cx.drawImage(comp, (120 - comp.width * k) / 2, 120 - comp.height * k - b, comp.width * k, comp.height * k); }, 160); return; }
    const fw = comp.width / sh.cols, fh = comp.height / sh.rows; const r = sh.anims[name] || [0, 0]; let f = r[0];
    animTimer = setInterval(() => { cx.clearRect(0, 0, 120, 120); const k = Math.min(120 / fw, 120 / fh); cx.drawImage(comp, (f % sh.cols) * fw, Math.floor(f / sh.cols) * fh, fw, fh, (120 - fw * k) / 2, (120 - fh * k) / 2, fw * k, fh * k); f = f >= r[1] ? r[0] : f + 1; }, 1000 / (sh.fps || 6));
  }

  // ---------- layers UI ----------
  function refreshLayers() {
    if (!layerList) return; layerList.innerHTML = '';
    doc.layers.map((Ly, i) => ({ Ly, i })).reverse().forEach(({ Ly, i }) => {
      const row = el('div', { class: 'layer' + (i === doc.active ? ' on' : '') });
      const vis = iconBtn(Ly.visible ? 'eye' : 'eyeoff', 'แสดง/ซ่อน', () => { Ly.visible = !Ly.visible; refreshLayers(); render(); preview(); });
      const nm = el('input', { type: 'text', value: Ly.name, class: 'lname' }); nm.addEventListener('change', () => Ly.name = nm.value); nm.addEventListener('focus', () => { doc.active = i; refreshLayers(); });
      const op = el('input', { type: 'range', min: 0, max: 100, value: Ly.opacity * 100, title: 'Opacity' }); op.addEventListener('input', () => { Ly.opacity = op.value / 100; render(); preview(); });
      row.addEventListener('click', e => { if (e.target.closest('button,input')) return; doc.active = i; refreshLayers(); });
      row.append(vis, nm, op, iconBtn('show', 'ลง', () => { if (i > 0) { [doc.layers[i - 1], doc.layers[i]] = [doc.layers[i], doc.layers[i - 1]]; doc.active = i - 1; refreshLayers(); render(); } }),
        iconBtn('hide', 'ขึ้น', () => { if (i < doc.layers.length - 1) { [doc.layers[i + 1], doc.layers[i]] = [doc.layers[i], doc.layers[i + 1]]; doc.active = i + 1; refreshLayers(); render(); } }),
        iconBtn('delete', 'ลบเลเยอร์', async () => { if (doc.layers.length <= 1) return toast('ต้องมีอย่างน้อย 1 เลเยอร์'); if (!await confirmBox('ลบเลเยอร์', `ลบ "${Ly.name}" ?`, 'ลบ', true)) return; doc.layers.splice(i, 1); doc.active = clamp(doc.active, 0, doc.layers.length - 1); refreshLayers(); render(); preview(); }));
      layerList.append(row);
    });
  }
  const L = () => doc.layers[doc.active];

  // ---------- view ----------
  function fit() { const r = stage.getBoundingClientRect(); vc.width = Math.max(50, r.width | 0); vc.height = Math.max(50, r.height | 0); view.zoom = Math.min((vc.width - 40) / doc.w, (vc.height - 40) / doc.h); view.ox = (vc.width - doc.w * view.zoom) / 2; view.oy = (vc.height - doc.h * view.zoom) / 2; }
  function zoomAt(f, cx = vc.width / 2, cy = vc.height / 2) { const z = clamp(view.zoom * f, 0.05, 40); view.ox = cx - (cx - view.ox) * z / view.zoom; view.oy = cy - (cy - view.oy) * z / view.zoom; view.zoom = z; render(); }
  function composite(includeHidden = false) {
    const [c, x] = makeCanvas(doc.w, doc.h);
    for (const Ly of doc.layers) { if (!Ly.visible && !includeHidden) continue; x.globalAlpha = Ly.opacity; x.drawImage(Ly.cv, 0, 0); }
    if (floating) { x.globalAlpha = 1; x.drawImage(floating.cv, floating.x, floating.y); }
    return c;
  }
  let rafPending = false;
  function render() {
    if (rafPending) return; rafPending = true;
    requestAnimationFrame(() => {
      rafPending = false; const c = vx; c.setTransform(1, 0, 0, 1, 0, 0); c.fillStyle = '#dfe9ee'; c.fillRect(0, 0, vc.width, vc.height);
      c.save(); c.translate(view.ox, view.oy); c.scale(view.zoom, view.zoom);
      // checkerboard
      const cs = Math.max(4, Math.round(16 / view.zoom)); for (let y = 0; y < doc.h; y += cs) for (let x = 0; x < doc.w; x += cs) { c.fillStyle = ((x / cs + y / cs) & 1) ? '#f3f3f3' : '#ffffff'; c.fillRect(x, y, Math.min(cs, doc.w - x), Math.min(cs, doc.h - y)); }
      if (ref && refOn) { c.globalAlpha = refAlpha; const k = Math.min(doc.w / ref.width, doc.h / ref.height); c.imageSmoothingEnabled = true; c.drawImage(ref, (doc.w - ref.width * k) / 2, doc.h - ref.height * k, ref.width * k, ref.height * k); c.globalAlpha = 1; }
      c.imageSmoothingEnabled = view.zoom < 1;
      c.drawImage(composite(), 0, 0);
      // ground line & sheet grid
      c.strokeStyle = 'rgba(228,107,74,0.5)'; c.lineWidth = 1 / view.zoom; c.setLineDash([4 / view.zoom, 4 / view.zoom]); c.beginPath(); c.moveTo(0, doc.h - 0.5); c.lineTo(doc.w, doc.h - 0.5); c.stroke(); c.setLineDash([]);
      const sh = oc.sheet; if (sh && sh.cols > 0 && sh.rows > 0) { c.strokeStyle = 'rgba(62,134,168,0.6)'; for (let i = 1; i < sh.cols; i++) { c.beginPath(); c.moveTo(i * doc.w / sh.cols, 0); c.lineTo(i * doc.w / sh.cols, doc.h); c.stroke(); } for (let i = 1; i < sh.rows; i++) { c.beginPath(); c.moveTo(0, i * doc.h / sh.rows); c.lineTo(doc.w, i * doc.h / sh.rows); c.stroke(); } }
      if (tool.mirror) { c.strokeStyle = 'rgba(62,134,168,0.5)'; c.beginPath(); c.moveTo(doc.w / 2, 0); c.lineTo(doc.w / 2, doc.h); c.stroke(); }
      c.strokeStyle = '#38434A'; c.strokeRect(0, 0, doc.w, doc.h);
      if (sel) { c.strokeStyle = '#3e86a8'; c.setLineDash([5 / view.zoom, 3 / view.zoom]); c.strokeRect(sel.x, sel.y, sel.w, sel.h); c.setLineDash([]); }
      c.restore();
    });
  }
  let prevT = null;
  function preview() {
    clearTimeout(prevT); prevT = setTimeout(async () => {
      const cx = prevCanvas.getContext('2d'); cx.imageSmoothingEnabled = false;
      cx.fillStyle = '#c9e7f2'; cx.fillRect(0, 0, 160, 90); cx.fillStyle = '#c89a62'; cx.fillRect(0, 70, 160, 20); cx.fillStyle = '#8e6a42'; for (let x = 0; x < 160; x += 12) cx.fillRect(x, 70, 2, 20);
      try {
        const spr = await buildSprites({ ...oc, image: composite().toDataURL() });
        // 80×45 world-pixel view: floor at y=35, cabin ceiling 40 px above it, adult reference silhouette, metre ruler
        const [lc, lx] = makeCanvas(80, 45); const FL = 44;
        lx.fillStyle = '#c9e7f2'; lx.fillRect(0, 0, 80, 45); lx.fillStyle = '#c89a62'; lx.fillRect(0, FL, 80, 1);
        lx.fillStyle = '#e46b4a'; lx.fillRect(0, FL - 40, 80, 1);
        lx.fillStyle = '#7b8a94'; for (let m = 0; m <= 2; m += 0.5) { const y = FL - Math.round(m * 20); lx.fillRect(0, y, m % 1 ? 2 : 4, 1); }
        lx.fillStyle = 'rgba(56,67,74,0.28)'; const ax = 64, ah = CHAR_STD; lx.fillRect(ax - 2, FL - ah, 5, 5); lx.fillRect(ax - 4, FL - ah + 5, 9, 14); lx.fillRect(ax - 3, FL - ah + 19, 3, ah - 19); lx.fillRect(ax + 1, FL - ah + 19, 3, ah - 19);
        lx.drawImage(spr.frames[0], Math.round(34 - spr.w * (oc.transform.pivotX ?? 0.5)), FL + spr.ground - spr.h);
        cx.imageSmoothingEnabled = false; cx.drawImage(lc, 0, 0, 160, 90);
        if (hRead && spr.size) { hRead.textContent = `สูงในเกม ${spr.h} px ≈ ${pxToM(spr.h)} ม. (มาตรฐานผู้ใหญ่ ${CHAR_STD} px = ${pxToM(CHAR_STD)} ม.)` + (spr.size.clamped ? ` — ขอ ${spr.size.want} px แต่ถูกจำกัดไม่ให้เกินเพดานห้อง` : ''); hRead.classList.toggle('warn', spr.size.clamped); }
      } catch (e) { }
    }, 250);
  }

  // ---------- drawing ----------
  function toDoc(e) { const r = vc.getBoundingClientRect(); return [((e.clientX - r.left) * vc.width / r.width - view.ox) / view.zoom, ((e.clientY - r.top) * vc.height / r.height - view.oy) / view.zoom]; }
  function pushUndo(all = false) { undo.push(all ? { all: doc.layers.map(Ly => ({ ...Ly, data: Ly.cx.getImageData(0, 0, doc.w, doc.h) })), w: doc.w, h: doc.h, active: doc.active } : { i: doc.active, data: L().cx.getImageData(0, 0, doc.w, doc.h) }); if (undo.length > 30) undo.shift(); redo = []; }
  function restore(entry, stackTo) {
    if (entry.all) { stackTo.push({ all: doc.layers.map(Ly => ({ ...Ly, data: Ly.cx.getImageData(0, 0, doc.w, doc.h) })), w: doc.w, h: doc.h, active: doc.active }); doc.w = entry.w; doc.h = entry.h; doc.layers = entry.all.map(Ly => { const n = newLayer(Ly.name); n.cx.putImageData(Ly.data, 0, 0); n.visible = Ly.visible; n.opacity = Ly.opacity; return n; }); doc.active = entry.active; }
    else { const Ly = doc.layers[entry.i]; if (!Ly) return; stackTo.push({ i: entry.i, data: Ly.cx.getImageData(0, 0, doc.w, doc.h) }); Ly.cx.putImageData(entry.data, 0, 0); }
    refreshLayers(); render(); preview();
  }
  function doUndo() { commitFloating(); const e = undo.pop(); if (e) restore(e, redo); }
  function doRedo() { const e = redo.pop(); if (e) restore(e, undo); }
  function stamp(cx, x, y, size, erase, pencil) {
    cx.globalCompositeOperation = erase ? 'destination-out' : 'source-over'; cx.globalAlpha = tool.opacity; cx.fillStyle = tool.color;
    const pts = [[x, y]]; if (tool.mirror) pts.push([doc.w - x, y]);
    for (const [px, py] of pts) { if (pencil) cx.fillRect(Math.floor(px - size / 2 + 0.5), Math.floor(py - size / 2 + 0.5), Math.max(1, Math.round(size)), Math.max(1, Math.round(size))); else { cx.beginPath(); cx.arc(px, py, Math.max(0.5, size / 2), 0, Math.PI * 2); cx.fill(); } }
    cx.globalAlpha = 1; cx.globalCompositeOperation = 'source-over';
  }
  function line(cx, a, b, size, erase, pencil) {
    const d = Math.hypot(b[0] - a[0], b[1] - a[1]); const step = Math.max(0.5, pencil ? 1 : size * 0.25); const n = Math.ceil(d / step);
    for (let i = 1; i <= n; i++) stamp(cx, a[0] + (b[0] - a[0]) * i / n, a[1] + (b[1] - a[1]) * i / n, size, erase, pencil);
  }
  function floodFill(x, y) {
    x |= 0; y |= 0; if (x < 0 || y < 0 || x >= doc.w || y >= doc.h) return;
    const cx = L().cx; const id = cx.getImageData(0, 0, doc.w, doc.h); const d = id.data; const W = doc.w, H = doc.h;
    const i0 = (y * W + x) * 4; const t = [d[i0], d[i0 + 1], d[i0 + 2], d[i0 + 3]]; const [r, g, b] = hexToRgb(tool.color); const a = Math.round(255 * tool.opacity);
    if (t[0] === r && t[1] === g && t[2] === b && t[3] === a) return;
    const tol = 32; const same = i => Math.abs(d[i] - t[0]) + Math.abs(d[i + 1] - t[1]) + Math.abs(d[i + 2] - t[2]) + Math.abs(d[i + 3] - t[3]) <= tol;
    const seen = new Uint8Array(W * H); const stack = [[x, y]];
    while (stack.length) {
      let [sx, sy] = stack.pop(); while (sx >= 0 && same((sy * W + sx) * 4) && !seen[sy * W + sx]) sx--; sx++;
      let up = false, dn = false;
      while (sx < W && !seen[sy * W + sx] && same((sy * W + sx) * 4)) {
        const i = (sy * W + sx) * 4; d[i] = r; d[i + 1] = g; d[i + 2] = b; d[i + 3] = a; seen[sy * W + sx] = 1;
        if (sy > 0) { const u = ((sy - 1) * W + sx); if (!seen[u] && same(u * 4)) { if (!up) { stack.push([sx, sy - 1]); up = true; } } else up = false; }
        if (sy < H - 1) { const u = ((sy + 1) * W + sx); if (!seen[u] && same(u * 4)) { if (!dn) { stack.push([sx, sy + 1]); dn = true; } } else dn = false; }
        sx++;
      }
    }
    cx.putImageData(id, 0, 0);
  }
  function pick(x, y) { const c = composite().getContext('2d').getImageData(clamp(x | 0, 0, doc.w - 1), clamp(y | 0, 0, doc.h - 1), 1, 1).data; if (c[3] === 0) return; tool.color = rgbToHex(c[0], c[1], c[2]); colorIn.value = tool.color; toast('เลือกสี ' + tool.color); }
  function liftSelection() { if (!sel || floating) return; pushUndo(); const [fc, fx] = makeCanvas(Math.max(1, sel.w), Math.max(1, sel.h)); fx.drawImage(L().cv, -sel.x, -sel.y); L().cx.clearRect(sel.x, sel.y, sel.w, sel.h); floating = { cv: fc, x: sel.x, y: sel.y }; }
  function commitFloating() { if (!floating) return; L().cx.drawImage(floating.cv, Math.round(floating.x), Math.round(floating.y)); sel = { x: Math.round(floating.x), y: Math.round(floating.y), w: floating.cv.width, h: floating.cv.height }; floating = null; render(); preview(); }
  function flipLayer() { commitFloating(); pushUndo(); const Ly = L(); const [t, tx] = makeCanvas(doc.w, doc.h); tx.translate(doc.w, 0); tx.scale(-1, 1); tx.drawImage(Ly.cv, 0, 0); Ly.cx.clearRect(0, 0, doc.w, doc.h); Ly.cx.drawImage(t, 0, 0); render(); preview(); }
  function rotateLayer() { commitFloating(); pushUndo(); const Ly = L(); const [t, tx] = makeCanvas(doc.w, doc.h); tx.translate(doc.w / 2, doc.h / 2); tx.rotate(Math.PI / 2); tx.drawImage(Ly.cv, -doc.w / 2, -doc.h / 2); Ly.cx.clearRect(0, 0, doc.w, doc.h); Ly.cx.drawImage(t, 0, 0); render(); preview(); }
  function scaleLayer(k) {
    commitFloating(); pushUndo(); const Ly = L(); const r = sel || { x: 0, y: 0, w: doc.w, h: doc.h };
    const [t, tx] = makeCanvas(r.w, r.h); tx.drawImage(Ly.cv, -r.x, -r.y); Ly.cx.clearRect(r.x, r.y, r.w, r.h); Ly.cx.imageSmoothingEnabled = doc.h > 128;
    const nw = r.w * k, nh = r.h * k; Ly.cx.drawImage(t, r.x + (r.w - nw) / 2, r.y + (r.h - nh), nw, nh); render(); preview();
  }
  function setTool(n) { if (n !== 'transform') commitFloating(); tool.name = n; for (const k in toolBtns) toolBtns[k].classList.toggle('on', k === n); vc.style.cursor = n === 'pan' ? 'grab' : n === 'picker' ? 'copy' : 'crosshair'; }

  const pointers = new Map(); let stroke = null, pinch = null;
  vc.addEventListener('pointerdown', e => {
    vc.setPointerCapture(e.pointerId); pointers.set(e.pointerId, [e.clientX, e.clientY]);
    if (pointers.size === 2) { stroke = null; const [a, b] = [...pointers.values()]; pinch = { d: Math.hypot(a[0] - b[0], a[1] - b[1]), z: view.zoom, ox: view.ox, oy: view.oy, cx: (a[0] + b[0]) / 2, cy: (a[1] + b[1]) / 2 }; return; }
    const [x, y] = toDoc(e); const panMode = tool.name === 'pan' || e.button === 1 || spaceDown;
    if (panMode) { stroke = { pan: true, sx: e.clientX, sy: e.clientY, ox: view.ox, oy: view.oy }; return; }
    if (tool.name === 'fill') { pushUndo(); floodFill(x, y); render(); preview(); return; }
    if (tool.name === 'picker') { pick(x, y); return; }
    if (tool.name === 'select') { commitFloating(); stroke = { sel: true, x0: x, y0: y }; sel = { x: x | 0, y: y | 0, w: 0, h: 0 }; return; }
    if (tool.name === 'transform') { if (sel && !floating) liftSelection(); if (!floating) { pushUndo(); const Ly = L(); const [fc, fx] = makeCanvas(doc.w, doc.h); fx.drawImage(Ly.cv, 0, 0); Ly.cx.clearRect(0, 0, doc.w, doc.h); floating = { cv: fc, x: 0, y: 0, whole: true }; } stroke = { move: true, x0: x, y0: y, fx: floating.x, fy: floating.y }; return; }
    pushUndo();
    const pr = tool.pressure && e.pointerType === 'pen' ? (e.pressure || 0.5) * 1.6 : 1;
    stroke = { last: [x, y] }; stamp(L().cx, x, y, tool.size * pr, tool.name === 'eraser', tool.name === 'pencil'); render();
  });
  vc.addEventListener('pointermove', e => {
    if (pointers.has(e.pointerId)) pointers.set(e.pointerId, [e.clientX, e.clientY]);
    if (pinch && pointers.size === 2) { const [a, b] = [...pointers.values()]; const d = Math.hypot(a[0] - b[0], a[1] - b[1]); const r = vc.getBoundingClientRect(); const z = clamp(pinch.z * d / pinch.d, 0.05, 40); const cx = (pinch.cx - r.left) * vc.width / r.width, cy = (pinch.cy - r.top) * vc.height / r.height; view.ox = cx - (cx - pinch.ox) * z / pinch.z; view.oy = cy - (cy - pinch.oy) * z / pinch.z; view.zoom = z; render(); return; }
    if (!stroke) return;
    const [x, y] = toDoc(e);
    if (stroke.pan) { const r = vc.getBoundingClientRect(); view.ox = stroke.ox + (e.clientX - stroke.sx) * vc.width / r.width; view.oy = stroke.oy + (e.clientY - stroke.sy) * vc.height / r.height; render(); return; }
    if (stroke.sel) { sel = { x: Math.round(Math.min(x, stroke.x0)), y: Math.round(Math.min(y, stroke.y0)), w: Math.round(Math.abs(x - stroke.x0)), h: Math.round(Math.abs(y - stroke.y0)) }; render(); return; }
    if (stroke.move) { floating.x = stroke.fx + (x - stroke.x0); floating.y = stroke.fy + (y - stroke.y0); render(); return; }
    const evs = e.getCoalescedEvents ? e.getCoalescedEvents() : [e];
    for (const ev of evs) { const p = toDoc(ev); const pr = tool.pressure && ev.pointerType === 'pen' ? (ev.pressure || 0.5) * 1.6 : 1; line(L().cx, stroke.last, p, tool.size * pr, tool.name === 'eraser', tool.name === 'pencil'); stroke.last = p; }
    render();
  });
  const end = e => { pointers.delete(e.pointerId); if (pointers.size < 2) pinch = null; if (stroke && !stroke.pan && !stroke.sel) preview(); if (stroke?.move && floating?.whole) commitFloating(); if (stroke?.sel && sel && (sel.w < 2 || sel.h < 2)) sel = null; stroke = null; render(); };
  vc.addEventListener('pointerup', end); vc.addEventListener('pointercancel', end);
  vc.addEventListener('wheel', e => { e.preventDefault(); const r = vc.getBoundingClientRect(); zoomAt(e.deltaY < 0 ? 1.15 : 1 / 1.15, (e.clientX - r.left) * vc.width / r.width, (e.clientY - r.top) * vc.height / r.height); }, { passive: false });
  let spaceDown = false;
  const keys = e => {
    if (e.target.matches('input,select,textarea')) return;
    if (e.type === 'keydown' && e.code === 'Space') { spaceDown = true; e.preventDefault(); return; } if (e.type === 'keyup' && e.code === 'Space') { spaceDown = false; return; }
    if (e.type !== 'keydown') return;
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') { e.preventDefault(); e.shiftKey ? doRedo() : doUndo(); return; }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') { e.preventDefault(); doRedo(); return; }
    const m = { b: 'brush', p: 'pencil', e: 'eraser', g: 'fill', i: 'picker', m: 'select', v: 'transform', h: 'pan' }[e.key.toLowerCase()]; if (m) setTool(m);
    if (e.key === 'Enter') commitFloating(); if (e.key === 'Escape') { commitFloating(); sel = null; render(); }
  };
  addEventListener('keydown', keys); addEventListener('keyup', keys);
  const ro = new ResizeObserver(() => { fit(); render(); }); ro.observe(stage);

  // ---------- init document ----------
  (async () => {
    if (existing?.layers?.length) {
      doc.w = existing.docW; doc.h = existing.docH;
      for (const Ly of existing.layers) { const img = await decodeImage(Ly.data); const n = newLayer(Ly.name, img, true); n.visible = Ly.visible; n.opacity = Ly.opacity; doc.layers.push(n); }
    } else if (existing?.image) {
      const img = await decodeImage(existing.image); doc.w = img.width; doc.h = img.height; doc.layers.push(newLayer('Sprite', img, true));
    } else {
      // default base character (the supplied "OC HERE" figure), integer-scaled so every pixel stays square
      const s = await decodeImage(BASE_OC.url); const k = 4; doc.w = s.width * k; doc.h = s.height * k;
      doc.layers.push(newLayer('เบสตัวละคร', s, true)); doc.layers.push(newLayer('เลเยอร์วาด'));
    }
    doc.active = doc.layers.length - 1; setTool(existing ? 'brush' : 'brush'); refreshLayers(); fit(); render(); preview();
  })().catch(e => { toast('เปิดตัวแก้ไขไม่สำเร็จ: ' + e.message, 'error'); });

  // ---------- save / export / close ----------
  async function save() {
    commitFloating();
    const comp = composite();
    // reject fully transparent sprites
    const d = comp.getContext('2d').getImageData(0, 0, comp.width, comp.height).data; let any = false; for (let i = 3; i < d.length; i += 16) if (d[i]) { any = true; break; }
    if (!any) return toast('Sprite ว่างเปล่า กรุณาวาดหรือนำเข้าภาพก่อน', 'error');
    // keep stored sprites reasonable: anything above 1024px is downscaled once here
    let out = comp; if (Math.max(comp.width, comp.height) > 1024) { const k = 1024 / Math.max(comp.width, comp.height); out = scaleCanvas(comp, comp.width * k, comp.height * k, false); }
    oc.name = (oc.name || '').trim() || 'OC'; oc.image = out.toDataURL('image/png'); oc.docW = doc.w; oc.docH = doc.h;
    oc.layers = doc.layers.map(Ly => ({ name: Ly.name, visible: Ly.visible, opacity: Ly.opacity, data: Ly.cv.toDataURL('image/png') }));
    if (oc.sheet && (!oc.sheet.cols || !oc.sheet.rows)) oc.sheet = null;
    try { await buildSprites(oc); } catch (e) { return toast('ประมวลผล Sprite ไม่สำเร็จ: ' + e.message, 'error'); }
    await onSave(oc); dirty = false; close(); toast('บันทึก OC "' + oc.name + '" แล้ว', 'ok');
  }
  function exportPNG() {
    commitFloating(); const url = composite().toDataURL('image/png');
    const a = el('a', { href: url, download: (oc.name || 'oc') + '.png', class: 'btn primary' }, 'ดาวน์โหลด PNG');
    modal({ title: 'ส่งออก PNG', body: el('div', { class: 'export-png' }, el('img', { src: url, alt: 'ภาพ OC ที่ส่งออก' }), el('p', { class: 'muted' }, 'หากปุ่มดาวน์โหลดถูกบล็อกในหน้าต่างนี้ ให้คลิกขวา (หรือกดค้างบนมือถือ) ที่ภาพเพื่อบันทึก'), a) });
  }
  let dirty = true;
  async function tryClose() { if (dirty && !await confirmBox('ออกจากตัวแก้ไข', 'การเปลี่ยนแปลงที่ยังไม่บันทึกจะหายไป ต้องการออกหรือไม่?', 'ออก', true)) return; close(); }
  function close() { removeEventListener('keydown', keys); removeEventListener('keyup', keys); ro.disconnect(); clearInterval(animTimer); root.remove(); Bus.emit('editor:closed'); }
}
