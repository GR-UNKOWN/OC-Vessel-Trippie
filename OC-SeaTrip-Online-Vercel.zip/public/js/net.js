// One request exchanges the player's latest state and the other players' changes.
export const MAX_PLAYERS = 12;
export const PIN_LENGTH = 8;
export const MAX_SPRITE = 80 * 1024;
const PIN_PATTERN = /^[ABCDEFGHJKMNPQRSTUVWXYZ23456789]{8}$/;
export const validPin = value => typeof value === 'string' && PIN_PATTERN.test(value);
export const cleanPin = value => String(value || '').trim().toUpperCase().replace(/[\s-]/g, '');
export const invitedPin = () => cleanPin(new URLSearchParams(location.hash.slice(1)).get('room'));
export const inviteLink = pin => location.origin + '/#room=' + pin;

const messages = {
  'unknown-room': 'ไม่พบห้อง ตรวจสอบ PIN และให้โฮสต์เปิดห้องไว้',
  'room-full': 'ห้องเต็มแล้ว (สูงสุด 12 คนรวมโฮสต์)',
  'invalid-request': 'คำขอเข้าห้องไม่ถูกต้อง ลองรีเฟรชหน้าเกม',
  'host-left': 'โฮสต์ปิดห้องแล้ว',
  'expired': 'หมดเวลาเชื่อมต่อกลับ กรุณาเข้าห้องใหม่',
  'disconnected': 'ขาดการเชื่อมต่อ เปิด Co-op เพื่อเข้าห้องอีกครั้ง',
  'setup-required': 'ยังไม่ได้เชื่อม Upstash Redis กับโปรเจกต์ Vercel',
  'storage-unavailable': 'เซิร์ฟเวอร์ห้องตอบช้า ลองใหม่อีกครั้ง',
};
const endpoint = '/api/room';

async function exchange(payload, signal) {
  const res = await fetch(endpoint, {
    method: 'POST', body: JSON.stringify(payload),
    headers: { 'Content-Type': 'application/json' }, cache: 'no-store', signal,
  });
  const result = await res.json();
  if (!res.ok) {
    const error = new Error(messages[result.error] || messages.disconnected);
    error.code = result.error;
    throw error;
  }
  return result;
}

export async function connect({ host, pin, onPeers, onPing, onLost }) {
  let session;
  try {
    session = await exchange(host ? { op: 'create' } : { op: 'join', pin }, AbortSignal.timeout(8000));
  } catch (error) {
    throw new Error(error.code ? error.message : messages.disconnected);
  }

  const { id, token } = session;
  const credentials = { id, token, pin: session.pin };
  const peers = new Map();
  let latest = null;
  let pendingSprite;
  let lastSuccess = Date.now();
  let retry = 0;
  let stopped = false;
  let timer, request;

  function leave() {
    if (stopped) return;
    stopped = true;
    clearTimeout(timer);
    request?.abort();
    fetch(endpoint, {
      method: 'POST', body: JSON.stringify({ ...credentials, op: 'leave' }),
      headers: { 'Content-Type': 'application/json' }, keepalive: true,
    }).catch(() => {});
  }

  async function sync() {
    if (stopped) return;
    let interval = 250;
    const started = performance.now();
    const state = latest;
    const sprite = pendingSprite;
    const known = Object.fromEntries([...peers].map(([id, p]) => [id, [p.revision, p.spriteVersion]]));
    request = new AbortController();
    try {
      const last = state && sprite !== undefined ? { ...state, sp: sprite } : state;
      const result = await exchange({ ...credentials, op: 'sync', state: last, known },
        AbortSignal.any([request.signal, AbortSignal.timeout(4500)]));
      if (stopped) return;
      lastSuccess = Date.now();
      retry = 0;
      if (latest === state) latest = null;
      if (pendingSprite === sprite) pendingSprite = undefined;
      const present = new Set(result.present);
      for (const entry of result.updated) {
        const sp = peers.get(entry.id)?.state.sp;
        peers.set(entry.id, { ...entry, state: { sp, ...entry.state } });
      }
      for (const id of peers.keys()) if (!present.has(id)) peers.delete(id);
      onPeers(peers.values());
      onPing(Math.round(performance.now() - started));
      if (document.hidden) interval = 1200;
      else if (state?.p[3] === 1 || result.updated.some(p => p.state.p[3] === 1)) interval = 160;
      else if (peers.size === 0) interval = 700;
    } catch (error) {
      if (stopped) return;
      const ended = error.code === 'unknown-room' || error.code === 'expired';
      if (ended || Date.now() - lastSuccess >= 30000) {
        leave();
        onLost(error.code === 'unknown-room' ? messages['host-left'] : messages[error.code] || messages.disconnected);
        return;
      }
      interval = Math.min(2000, 350 * 2 ** retry++);
    }
    if (!stopped) timer = setTimeout(sync, Math.max(40, interval - (performance.now() - started)));
  }

  timer = setTimeout(sync, 0);
  return {
    pin: session.pin, host: session.host, connected: () => !stopped && retry === 0,
    send: state => {
      if (stopped) return false;
      if (Object.hasOwn(state, 'sp')) pendingSprite = state.sp;
      const { sp, ...snapshot } = state;
      latest = snapshot;
      return true;
    },
    peers: () => peers.values(),
    leave,
  };
}
