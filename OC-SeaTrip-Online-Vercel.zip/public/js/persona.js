// Personalities, relationships and dialogue. Lines are picked by persona + situation + relationship,
// with placeholders {ชื่อ} (other's name), {เรียก} (how the speaker addresses them) and {ฉัน} (speaker's name).

export const PERSONAS = {
  normal: { th: 'ปกติ', social: 0, explore: 0, relax: 0, speed: 1, patience: 1, chatty: 1 },
  playful: { th: 'ขี้เล่น', social: 0.2, explore: 0.15, relax: -0.05, speed: 1.1, patience: 0.8, chatty: 1.3 },
  tsundere: { th: 'ซึนเดเระ', social: 0.05, explore: 0, relax: 0.05, speed: 1, patience: 1, chatty: 1 },
  shy: { th: 'ขี้อาย', social: -0.2, explore: -0.05, relax: 0.1, speed: 0.9, patience: 1.2, chatty: 0.6 },
  calm: { th: 'สุขุม', social: -0.05, explore: -0.05, relax: 0.2, speed: 0.85, patience: 1.5, chatty: 0.7 },
  bored: { th: 'ขี้เบื่อ', social: 0.05, explore: 0.25, relax: -0.1, speed: 1, patience: 0.45, chatty: 1 },
  hyper: { th: 'ขี้ดีด', social: 0.15, explore: 0.2, relax: -0.2, speed: 1.3, patience: 0.6, chatty: 1.4 },
  joker: { th: 'ติดตลก', social: 0.25, explore: 0.05, relax: 0, speed: 1.05, patience: 0.9, chatty: 1.5 },
};

// "A is <type> of B"
export const REL_TYPES = {
  father: { th: 'พ่อ', inv: 'child', group: 'family' }, mother: { th: 'แม่', inv: 'child', group: 'family' },
  obro: { th: 'พี่ชาย', inv: 'ysib', group: 'family' }, ybro: { th: 'น้องชาย', inv: 'osib', group: 'family' },
  osis: { th: 'พี่สาว', inv: 'ysib', group: 'family' }, ysis: { th: 'น้องสาว', inv: 'osib', group: 'family' },
  bf: { th: 'แฟนหนุ่ม', inv: 'lover', group: 'love' }, gf: { th: 'แฟนสาว', inv: 'lover', group: 'love' },
  bff: { th: 'เพื่อนสนิท', inv: 'bff', group: 'bff' }, friend: { th: 'เพื่อน', inv: 'friend', group: 'friend' },
  lung: { th: 'ลุง', inv: 'niece', group: 'family' }, pa: { th: 'ป้า', inv: 'niece', group: 'family' },
  na: { th: 'น้า', inv: 'niece', group: 'family' }, aa: { th: 'อา', inv: 'niece', group: 'family' },
};
// derived (inverse) types — only used when reading links
const INV = { child: { th: 'ลูก', group: 'family' }, ysib: { th: 'น้อง', group: 'family' }, osib: { th: 'พี่', group: 'family' }, lover: { th: 'แฟน', group: 'love' }, niece: { th: 'หลาน', group: 'family' } };
export const relLabel = t => (REL_TYPES[t] || INV[t])?.th || t;
const ADDR = { father: 'พ่อ', mother: 'แม่', obro: 'พี่', osis: 'พี่', osib: 'พี่', ybro: 'น้อง', ysis: 'น้อง', ysib: 'น้อง', bf: 'ที่รัก', gf: 'ที่รัก', lover: 'ที่รัก', lung: 'ลุง', pa: 'ป้า', na: 'น้า', aa: 'อา', child: 'ลูก', niece: 'หลาน' };

export const LINE_CATS = { greet: 'ทักทาย', chat: 'คุยเล่น', reply: 'ตอบกลับ', eat: 'ตอนกิน', sleep: 'ตอนง่วง/จะนอน', wake: 'ตอนตื่น', view: 'ชมวิว', fun: 'เล่นสนุก/ออกกำลัง', idle: 'บ่นคนเดียว' };

/* relationship graph built from every OC's own links: links = [{ to: slot, type }] meaning "this OC is <type> of <to>" */
export class Relations {
  constructor() { this.map = new Map(); }
  build(ocs) {
    this.map.clear();
    const set = (a, b, type) => { if (a == null || b == null || a === b) return; const k = a + '>' + b; if (!this.map.has(k)) this.map.set(k, type); };
    for (const oc of ocs) for (const l of oc.links || []) { if (!REL_TYPES[l.type] || !ocs.some(o => o.slot === l.to)) continue; this.map.set(oc.slot + '>' + l.to, l.type); }
    // inverse view only where the other side didn't define one
    for (const oc of ocs) for (const l of oc.links || []) { const t = REL_TYPES[l.type]; if (t && ocs.some(o => o.slot === l.to)) set(l.to, oc.slot, t.inv); }
  }
  // what A is to B ("father"), or null
  of(a, b) { return this.map.get(a + '>' + b) || null; }
  group(a, b) { const t = this.of(a, b) || this.of(b, a); return t ? (REL_TYPES[t] || INV[t]).group : null; }
  list(slot) { const out = []; for (const [k, t] of this.map) { const [a, b] = k.split('>').map(Number); if (a === slot) out.push({ to: b, type: t }); } return out; }
}
// how speaker addresses target: by what target is to the speaker
export function addressOf(rel, speaker, target) {
  const t = rel?.of(target.slot_, speaker.slot_);
  return (t && ADDR[t]) || target.name;
}

const L = (s) => s.split('|');
// generic lines per persona; each category picks randomly
const BANK = {
  normal: { greet: L('สวัสดี {เรียก}|ไง {เรียก} เป็นไงบ้าง|หวัดดีจ้า'), chat: L('วันนี้ทะเลสวยดีนะ|เดี๋ยวจะไปไหนกันต่อ|อากาศกำลังดีเลย|กินข้าวยัง {เรียก}'), reply: L('ใช่ๆ|ก็ดีนะ|เห็นด้วย|อืม จริงด้วย'), eat: L('อร่อยดี|อิ่มแล้ว|หิวพอดีเลย'), sleep: L('ง่วงแล้ว ไปนอนก่อนนะ|ฝันดี'), wake: L('อรุณสวัสดิ์|ตื่นแล้ว~'), view: L('วิวสวยจัง|ลมเย็นดี'), fun: L('สนุกดี|เหนื่อยนิดหน่อย'), idle: L('ทำอะไรดีน้า|เงียบดีจัง') },
  playful: { greet: L('เย้ {เรียก} มาแล้ว!|แอบมาจากข้างหลัง~ จ๊ะเอ๋!|ไปเล่นกัน {เรียก}!'), chat: L('แข่งวิ่งรอบเรือกันมั้ย|เดาสิว่าฉันซ่อนขนมไว้ไหน|มาถ่ายรูปกันเถอะ!'), reply: L('ฮ่าๆ ได้เลย!|ไปๆๆ|เอาสิ!'), eat: L('ขอชิมของ {เรียก} คำนึงนะ|อร่อยยย'), sleep: L('ยังไม่อยากนอนเลย...|แค่งีบแป๊บเดียวนะ'), wake: L('ตื่นแล้ว! วันนี้เล่นอะไรดี'), view: L('ปลาโลมาอยู่ไหนน้า|ว้าว ดูนั่นสิ!'), fun: L('อีกรอบ! อีกรอบ!|สนุกสุดๆ'), idle: L('เบื่อแล้ว ใครว่างบ้าง~|ลัลลา~') },
  tsundere: { greet: L('ห-หวัดดี... ไม่ได้รอนะ!|อ้าว {เรียก} มาทำไมเนี่ย|ก็... ดีใจนิดหน่อยแหละที่เจอ'), chat: L('ไม่ได้เป็นห่วงหรอกนะ แค่ถามเฉยๆ|อย่าเข้าใจผิดล่ะ!|ช-ช่างเถอะ ไม่มีอะไร'), reply: L('ฮึ่ม ก็ได้|ไม่ได้อยากคุยด้วยหรอก... แต่ก็ได้|บ-บ้าน่ะ!'), eat: L('ไม่ได้ทำเผื่อหรอกนะ แค่ทำเกิน|ก็... อร่อยแหละ'), sleep: L('จะนอนแล้ว อย่ามากวน!|ฝันดี... ไม่ได้พูดนะ!'), wake: L('ตื่นเองได้ ไม่ต้องมาปลุก!'), view: L('ก็สวยดีแหละ... นิดนึง'), fun: L('ไม่ได้สนุกสักหน่อย!|ฮึ เล่นอีกรอบก็ได้'), idle: L('ไม่มีใครสนใจเลยเหรอ... ไม่ได้น้อยใจนะ!|ฮึ่ม') },
  shy: { greet: L('อ-อ่า... สวัสดี {เรียก}|...หวัดดีค่ะ/ครับ|(โบกมือเบาๆ)'), chat: L('ข-ขอโทษที่รบกวนนะ|วันนี้... อากาศดีเนอะ|...'), reply: L('อ-อืม|(พยักหน้า)|จ-จริงเหรอ'), eat: L('ขอบคุณนะ... อร่อยมาก'), sleep: L('ไปนอนก่อนนะ...'), wake: L('...อรุณสวัสดิ์'), view: L('ที่นี่เงียบดี ชอบจัง'), fun: L('ส-สนุกดีนะ'), idle: L('...|(แอบมองทะเล)') },
  calm: { greet: L('สวัสดี {เรียก} วันนี้เป็นอย่างไรบ้าง|ยินดีที่ได้พบ'), chat: L('ทะเลสงบดีนะ|ค่อยเป็นค่อยไป ไม่ต้องรีบ|ชาร้อนสักแก้วไหม'), reply: L('เป็นความคิดที่ดี|อืม... น่าสนใจ|ใจเย็นๆ นะ'), eat: L('รสชาติกลมกล่อมดี'), sleep: L('ได้เวลาพักผ่อนแล้ว'), wake: L('เช้าที่สดชื่น'), view: L('แสงบนผิวน้ำงามมาก|ลมทะเลช่วยให้ใจสงบ'), fun: L('ออกกำลังพอดีๆ ก็ดี'), idle: L('...(หายใจลึกๆ)|เงียบสงบดี') },
  bored: { greet: L('อ้าว {เรียก}|เออ หวัดดี'), chat: L('เบื่ออะ มีอะไรทำมั้ย|ไปที่อื่นกันเถอะ|อีกนานมั้ยกว่าจะถึง'), reply: L('อืม... ก็ได้|แล้วไงต่อ|ฮ้าว~'), eat: L('กินอีกแล้วเหรอ... ก็ได้'), sleep: L('นอนดีกว่า ไม่มีอะไรทำ'), wake: L('วันใหม่... เหมือนเดิม'), view: L('ทะเลอีกแล้ว...|ก็สวยแหละ แต่เห็นทุกวัน'), fun: L('เบื่อแล้ว เปลี่ยนเถอะ'), idle: L('เบื่อออ|ทำอะไรดีวะ...|ฮ้าววว') },
  hyper: { greet: L('{เรียก}!!! มาแล้วๆๆ!|เย้ๆๆ เจอกันอีกแล้ว!'), chat: L('วันนี้พลังเต็มร้อย!!|ไปว่ายน้ำกัน! ไปฟิตเนส! ไปทุกที่!|รู้มั้ยๆๆ เมื่อกี้เห็นปลากระโดดด้วย!!'), reply: L('ใช่เลยยย!!|เอาๆๆๆ!|ว้ายยย จริงดิ!'), eat: L('อร่อยมากกก!|ขออีกจาน!!'), sleep: L('ยังไม่ง่วงเลย... หาว... ง่วงนิดนึง'), wake: L('ตื่นแล้ววว! พร้อมลุย!'), view: L('ว้าววว!! สวยมากกก!'), fun: L('เร็วอีก! แรงอีก!|สุดยอดดด!'), idle: L('อยู่เฉยไม่ได้แล้ว!|ดึ๋งๆๆ') },
  joker: { greet: L('ว่าไง {เรียก} หน้าบานเชียว|มาแล้วตัวตึง~'), chat: L('รู้มั้ยทำไมปลาไม่เล่นเน็ต... กลัวติดเบ็ด|กัปตันบอกว่าวันนี้คลื่นลมสงบ... ยกเว้นท้องฉัน|เรือลำนี้ใหญ่มาก หลงทางไปห้องน้ำสามรอบแล้ว'), reply: L('ฮ่าๆๆๆ|ตลกตัวเองอีกแล้ว|มุกนี้ห้าดาว'), eat: L('อาหารอร่อยจนลืมว่าลดน้ำหนักอยู่'), sleep: L('ไปนอนแล้ว อย่าแอบกินขนมฉันล่ะ'), wake: L('ตื่นแล้ว หล่อ/สวยเหมือนเดิม'), view: L('วิวสวยเกือบเท่าหน้าฉันเลย'), fun: L('กล้ามขึ้นยัง ดูหน่อยสิ'), idle: L('เล่ามุกให้ทะเลฟังดีกว่า|ฮัมเพลงไปเรื่อย~') },
};
// relationship-flavoured openers (override generic greet/chat sometimes)
const REL_LINES = {
  family: { greet: L('{เรียก} กินข้าวยัง|{เรียก} อยู่นี่เอง|{เรียก} วันนี้เหนื่อยมั้ย'), chat: L('{เรียก} จำทริปครั้งก่อนได้มั้ย|คิดถึงบ้านนิดนึงนะ {เรียก}|เดี๋ยวช่วยกันทำกับข้าวนะ {เรียก}') },
  love: { greet: L('ที่รัก~|มาแล้วเหรอ คิดถึงนะ|อยู่นี่เอง ตามหาตั้งนาน'), chat: L('ไปดูพระอาทิตย์ตกด้วยกันนะ|วันนี้ดูดีจัง|อยู่ด้วยกันแบบนี้นานๆ นะ') },
  bff: { greet: L('แก! มาพอดีเลย|เพื่อนรักกก'), chat: L('มีเรื่องจะเล่าให้ฟัง!|เดี๋ยวคืนนี้คุยกันยาวๆ|จำตอนนั้นได้มั้ย ฮ่าๆ') },
};
const TSUN_LOVE = L('ม-ไม่ได้คิดถึงหรอกนะ ที่รัก...|อย่ามาใกล้นักสิ! ...แต่ก็อยู่ได้');

const pick = a => a[(Math.random() * a.length) | 0];
const fill = (s, me, other, rel) => s.replace(/\{เรียก\}/g, other ? addressOf(rel, me, other) : '').replace(/\{ชื่อ\}/g, other?.name || '').replace(/\{ฉัน\}/g, me.name).replace(/\s+$/, '');
export function lineFor(me, cat, other = null, rel = null) {
  const custom = me.oc?.lines?.[cat]?.filter(s => s && s.trim());
  // custom lines from the player take priority most of the time
  if (custom?.length && Math.random() < 0.75) return fill(pick(custom), me, other, rel);
  const p = PERSONAS[me.oc?.persona] ? me.oc.persona : 'normal';
  const grp = other && rel ? rel.group(me.slot_, other.slot_) : null;
  if (grp === 'love' && p === 'tsundere' && (cat === 'greet' || cat === 'chat') && Math.random() < 0.6) return fill(pick(TSUN_LOVE), me, other, rel);
  if (grp && REL_LINES[grp]?.[cat] && Math.random() < 0.55) return fill(pick(REL_LINES[grp][cat]), me, other, rel);
  const bank = BANK[p][cat] || BANK.normal[cat] || BANK.normal.chat;
  return fill(pick(bank), me, other, rel);
}
export const personaOf = ch => PERSONAS[ch.oc?.persona] || PERSONAS.normal;
