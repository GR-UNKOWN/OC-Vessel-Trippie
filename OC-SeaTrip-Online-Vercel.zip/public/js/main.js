// Game bootstrap, state store, fixed-timestep loop, input, camera and save integration.
import { Bus, clamp, lerp, uid, sleep } from './util.js';
import * as Store from './store.js';
import { Presenter } from './gl.js';
import { Scene } from './scene.js';
import { TENDER, YW, YH, WL, LEVELS, LEVEL_ORDER, ROOMS, OBJECTS, FIXTURES, PADS, SPEC, YACHTS, setYacht, defaultPaint, roomAt, roomTop } from './yacht.js';
import { Heli, PPM } from './heli.js';
import { Party, Character, buildSprites, drawChar, defaultTransform } from './chars.js';
import { Clock, solarPosition } from './timesys.js';
import { Geo, Journey, PORTS, distNm, scanHorizon } from './navmap.js';
import { Audio, Music, parseMusicURL } from './audio.js';
import { BASE_OC } from './baseoc.js';
import { CONFIG } from './config.js';
import * as UI from './ui.js';
import { Relations } from './persona.js';
import { Coop } from './coop.js';
import { fallOverboard, swimInput, updateWater, drawWater, remoteShark, splashAt } from './water.js';
import { Sink, SINK_CODE } from './sink.js';
import { Weather } from './weather.js';
import { Helm, helmFollowAuto } from './helm.js';

const DEFAULT_SETTINGS = { qv: 2, autoLights: true, heliLivery: 'skyblue', quality: -1, fps: 0, reduceMotion: false, noReflection: false, noParticles: false, simpleShadows: false, battery: false, zoom: 0, uiCollapsed: false, autoWalk: false };
const INVENTORY = { plant: 3, rug: 2, painting: 2, lantern: 3, books: 1, cushion: 4, surfboard: 1, guitar: 1 };

export const G = {
  screen: 'loading', time: 0, dt: 0, session: null, ocs: [], party: null, player: null,
  yachtId: 'southcozy', fleet: null, heli: null, heliCam: false, flying: false, heliPad: 'heli', lifeboats: [],
  paint: defaultPaint('southcozy'), paintPresets: [], decor: [], lights: {}, relationships: {},
  clock: new Clock(), journey: new Journey(), settings: { ...DEFAULT_SETTINGS }, inventory: { ...INVENTORY },
  cam: { x: 350, y: 150, scale: 4, follow: true, tx: 350, ty: 150 }, env: { sunElev: 30, sunAz: 120, heading: 180, speed: 0, scroll: 0, coast: null },
  tender: { state: 'stowed', x: 92, y: 238, door: 0, rider: null, t: 0 }, liferaft: { state: 'stowed', t: 0, x: 74, y: 140 },
  staging: false, cutawayAll: false, autoView: true, rel: new Relations(), photo: false, hoverObj: null, dropPreview: null, walkMarker: null,
  saveSlot: 'auto', seaState: 1, lastAutosave: 0, dirty: false,
  get quality() { return this.settings.battery ? 0 : this.settings.quality < 0 ? Perf.autoQ : this.settings.quality; },
  get reduceMotion() { return this.settings.reduceMotion; },
  get noReflection() { return this.settings.noReflection || this.quality === 0; },
  get chars() { return this.party ? this.party.chars : []; },
};
window.G = G; // handy for debugging in the console

let presenter, scene, canvas;

/* ---------------- device tier + runtime adaptive quality ---------------- */
export const Perf = { tier: 1, autoQ: 1, gpu: '', ema: 16, cost: 6, acc: 0, low: 0, high: 0, told: false };
function detectTier() {
  const mem = navigator.deviceMemory || 4, cores = navigator.hardwareConcurrency || 4;
  const mobile = /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent) || matchMedia('(pointer:coarse)').matches;
  try { const gl = document.createElement('canvas').getContext('webgl'); const ext = gl && gl.getExtension('WEBGL_debug_renderer_info'); Perf.gpu = ext ? String(gl.getParameter(ext.UNMASKED_RENDERER_WEBGL)) : ''; gl?.getExtension('WEBGL_lose_context')?.loseContext(); } catch { }
  let s = (mem >= 8 ? 2 : mem >= 4 ? 1 : 0) + (cores >= 8 ? 2 : cores >= 4 ? 1 : 0) - (mobile ? 1 : 0);
  if (/swiftshader|llvmpipe|software|mali-[34t]|mali-g(31|51|52)|adreno.{0,6}(3\d\d|4\d\d|50\d|51\d)|powervr|hd graphics [2-5]\d\d/i.test(Perf.gpu)) s -= 2;
  if (presenter?.mode === 'canvas2d') s = -9;
  return s >= 3 ? 2 : s >= 1 ? 1 : 0;
}
function fpsTarget() { const f = G.settings.fps; return G.settings.battery ? 30 : f > 0 ? f : (Perf.autoQ === 0 && Perf.tier === 0 ? 30 : 60); }
function adaptQuality(dt, interval, cost) {
  Perf.ema += (interval - Perf.ema) * 0.05; Perf.cost += (cost - Perf.cost) * 0.05;
  if (G.settings.quality >= 0 || G.settings.battery) return;
  Perf.acc += dt; if (Perf.acc < 2) return; Perf.acc = 0;
  const target = 1000 / fpsTarget();
  if (Perf.ema > target * 1.35 || Perf.cost > target * 0.7) Perf.low += 2; else Perf.low = 0;
  if (Perf.ema < target * 1.12 && Perf.cost < target * 0.3) Perf.high += 2; else Perf.high = 0;
  if (Perf.low >= 4 && Perf.autoQ > 0) { Perf.autoQ--; Perf.low = 0; if (!Perf.told) { Perf.told = true; Bus.emit('toast', 'ปรับคุณภาพกราฟิกอัตโนมัติให้ลื่นขึ้น'); } }
  if (Perf.high >= 24 && Perf.autoQ < Perf.tier) { Perf.autoQ++; Perf.high = 0; }
}

/* ---------------- boot ---------------- */
export async function boot() {
  canvas = document.getElementById('game');
  const tasks = [
    { id: 'db', th: 'ฐานข้อมูลในเครื่อง (IndexedDB)', run: () => Store.openDB() },
    { id: 'gl', th: 'ตัวเรนเดอร์ WebGL 2 + ตรวจสเปคเครื่อง', run: async () => { presenter = new Presenter(canvas); watchContext(); if (presenter.mode === 'canvas2d') Bus.emit('toast', 'อุปกรณ์ไม่รองรับ WebGL ใช้โหมด Canvas แทน'); Perf.tier = Perf.autoQ = detectTier(); } },
    { id: 'tex', th: 'Texture พิกเซลอาร์ต (เมฆ ต้นไม้ ทะเล)', run: async () => { scene = new Scene(presenter); await scene.init(); window.__scene = scene; window.__G = G; } },
    { id: 'yacht', th: 'Sprite เรือ SouthCozy SeaLife', run: async () => { scene.setPaint(G.paint); if (!scene.interior || !scene.exterior) throw new Error('สร้าง Sprite เรือไม่สำเร็จ'); } },
    { id: 'oc', th: 'ตัวละครเบสเริ่มต้น', run: async () => { await buildSprites({ image: BASE_OC.url, preset: 'custom', transform: { ...defaultTransform(), height: 34 } }); } },
    { id: 'font', th: 'ฟอนต์พิกเซลภาษาไทย', run: async () => { if (document.fonts?.load) { await Promise.all([document.fonts.load('16px PixelThai', 'ก'), document.fonts.load('bold 16px PixelThai', 'ก'), document.fonts.load('16px PixelThai', 'A')]); } } },
    { id: 'geo', th: 'แผนที่แนวชายฝั่งเอเชีย (Natural Earth)', run: () => Geo.load() },
    { id: 'auth', th: 'สถานะบัญชีผู้ใช้', run: async () => { G.session = await Store.Auth.restore(); } },
  ];
  const ok = await UI.loadingScreen(tasks);
  if (!ok) return;
  window.addEventListener('resize', onResize); onResize();
  setupInput();
  requestAnimationFrame(loop);
  document.getElementById('game').classList.add('ready');
  if (G.session) await enterMenu(); else { G.screen = 'gateway'; G.cam.scale = menuScale(); UI.gateway(); }
}

export async function setMenuYacht(id) {
  setYacht(id); G.yachtId = id; G.decor = []; G.lights = defaultLights(); G.party = null; G.player = null; G.heli = null;
  G.paint = Object.assign(defaultPaint(id), (G.session && await Store.kvGet('paint:' + G.session.id + ':' + id)) || {});
  G.tender = freshTender(); G.liferaft = freshLiferaft(); G.lifeboats = freshLifeboats();
  scene.shell = {}; for (const r of ROOMS) scene.shell[r.id] = 1;
  await UI.hydrateTiles(); scene.setPaint(G.paint); G.cam.scale = menuScale(); G.cam.x = YW / 2; G.cam.y = YH / 2 - 30;
  if (G.session) await Store.kvSet('menuYacht', id);
}
export async function enterMenu() {
  G.screen = 'menu';
  await loadAccountData();
  await setMenuYacht((await Store.kvGet('menuYacht')) || 'southcozy');
  G.cam.scale = menuScale(); G.cam.x = YW / 2; G.cam.y = YH / 2 - 30;
  UI.mainMenu();
}
function menuScale() { return clamp(Math.floor(Math.min(innerWidth / (Math.min(YW, 1100) * 0.9), innerHeight / (YH + 40))), 1, 6); }
async function loadAccountData() {
  const acc = G.session.id;
  G.ocs = await Store.listOCs(acc);
  const ui = await Store.kvGet('ui:' + acc); if (ui?.settings && ui.settings.qv !== 2) { ui.settings.quality = -1; ui.settings.fps = 0; ui.settings.qv = 2; }
  if (ui) Object.assign(G.settings, ui.settings || {}), Object.assign(Audio.vol, ui.vol || {}), (Music.playlist = (ui.playlist || []).filter(p => p.kind !== 'local').map(p => { const r = parseMusicURL(p.url || p.embed); return r.ok ? r : null; }).filter(Boolean)); // rebuild clean embed URLs
  G.paintPresets = (await Store.kvGet('paintPresets:' + acc)) || [];
}

/* ---------------- fleet (two yachts sail together; each keeps its own crew, paint, decor and lights) ---------------- */
export function refreshRelations() { (G.rel || (G.rel = new Relations())).build(G.ocs || []); }
function blankYacht(id) { return { paint: defaultPaint(id), decor: [], lights: null, roster: [], chars: {} }; }
function freshTender() { const t = SPEC.tender; return { state: 'stowed', x: t.stowX, y: t.floorY - 2, door: 0, rider: null, pax: [], muster: false, t: 0 }; }
export const onTender = ch => !!ch && (G.tender.rider === ch.id || (G.tender.pax || []).includes(ch.id));
function freshLiferaft() { const l = SPEC.liferaft; return l ? { state: 'stowed', t: 0, x: l.x, y: l.y } : { state: 'none', t: 0, x: 0, y: 0 }; }
function freshLifeboats() { return SPEC.lifeboats.map(b => ({ ...b, state: 'stowed', cy: b.y })); }
const sprCache = new Map();
async function spriteFor(oc) { const k = oc.key + ':' + (oc.updatedAt || 0); if (!sprCache.has(k)) { for (const kk of [...sprCache.keys()]) if (kk.startsWith(oc.key + ':')) sprCache.delete(kk); sprCache.set(k, await buildSprites(oc)); } return sprCache.get(k); }
export function stash() {
  if (!G.fleet || !G.yachtId) return; const F = G.fleet[G.yachtId];
  F.paint = G.paint; F.decor = G.decor; F.lights = G.lights;
  if (G.party) {
    const keep = G.chars.filter(c => !c.inHeli);
    F.roster = keep.map(c => c.slot_); F.chars = Object.fromEntries(keep.map(c => [c.slot_, c.toJSON()]));
    const m = G.heli?.mission;
    if (m?.type === 'pickup') for (const c of G.chars.filter(c => c.inHeli)) { const T = G.fleet[m.to]; if (!T.roster.includes(c.slot_)) T.roster.push(c.slot_); T.chars[c.slot_] = { mode: c.mode === 'player' ? 'bot' : c.mode, needs: c.needs }; }
    if (m?.type === 'drop' && !m.landedDone) for (const s of m.slots) if (!F.roster.includes(s)) F.roster.push(s);
  }
}
export async function loadYachtView(id, { mainSlot, exclude = [] } = {}) {
  G.party = null; G.player = null; // detach the old crew before the deck layout changes (the loop keeps running)
  setYacht(id); G.yachtId = id; const F = G.fleet[id];
  G.paint = Object.assign(defaultPaint(id), F.paint || {}); G.decor = F.decor || (F.decor = []); G.lights = F.lights || (F.lights = defaultLights());
  for (const f of FIXTURES) if (!(f.id in G.lights)) G.lights[f.id] = false;
  G.tender = freshTender(); G.liferaft = freshLiferaft(); G.lifeboats = freshLifeboats(); G.hoverObj = null; G.walkMarker = null; G.dropPreview = null;
  scene.shell = {}; for (const r of ROOMS) scene.shell[r.id] = 1;
  G.heliPad = PADS[0]?.id;
  await UI.hydrateTiles(); scene.setPaint(G.paint);
  G.party = new Party(G); G.player = null; refreshRelations(); G.autoLightState = {};
  for (const slot of F.roster) {
    if (exclude.includes(slot)) continue;
    const oc = G.ocs.find(o => o.slot === slot); if (!oc) continue;
    try { const st = F.chars?.[slot] || { mode: oc.mode === 'player' ? 'bot' : oc.mode }; if (st.level && !LEVELS[st.level]) { delete st.level; delete st.x; } const ch = new Character(oc, await spriteFor(oc), st); ch.slot_ = slot; G.party.add(ch); }
    catch (e) { console.warn(e); Bus.emit('toast', 'โหลด Sprite ของ ' + oc.name + ' ไม่สำเร็จ'); }
  }
  const main = G.chars.find(c => c.slot_ === mainSlot) || G.chars.find(c => c.mode === 'player') || G.chars[0];
  if (main) setPlayer(main);
  if (main) { const [px, py] = main.pos(); G.cam.x = G.cam.tx = px; G.cam.y = G.cam.ty = py - 20; } else { G.cam.follow = false; G.cam.x = G.cam.tx = PADS[0]?.cx ?? YW / 2; G.cam.y = G.cam.ty = (PADS[0]?.y ?? YH / 2) - 40; }
  Bus.emit('yacht:changed', id);
}
export async function switchYacht(id, { followSlot } = {}) {
  if (id === G.yachtId) return;
  const following = followSlot != null;
  if (G.coop?.guest && !following) return Bus.emit('toast', 'คุณจะย้ายเรือตามโฮสต์โดยอัตโนมัติ');
  if (!following && G.heli && G.heli.phase !== 'parked') return Bus.emit('toast', 'รอให้เฮลิคอปเตอร์ปฏิบัติภารกิจเสร็จก่อน');
  const target = G.fleet[id];
  if (following && !target.roster.includes(followSlot)) target.roster.push(followSlot);
  if (!target.roster.length) return Bus.emit('toast', 'ยังไม่มี OC บน ' + YACHTS[id].name + ' — ส่งตัวละครไปด้วยเฮลิคอปเตอร์ก่อน');
  UI.busy('กำลังย้ายไปเรือ ' + YACHTS[id].name + '...');
  try {
    stash(); G.heli = null; G.flying = false; G.heliCam = false; UI.flightHUD(false);
    await loadYachtView(id, { mainSlot: followSlot });
    UI.hud(); Bus.emit('toast', 'อยู่บน ' + YACHTS[id].name);
  } finally {
    UI.busy(false);
  }
}

/* ---------------- start / load / save ---------------- */
export async function startGame(saveSlot = 'auto', fresh = false, boardSlots = null, mainSlot = null, yachtId = 'southcozy') {
  UI.busy('กำลังเตรียมเรือ...');
  try {
    const acc = G.session.id; G.saveSlot = saveSlot;
    const save = fresh ? null : Store.migrateSave(await Store.readSave(acc, saveSlot));
    G.ocs = await Store.listOCs(acc);
    G.fleet = save?.fleet ? structuredClone(save.fleet) : {};
    for (const id of Object.keys(YACHTS)) if (!G.fleet[id]) { G.fleet[id] = blankYacht(id); const kp = await Store.kvGet('paint:' + acc + ':' + id); if (kp) G.fleet[id].paint = Object.assign(defaultPaint(id), kp); }
    if (fresh) {
      const onboard = boardSlots || G.ocs.slice(0, 3).map(o => o.slot);
      for (const id in G.fleet) G.fleet[id].roster = G.fleet[id].roster.filter(s => !onboard.includes(s));
      G.fleet[yachtId].roster = onboard;
    }
    for (const id in G.fleet) G.fleet[id].roster = G.fleet[id].roster.filter(s => G.ocs.some(o => o.slot === s));
    G.relationships = save?.relationships || {};
    G.inventory = { ...INVENTORY }; for (const F of Object.values(G.fleet)) for (const d of F.decor || []) G.inventory[d.type] = Math.max(0, (G.inventory[d.type] || 0) - 1);
    G.clock = new Clock(save?.clock); G.journey = new Journey(save?.journey);
    if (save?.journey && save.journey.status === 'sailing' && save.journey.speed > 0) { G.journey.s.speed = 0; G.journey.s.targetSpeed = 0; G.journey.s.autopilot = false; UI.resumePrompt(save.journey); }
    G.heli = null; G.flying = false; G.heliCam = false;
    let yid = fresh ? yachtId : (save?.yachtId || 'southcozy');
    if (!G.fleet[yid].roster.length) yid = Object.keys(G.fleet).find(k => G.fleet[k].roster.length) || yid;
    await loadYachtView(yid, { mainSlot: mainSlot ?? save?.main });
    if (!G.chars.length) throw new Error('ไม่มี OC บนเรือ');
    G.cam.scale = roomScale(); G.settings.zoom = G.cam.scale; G.autoView = G.settings.autoView ?? true; G.cam.follow = true;
    G.screen = 'game'; G.lastAutosave = performance.now();
    UI.hud(); Audio.start(); UI.openRoomInvitation();
  } catch (e) { console.error(e); Bus.emit('toast', 'เริ่มเกมไม่สำเร็จ: ' + e.message); UI.mainMenu(); }
  finally { UI.busy(false); }
}
// starting view: the room the player stands in fills the screen (between the top HUD card and the bottom bar),
// integer scale so the pixel art stays crisp.
export function roomScale() {
  const p = G.player; const r = p && !p.stair ? roomAt(p.level, p.x) : null;
  const rw = r ? Math.max(60, r.x2 - r.x1 + 16) : 120, rh = 50;
  const availH = innerHeight - (innerWidth < 700 ? 150 : 175), availW = innerWidth * 0.94;
  return clamp(Math.floor(Math.min(availH / rh, availW / rw)), 3, maxScale());
}
export function defaultScale() { return clamp(Math.round(Math.min(innerHeight / 250, innerWidth / 200)), 2, 6); }
function defaultLights() { const l = {}; for (const f of FIXTURES) l[f.id] = false; l.nav = true; return l; }
export function setPlayer(ch) {
  if (G.player && G.player !== ch) G.player.mode = G.player.prevMode || 'bot';
  ch.prevMode = ch.mode === 'player' ? (ch.oc.mode !== 'player' ? ch.oc.mode : 'bot') : ch.mode;
  ch.mode = G.settings.autoWalk ? 'assisted' : 'player'; G.player = ch; G.cam.follow = true; Bus.emit('player:changed', ch);
}
export function serialize() {
  stash(); const all = Object.values(G.fleet).flatMap(f => f.roster);
  return {
    yachtId: G.yachtId, fleet: G.fleet, main: G.player?.slot_, clock: G.clock.toJSON(), journey: G.journey.toJSON(), relationships: G.relationships,
    location: (() => { const n = G.journey.nearestPort(); return (G.journey.s.dockedAt ? 'จอดที่ ' + n.port.th : `ทะเล ใกล้${n.port.th} (${n.dist.toFixed(0)} nm)`) + ' · ' + SPEC.name; })(),
    oc_names: G.ocs.filter(o => all.includes(o.slot)).map(o => o.name),
  };
}
export async function saveGame(slot = G.saveSlot, silent = false) {
  if (G.screen !== 'game' || !G.party || G.sink) return;
  try {
    const rec = await Store.writeSave(G.session.id, slot, serialize());
    await saveUIPrefs();
    G.lastAutosave = performance.now(); if (!silent) Bus.emit('toast', 'บันทึกเกมแล้ว (' + (slot === 'auto' ? 'อัตโนมัติ' : 'ช่อง ' + slot.slice(1)) + ')');
    Bus.emit('saved', rec); return rec;
  } catch (e) { Bus.emit('toast', 'บันทึกไม่สำเร็จ: ' + e.message); }
}
export async function saveUIPrefs() {
  if (!G.session) return;
  await Store.kvSet('ui:' + G.session.id, { settings: G.settings, vol: Audio.vol, playlist: Music.playlist.filter(p => p.kind !== 'local').map(({ kind, id, embed, url, title, tall }) => ({ kind, id, embed, url, title, tall })) });
  await Store.kvSet('paintPresets:' + G.session.id, G.paintPresets); await Store.kvSet('paint:' + G.session.id + ':' + SPEC.id, G.paint);
}
export async function quitToMenu() { if (G.Sink?.active) G.Sink.stop(true); await Coop.leave(true); await saveGame('auto', true); G.screen = 'menu'; G.party = null; G.player = null; G.heli = null; G.flying = false; UI.flightHUD(false); G.cam.scale = menuScale(); G.cam.x = YW / 2; G.cam.y = YH / 2 - 30; UI.mainMenu(); }
export async function logout() { Coop.leave(true); if (G.screen === 'game') await saveGame('auto', true); await Store.Auth.logout(); G.session = null; G.party = null; G.screen = 'gateway'; UI.gateway(); }
export function repaint() { scene.setPaint(G.paint); G.dirty = true; }

/* ---------------- lights / objects ---------------- */
export function toggleRoomLights(roomId, on, silent = false) {
  const fx = FIXTURES.filter(f => f.room === roomId && f.kind !== 'nav'); if (!fx.length) return;
  const val = on ?? !fx.some(f => G.lights[f.id]);
  if (fx.every(f => !!G.lights[f.id] === val)) return;
  if (!silent) {
    Audio.click(val ? 1100 : 700);
    if (G.coop?.guest) return Coop.requestLight(roomId, val);
  }
  for (const f of fx) G.lights[f.id] = val;
  Bus.emit('lights');
}
// automatic lighting: on at dusk, off after sunrise; bedrooms go dark while someone sleeps, empty rooms switch off late at night.
// Only acts when the wanted state *changes*, so a light you flip by hand stays that way until the next transition.
let autoLT = 0;
function updateAutoLights(dt) {
  if (!G.settings.autoLights || !G.party || G.coop?.guest || (autoLT -= dt) > 0) return; autoLT = 1.5;
  const st = G.autoLightState || (G.autoLightState = {});
  const elev = G.env.sunElev; const prev = st.__dark ?? (elev < 1);
  const dark = (prev ? elev < 4 : elev < 0) || Weather.p.dark > (prev ? 0.45 : 0.55); st.__dark = dark; // hysteresis; storms darken the day too
  const h = G.clock.localHour(); const lateNight = h >= 0.5 && h < 5;
  for (const r of ROOMS) {
    if (!FIXTURES.some(f => f.room === r.id && f.kind !== 'nav')) continue;
    const here = G.chars.filter(c => !c.stair && c.level === r.level && c.x >= r.x1 && c.x < r.x2 && !c.inHeli);
    const sleeping = here.some(c => c.state === 'sleep'), awake = here.some(c => c.state !== 'sleep');
    let want = dark;
    if (dark && sleeping && !awake) want = false;
    if (dark && lateNight && !here.length && r.type === 'in') want = false;
    if (dark && lateNight && r.type === 'out') want = false;
    if (st[r.id] !== want) { const first = st[r.id] === undefined; st[r.id] = want; if (!first || want !== !!FIXTURES.find(f => f.room === r.id && f.kind !== 'nav' && G.lights[f.id])) toggleRoomLights(r.id, want, true); }
  }
}
G.toggleRoomLights = toggleRoomLights; G.onTender = onTender; G.Coop = Coop; G.Weather = Weather; G.Helm = Helm; G.fallOverboard = fallOverboard; G.Sink = Sink; G.quitToMenu = () => quitToMenu();
// hidden objects: engine-room service panel (keypad) + captain's logbook
Bus.on('secret:panel', () => UI.keypad((code) => { if (code !== SINK_CODE) return false; if (!Sink.canStart()) return 'locked'; Sink.start(); return true; }));
Bus.on('secret:logbook', () => UI.logbook()); G.drawUnderwater = drawWater;
Bus.on('coop:shark', r => remoteShark(r));
// yacht coords → CSS pixels (used by the DOM speech bubbles so text stays crisp at any zoom)
G.worldToCss = (x, y) => { const [vx, vy] = scene.worldToScreen(G, x, y); const r = canvas.getBoundingClientRect(); return [r.left + vx * r.width / scene.W, r.top + vy * r.height / scene.H]; };
// in-game OCs pick up edits (name, personality, relationships, own lines) immediately
Bus.on('ocs:changed', oc => { if (!G.session || oc.accountId !== G.session.id) return; const i = (G.ocs || []).findIndex(o => o.slot === oc.slot); if (i >= 0) G.ocs[i] = oc; else (G.ocs || (G.ocs = [])).push(oc);
  for (const ch of G.chars || []) if (ch.slot_ === oc.slot) { Object.assign(ch.oc, { name: oc.name, persona: oc.persona, links: oc.links, lines: oc.lines, pref: oc.pref }); ch.name = oc.name; ch.pref = oc.pref || ch.pref; }
  refreshRelations(); });
G.openObjectPanel = o => UI.objectPanel(o);
G.isVisible = ch => { const [x, y] = ch.pos(); const [sx, sy] = scene.worldToScreen(G, x, y); return sx > -40 && sy > -40 && sx < scene.W + 40 && sy < scene.H + 60; };

/* ---------------- tender, liferaft, davit lifeboats ---------------- */
const exitX = () => SPEC.tender.doorX - 66;
export function tenderCmd(cmd) {
  if (G.coop?.guest) return Bus.emit('toast', 'โฮสต์เป็นคนควบคุมเรือเล็ก'), false;
  const t = G.tender; const moving = Math.abs(G.journey.s.speed) > 0.5 && !G.sink;
  if (moving && cmd !== 'close') return Bus.emit('toast', 'ต้องหยุดเรือก่อนใช้งานเรือเล็ก'), false;
  if (cmd === 'launch' && t.state === 'stowed') { t.state = 'opening'; return true; }
  if (cmd === 'recall' && t.state === 'floating') { t.state = 'returning'; return true; }
  if (cmd === 'board' && t.state === 'floating' && G.player) { const p = G.player; G.party.goto(p, 'swim', (LEVELS.swim.x1 + LEVELS.swim.x2) / 2, null); p.boardTender = true; return true; }
  if (cmd === 'disembark' && t.rider) {
    if (t.state === 'drive') { if (G.sink) return false; if (Math.abs(t.x - exitX()) > 60 || Math.abs(t.vx || 0) > 40) { t.state = 'homing'; return true; } }
    t.state = 'back'; t.vx = 0; t.face = 1; t.pitch = 0; t.hop = 0; Bus.emit('drive'); return true;
  }
  // rescue-boat role: everyone musters on the swim platform and boards; the boat then stands off the stern
  if (cmd === 'muster') {
    if (t.muster) return false;
    if (t.state === 'cruise') t.state = 'back';
    t.muster = true; if (t.state === 'stowed') t.state = 'opening';
    Bus.emit('toast', 'ฝึกสละเรือ: ทุกคนไปที่ชานท้ายเรือ แล้วขึ้นเรือชูชีพ (เรือเล็ก)'); return true;
  }
  if (cmd === 'unmuster' && t.muster) { t.muster = false; t.state = 'return_all'; return true; }
  return false;
}
export function liferaftCmd(cmd) {
  const r = G.liferaft; if (r.state === 'none') return Bus.emit('toast', 'เรือลำนี้ใช้เรือชูชีพแบบเดวิทแทนแพชูชีพ'), false;
  if (cmd === 'deploy' && r.state === 'stowed') { r.state = 'deploying'; r.t = 0; Bus.emit('toast', 'โหมดจำลอง: ปล่อยแพชูชีพ'); return true; }
  if (cmd === 'pack' && r.state === 'deployed') { r.state = 'packing'; return true; }
  return false;
}
export function lifeboatCmd(id, cmd) {
  const b = G.lifeboats.find(k => k.id === id); if (!b) return false;
  if (Math.abs(G.journey.s.speed) > 0.5) return Bus.emit('toast', 'ต้องหยุดเรือก่อนหย่อนเรือชูชีพ'), false;
  if (cmd === 'lower' && b.state === 'stowed') { b.state = 'outboard'; b.t = 0; Bus.emit('toast', b.th + ': เดวิทยื่นออก แล้วหย่อนลงน้ำ (จำลอง)'); return true; }
  if (cmd === 'raise' && b.state === 'afloat') { b.state = 'raising'; return true; }
  return false;
}
function updateTender(dt) {
  const t = G.tender, T = SPEC.tender, exitX = T.doorX - 66;
  if (t.state !== 'drive' && t.state !== 'homing') Audio.motor?.(0, false);
  switch (t.state) {
    case 'opening': t.door = Math.min(1, t.door + dt * 0.8); if (t.door >= 1) t.state = 'sliding'; break;
    case 'sliding': t.x -= 26 * dt; if (t.x <= T.doorX - 26) t.state = 'lowering'; break;
    case 'lowering': t.x -= 14 * dt; t.y = lerp(t.y, WL + 3, dt * 2); if (t.x <= exitX) { t.state = 'floating'; t.door = 1; } break;
    case 'floating': t.y = WL + 3 + Math.sin(G.time * 1.3) * 1; break;
    // ---- manual driving: throttle, planing, wave hops, spray ----
    case 'drive': case 'homing': {
      let u = G.driveInput || 0;
      if (t.state === 'homing') { const dx = exitX - t.x; u = clamp(dx / 120, -1, 1); if (Math.abs(dx) < 8 && Math.abs(t.vx) < 25) { t.state = 'back'; Bus.emit('drive'); break; } }
      t.vx = t.vx || 0; t.face = t.face || -1;
      if (u && Math.sign(u) !== t.face && Math.abs(t.vx) < 22) t.face = Math.sign(u);       // swing the bow round when nearly stopped
      const fwd = u * t.face > 0; t.vx += u * (fwd ? 150 : 70) * dt;
      t.vx -= t.vx * (u ? 0.35 : 0.9) * dt; t.vx = clamp(t.vx, -280, 280);
      t.x = clamp(t.x + t.vx * dt, -2600, YW + 2600);
      const sp = Math.abs(t.vx), plane = clamp(sp / 280, 0, 1);
      t.pitch = lerp(t.pitch || 0, -0.11 * plane * (Math.sign(t.vx) === t.face ? 1 : -0.4), dt * 3);
      // hop over the swell at speed
      t.hv = (t.hv || 0) + 260 * dt; t.hop = Math.min(0, (t.hop || 0) + t.hv * dt);
      if (t.hop >= 0) { t.hv = 0; if (sp > 150 && Math.random() < dt * 1.6) { t.hv = -(40 + sp * 0.18); splashAt(t.x - t.face * 40, WL, 1); } }
      if (sp > 40 && Math.random() < dt * (6 + sp * 0.06)) splashAt(t.x - t.face * 56, WL + 1, 0.4, -t.vx * 0.3);
      if (sp > 90 && Math.random() < dt * 8) splashAt(t.x + t.face * 44, WL, 0.3, t.vx * 0.2);
      t.y = WL + 3 + Math.sin(G.time * 2.2) * (1 - plane) * 1.2;
      Audio.motor?.(plane, true);
      break;
    }
    case 'cruise': t.t += dt; t.x = exitX - Math.sin(Math.min(1, t.t / 14) * Math.PI) * 240; t.y = WL + 3 + Math.sin(G.time * 2) * 1.2; if (t.t > 14) { t.state = 'back'; } break;
    case 'back': { t.face = 1; t.pitch = 0; t.hop = 0; t.vx = 0; const r = G.chars.find(c => c.id === t.rider); t.rider = null; t.state = 'floating'; if (r) { r.level = 'swim'; r.x = (LEVELS.swim.x1 + LEVELS.swim.x2) / 2; r.state = 'idle'; } break; }
    case 'standoff': t.x = lerp(t.x, exitX - 70, dt * 0.4); t.y = WL + 3 + Math.sin(G.time * 1.2) * 1.2; break;
    case 'return_all': t.x = lerp(t.x, exitX, dt * 0.8); t.y = WL + 3; if (Math.abs(t.x - exitX) < 1.5) { const sx = (LEVELS.swim.x1 + LEVELS.swim.x2) / 2; for (const id of [t.rider, ...t.pax]) { const r = G.chars.find(c => c.id === id); if (r) { r.level = 'swim'; r.x = sx + (Math.random() - 0.5) * 16; r.state = 'idle'; r.path = []; } } t.rider = null; t.pax = []; t.state = 'floating'; Bus.emit('toast', 'ทุกคนกลับขึ้นเรือใหญ่แล้ว'); } break;
    case 'returning': t.x += 18 * dt; t.y = lerp(t.y, T.floorY - 2, dt * 3); if (t.x >= T.stowX) { t.x = T.stowX; t.y = T.floorY - 2; t.state = 'closing'; } break;
    case 'closing': t.door = Math.max(0, t.door - dt * 0.8); if (t.door <= 0) t.state = 'stowed'; break;
  }
  // muster: send everyone (bots too) to the swim platform and seat them in the boat
  if (t.muster && t.state === 'floating') {
    const sx = (LEVELS.swim.x1 + LEVELS.swim.x2) / 2; let left = 0;
    for (const ch of G.chars) {
      if (onTender(ch) || ch.inHeli) continue; left++;
      if (!ch.mustering) { ch.mustering = true; if (ch.state === 'sleep') G.party.standUp(ch); G.party.release?.(ch); ch.state = 'idle'; G.party.goto(ch, 'swim', sx, null); }
      else if (!ch.path.length && !ch.stair && ch.level === 'swim') { ch.mustering = false; if (t.pax.length + 1 < TENDER.cap) t.pax.push(ch.id); }
      else if (!ch.path.length && !ch.stair) G.party.goto(ch, 'swim', sx, null);
    }
    if (!left && (t.pax.length || t.rider)) { t.state = 'standoff'; Bus.emit('toast', `ทุกคนอยู่บนเรือชูชีพแล้ว (${t.pax.length + (t.rider ? 1 : 0)} คน)`); }
  }
  const p = G.player; if (p?.boardTender && !p.path.length && !p.stair && p.level === 'swim') { p.boardTender = false; if (t.state === 'floating') { t.rider = p.id; t.state = 'drive'; t.vx = 0; t.face = -1; t.t = 0; Bus.emit('toast', 'ขับเรือเล็ก: ← → เร่ง/ถอย · กด "จอดเทียบ" เมื่อกลับมาที่ท้ายเรือ'); Bus.emit('drive'); } }
  const r = G.liferaft, L = SPEC.liferaft;
  if (L) {
    if (r.state === 'deploying') { r.t = Math.min(1, r.t + dt * 0.5); const k = r.t; r.x = lerp(L.x, -80, k); r.y = lerp(L.y, WL + 4, k * k) - Math.sin(k * Math.PI) * 30; if (k >= 1) r.state = 'deployed'; }
    else if (r.state === 'deployed') { r.y = WL + 4 + Math.sin(G.time * 1.1) * 1; }
    else if (r.state === 'packing') { r.t = Math.max(0, r.t - dt * 0.6); r.x = lerp(L.x, -80, r.t); r.y = lerp(L.y, WL + 4, r.t); if (r.t <= 0) r.state = 'stowed'; }
  }
  for (const b of G.lifeboats) {
    if (b.state === 'outboard') { b.t = Math.min(1, b.t + dt * 0.6); if (b.t >= 1) b.state = 'lowering'; }
    else if (b.state === 'lowering') { b.cy += 15 * dt; if (b.cy >= WL + 6) { b.cy = WL + 6; b.state = 'afloat'; } }
    else if (b.state === 'afloat') b.cy = WL + 6 + Math.sin(G.time * 1.2 + b.x) * 0.8;
    else if (b.state === 'raising') { b.cy -= 12 * dt; if (b.cy <= b.y) { b.cy = b.y; b.state = 'inboard'; } }
    else if (b.state === 'inboard') { b.t = Math.max(0, b.t - dt * 0.6); if (b.t <= 0) b.state = 'stowed'; }
  }
}

/* ---------------- helicopter: missions, manual flight ---------------- */
function padById(id) { return PADS.find(p => p.id === id) || PADS[0]; }
function heliWorld() { return { surfaces: PADS, WL, solid: (x, y) => scene.solid(x, y) }; }
function clearPad(pad, except = []) {
  const L = LEVELS[roomById_(pad.room).level];
  for (const ch of G.chars) { if (except.includes(ch) || ch.inHeli) continue; if (ch.level === roomById_(pad.room).level && ch.x > pad.x1 - 10 && ch.x < pad.x2 + 10) { const tx = pad.face > 0 ? Math.min(L.x2, pad.x2 + 30 + Math.random() * 40) : Math.max(L.x1, pad.x1 - 30 - Math.random() * 40); G.party.goto(ch, roomById_(pad.room).level, tx); } }
}
function roomById_(id) { return ROOMS.find(r => r.id === id); }
export async function startHeliMission(type, opts = {}) {
  if (!PADS.length) return Bus.emit('toast', 'เรือนี้ไม่มีลานจอดเฮลิคอปเตอร์'), false;
  if (G.heli && G.heli.phase !== 'parked') return Bus.emit('toast', 'เฮลิคอปเตอร์กำลังปฏิบัติภารกิจอยู่'), false;
  if (G.flying) return Bus.emit('toast', 'ออกจากโหมดบินเองก่อน'), false;
  const pad = padById(opts.pad || G.heliPad);
  const m = { type, ...opts, landedDone: false };
  if (type === 'drop') { for (const s of m.slots) { const oc = G.ocs.find(o => o.slot === s); if (oc) await spriteFor(oc); } if (m.from && G.fleet[m.from]) { const F = G.fleet[m.from]; F.roster = F.roster.filter(s => !m.slots.includes(s)); } }
  if (type === 'pickup') {
    m.passengers = m.chars; delete m.chars; const L = roomById_(pad.room).level;
    for (const [i, ch] of m.passengers.entries()) { G.party.standUp(ch); ch.mode = ch === G.player ? ch.mode : 'assisted'; ch.idleT = 0; G.party.goto(ch, L, clamp(pad.cx + pad.face * (100 + i * 14), LEVELS[L].x1, LEVELS[L].x2)); ch.boardHeli = true; }
  }
  clearPad(pad, m.passengers || []);
  let h = G.heli;
  if (h && h.phase === 'parked' && h.pad.id === pad.id) { h.engines = true; h.mode = 'auto'; h.mission = m; h.phase = (type === 'return') ? 'spool' : 'landed'; h.timer = 0; if (type !== 'return') m.spoolFirst = true; }
  else { h = G.heli = new Heli(pad, { livery: G.settings.heliLivery }); h.mission = m; if (type === 'return') { h.phase = 'parked'; } else h.spawnInbound(); }
  h.livery = G.settings.heliLivery;
  G.heliCam = opts.follow ?? true; G.cam.follow = !G.heliCam;
  Bus.emit('toast', { supply: 'เรียกเฮลิคอปเตอร์ส่งเสบียง', drop: 'เฮลิคอปเตอร์กำลังนำ OC มาส่ง', pickup: 'เฮลิคอปเตอร์กำลังมารับ OC', return: 'เฮลิคอปเตอร์กลับฐาน' }[type] || 'เฮลิคอปเตอร์ออกปฏิบัติภารกิจ');
  Bus.emit('heli'); return true;
}
function missionLanded(h, m) {
  const pad = h.pad, L = roomById_(pad.room).level;
  if (m.type === 'supply') { h.cargo = [0, 1, 2].map(i => ({ x: h.doorX + (pad.face > 0 ? -1 : 1) * (10 + i * 12), y: pad.y })); Bus.emit('toast', 'ขนเสบียงลงจากเฮลิคอปเตอร์...'); }
  if (m.type === 'drop') {
    m.slots.forEach((s, i) => {
      const oc = G.ocs.find(o => o.slot === s); if (!oc) return; const spr = sprCache.get(oc.key + ':' + (oc.updatedAt || 0)); if (!spr) return;
      const F = G.fleet[G.yachtId]; const st = { ...(F.chars[s] || {}), level: L, x: h.doorX, mode: oc.mode === 'player' ? 'bot' : (F.chars[s]?.mode || oc.mode) };
      const ch = new Character(oc, spr, st); ch.slot_ = s; G.party.add(ch); if (!F.roster.includes(s)) F.roster.push(s);
      setTimeout(() => G.party.goto(ch, L, clamp(pad.cx + pad.face * (110 + i * 18), LEVELS[L].x1, LEVELS[L].x2)), 400 + i * 700);
      if (m.mainSlot === s) setPlayer(ch);
    });
    Bus.emit('toast', 'OC ลงจากเฮลิคอปเตอร์แล้ว'); if (m.mainSlot != null) { G.heliCam = false; G.cam.follow = true; }
  }
  if (m.type === 'pickup') for (const ch of m.passengers) if (!ch.inHeli) G.party.goto(ch, L, h.doorX);
}
function missionReady(h, m, dt) {
  if (m.spoolFirst && h.rpm < 0.95) return false;
  if (m.type === 'supply') {
    if (h.timer > 3.5 && h.cargo.length) {
      h.cargo = []; const keys = Object.keys(INVENTORY); const got = [];
      for (let i = 0; i < 3; i++) { const k = keys[(Math.random() * keys.length) | 0]; G.inventory[k] = (G.inventory[k] || 0) + 1; got.push(k); }
      for (const c of G.chars) c.needs.hunger = Math.max(0, c.needs.hunger - 25);
      Bus.emit('inventory'); Bus.emit('toast', 'ได้รับเสบียงและของตกแต่ง +3 ชิ้น (ดูในของตกแต่ง)');
    }
    return h.timer > 5;
  }
  if (m.type === 'drop') return h.timer > 4.5;
  if (m.type === 'pickup') {
    const L = roomById_(h.pad.room).level;
    for (const ch of m.passengers) if (!ch.inHeli && !ch.path.length && !ch.stair && ch.level === L && Math.abs(ch.x - h.doorX) < 8) { ch.inHeli = true; ch.path = []; ch.state = 'idle'; Audio.click(500); if (ch === G.player) { G.heliCam = true; } }
    if (h.timer > 60) m.passengers = m.passengers.filter(c => { if (!c.inHeli) { c.boardHeli = false; c.mode = 'bot'; } return c.inHeli; });
    return m.passengers.length > 0 && m.passengers.every(c => c.inHeli);
  }
  return h.timer > 2;
}
async function missionGone(m) {
  if (!m) return;
  if (m.type === 'pickup') {
    const slots = m.passengers.map(c => c.slot_); const hadPlayer = m.passengers.includes(G.player); const playerSlot = hadPlayer ? G.player.slot_ : null;
    for (const ch of m.passengers) { G.party.release(ch); G.party.chars = G.party.chars.filter(c => c !== ch); }
    if (hadPlayer) G.player = null;
    stash(); const T = G.fleet[m.to];
    if (hadPlayer) {
      T.roster = T.roster.filter(s => !slots.includes(s));
      for (const s of slots) { const prev = m.passengers.find(c => c.slot_ === s); T.chars[s] = { mode: 'bot', needs: prev?.needs }; }
      UI.busy('บินไป ' + YACHTS[m.to].name + '...'); await loadYachtView(m.to); UI.busy(false); UI.hud();
      await startHeliMission('drop', { slots, mainSlot: playerSlot, follow: true, pad: m.toPad });
      if (G.player == null) G.heliCam = true;
    } else {
      for (const s of slots) { if (!T.roster.includes(s)) T.roster.push(s); const prev = m.passengers.find(c => c.slot_ === s); T.chars[s] = { mode: 'bot', needs: prev?.needs }; }
      Bus.emit('toast', `ส่ง ${m.passengers.map(c => c.name).join(', ')} ไป ${YACHTS[m.to].name} แล้ว`);
      if (!G.player && G.chars.length) setPlayer(G.chars[0]);
    }
    saveGame('auto', true);
  }
  Bus.emit('heli');
}
export function startManualFlight() {
  if (!PADS.length) return Bus.emit('toast', 'เรือนี้ไม่มีลานจอดเฮลิคอปเตอร์');
  if (G.heli && G.heli.phase !== 'parked') return Bus.emit('toast', 'รอให้เฮลิคอปเตอร์ปฏิบัติภารกิจเสร็จก่อน');
  const pad = padById(G.heliPad);
  if (!G.heli) { G.heli = new Heli(pad, { livery: G.settings.heliLivery }); clearPad(pad); }
  const h = G.heli; h.mode = 'manual'; h.phase = 'manual'; h.mission = null; h.livery = G.settings.heliLivery;
  G.flying = true; G.heliCam = true; G.cam.follow = false; UI.flightHUD(true); Bus.emit('heli');
}
export function endManualFlight() {
  const h = G.heli; G.flying = false; UI.flightHUD(false); if (!h) return;
  h.mode = 'auto'; h.manual.up = h.manual.down = h.manual.left = h.manual.right = 0;
  if (h.onGround && PADS.some(p => Math.abs(h.y - p.y) < 1 && h.x >= p.x1 && h.x <= p.x2)) { h.pad = PADS.find(p => Math.abs(h.y - p.y) < 1 && h.x >= p.x1 && h.x <= p.x2); h.phase = 'landed'; h.timer = 0; h.mission = null; }
  else { // autopilot brings it back to the nearest pad
    h.engines = true; h.pad = PADS.reduce((a, b) => Math.hypot(a.cx - h.x, a.y - h.y) < Math.hypot(b.cx - h.x, b.y - h.y) ? a : b);
    if (Math.sign(h.pad.cx - h.x) !== h.facing && Math.abs(h.pad.cx - h.x) > 20) h.turnTarget = Math.sign(h.pad.cx - h.x) || h.facing;
    h.phase = 'approach'; h.mission = null; Bus.emit('toast', 'Autopilot: บินกลับลงจอดที่ ' + h.pad.th);
  }
  G.heliCam = false; G.cam.follow = true; Bus.emit('heli');
}
function resetHeliToPad() { const h = G.heli; if (!h) return; const pad = h.pad; Object.assign(h, { x: pad.cx, y: pad.y, vx: 0, vy: 0, th: 0, om: 0, onGround: true, facing: pad.face, turnTarget: pad.face, coll: 0 }); if (h.mode !== 'manual') { h.phase = 'landed'; h.timer = 0; } }
function updateHeli(dt) {
  const h = G.heli; if (!h) return;
  h.step(dt, heliWorld()); h.updateParticles(dt, WL);
  for (const ev of h.events.splice(0)) {
    if (ev === 'hard') Bus.emit('toast', 'ลงจอดแรงเกินไป! ความเร็วแนวดิ่งเกิน 2.8 m/s');
    if (ev === 'bump') Bus.emit('toast', 'ระวัง! ลำตัวเฉียดโครงสร้างเรือ');
    if (ev === 'touchdown' && h.mode === 'manual') Bus.emit('toast', 'แตะพื้นลานจอดเรียบร้อย');
    if (ev === 'water') { Bus.emit('toast', 'บินต่ำเกินไปเหนือผิวน้ำ — รีเซ็ตกลับลานจอด'); resetHeliToPad(); return; }
  }
  if (h.mode === 'manual') return;
  const p = h.pad, m = h.mission; h.timer += dt;
  switch (h.phase) {
    case 'inbound': if (Math.abs(h.x - (p.cx + p.from * 160)) < 40 && Math.abs(h.vx) < 6 * PPM) { h.phase = 'approach'; h.timer = 0; } break;
    case 'approach': if (Math.abs(h.x - p.cx) < 5 && Math.abs(h.vx) < 0.8 * PPM && Math.abs(h.y - (p.y - 34)) < 6) { h.holdT = (h.holdT || 0) + dt; if (h.holdT > 1.2) { h.phase = 'descend'; h.holdT = 0; } } else h.holdT = 0; break;
    case 'descend': if (h.onGround) { h.phase = 'landed'; h.timer = 0; } break;
    case 'landed':
      if (m && !m.landedDone) { m.landedDone = true; missionLanded(h, m); }
      if (m && missionReady(h, m, dt)) { h.phase = 'liftoff'; h.timer = 0; }
      if (!m && h.timer > 3) { h.engines = false; h.phase = 'parked'; Bus.emit('heli'); }
      break;
    case 'spool': if (h.rpm > 0.95) h.phase = 'liftoff'; break;
    case 'liftoff': if (h.y < p.y - 40) { h.phase = 'turning'; h.turnTarget = p.from; h.timer = 0; } break;
    case 'turning': if (h.turnTarget === h.facing) h.phase = 'depart'; break;
    case 'depart': if (Math.abs(h.x - p.cx) > 3800) { G.heli = null; G.heliCam = false; if (G.player) G.cam.follow = true; missionGone(m); } break;
  }
}
function drawAfterShell(c, l, sc, ambCss) {
  // davit lifeboats hang outboard of the hull
  for (const b of G.lifeboats) {
    const r = ROOMS.find(k => k.id === b.room); if (!r) continue; const top = roomTop(r);
    const ext = b.state === 'stowed' ? 0 : b.state === 'outboard' || b.state === 'inboard' ? b.t : 1;
    for (const ax of [r.x1 + 24, r.x2 - 24]) { c.fillStyle = '#c9ced2'; c.fillRect(ax - 1, top + 2, 2, Math.round(4 + ext * 6)); c.fillStyle = '#59646e'; c.fillRect(ax - 1, top + 6 + Math.round(ext * 6), 2, 2); }
    c.strokeStyle = 'rgba(60,66,72,0.85)'; c.lineWidth = 1; c.beginPath();
    // the limousine tender hangs in the davit falls (lifting eyes fore and aft of the cabin roof)
    const lift = b.state === 'stowed' ? 0 : -ext * 2, oy = Math.round(b.cy - TENDER.ay - 2 + lift), ox = Math.round(b.x - TENDER.ax);
    for (const [ax, bx] of [[r.x1 + 24, ox + 50], [r.x2 - 24, ox + 104]]) { c.moveTo(ax + 0.5, top + 8 + ext * 6); c.lineTo(bx + 0.5, oy + 3); } c.stroke();
    for (const hx of [ox + 50, ox + 104]) { c.fillStyle = '#e6b84a'; c.fillRect(hx - 1, oy + 2, 3, 2); }
    c.drawImage(sc.tender.back, ox, oy); c.drawImage(sc.tender.front, ox, oy);
    l.drawImage(sc.tinted(sc.tender.front, ambCss), ox, oy);
  }
  const h = G.heli; if (!h) return;
  const agl = (h.surfaceY - h.y) / PPM; if (agl < 40) { c.fillStyle = `rgba(0,0,0,${(0.18 * (1 - agl / 40)).toFixed(3)})`; c.beginPath(); c.ellipse(Math.round(h.x), Math.round(h.surfaceY - 1), 60 * (1 - agl / 80), 2, 0, 0, Math.PI * 2); c.fill(); }
  if (!sc.heliCv) { sc.heliCv = document.createElement('canvas'); sc.heliCv.width = 340; sc.heliCv.height = 170; sc.heliCx = sc.heliCv.getContext('2d'); }
  const hc = sc.heliCx; hc.setTransform(1, 0, 0, 1, 0, 0); hc.clearRect(0, 0, 340, 170); hc.imageSmoothingEnabled = false; hc.translate(170 - Math.round(h.x), 120 - Math.round(h.y)); h.draw(hc, G.time);
  c.drawImage(sc.heliCv, Math.round(h.x) - 170, Math.round(h.y) - 120);
  l.drawImage(sc.tinted(sc.heliCv, ambCss), 0, 0, 340, 170, Math.round(h.x) - 170, Math.round(h.y) - 120, 340, 170);
}

/* ---------------- loop ---------------- */
let last = performance.now(), acc = 0, lastFrame = 0, lastUtc = 0, tzT = 0;
const STEP = 1 / 60;
function loop(now) {
  requestAnimationFrame(loop);
  const fpsCap = fpsTarget();
  if (now - lastFrame < 1000 / fpsCap - 2) return; const interval = now - lastFrame; lastFrame = now;
  let dt = Math.min(0.1, (now - last) / 1000); last = now;
  if (document.hidden) return;
  if (G.screen !== 'game' && G.screen !== 'menu' && G.screen !== 'gateway') return;
  const t0 = performance.now();
  acc += dt; let steps = 0;
  while (acc >= STEP && steps < 4) { safeUpdate(STEP); acc -= STEP; steps++; }
  if (steps === 4) acc = 0;
  if (!glLost) try { render(dt); } catch (e) { reportError(e, 'render'); }
  if (interval < 250) adaptQuality(dt, interval, performance.now() - t0);
}
// crash guard: an exception in one system must never freeze the whole game. Errors are logged, the crew is
// re-seated on valid floors, and the player sees one short notice instead of a frozen screen.
let errCount = 0, errNoticeT = 0;
function reportError(e, where) {
  errCount++; console.error('[' + where + ']', e);
  if (performance.now() - errNoticeT > 15000) { errNoticeT = performance.now(); Bus.emit('toast', 'เกิดข้อผิดพลาดเล็กน้อย ระบบกู้คืนให้อัตโนมัติแล้ว'); }
}
function recoverCrew() {
  for (const ch of G.chars || []) {
    try { if (ch.stair && (!LEVELS[ch.stair.s?.a] || !LEVELS[ch.stair.s?.b])) ch.stair = null; if (!LEVELS[ch.level]) { ch.level = SPEC.spawn.level; ch.x = SPEC.spawn.x1 + 10; }
      if (!Number.isFinite(ch.x)) ch.x = SPEC.spawn.x1 + 10; ch.path = []; ch.action = null; ch.busy = 0; ch.after = null; ch.onDone = null; if (ch.state !== 'sleep') ch.state = 'idle';
      for (const k in ch.needs) if (!Number.isFinite(ch.needs[k])) ch.needs[k] = 50; } catch (e) { }
  }
  if (G.party) G.party.convos = [];
  if (!Number.isFinite(G.cam.x) || !Number.isFinite(G.cam.y)) { G.cam.x = YW / 2; G.cam.y = YH / 2; }
}
function safeUpdate(dt) {
  try { update(dt); } catch (e) { reportError(e, 'update'); recoverCrew(); }
}
function update(dt) {
  G.time += dt; G.dt = dt;
  const j = G.journey;
  if (G.screen === 'game' && !G.coop?.guest) { j.update(dt); helmFollowAuto(j.s); } // guests follow the host's voyage
  // timezone of nearest port
  if ((tzT -= dt) <= 0) { tzT = 3; G.env.land = scanHorizon(j.s.lat, j.s.lon); const np = j.nearestPort(); if (!G.coop?.guest) G.clock.tz = np.port.tz; G.env.near = np; G.env.coast = np.dist < 26 ? { port: np.port, prox: clamp(1 - (np.dist - 3) / 23, 0, 1), docked: j.s.status === 'docked' && np.dist < 1 } : null; }
  const utc = G.clock.utc(); const sun = solarPosition(utc, j.s.lat, j.s.lon);
  Object.assign(G.env, { sunElev: sun.elev, sunAz: sun.az, heading: j.s.heading, speed: j.s.speed, moored: j.s.status === 'docked' });
  G.env.scroll += j.s.speed * dt * 9;
  G.seaState = (0.8 + Math.min(0.6, Math.abs(j.s.speed) / 20)) * (G.seaWeather || 1);
  if (G.screen === 'game' && G.party) {
    const gh = lastUtc ? clamp((utc - lastUtc) / 3.6e6, 0, 0.5) : 0; lastUtc = utc;
    G.party.update(dt, gh, G.clock.localHour());
    Sink.update(dt);
    Weather.update(dt);
    { const wp = Weather.p; G.env.vis = 40 * (1 - 0.85 * wp.fog) * (1 - 0.45 * wp.rain); } // how far land can be seen
    updateWater(dt);
    if (!G.coop?.guest) updateTender(dt);
    Coop.update(dt);
    if (!G.party || !G.player) return; // following the host can switch decks asynchronously
    updateHeli(dt);
    updateShells(dt);
    updateAutoLights(dt);
    updateCamera(dt);
    G.driveInput = keys.right ? 1 : keys.left ? -1 : (G.driveTouch || 0);
    if (G.tender?.rider === G.player?.id && (G.tender.state === 'drive' || G.tender.state === 'homing')) { /* arrows drive the tender */ }
    else if (G.player?.swim) swimInput(G.player, keys.right ? 1 : keys.left ? -1 : (G.player.swim.tapDir || 0));
    else if (keys.left || keys.right) keyWalk();
    if (G.walkMarker) G.walkMarker.t -= dt;
    if (performance.now() - G.lastAutosave > CONFIG.autosaveSeconds * 1000) saveGame('auto', true);
    if (Math.random() < dt * 0.02 && G.env.sunElev > 0) Audio.gull();
    Audio.setOceanIntensity(Math.abs(j.s.speed) / 15);
    if (G.heli) { const d = Math.hypot(G.heli.x - G.cam.x, G.heli.y - G.cam.y); Audio.rotor(G.heli.rpm * clamp(1 - d / 2600, 0.05, 1), G.heli.rpm); } else if (!G.rescueHeli) Audio.rotor(0, 0);
  } else if (G.screen === 'menu' || G.screen === 'gateway') {
    G.cam.x = YW / 2 + Math.sin(G.time * 0.08) * Math.min(300, YW * 0.25); G.cam.y = YH / 2 - 30;
    for (const r of ROOMS) scene.shell[r.id] = 1;
  }
}
function updateShells(dt) {
  const p = G.player; const pr = p && !p.stair && !onTender(p) ? roomAt(p.level, p.x) : null;
  for (const r of ROOMS) {
    if (r.type !== 'in') continue;
    let target = 1;
    // auto view: standing inside → every cabin opens (x-ray); outside on deck / tender / water → full exterior
    const inside = !!(p && !onTender(p) && !p.inHeli && (p.stair || (pr && pr.type === 'in')));
    if (G.cutawayAll) target = 0.12;
    else if (pr && pr.id === r.id) target = 0.08;
    else if (G.autoView && inside) target = 0.14;
    // when walking on a stair inside the stairwell, open it
    if (p?.stair && r.stair && (r.level === p.stair.s.a || r.level === p.stair.s.b)) target = Math.min(target, 0.15);
    scene.shell[r.id] = lerp(scene.shell[r.id], target, clamp(dt * 6, 0, 1));
    if (Math.abs(scene.shell[r.id] - target) < 0.01) scene.shell[r.id] = target;
  }
}
function updateCamera(dt) {
  const c = G.cam;
  const heli = G.heliCam && G.heli;
  if (heli) { c.tx = G.heli.x - G.heli.facing * 20; c.ty = G.heli.y - 40; }
  else if (c.follow && G.player) {
    let [x, y] = G.player.pos(); const P = G.player;
    if (onTender(P)) { x = G.tender.x; y = G.tender.y; }
    else if (!P.stair && !P.swim && !P.inHeli) { const r = roomAt(P.level, P.x), vw = innerWidth / c.scale; if (r && r.x2 - r.x1 + 16 <= vw) x = (r.x1 + r.x2) / 2; } // whole room framed while it fits
    c.tx = x; c.ty = y - 22;
  }
  c.x = lerp(c.x, c.tx, clamp(dt * (heli ? 6 : 4), 0, 1)); c.y = lerp(c.y, c.ty, clamp(dt * (heli ? 6 : 4), 0, 1));
  if (G.shake > 0) { G.shake = Math.max(0, G.shake - dt); const a = G.shake * 10; c.x += (Math.random() - 0.5) * a; c.y += (Math.random() - 0.5) * a; }
  const H = scene.H || 200; const far = heli || (onTender(G.player) && G.tender.state !== 'standoff'); const lo = far ? -4200 : -260, hi = far ? YW + 4200 : YW - 40;
  const deep = G.player?.swim ? 90 : G.sink ? Math.min(240, G.sink.dy) : 0; // follow a swimmer (or the shark) below the surface
  c.tx = clamp(c.tx, lo, hi); c.ty = clamp(c.ty, heli ? -700 : -20, YH - 40 + deep);
  c.x = clamp(c.x, lo, hi); c.y = clamp(c.y, Math.min(H / 2 - (heli ? 700 : 30), YH / 2), Math.max(YH + 12 + deep - H / 2, YH / 2));
}
// hi-res render factor: keep each canvas pixel ≥ d device pixels (d by quality tier) and cap the canvas size
function renderRes(ps) {
  if (G.screen !== 'game') return 1;
  // never go finer than the OCs' own source art (otherwise their pixels would be duplicated unevenly)
  let cap = 6; for (const ch of G.chars || []) { const s = ch.spr; if (s?.fh) cap = Math.min(cap, Math.max(1, Math.floor(s.fh / s.h))); }
  const d = [4, 3, 2][G.quality] ?? 3; let R = Math.min(cap, Math.floor(ps / d));
  while (R > 1 && (innerWidth * innerHeight * Math.pow((window.devicePixelRatio || 1) * R / ps, 2)) > 2.2e6) R--;
  return Math.max(1, R);
}
export function maxScale() { return clamp(Math.floor(innerHeight / 58), 6, 16); } // max zoom ≈ one cabin (40 px tall) fills the screen
function render(dt) {
  const cssW = innerWidth, cssH = innerHeight;
  const dprQ = [1, 2, 3][G.quality] || 1; const dpr = Math.min(window.devicePixelRatio || 1, dprQ);
  // integer device pixels per world pixel; when zoomed in, the scene is rendered R× finer (R·d = ps, both integers → no distortion)
  let ps = Math.max(1, Math.round(G.cam.scale * dpr));
  const R = renderRes(ps); if (R > 1) ps = R * Math.max(1, Math.round(ps / R));
  const W = Math.ceil(cssW * dpr / ps), H = Math.ceil(cssH * dpr / ps);
  scene.resize(W, H, R);
  presenter.resize(W * ps, H * ps); const cw = W * ps / dpr, chh = H * ps / dpr; canvas.style.width = cw + 'px'; canvas.style.height = chh + 'px';
  canvas.style.left = -Math.round((cw - cssW) / 2) + 'px'; canvas.style.top = -Math.round((chh - cssH) / 2) + 'px'; // integer pixel scale overshoots a little: centre it
  G.drawCharacters = drawCharacters; G.drawAfterShell = drawAfterShell; G.drawCharAt = (c, ch, x, y) => drawChar(c, ch, x, y);
  if (G.screen === 'menu') { G.decor = G.decor || []; }
  scene.render(G, dt);
  const night = scene.pal.night;
  presenter.present(scene.cv, scene.lcv, W * R, H * R, { tint: [1, 1, 1 + night * 0.04], vig: G.photo ? 0.5 : 0.32, sat: 1.04 });
  UI.tick?.(dt);
}
function drawCharacters(c, l, sc, ambCss) {
  if (G.screen !== 'game' || !G.party) return;
  const list = [...G.chars].sort((a, b) => a.z - b.z);
  Coop.draw(c);
  for (const ch of list) {
    if (onTender(ch) || ch.inHeli || (G.coopSolo && ch !== G.player)) continue;
    if (ch.lost) continue;
    if (ch.swim?.phase === 'shark' && ch.swim.y > WL + 45) continue; // dragged under
    let [x, y] = ch.pos();
    if (ch.drag) { x = ch.drag.x; y = ch.drag.y; }
    if (ch.hoist) { x = ch.hoist.x; y = ch.hoist.y + 30; }
    if ((ch.swim || ch.hoist) && G.sink) { c.save(); l.save(); sc.setST(c); sc.setST(l); } // in the sea / on the winch, not on the tilting hull
    const b = drawChar(c, ch, x, y, { marker: ch === G.player && !G.photo, alpha: ch.drag ? 0.75 : null });
    ch.bounds = b;
    if ((ch.swim || ch.hoist) && G.sink) { c.restore(); l.restore(); continue; }
    // ambient light for characters outdoors (indoor rooms are lit by their room rect)
    const r = ch.stair ? null : roomAt(ch.level, ch.x);
    if (!r || r.type === 'out' || ch.drag) { l.save(); const tmp = sc.tinted(spriteFrameCanvas(ch, x, y), ambCss); l.drawImage(tmp, 0, 0, frameCv.width, frameCv.height, Math.round(x) - 40, Math.round(y) - 70, frameCv.width, frameCv.height); l.restore(); }
  }
}
let frameCv = null, frameCx = null;
function spriteFrameCanvas(ch, x, y) {
  if (!frameCv) { frameCv = document.createElement('canvas'); frameCv.width = 80; frameCv.height = 90; frameCx = frameCv.getContext('2d'); }
  frameCx.setTransform(1, 0, 0, 1, 0, 0); frameCx.clearRect(0, 0, 80, 90); frameCx.translate(40 - Math.round(x), 70 - Math.round(y));
  const bub = ch.bubble; ch.bubble = null; drawChar(frameCx, ch, x, y, { silhouette: true }); ch.bubble = bub;
  return frameCv;
}

function onResize() { if (G.screen === 'menu') G.cam.scale = menuScale(); Bus.emit('resize'); }

/* ---------------- input ---------------- */
const keys = { left: false, right: false };
function keyWalk() { const p = G.player; if (!p || G.photo) return; const dir = keys.right ? 1 : -1; if (p.state === 'sleep' || p.state === 'sit' || p.state === 'lie') G.party.standUp(p); const L = LEVELS[p.level]; if (p.stair) return; if (p.level === 'swim' && dir < 0 && p.x <= L.x1 + 1.5 && !p.path.length) { fallOverboard(p); return; } const tx = clamp(p.x + dir * 30, L.x1, L.x2); p.path = [{ t: 'walk', level: p.level, x: tx }]; p.action = null; p.state = 'walk'; G.cam.follow = true; }
function toVirtual(e) { const r = canvas.getBoundingClientRect(); return [(e.clientX - r.left) / r.width * scene.W, (e.clientY - r.top) / r.height * scene.H]; }
export function screenToYacht(e) { const [vx, vy] = toVirtual(e); return scene.screenToYacht(G, vx, vy); }
export function levelAt(x, y) {
  let best = null, bd = 1e9;
  for (const [id, L] of Object.entries(LEVELS)) { if (x < L.x1 - 6 || x > L.x2 + 6) continue; const d = L.y - y; if (d >= -6 && d <= 46 && d < bd) { bd = d; best = id; } }
  return best;
}
function roomVisible(r) { return r.type === 'out' || scene.shell[r.id] < 0.5; }
function pickObject(x, y) {
  for (const o of OBJECTS) { const [rx, ry, rw, rh] = o.rect; if (x >= rx - 2 && x <= rx + rw + 2 && y >= ry - 2 && y <= ry + rh + 2) { const r = ROOMS.find(k => k.id === o.room); if (roomVisible(r)) return o; } }
  return null;
}
function pickChar(x, y) {
  for (const ch of [...G.chars].reverse()) { const b = ch.bounds; if (!b || onTender(ch) || ch.inHeli || (G.coopSolo && ch !== G.player)) continue; const r = ch.stair ? null : roomAt(ch.level, ch.x); if (r && !roomVisible(r)) continue; if (x >= b[0] - 2 && x <= b[0] + b[2] + 2 && y >= b[1] - 2 && y <= b[1] + b[3] + 2) return ch; }
  return null;
}
function pickDecor(x, y) { for (const d of [...G.decor].reverse()) { const L = LEVELS[d.level]; if (Math.abs(d.x - x) < 10 && y > L.y - 34 && y < L.y + 2) return d; } return null; }
export function placeDecor(type, e) {
  const [x, y] = screenToYacht(e); const lv = levelAt(x, y);
  if (!lv || (G.inventory[type] || 0) <= 0) return Bus.emit('toast', 'วางตรงนี้ไม่ได้ — ต้องวางบนพื้นเรือ'), false;
  const L = LEVELS[lv]; G.decor.push({ id: uid('d'), type, level: lv, x: clamp(Math.round(x), L.x1, L.x2), color: ['#7fb7c9', '#e7a27c', '#a8cc6e', '#f4d7c5'][G.decor.length % 4] });
  G.inventory[type]--; Bus.emit('inventory'); Audio.click(1200); return true;
}
export function decorPreview(e) { if (!e) { G.dropPreview = null; return; } const [x, y] = screenToYacht(e); const lv = levelAt(x, y); G.dropPreview = lv ? { level: lv, x: Math.round(x), ok: true } : null; }

function setupInput() {
  const pointers = new Map(); let down = null, pinch = null, lpTimer = null;
  canvas.addEventListener('contextmenu', e => e.preventDefault());
  canvas.addEventListener('pointerdown', e => {
    Audio.start();
    if (G.screen !== 'game') return;
    canvas.setPointerCapture(e.pointerId); pointers.set(e.pointerId, [e.clientX, e.clientY]);
    if (pointers.size === 2) { const [a, b] = [...pointers.values()]; pinch = { d: Math.hypot(a[0] - b[0], a[1] - b[1]), s: G.cam.scale }; down = null; clearTimeout(lpTimer); return; }
    const [x, y] = screenToYacht(e);
    down = { x: e.clientX, y: e.clientY, cx: G.cam.x, cy: G.cam.y, yx: x, yy: y, moved: false, long: false };
    if (G.staging) { const ch = pickChar(x, y); if (ch) { down.dragChar = ch; ch.drag = { x, y: y + 10 }; G.party.standUp(ch); ch.path = []; ch.action = null; return; } const d = pickDecor(x, y); if (d) { down.dragDecor = d; return; } }
    lpTimer = setTimeout(() => { if (down && !down.moved) { down.long = true; contextAt(e, x, y); } }, 520);
  });
  canvas.addEventListener('pointermove', e => {
    if (G.screen !== 'game') return;
    if (pointers.has(e.pointerId)) pointers.set(e.pointerId, [e.clientX, e.clientY]);
    if (pinch && pointers.size === 2) { const [a, b] = [...pointers.values()]; const d = Math.hypot(a[0] - b[0], a[1] - b[1]); const s = clamp(Math.round(pinch.s * d / pinch.d), 1, maxScale()); if (s !== G.cam.scale) { G.cam.scale = s; G.settings.zoom = s; } return; }
    const [x, y] = screenToYacht(e);
    if (!down) { if (e.pointerType === 'mouse') { const o = pickObject(x, y); const ch = pickChar(x, y); G.hoverObj = o; canvas.style.cursor = o || ch ? 'pointer' : G.staging ? 'grab' : 'default'; } return; }
    const dx = e.clientX - down.x, dy = e.clientY - down.y;
    if (Math.hypot(dx, dy) > 6) { down.moved = true; clearTimeout(lpTimer); }
    if (down.dragChar) { const lv = levelAt(x, y + 8); down.dragChar.drag = { x, y: y + 10 }; G.dropPreview = lv ? { level: lv, x: Math.round(x), ok: true } : { level: down.dragChar.level, x: Math.round(x), ok: false }; return; }
    if (down.dragDecor) { const lv = levelAt(x, y); if (lv) { down.dragDecor.level = lv; down.dragDecor.x = clamp(Math.round(x), LEVELS[lv].x1, LEVELS[lv].x2); } return; }
    if (down.moved) { const k = scene.W / canvas.getBoundingClientRect().width; G.cam.follow = false; G.cam.tx = G.cam.x = down.cx - dx * k; G.cam.ty = G.cam.y = down.cy - dy * k; }
  });
  const up = e => {
    pointers.delete(e.pointerId); if (pointers.size < 2) pinch = null; clearTimeout(lpTimer);
    if (G.screen !== 'game' || !down) { down = null; return; }
    const d = down; down = null; const [x, y] = screenToYacht(e);
    if (d.dragChar) { const ch = d.dragChar; ch.drag = null; const lv = levelAt(x, y + 8); if (lv) { const L = LEVELS[lv]; ch.level = lv; ch.x = clamp(x, L.x1, L.x2); ch.stair = null; ch.state = 'idle'; Audio.click(600); } else Bus.emit('toast', 'วางตัวละครได้เฉพาะบนพื้นเรือ'); G.dropPreview = null; return; }
    if (d.dragDecor) { if (!d.moved) UI.decorMenu(d.dragDecor); return; }
    if (d.moved || d.long) return;
    click(x, y, e);
  };
  canvas.addEventListener('pointerup', up); canvas.addEventListener('pointercancel', up);
  canvas.addEventListener('wheel', e => { if (G.screen !== 'game') return; e.preventDefault(); zoomBy(e.deltaY < 0 ? 1 : -1); }, { passive: false });
  addEventListener('keydown', e => {
    if (G.screen !== 'game' || e.target.matches('input,textarea,select')) return;
    const k = e.key.toLowerCase();
    if (G.flying && G.heli) { const m = G.heli.manual; if (k === 'arrowup' || k === 'w') m.up = 1; if (k === 'arrowdown' || k === 's') m.down = 1; if (k === 'arrowleft' || k === 'a') m.left = 1; if (k === 'arrowright' || k === 'd') m.right = 1; if (k === 'q' || k === 'e') UI.heliPedal(); if (k === 'escape') endManualFlight(); if (['arrowup', 'arrowdown', 'arrowleft', 'arrowright', ' '].includes(k)) e.preventDefault(); return; }
    if (k === 'arrowleft' || k === 'a') keys.left = true; if (k === 'arrowright' || k === 'd') keys.right = true;
    if (k === 'arrowup' || k === 'w') floorNav(1); if (k === 'arrowdown' || k === 's') floorNav(-1);
    if (k === 'enter' || k === 't') { e.preventDefault(); UI.sayBar(); return; }
    if (k === 'tab') { e.preventDefault(); const i = G.chars.indexOf(G.player); setPlayer(G.chars[(i + 1) % G.chars.length]); }
    if (k === 'm') UI.mapWindow(); if (k === 'f') UI.toggleFullscreen(); if (k === 'c') { G.autoView = !G.autoView; G.settings.autoView = G.autoView; Bus.emit('hud'); Bus.emit('toast', G.autoView ? 'มุมมองอัตโนมัติ: เปิด' : 'มุมมองอัตโนมัติ: ปิด'); }
    if (k === '+' || k === '=') zoomBy(1); if (k === '-') zoomBy(-1);
    if (k === 'escape' && G.photo) UI.photoMode(false);
  });
  addEventListener('keyup', e => { const k = e.key.toLowerCase(); if (G.heli) { const m = G.heli.manual; if (k === 'arrowup' || k === 'w') m.up = 0; if (k === 'arrowdown' || k === 's') m.down = 0; if (k === 'arrowleft' || k === 'a') m.left = 0; if (k === 'arrowright' || k === 'd') m.right = 0; } if (k === 'arrowleft' || k === 'a') keys.left = false; if (k === 'arrowright' || k === 'd') keys.right = false; });
}
export function zoomBy(d) { const s = G.cam.scale; G.cam.scale = clamp(s + d * (s >= 8 ? 2 : 1), 1, maxScale()); G.settings.zoom = G.cam.scale; Bus.emit('zoom', G.cam.scale); }
export function floorNav(dir) {
  const order = LEVEL_ORDER; const cur = order.reduce((best, id) => Math.abs(LEVELS[id].y - 22 - G.cam.ty) < Math.abs(LEVELS[best].y - 22 - G.cam.ty) ? id : best, order[0]);
  const i = clamp(order.indexOf(cur) + dir, 0, order.length - 1); G.heliCam = false; G.cam.follow = false; G.cam.ty = LEVELS[order[i]].y - 22; Bus.emit('toast', LEVELS[order[i]].name);
}
function click(x, y, e) {
  if (G.player?.swim) { const s = G.player.swim; s.tapDir = x > s.x ? 1 : -1; return; }
  if (G.flying) return;
  const p = G.player; if (!p || p.inHeli) return;
  if (G.tender.rider === p.id) { tenderCmd('disembark'); return; }
  if (onTender(p)) { tenderCmd('unmuster'); return; }
  const ch = pickChar(x, y);
  if (ch && ch !== p) { UI.charMenu(ch, e); return; }
  if (ch === p && (p.state === 'sleep')) { G.party.wake(p); return; }
  const o = pickObject(x, y);
  if (o) { if (!G.staging) { G.party.interact(p, o, defaultVerb(o)); G.cam.follow = true; Audio.click(); } return; }
  if (G.staging) return;
  const lv = levelAt(x, y);
  if (lv) { const L = LEVELS[lv]; const tx = clamp(x, L.x1, L.x2); if (G.party.goto(p, lv, tx)) { G.walkMarker = { level: lv, x: Math.round(tx), t: 1 }; G.cam.follow = true; } }
}
export function defaultVerb(o) { return { bed: 'sleep', sofa: 'sit', lounger: 'sit', dining: 'eat', bar: 'eat', cinema: 'sit', desk: 'sit' }[o.kind] || 'use'; }
function contextAt(e, x, y) {
  const ch = pickChar(x, y); if (ch) return UI.charMenu(ch, e);
  const o = pickObject(x, y); if (o) return UI.objectMenu(o, e);
  const lv = levelAt(x, y); if (lv) UI.floorMenu(lv, x, e);
}

/* ---------------- photo ---------------- */
export function capturePhoto() { try { return canvas.toDataURL('image/png'); } catch (e) { Bus.emit('toast', 'จับภาพไม่สำเร็จ'); return null; } }

Bus.on('journey:arrived', p => { Bus.emit('toast', 'ถึงแล้ว: ' + p.th); saveGame('auto', true); });
Bus.on('player:sleep', () => UI.sleepPrompt());
document.addEventListener('visibilitychange', () => { if (document.hidden) { if (G.screen === 'game') saveGame('auto', true); } else { last = performance.now(); Audio.wake?.(); } });
// audio is suspended by mobile OSes (app switch, phone call, silent switch): wake it on the next touch / key
for (const ev of ['pointerdown', 'touchend', 'keydown']) addEventListener(ev, () => Audio.wake?.(), { passive: true, capture: true });
addEventListener('pageshow', e => { if (e.persisted) { last = performance.now(); Audio.wake?.(); Bus.emit('resize'); } });
addEventListener('pagehide', () => { Coop.leave(true); if (G.screen === 'game') saveGame('auto', true); });
// GPU context can be dropped by the OS (mobile tab switch, driver reset): pause drawing and rebuild instead of going black / crashing
let glLost = false, glLostAt = 0;
function watchContext() {
  if (canvas.__watch) return; canvas.__watch = true;
  const loseExt = presenter?.gl?.getExtension?.('WEBGL_lose_context');
  canvas.addEventListener('webglcontextlost', e => { e.preventDefault(); glLost = true; glLostAt = performance.now(); console.warn('WebGL context lost'); });
  // some mobile browsers (iOS Safari) never fire 'restored' on their own: ask for it once the page is visible again
  setInterval(() => { if (glLost && !document.hidden && performance.now() - glLostAt > 1500) { glLostAt = performance.now(); try { loseExt?.restoreContext(); } catch (e) { } } }, 1000);
  canvas.addEventListener('webglcontextrestored', () => { try { presenter = new Presenter(canvas); glLost = false; Bus.emit('toast', 'กู้คืนการแสดงผลแล้ว'); } catch (e) { reportError(e, 'gl-restore'); } });
}
addEventListener('error', e => { if (e?.error) reportError(e.error, 'global'); });
addEventListener('unhandledrejection', e => { reportError(e.reason, 'promise'); e.preventDefault?.(); });

boot();
