// Robust image import: real file pickers that work on desktop / Android / iOS (and inside sandboxed frames),
// tolerant format detection, decode with fallbacks, background removal and pixel-art friendly scaling.
import { el, makeCanvas, loadImage } from './util.js';
import { icon } from './icons.js';

export const IMAGE_ACCEPT = 'image/*,.png,.webp,.jpg,.jpeg,.gif,.bmp,.avif';
const EXT_OK = /\.(png|webp|jpe?g|gif|bmp|avif)$/i, EXT_HEIC = /\.(heic|heif)$/i;
export const MAX_IMAGE_BYTES = 25 * 1024 * 1024;

// A <label> wrapping a visually-hidden <input type=file>: activation is native, so it works where input.click() is blocked.
export function filePicker(label, { icon: ic = 'image', cls = 'small', accept = IMAGE_ACCEPT } = {}, onfile) {
  const inp = el('input', { type: 'file', accept, class: 'vh-input', tabindex: '-1' });
  inp.addEventListener('change', () => { const f = inp.files && inp.files[0]; inp.value = ''; if (f) onfile(f); });
  const lab = el('label', { class: 'btn ' + cls, role: 'button', tabindex: '0', html: icon(ic, 16) + `<span>${label}</span>` });
  lab.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); inp.click(); } });
  lab.append(inp); lab.input = inp; return lab;
}

export function checkImageFile(file) {
  if (!file) return 'ไม่พบไฟล์';
  if (EXT_HEIC.test(file.name) || /heic|heif/i.test(file.type)) return 'ไฟล์ HEIC/HEIF ยังไม่รองรับในเบราว์เซอร์ส่วนใหญ่ — กรุณาแปลงเป็น PNG หรือ JPG ก่อน';
  const okType = file.type ? file.type.startsWith('image/') && !/svg/i.test(file.type) : EXT_OK.test(file.name);
  if (!okType && !EXT_OK.test(file.name)) return `ไฟล์ "${file.name}" ไม่ใช่ไฟล์ภาพที่รองรับ (PNG, WebP, JPG, GIF, BMP, AVIF)`;
  if (file.size > MAX_IMAGE_BYTES) return `ไฟล์ใหญ่เกินไป (${(file.size / 1048576).toFixed(1)} MB) — สูงสุด 25 MB`;
  if (file.size === 0) return 'ไฟล์ว่างเปล่า';
  return null;
}

// decode to a canvas; tries createImageBitmap then <img> with an object URL
export async function decodeImage(src) {
  let img = null;
  if (src instanceof Blob) {
    try { img = await createImageBitmap(src); } catch { }
    if (!img) { const url = URL.createObjectURL(src); try { img = await loadImage(url); } catch { } finally { setTimeout(() => URL.revokeObjectURL(url), 2000); } }
  } else if (typeof src === 'string') img = await loadImage(src);
  if (!img || !img.width) throw new Error('ไม่สามารถถอดรหัสภาพได้ ไฟล์อาจเสียหายหรือเป็นรูปแบบที่ไม่รองรับ');
  const [cv, c] = makeCanvas(img.width, img.height); c.drawImage(img, 0, 0); img.close?.();
  return cv;
}

export function hasTransparency(cv) {
  const d = cv.getContext('2d').getImageData(0, 0, cv.width, cv.height).data;
  for (let i = 3; i < d.length; i += 4 * 7) if (d[i] < 250) return true;
  return false;
}
// flood-fill the background from the borders (colour taken from the corners) → transparent
export function removeBackground(cv, tol = 38) {
  const W = cv.width, H = cv.height, c = cv.getContext('2d'); const id = c.getImageData(0, 0, W, H), d = id.data;
  const corners = [0, W - 1, (H - 1) * W, H * W - 1].map(i => [d[i * 4], d[i * 4 + 1], d[i * 4 + 2]]);
  const near = i => corners.some(([r, g, b]) => Math.abs(d[i * 4] - r) + Math.abs(d[i * 4 + 1] - g) + Math.abs(d[i * 4 + 2] - b) <= tol);
  const seen = new Uint8Array(W * H); const st = [];
  for (let x = 0; x < W; x++) st.push(x, (H - 1) * W + x); for (let y = 0; y < H; y++) st.push(y * W, y * W + W - 1);
  while (st.length) { const i = st.pop(); if (seen[i] || !near(i)) continue; seen[i] = 1; d[i * 4 + 3] = 0; const x = i % W; if (x > 0) st.push(i - 1); if (x < W - 1) st.push(i + 1); if (i >= W) st.push(i - W); if (i < W * (H - 1)) st.push(i + W); }
  c.putImageData(id, 0, 0); return cv;
}
// detect integer up-scaled pixel art (blocks of identical pixels) → factor, else 1
export function detectPixelScale(cv) {
  // pixel art upscaled by k has every colour change on the same column/row phase modulo k
  const W = cv.width, H = cv.height; if (W < 24 || H < 24) return 1;
  const d = cv.getContext('2d').getImageData(0, 0, W, H).data;
  const diff = (a, b) => Math.abs(d[a] - d[b]) + Math.abs(d[a + 1] - d[b + 1]) + Math.abs(d[a + 2] - d[b + 2]) + Math.abs(d[a + 3] - d[b + 3]) > 24;
  const xs = [], ys = [];
  for (let y = 0; y < H; y += Math.max(1, (H / 60) | 0)) for (let x = 0; x < W - 1; x++) { const i = (y * W + x) * 4; if (diff(i, i + 4)) xs.push(x + 1); }
  for (let x = 0; x < W; x += Math.max(1, (W / 60) | 0)) for (let y = 0; y < H - 1; y++) { const i = (y * W + x) * 4; if (diff(i, i + W * 4)) ys.push(y + 1); }
  if (xs.length < 120 || ys.length < 120) return 1;
  const phaseRatio = (arr, k) => { const h = new Array(k).fill(0); for (const v of arr) h[v % k]++; return Math.max(...h) / arr.length; };
  for (const k of [16, 12, 10, 8, 7, 6, 5, 4, 3, 2]) if (phaseRatio(xs, k) > 0.9 && phaseRatio(ys, k) > 0.9) return k;
  return 1;
}
export function scaleCanvas(cv, w, h, pixel) {
  w = Math.max(1, Math.round(w)); h = Math.max(1, Math.round(h));
  if (pixel) { const [o, c] = makeCanvas(w, h); c.imageSmoothingEnabled = false; c.drawImage(cv, 0, 0, w, h); return o; }
  let src = cv;
  while (src.width / 2 >= w && src.height / 2 >= h) { const [t, tc] = makeCanvas(Math.round(src.width / 2), Math.round(src.height / 2)); tc.imageSmoothingEnabled = true; tc.imageSmoothingQuality = 'high'; tc.drawImage(src, 0, 0, t.width, t.height); src = t; }
  const [o, c] = makeCanvas(w, h); c.imageSmoothingEnabled = true; c.imageSmoothingQuality = 'high'; c.drawImage(src, 0, 0, w, h); return o;
}
export function trimCanvas(cv) {
  const c = cv.getContext('2d'); const d = c.getImageData(0, 0, cv.width, cv.height).data; let x1 = cv.width, y1 = cv.height, x2 = -1, y2 = -1;
  for (let y = 0; y < cv.height; y++) for (let x = 0; x < cv.width; x++) if (d[(y * cv.width + x) * 4 + 3] > 8) { if (x < x1) x1 = x; if (y < y1) y1 = y; if (x > x2) x2 = x; if (y > y2) y2 = y; }
  if (x2 < x1) return cv; const [o, oc] = makeCanvas(x2 - x1 + 1, y2 - y1 + 1); oc.drawImage(cv, -x1, -y1); return o;
}
