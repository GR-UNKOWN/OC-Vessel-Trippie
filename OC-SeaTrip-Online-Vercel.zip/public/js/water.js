// Falling overboard — a silent trap. No warning, no hint: stay in the water for 3 seconds and a ~9 m shark
// (two cars long; body plan from the reef-shark reference: slender torpedo body, pointed snout, tall first dorsal,
// long upper tail lobe, pale flank band, white belly and black-tipped fins) rockets up from below, a full-screen
// jaw close-up slams in with a CHOMP, blood blooms underwater and you're dragged into the dark. Then you warp
// straight back onto the aft deck.
import { Bus, clamp, lerp, makeCanvas, el } from './util.js';
import { LEVELS, WL, SPEC } from './yacht.js';
import { G } from './main.js';
import { Audio } from './audio.js';

const GRACE = 3;                 // seconds before it strikes
const PX_PER_M = 20, SHARK_M = 9; // 9 m ≈ two cars nose to tail
const fx = []; let shark = null; let scareEl = null;

export function fallOverboard(ch, x) {
  if (!ch || ch.swim || ch.inHeli) return;
  G.party?.standUp?.(ch); ch.path = []; ch.action = null; ch.stair = null;
  const [px, py] = ch.pos();
  ch.swim = { phase: 'fall', x: x ?? px - 6, y: py, vy: -40, t: 0 };
  ch.state = 'idle'; splash(ch.swim.x, WL);
}
export function swimInput(ch, dir) { if (ch?.swim && ch.swim.phase === 'swim') ch.swim.dir = dir; }

export function updateWater(dt) {
  for (const ch of G.chars || []) {
    const s = ch.swim; if (!s) continue; s.t += dt;
    const L = LEVELS.swim;
    if (s.phase === 'fall') { s.vy += 260 * dt; s.y += s.vy * dt; s.x -= 10 * dt; if (s.y >= WL + 9) { s.y = WL + 9; s.phase = 'swim'; s.t = 0; splash(s.x, WL); } }
    else if (s.phase === 'swim') {
      s.y = WL + 9 + Math.sin(G.time * 3) * 0.8; s.x += (s.dir || 0) * 22 * dt;
      // reach a floating tender → climb in (the only way out once the yacht is gone)
      const td = G.tender; if (td && !['stowed', 'opening', 'sliding', 'returning', 'closing'].includes(td.state) && Math.abs(s.x - td.x) < 52) {
        ch.swim = null; if (!td.rider && ch === G.player) { td.rider = ch.id; td.state = 'drive'; td.vx = 0; td.face = td.face || -1; Bus.emit('drive'); } else if (!(td.pax ||= []).includes(ch.id)) td.pax.push(ch.id); continue;
      }
      if (L && !G.sink && s.x >= L.x1 - 4) { ch.swim = null; ch.level = 'swim'; ch.x = clamp(L.x1 + 6, L.x1, L.x2); ch.state = 'idle'; continue; }
      if (ch !== G.player && ch.mode === 'bot') s.dir = 1;
      if (s.t >= GRACE && !shark) startShark(ch);
    }
  }
  if (shark) updateShark(dt);
  for (const p of fx) { p.t += dt; p.x += p.vx * dt; p.y += p.vy * dt; p.vx *= 0.97; p.vy *= 0.97; p.r += p.gr * dt; }
  for (let i = fx.length - 1; i >= 0; i--) if (fx[i].t > fx[i].life) fx.splice(i, 1);
}

/* ---------------- the strike ---------------- */
function victimPos(ch) { return ch.swim ? [ch.swim.x, ch.swim.y] : ch.pos(); }
function startShark(ch, visualOnly = false) {
  const [vx, vy] = victimPos(ch);
  // comes from deep below and behind, nearly vertical, mouth already opening
  shark = { ch, visualOnly, t: 0, phase: 'strike', x: vx - 40, y: vy + 150, vx, vy, ang: -1.2, jaw: 0.4, tail: 0, stop: 0 };
  if (ch.swim) ch.swim.phase = 'shark';
  if (ch === G.player || visualOnly) Audio.rush?.();
}
export function remoteShark(remote) { if (shark) return; startShark({ remote, name: remote.name, pos: () => [remote.x, remote.y] }, true); }
function updateShark(dt) {
  const k = shark;
  if (k.stop > 0) { k.stop -= dt; return; } // hit-stop freeze on the bite
  k.t += dt; k.tail += dt * (k.phase === 'drag' ? 16 : 22);
  if (k.phase === 'strike') {
    const f = clamp(k.t / 0.28, 0, 1), e = f * f;                         // accelerating lunge
    k.x = lerp(k.vx - 40, k.vx - 6, e); k.y = lerp(k.vy + 150, k.vy + 10, e); k.ang = lerp(-1.2, -0.75, e); k.jaw = lerp(0.4, 1, f);
    if (f >= 1) { k.phase = 'bite'; k.t = 0; bite(k); }
  } else if (k.phase === 'bite') {                                        // jaws slam shut, thrash
    k.jaw = Math.max(0, 1 - k.t * 8); k.ang = -0.75 + Math.sin(k.t * 45) * 0.12; k.x = k.vx - 6 + Math.sin(k.t * 38) * 4;
    if (Math.random() < 0.8) blood(k.vx + (Math.random() - 0.5) * 16, k.vy + 6 + Math.random() * 10, 4);
    if (k.t > 0.6) { k.phase = 'drag'; k.t = 0; Audio.drag?.(); }
  } else if (k.phase === 'drag') {                                        // dives, dragging the victim into the dark
    k.ang = lerp(k.ang, 0.9, dt * 4); k.x += 45 * dt; k.y += 120 * dt;
    if (Math.random() < 0.9) blood(k.x, k.y, 3);
    if (k.ch.swim) { k.ch.swim.x = k.x; k.ch.swim.y = k.y; }
    if (k.t > 1.5) { warp(k.ch); shark = null; }
  }
}
function bite(k) {
  for (let i = 0; i < 30; i++) blood(k.vx + (Math.random() - 0.5) * 20, k.vy + 4 + Math.random() * 12, 6);
  splash(k.vx, WL, 3); k.stop = 0.12;
  if (k.ch === G.player || k.visualOnly) { Audio.chomp?.(); G.shake = 0.7; jumpScare(); }
}
// warp straight back aboard (aft deck), with a quick white flash
function warp(ch) {
  if (ch.remote) return;
  if (G.sink) { ch.swim = null; ch.lost = true; return; } // the yacht is gone: wait for the world to reset
  ch.swim = null; const r = SPEC.rooms.find(r => r.io === 'out' && r.type_ === 'aftdeck');
  if (r) { ch.level = r.level; ch.x = (r.x1 + r.x2) / 2; } ch.state = 'idle'; ch.path = []; ch.stair = null;
  if (ch === G.player) { G.cam.follow = true; const [x, y] = ch.pos(); G.cam.x = G.cam.tx = x; G.cam.y = G.cam.ty = y - 22; warpFlash(); }
}
function blood(x, y, n) { for (let i = 0; i < n * 2; i++) fx.push({ x, y, vx: (Math.random() - 0.5) * 60, vy: (Math.random() - 0.4) * 30, r: 0.5 + Math.random() * 1.2, gr: 0.6 + Math.random() * 2.2, t: 0, life: 3 + Math.random() * 2.5, c: ['#7a0a18', '#9e1222', '#c01e2e'][(Math.random() * 3) | 0] }); }
function splash(x, y, k = 1, bias = 0) { for (let i = 0; i < Math.max(1, Math.round(10 * k)); i++) fx.push({ x: x + (Math.random() - 0.5) * 10, y: y - 1, vx: bias + (Math.random() - 0.5) * 60, vy: -30 - Math.random() * 50, r: 1, gr: 0, t: 0, life: 0.6, c: '#ffffff', spray: 1 }); }
export const splashAt = splash;

/* ---------------- full-screen jump scare ---------------- */
function jumpScare() {
  if (!scareEl || !scareEl.isConnected) {
    scareEl = el('div', { class: 'shark-scare' }); const cv = document.createElement('canvas'); scareEl.append(cv); document.body.append(scareEl);
    const head = sharkHead(); cv.width = head.width; cv.height = head.height; cv.getContext('2d').drawImage(head, 0, 0);
  }
  scareEl.classList.remove('on'); void scareEl.offsetWidth; scareEl.classList.add('on');
}
function warpFlash() { const f = el('div', { class: 'warp-flash' }); document.body.append(f); setTimeout(() => f.remove(), 700); }

/* ---------------- shark art ---------------- */
// Built as vector shapes on a small canvas, then hard-thresholded so every edge is a clean pixel edge.
const COL = { back: '#8f8371', back2: '#a39684', flank: '#bdb2a0', band: '#ddd8cc', belly: '#efede6', line: '#5e5548', tip: '#17130f', eye: '#0b0908', gill: '#6d6455', mouth: '#5a1a1e', teeth: '#f6f2ea' };
let parts = null;
function P(c, pts, col) { c.beginPath(); pts.forEach(([x, y], i) => i ? c.lineTo(x, y) : c.moveTo(x, y)); c.closePath(); c.fillStyle = col; c.fill(); }
function crisp(cv) { const c = cv.getContext('2d'); const d = c.getImageData(0, 0, cv.width, cv.height); for (let i = 3; i < d.data.length; i += 4) d.data[i] = d.data[i] > 110 ? 255 : 0; c.putImageData(d, 0, 0); return cv; }
// Outline traced from the reference photo (blacktip-type reef shark, lateral view, photo pixels, facing left),
// then mirrored to face right and scaled so the fish is SHARK_M metres long.
const REF = { x0: 725, y0: 330, len: 662 };
const BODY = [[63, 455], [72, 446], [92, 436], [130, 422], [175, 410], [230, 400], [300, 392], [360, 394], [420, 400], [480, 412], [520, 424], [552, 436], [568, 442],
  [568, 452], [552, 457], [520, 462], [490, 470], [450, 480], [400, 490], [330, 500], [260, 497], [200, 490], [150, 482], [110, 474], [80, 466]];
const DORSAL = [[296, 393], [306, 372], [318, 352], [330, 342], [344, 346], [345, 352], [340, 362], [344, 378], [362, 395]];
const DORSAL_TIP = [[318, 352], [330, 342], [344, 346], [345, 352], [336, 356], [322, 356]];
const DORSAL2 = [[488, 416], [500, 418], [512, 412], [518, 418], [516, 428]];
const DORSAL2_TIP = [[506, 415], [512, 412], [518, 418], [512, 420]];
const PECT = [[205, 488], [226, 504], [248, 524], [266, 544], [274, 548], [272, 532], [262, 510], [252, 494]];
const PECT_TIP = [[262, 538], [266, 544], [274, 548], [272, 532]];
const PELV = [[392, 492], [410, 498], [428, 504], [432, 500], [424, 488]];
const PELV_TIP = [[422, 502], [428, 504], [432, 500], [427, 496]];
const ANAL = [[472, 474], [486, 488], [500, 500], [506, 498], [496, 476]];
const ANAL_TIP = [[496, 496], [500, 500], [506, 498], [501, 491]];
const CAUDAL = [[560, 437], [600, 426], [650, 414], [700, 404], [725, 404], [712, 414], [670, 434], [630, 452], [604, 470], [606, 500], [608, 530], [600, 534], [584, 506], [570, 470], [560, 458]];
const CAUDAL_EDGE = [[725, 404], [712, 414], [670, 434], [630, 452], [604, 470], [606, 500], [608, 530]];
const CAUDAL_TIP = [[596, 512], [606, 506], [608, 530], [600, 534]];
const BELLY = [[63, 456], [100, 462], [150, 468], [220, 472], [300, 472], [350, 468], [395, 460], [430, 456], [452, 462], [470, 470], [520, 461], [568, 452], [568, 520], [40, 520]];
const BAND = [[300, 471], [350, 464], [395, 456], [430, 452], [445, 458], [420, 466], [360, 474]];
const MOUTH_OPEN = [[86, 466], [118, 474], [160, 480], [148, 510], [116, 504], [92, 486]];
const LOWER_JAW = [[92, 486], [116, 504], [148, 510], [150, 516], [112, 512], [86, 494]];
function buildParts(jawOpen) {
  const s = (SHARK_M * PX_PER_M) / REF.len;            // ≈0.27 px per photo px → ~180 px long
  const W = 196, H = 70;
  const T = ([x, y]) => [(REF.x0 - x) * s + 2, (y - REF.y0) * s + 2];
  const poly = (c, pts, col) => P(c, pts.map(T), col);
  const [b, c] = makeCanvas(W, H);
  // fins behind the body
  poly(c, DORSAL, COL.back); poly(c, DORSAL_TIP, COL.tip); poly(c, DORSAL2, COL.back); poly(c, DORSAL2_TIP, COL.tip);
  poly(c, PELV, COL.back2); poly(c, PELV_TIP, COL.tip); poly(c, ANAL, COL.back2); poly(c, ANAL_TIP, COL.tip);
  // body + countershading
  poly(c, BODY, COL.back2);
  c.save(); P(c, BODY.map(T), '#0000'); c.clip();
  poly(c, BODY.map(([x, y]) => [x, y - 22]), COL.back);              // darker back
  poly(c, BELLY, COL.belly); poly(c, BAND, COL.band);                 // white belly + pale flank band
  c.restore();
  // pectoral fin in front of the body
  poly(c, PECT, COL.back2); poly(c, PECT_TIP, COL.tip);
  // head details
  const [ex, ey] = T([113, 446]); c.fillStyle = COL.eye; c.fillRect(Math.round(ex), Math.round(ey), 2, 2); c.fillStyle = '#d8d2c4'; c.fillRect(Math.round(ex), Math.round(ey) - 1, 2, 1);
  for (let i = 0; i < 5; i++) { const [gx, gy] = T([172 + i * 9, 452]); c.fillStyle = COL.gill; c.fillRect(Math.round(gx), Math.round(gy), 1, 5 - (i === 4 ? 1 : 0)); }
  const [nx, ny] = T([78, 452]); c.fillStyle = COL.line; c.fillRect(Math.round(nx), Math.round(ny), 2, 1);
  if (jawOpen) {
    poly(c, MOUTH_OPEN, COL.mouth); poly(c, LOWER_JAW, COL.belly);
    c.fillStyle = COL.teeth;
    for (let i = 0; i <= 8; i++) { const [tx, ty] = T([90 + i * 8, 467 + i * 1.6]); c.fillRect(Math.round(tx), Math.round(ty), 1, 2); }
    for (let i = 0; i <= 6; i++) { const [tx, ty] = T([100 + i * 8, 494 + i * 1.8]); c.fillRect(Math.round(tx), Math.round(ty) - 1, 1, 2); }
  } else { c.strokeStyle = COL.line; c.beginPath(); const m = [[88, 468], [118, 475], [146, 478]].map(T); c.moveTo(...m[0]); c.lineTo(...m[1]); c.lineTo(...m[2]); c.stroke(); }
  c.save(); P(c, BODY.map(T), '#0000'); c.strokeStyle = 'rgba(70,62,52,0.55)'; c.lineWidth = 1; c.stroke(); c.restore();
  crisp(b);
  // caudal fin as its own sprite (pivot = peduncle) so it can beat
  const [t, tc] = makeCanvas(56, 70); const [px0, py0] = T([568, 447]);
  const TT = p => { const [x, y] = T(p); return [x - px0 + 54, y - py0 + 36]; };
  P(tc, CAUDAL.map(TT), COL.back2); tc.strokeStyle = COL.tip; tc.lineWidth = 1.6; tc.beginPath(); CAUDAL_EDGE.map(TT).forEach(([x, y], i) => i ? tc.lineTo(x, y) : tc.moveTo(x, y)); tc.stroke();
  P(tc, CAUDAL_TIP.map(TT), COL.tip);
  crisp(t);
  return { body: b, tail: t, pivot: [px0, py0] };
}
function sharkParts(open) { if (!parts) parts = { closed: buildParts(false), open: buildParts(true) }; return open ? parts.open : parts.closed; }
function sharkHead() { const p = sharkParts(true); const [h, hc] = makeCanvas(70, 46); hc.drawImage(p.body, 126, 14, 70, 46, 0, 0, 70, 46); return h; }

let tintCv = null;
function underwater(img, depth) {
  if (!tintCv) tintCv = makeCanvas(256, 140);
  const [cv, x] = tintCv; x.globalCompositeOperation = 'source-over'; x.clearRect(0, 0, cv.width, cv.height); x.drawImage(img, 0, 0);
  x.globalCompositeOperation = 'source-atop'; x.fillStyle = `rgba(16,70,96,${clamp(0.12 + depth / 160, 0.12, 0.8).toFixed(2)})`; x.fillRect(0, 0, cv.width, cv.height); x.globalCompositeOperation = 'source-over';
  return cv;
}
let frameCv = null;
function sharkFrame(k) {
  const p = sharkParts(k.jaw > 0.4);
  if (!frameCv) frameCv = makeCanvas(256, 140);
  const [cv, c] = frameCv; c.clearRect(0, 0, cv.width, cv.height);
  // tail beats side to side (seen as a vertical sweep) about the peduncle
  c.save(); c.translate(30 + p.pivot[0], 35 + p.pivot[1]); c.rotate(Math.sin(k.tail) * 0.2); c.drawImage(p.tail, -54, -36); c.restore();
  c.drawImage(p.body, 30, 35);
  return cv;
}
/* ---------------- drawing (after the front water, in yacht space) ---------------- */
export function drawWater(c) {
  for (const p of fx) {
    const a = clamp(1 - p.t / p.life, 0, 1);
    if (p.spray) { c.globalAlpha = a; c.fillStyle = p.c; c.fillRect(Math.round(p.x), Math.round(p.y), 1, 1); continue; }
    if (p.y < WL + 1) continue;
    c.globalAlpha = a * a * 0.6; c.fillStyle = p.c; const r = Math.max(1, Math.round(p.r)); c.fillRect(Math.round(p.x - r / 2), Math.round(p.y - r / 2), r, r);
  }
  c.globalAlpha = 1;
  if (!shark) return;
  const k = shark, fr = sharkFrame(k);
  // the mouth (≈182,72 in the frame) sits on the victim; rotate the whole fish around it
  c.save(); c.translate(Math.round(k.x), Math.round(k.y)); c.rotate(k.ang);
  c.drawImage(underwater(fr, Math.max(0, k.y - WL)), -182, -72);
  c.restore();
}
export const sharkActive = () => !!shark;
export const _sharkFrame = (jaw, tail) => { const f = sharkFrame({ jaw, tail }); const [c, x] = makeCanvas(f.width, f.height); x.drawImage(f, 0, 0); return c; };
