// Persistence: IndexedDB (guest + local accounts), PBKDF2 password hashing, save slots, versioned save data.
import { uid, Bus } from './util.js';
import { CONFIG } from './config.js';

const DB_NAME = 'oc-openseas-cozy';
const DB_VER = 1;
export const SAVE_VERSION = 3;
let db = null;
let memFallback = null; // when IndexedDB is unavailable (private mode etc.)

export async function openDB() {
  if (db || memFallback) return;
  try {
    db = await new Promise((res, rej) => {
      const r = indexedDB.open(DB_NAME, DB_VER);
      r.onupgradeneeded = () => {
        const d = r.result;
        if (!d.objectStoreNames.contains('accounts')) d.createObjectStore('accounts', { keyPath: 'id' });
        if (!d.objectStoreNames.contains('ocs')) d.createObjectStore('ocs', { keyPath: 'key' });
        if (!d.objectStoreNames.contains('saves')) d.createObjectStore('saves', { keyPath: 'key' });
        if (!d.objectStoreNames.contains('kv')) d.createObjectStore('kv', { keyPath: 'k' });
      };
      r.onsuccess = () => res(r.result);
      r.onerror = () => rej(r.error);
      r.onblocked = () => rej(new Error('IndexedDB ถูกบล็อก'));
    });
  } catch (e) {
    console.warn('IndexedDB unavailable, using memory store', e);
    memFallback = { accounts: new Map(), ocs: new Map(), saves: new Map(), kv: new Map() };
  }
}
export const storageMode = () => memFallback ? 'memory' : 'indexeddb';

function tx(store, mode, fn) {
  if (memFallback) return Promise.resolve(fn(null));
  return new Promise((res, rej) => {
    const t = db.transaction(store, mode); const s = t.objectStore(store);
    let out; const r = fn(s);
    if (r && 'onsuccess' in r) r.onsuccess = () => { out = r.result; };
    t.oncomplete = () => res(out); t.onerror = () => rej(t.error); t.onabort = () => rej(t.error || new Error('abort'));
  });
}
const keyOf = { accounts: 'id', ocs: 'key', saves: 'key', kv: 'k' };
export async function put(store, val) {
  if (memFallback) { memFallback[store].set(val[keyOf[store]], structuredClone(val)); return; }
  return tx(store, 'readwrite', s => s.put(val));
}
export async function get(store, key) {
  if (memFallback) { const v = memFallback[store].get(key); return v ? structuredClone(v) : undefined; }
  return tx(store, 'readonly', s => s.get(key));
}
export async function del(store, key) {
  if (memFallback) { memFallback[store].delete(key); return; }
  return tx(store, 'readwrite', s => s.delete(key));
}
export async function all(store) {
  if (memFallback) return [...memFallback[store].values()].map(v => structuredClone(v));
  return tx(store, 'readonly', s => s.getAll());
}
export const kvGet = async k => (await get('kv', k))?.v;
export const kvSet = (k, v) => put('kv', { k, v });

/* ---------------- Auth ---------------- */
const enc = new TextEncoder();
const b64 = buf => btoa(String.fromCharCode(...new Uint8Array(buf)));
async function pbkdf2(password, saltB64, iterations = 150000) {
  const salt = Uint8Array.from(atob(saltB64), c => c.charCodeAt(0));
  const key = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt, iterations, hash: 'SHA-256' }, key, 256);
  return b64(bits);
}
function randomB64(n = 16) { const a = new Uint8Array(n); crypto.getRandomValues(a); return b64(a); }
function safeEqual(a, b) { if (a.length !== b.length) return false; let r = 0; for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i); return r === 0; }

export function passwordStrength(pw) {
  let s = 0;
  if (pw.length >= 8) s++; if (pw.length >= 12) s++;
  if (/[a-z]/.test(pw) && /[A-Z]/.test(pw)) s++;
  if (/\d/.test(pw)) s++; if (/[^A-Za-z0-9]/.test(pw)) s++;
  const labels = ['อ่อนมาก', 'อ่อน', 'พอใช้', 'ดี', 'แข็งแรง', 'แข็งแรงมาก'];
  return { score: s, label: labels[s] };
}
export const validEmail = e => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e);
export const validUsername = u => /^[A-Za-z0-9_฀-๿]{3,20}$/.test(u);

let supa = null;
async function supabase() {
  if (!CONFIG.supabaseUrl || !CONFIG.supabaseAnonKey) return null;
  if (supa) return supa;
  const mod = await import('https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm');
  supa = mod.createClient(CONFIG.supabaseUrl, CONFIG.supabaseAnonKey);
  return supa;
}
export const authBackend = () => (CONFIG.supabaseUrl && CONFIG.supabaseAnonKey) ? 'supabase' : 'local';

export const Auth = {
  session: null, // {id, username, email, guest, backend}
  async restore() {
    const s = await kvGet('session');
    if (s) {
      if (s.named) { this.session = s; return s; }
      if (s.guest) { this.session = s; return null; } // old Guest: keep its data id, but ask for a name first
      const acc = await get('accounts', s.id);
      if (acc) { this.session = { id: acc.id, username: acc.username, email: acc.email, verified: acc.verified, backend: acc.backend || 'local' }; return this.session; }
    }
    return null;
  },
  async guest() {
    this.session = { id: 'guest', username: 'Guest', guest: true, backend: 'local' };
    await kvSet('session', this.session); return this.session;
  },
  // free play: no account, just a name. Data stays in this browser under the same local id
  // (old Guest saves/OCs carry over; an earlier local account keeps its own id).
  async player(name) {
    name = String(name || '').replace(/\s+/g, ' ').trim().slice(0, 20);
    if (!name) throw new Error('ตั้งชื่อก่อนเริ่มเล่น');
    const prev = this.session || await kvGet('session');
    this.session = { id: prev?.id || 'guest', username: name, named: true, guest: false, backend: 'local' };
    await kvSet('session', this.session); await kvSet('lastName', name); return this.session;
  },
  async usernameTaken(username) {
    const accs = await all('accounts');
    return accs.some(a => a.username.toLowerCase() === username.toLowerCase());
  },
  async register({ username, email, password }) {
    if (!validUsername(username)) throw new Error('ชื่อผู้ใช้ต้องมี 3–20 ตัวอักษร (ตัวอักษร ตัวเลข หรือ _)');
    if (!validEmail(email)) throw new Error('รูปแบบอีเมลไม่ถูกต้อง');
    if (passwordStrength(password).score < 2) throw new Error('รหัสผ่านอ่อนเกินไป ใช้อย่างน้อย 8 ตัวและผสมตัวอักษร/ตัวเลข');
    if (await this.usernameTaken(username)) throw new Error('ชื่อผู้ใช้นี้ถูกใช้แล้ว');
    const accs = await all('accounts');
    if (accs.some(a => a.email.toLowerCase() === email.toLowerCase())) throw new Error('อีเมลนี้ถูกใช้แล้ว');
    let id = uid('acc'), backend = 'local', verified = false, note = '';
    const sb = await supabase().catch(() => null);
    if (sb) {
      const { data, error } = await sb.auth.signUp({ email, password, options: { data: { username } } });
      if (error) throw new Error(error.message);
      id = data.user.id; backend = 'supabase'; note = 'ส่งอีเมลยืนยันไปที่ ' + email + ' แล้ว';
    }
    const salt = randomB64();
    const hash = backend === 'local' ? await pbkdf2(password, salt) : null;
    const recoveryCode = Array.from(crypto.getRandomValues(new Uint8Array(6))).map(b => (b % 36).toString(36)).join('').toUpperCase() + '-' + Array.from(crypto.getRandomValues(new Uint8Array(6))).map(b => (b % 36).toString(36)).join('').toUpperCase();
    const recSalt = randomB64();
    const recoveryHash = await pbkdf2(recoveryCode, recSalt, 60000);
    await put('accounts', { id, username, email, salt, hash, iterations: 150000, recSalt, recoveryHash, verified, backend, createdAt: Date.now(), slots: 12 });
    // migrate guest data when registering from guest mode
    let migrated = 0;
    if (this.session?.guest) migrated = await migrateAccountData('guest', id);
    this.session = { id, username, email, verified, backend };
    await kvSet('session', this.session);
    return { recoveryCode: backend === 'local' ? recoveryCode : null, migrated, note };
  },
  async login(identity, password) {
    const accs = await all('accounts');
    const acc = accs.find(a => a.username.toLowerCase() === identity.toLowerCase() || a.email.toLowerCase() === identity.toLowerCase());
    if (acc?.backend === 'supabase' || (!acc && authBackend() === 'supabase')) {
      const sb = await supabase();
      const email = acc?.email || identity;
      const { data, error } = await sb.auth.signInWithPassword({ email, password });
      if (error) throw new Error(error.message);
      const id = data.user.id;
      if (!acc) await put('accounts', { id, username: data.user.user_metadata?.username || email.split('@')[0], email, backend: 'supabase', verified: !!data.user.email_confirmed_at, createdAt: Date.now(), slots: 12 });
      const a2 = await get('accounts', id);
      this.session = { id, username: a2.username, email, verified: a2.verified, backend: 'supabase' };
      await kvSet('session', this.session); return this.session;
    }
    if (!acc) throw new Error('ไม่พบบัญชีนี้');
    const h = await pbkdf2(password, acc.salt, acc.iterations);
    if (!safeEqual(h, acc.hash)) throw new Error('รหัสผ่านไม่ถูกต้อง');
    this.session = { id: acc.id, username: acc.username, email: acc.email, verified: acc.verified, backend: 'local' };
    await kvSet('session', this.session); return this.session;
  },
  async recover(identity, recoveryCode, newPassword) {
    const accs = await all('accounts');
    const acc = accs.find(a => a.username.toLowerCase() === identity.toLowerCase() || a.email.toLowerCase() === identity.toLowerCase());
    if (acc?.backend === 'supabase' || (!acc && authBackend() === 'supabase')) {
      const sb = await supabase();
      const { error } = await sb.auth.resetPasswordForEmail(acc?.email || identity);
      if (error) throw new Error(error.message);
      return 'ส่งลิงก์รีเซ็ตรหัสผ่านไปที่อีเมลแล้ว';
    }
    if (!acc) throw new Error('ไม่พบบัญชีนี้');
    const h = await pbkdf2(recoveryCode.trim().toUpperCase(), acc.recSalt, 60000);
    if (!safeEqual(h, acc.recoveryHash)) throw new Error('รหัสกู้คืนไม่ถูกต้อง');
    if (passwordStrength(newPassword).score < 2) throw new Error('รหัสผ่านใหม่อ่อนเกินไป');
    acc.salt = randomB64(); acc.hash = await pbkdf2(newPassword, acc.salt);
    await put('accounts', acc);
    return 'ตั้งรหัสผ่านใหม่เรียบร้อย';
  },
  async logout() {
    if (this.session?.backend === 'supabase') { try { (await supabase())?.auth.signOut(); } catch { } }
    this.session = null; await del('kv', 'session');
  }
};

async function migrateAccountData(fromId, toId) {
  let n = 0;
  for (const o of await all('ocs')) if (o.accountId === fromId) { await put('ocs', { ...o, key: toId + ':' + o.slot, accountId: toId }); await del('ocs', o.key); n++; }
  for (const s of await all('saves')) if (s.accountId === fromId) { await put('saves', { ...s, key: toId + ':' + s.slot, accountId: toId }); await del('saves', s.key); n++; }
  return n;
}

/* ---------------- OC records ---------------- */
export const MAX_OC_SLOTS = 4; // each player owns at most 4 OCs (also what they can bring into a co-op room)
export async function listOCs(accountId) {
  return (await all('ocs')).filter(o => o.accountId === accountId).sort((a, b) => a.slot - b.slot);
}
export async function saveOC(accountId, oc) {
  const have = await listOCs(accountId);
  if (!have.some(o => o.slot === oc.slot) && have.length >= MAX_OC_SLOTS) { Bus.emit('toast', `สร้าง OC ได้ไม่เกิน ${MAX_OC_SLOTS} ตัวต่อผู้เล่น`); throw new Error('oc limit'); }
  oc.accountId = accountId; oc.key = accountId + ':' + oc.slot; oc.updatedAt = Date.now();
  await put('ocs', oc); Bus.emit('ocs:changed', oc); return oc;
}
export async function deleteOC(accountId, slot) { await del('ocs', accountId + ':' + slot); }

/* ---------------- Game saves ---------------- */
export function migrateSave(s) {
  if (!s) return s;
  if (!s.version || s.version < 2) {
    s.decor = s.decor || [];
    s.relationships = s.relationships || {};
    s.version = 2;
  }
  if (s.version < 3) { // v3: fleet of yachts (SouthCozy SeaLife + Big Orcasia)
    s.fleet = { southcozy: { paint: s.paint, decor: s.decor || [], lights: s.lights || null, roster: s.onboard || [], chars: s.chars || {} } };
    s.yachtId = 'southcozy'; s.version = 3;
  }
  return s;
}
export async function writeSave(accountId, slot, data) {
  const rec = { ...data, key: accountId + ':' + slot, accountId, slot, version: SAVE_VERSION, savedAt: Date.now() };
  await put('saves', rec);
  return rec;
}
export async function readSave(accountId, slot) { return migrateSave(await get('saves', accountId + ':' + slot)); }
export async function listSaves(accountId) { return (await all('saves')).filter(s => s.accountId === accountId).sort((a, b) => a.slot.localeCompare?.(b.slot) ?? 0); }
export async function deleteSave(accountId, slot) { await del('saves', accountId + ':' + slot); }
