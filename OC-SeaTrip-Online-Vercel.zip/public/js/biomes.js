// Regional backdrops ("biomes"): parallax coast layers, landmarks, regional boats, birds, haze, petals,
// fireflies and night city lights. Everything is generated in code as pixel art and cached per port.
import { rng, makeCanvas, clamp, lerp, mixHex, shade, hexToRgb } from './util.js';
import * as PX from './pixel.js';

/* ---------------- biome catalogue ---------------- */
export const BIOMES = {
  andaman: { th: 'ทะเลอันดามัน', water: '#3fc2c6', haze: 0.25, boats: ['longtail', 'longtail', 'speed', 'sail'], birds: 'gull', fx: 'firefly', far: ['#7fa4b0', '#93b5bf', '#a8c6cf'] },
  gulf: { th: 'อ่าวไทย', water: '#58b6ae', haze: 0.3, boats: ['longtail', 'squid', 'trawler', 'sail'], birds: 'gull', fx: 'firefly', far: ['#82a2b4', '#97b4c4', '#acc6d3'] },
  resort: { th: 'เมืองชายทะเลตะวันออก', water: '#58a6bc', haze: 0.35, boats: ['speed', 'ferry', 'longtail', 'squid'], birds: 'gull', fx: null, far: ['#9ab3c4', '#aec4d2', '#c2d4df'] },
  metro: { th: 'เมืองท่าขนาดใหญ่', water: '#4f8fae', haze: 0.45, boats: ['cargo', 'ferry', 'tug', 'cargo'], birds: 'gull', fx: null, far: ['#9db0c0', '#b0c1cf', '#c3d1dc'] },
  volcanic: { th: 'หมู่เกาะภูเขาไฟ', water: '#36adc8', haze: 0.3, boats: ['bangka', 'sail', 'speed'], birds: 'gull', fx: 'firefly', far: ['#8fa9bd', '#a6bccd', '#bccfdc'] },
  halong: { th: 'อ่าวหินปูนเวียดนาม', water: '#6aa898', haze: 0.7, boats: ['junk', 'junk', 'sampan'], birds: 'flock', fx: 'mist', far: ['#a2b8b6', '#b4c7c4', '#c6d6d3'] },
  vietcoast: { th: 'ชายฝั่งเวียดนาม', water: '#4aa6b8', haze: 0.35, boats: ['basket', 'trawler', 'sail'], birds: 'gull', fx: null, far: ['#97b2c2', '#acc3d0', '#c0d3de'] },
  philippine: { th: 'หมู่เกาะฟิลิปปินส์', water: '#34c3d2', haze: 0.25, boats: ['bangka', 'bangka', 'sail'], birds: 'gull', fx: 'firefly', far: ['#8db6c2', '#a4c7d0', '#bad7de'] },
  borneo: { th: 'ชายฝั่งบอร์เนียว', water: '#56a0a8', haze: 0.45, boats: ['sampan', 'trawler', 'speed'], birds: 'flock', fx: 'firefly', far: ['#8ea8b4', '#a4bbc6', '#bacdd6'] },
  china: { th: 'ชายฝั่งจีนตอนใต้', water: '#6597a6', haze: 0.55, boats: ['junk', 'cargo', 'ferry'], birds: 'gull', fx: null, far: ['#a3b2bd', '#b5c3cc', '#c7d3da'] },
  taiwan: { th: 'ชายฝั่งไต้หวัน', water: '#4b9ab8', haze: 0.4, boats: ['trawler', 'ferry', 'cargo'], birds: 'gull', fx: null, far: ['#91a9bd', '#a7bccd', '#bdcfdc'] },
  ryukyu: { th: 'หมู่เกาะริวกิว', water: '#2fc6d6', haze: 0.2, boats: ['sail', 'ferry', 'trawler'], birds: 'gull', fx: null, far: ['#8cb6c6', '#a3c7d4', '#bad8e1'] },
  japan: { th: 'ชายฝั่งญี่ปุ่น', water: '#5a92b4', haze: 0.35, boats: ['trawler', 'ferry', 'sail'], birds: 'flock', fx: 'petal', far: ['#8ea4bf', '#a5b8cf', '#bccde0'] },
  japanmetro: { th: 'อ่าวเมืองหลวงญี่ปุ่น', water: '#5a8fb0', haze: 0.45, boats: ['cargo', 'ferry', 'tug'], birds: 'gull', fx: 'petal', far: ['#93a7c0', '#a9bbd0', '#bfcfe0'] },
  korea: { th: 'ชายฝั่งเกาหลีใต้', water: '#5a8eae', haze: 0.35, boats: ['trawler', 'ferry', 'cargo'], birds: 'gull', fx: null, far: ['#93a8bd', '#a9bccd', '#bfd0dd'] },
  open: { th: 'ทะเลเปิด', water: '#3e86b0', haze: 0.15, boats: ['cargo', 'sail', 'trawler'], birds: 'gull', fx: 'fish', far: null },
};
// landmark sets & layer recipes per biome
const RECIPE = {
  andaman: { far: 'karst', mid: 'karst', near: 'beach', trees: ['palm', 'palm', 'bush'], islets: true },
  gulf: { far: 'hills', mid: 'hills', near: 'beach', trees: ['palm', 'palm', 'bush'] },
  resort: { far: 'hills', mid: 'resortcity', near: 'promenade', trees: ['palm'] },
  metro: { far: 'skyfar', mid: 'metrocity', near: 'port', trees: ['bush'] },
  volcanic: { far: 'volcano', mid: 'terrace', near: 'beach', trees: ['palm', 'palm', 'bush'] },
  halong: { far: 'karst', mid: 'karst', near: 'karstshore', trees: ['bush'], islets: true },
  vietcoast: { far: 'mountain', mid: 'lowcity', near: 'beach', trees: ['palm', 'bush'] },
  philippine: { far: 'karst', mid: 'hills', near: 'beach', trees: ['palm', 'palm'], islets: true },
  borneo: { far: 'jagged', mid: 'jungle', near: 'stilt', trees: ['palm', 'bush', 'bush'] },
  china: { far: 'mountain', mid: 'metrocity', near: 'port', trees: ['pine', 'bush'] },
  taiwan: { far: 'jagged', mid: 'lowcity', near: 'port', trees: ['pine', 'palm'] },
  ryukyu: { far: 'hills', mid: 'hills', near: 'beach', trees: ['palm', 'bush'] },
  japan: { far: 'mountain', mid: 'pinehills', near: 'jtown', trees: ['pine', 'sakura', 'pine'] },
  japanmetro: { far: 'fuji', mid: 'metrocity', near: 'port', trees: ['sakura', 'pine'] },
  korea: { far: 'mountain', mid: 'apartments', near: 'port', trees: ['pine', 'bush'] },
};

/* ---------------- small drawing helpers ---------------- */
const BAY = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5].map(v => (v + 0.5) / 16);
const dith = (x, y) => BAY[(y & 3) * 4 + (x & 3)];
function R(c, x, y, w, h, col) { c.fillStyle = col; c.fillRect(Math.round(x), Math.round(y), Math.round(w), Math.round(h)); }
function pick(P, t, x, y) { t = clamp(t, 0, 0.999) * P.length; let i = Math.floor(t); if (t - i > dith(x, y) && i < P.length - 1) i++; return P[clamp(i, 0, P.length - 1)]; }
function putPx(d, W, x, y, rgb) { const o = (y * W + x) * 4; d[o] = rgb[0]; d[o + 1] = rgb[1]; d[o + 2] = rgb[2]; d[o + 3] = 255; }

// limestone karst towers: near-vertical cliffs with streaks, jungle caps, dark wave-cut notch at the base
function karst(seed, W, H, cliff, green, opts = {}) {
  const Rn = rng(seed); const [cv, c] = makeCanvas(W, H); const id = c.createImageData(W, H), d = id.data;
  const C = cliff.map(hexToRgb), G = green.map(hexToRgb);
  const n = opts.count || 7; const isl = [];
  for (let i = 0; i < n; i++) isl.push({ x: (i + 0.15 + Rn() * 0.7) * W / n, w: W * (0.03 + Rn() * 0.06), h: H * (0.3 + Rn() * 0.66), bump: Rn() * 10, lean: (Rn() - 0.5) * 0.5 });
  const top = new Float32Array(W).fill(H + 5), owner = new Int16Array(W).fill(-1);
  isl.forEach((s, k) => { for (let off of [-W, 0, W]) for (let x = Math.floor(s.x + off - s.w * 1.3); x <= s.x + off + s.w * 1.3; x++) { if (x < 0 || x >= W) continue;
    const dx = (x - s.x - off) / s.w + s.lean * 0.3; const ax = Math.abs(dx); if (ax >= 1.3) continue;
    // dome top + steep (slightly undercut) flanks + low talus skirt, with jagged jungle noise on the crown
    let prof = ax < 1 ? Math.sqrt(1 - ax * ax) : 0; prof = Math.pow(prof, 0.35);
    const skirt = ax < 1.3 ? (1.3 - ax) / 1.3 * 0.22 : 0; const hh = s.h * Math.max(prof, skirt);
    const y = H - hh + (Math.sin(x * 0.9 + s.bump) + Math.sin(x * 0.37 + s.bump * 2)) * (0.6 + prof) + (Rn() - 0.5) * 0.8;
    if (hh > 1 && y < top[x]) { top[x] = y; owner[x] = k; } } });
  for (let x = 0; x < W; x++) {
    if (owner[x] < 0) continue; const t0 = Math.max(0, Math.floor(top[x])); const s = isl[owner[x]]; const capH = 3 + (s.h * 0.18) * (0.6 + 0.4 * Math.sin(x * 0.7 + s.bump));
    for (let y = t0; y < H; y++) {
      const depth = y - t0;
      if (depth < capH) putPx(d, W, x, y, hexToRgb(pick(green, 0.85 - depth / capH * 0.6 + (Rn() - 0.5) * 0.3, x, y)));
      else { const streak = (Math.sin(x * 1.7 + s.bump * 3) + 1) * 0.15; let t = 0.65 - streak - (y / H) * 0.35 + (Rn() - 0.5) * 0.12; if (y > H - 4) t = 0.05; if (Rn() < 0.04 && depth < s.h * 0.6) { putPx(d, W, x, y, G[1]); continue; } putPx(d, W, x, y, hexToRgb(pick(cliff, t, x, y))); }
    }
  }
  c.putImageData(id, 0, 0); return cv;
}
function volcano(seed, W, H, pal, opts = {}) {
  const Rn = rng(seed); const [cv, c] = makeCanvas(W, H); const id = c.createImageData(W, H), d = id.data;
  const cones = opts.fuji ? [{ x: W * (0.15 + Rn() * 0.1), r: W * 0.16, h: H * 0.92 }, { x: W * (0.65 + Rn() * 0.1), r: W * 0.16, h: H * 0.86 }] : [{ x: W * (0.1 + Rn() * 0.1), r: W * 0.14, h: H * 0.9 }, { x: W * (0.38 + Rn() * 0.1), r: W * 0.1, h: H * 0.55 }, { x: W * (0.62 + Rn() * 0.1), r: W * 0.15, h: H * 0.8 }, { x: W * (0.88 + Rn() * 0.06), r: W * 0.09, h: H * 0.5 }];
  for (let x = 0; x < W; x++) {
    let top = H; let cone = null;
    for (const k of cones) for (const off of [-W, 0, W]) { const dx = Math.abs(x - k.x - off) / k.r; if (dx >= 1) continue; let y = H - k.h * Math.pow(1 - dx, 1.35); if (dx < 0.06) y += k.h * 0.05; if (y < top) { top = y; cone = k; } }
    const base = H - 6 - Math.sin(x * 0.05 + seed) * 3; top = Math.min(top, base);
    for (let y = Math.max(0, top | 0); y < H; y++) {
      const rel = cone ? (y - top) / Math.max(1, H - top) : 0.6;
      let col = pick(pal, 0.8 - rel * 0.6 + (Math.sin(x * 0.9) * 0.05), x, y);
      if (opts.fuji && cone && y - top < cone.h * 0.22 * (1 - Math.abs(Math.sin(x * 0.6)) * 0.3)) col = (y + x) % 3 ? '#f4f7fb' : '#dfe8f1';
      if (!opts.fuji && cone && (x * 7 + y * 3) % 11 === 0 && rel > 0.2) col = shade(col, -0.08);
      putPx(d, W, x, y, hexToRgb(col));
    }
  }
  c.putImageData(id, 0, 0); return cv;
}
function terraces(seed, W, H, pal) {
  const cv = PX.ridge(seed, W, H, pal, { peaks: 5, base: 0.95 }); const c = cv.getContext('2d');
  const id = c.getImageData(0, 0, W, H), d = id.data;
  for (let x = 0; x < W; x++) { let t0 = -1; for (let y = 0; y < H; y++) { const o = (y * W + x) * 4; if (!d[o + 3]) continue; if (t0 < 0) t0 = y; const k = (y - t0 + Math.round(Math.sin(x * 0.06) * 2)) % 4; if (k === 0) { d[o] = Math.min(255, d[o] + 30); d[o + 1] = Math.min(255, d[o + 1] + 34); d[o + 2] = Math.min(255, d[o + 2] + 10); } else if (k === 3) { d[o] = d[o] * 0.86; d[o + 1] = d[o + 1] * 0.88; d[o + 2] = d[o + 2] * 0.86; } } }
  c.putImageData(id, 0, 0); return cv;
}
// buildings → returns { cv, lit } (lit = canvas of window lights used at night)
function city(seed, W, H, style) {
  const Rn = rng(seed); const [cv, c] = makeCanvas(W, H); const [lit, lc] = makeCanvas(W, H);
  const pal = {
    resort: ['#f2ede4', '#f4d7c5', '#dfe8ee', '#e9e1cf', '#cfe3ea'], metro: ['#9fb6c6', '#b4c7d4', '#c8d8e2', '#8ea7b9', '#d7e2ea'],
    low: ['#e8e1d2', '#d9d2c4', '#eae4d8', '#cfc8b8'], apt: ['#e6e4de', '#d8d6cf', '#eceae4'],
  }[style] || ['#cfd8e0'];
  let x = Math.round(Rn() * 6);
  const warm = ['#ffd98a', '#ffe7b0', '#fff2c8', '#bfe3ff'];
  while (x < W) {
    let bw, bh;
    if (style === 'metro') { bw = 8 + (Rn() * 16) | 0; bh = (H * (0.3 + Rn() * 0.7)) | 0; }
    else if (style === 'resort') { bw = 12 + (Rn() * 14) | 0; bh = (H * (0.2 + Rn() * 0.55)) | 0; }
    else if (style === 'apt') { bw = 14 + (Rn() * 10) | 0; bh = (H * (0.35 + Rn() * 0.35)) | 0; }
    else { bw = 8 + (Rn() * 10) | 0; bh = (H * (0.12 + Rn() * 0.22)) | 0; }
    const col = pal[(Rn() * pal.length) | 0]; const y0 = H - bh;
    R(c, x, y0, bw, bh, col); R(c, x, y0, 1, bh, shade(col, 0.12)); R(c, x + bw - 1, y0, 1, bh, shade(col, -0.12));
    if (style === 'low') { R(c, x - 1, y0 - 2, bw + 2, 2, Rn() < 0.5 ? '#b85a48' : '#6a7a8a'); }
    if (style === 'metro' && Rn() < 0.25) { R(c, x + (bw >> 1), y0 - 6 - ((Rn() * 6) | 0), 1, 8, shade(col, -0.2)); }
    if (style === 'metro' && Rn() < 0.15) { R(c, x, y0, bw, 2, shade(col, -0.2)); }
    const gx = style === 'metro' ? 2 : 3, gy = style === 'apt' ? 3 : 3;
    for (let yy = y0 + 2; yy < H - 2; yy += gy) for (let xx = x + 2; xx < x + bw - 1; xx += gx) {
      const winCol = style === 'metro' ? shade(col, -0.18) : shade(col, -0.25); if (Rn() < (style === 'metro' ? 0.8 : 0.6)) R(c, xx, yy, 1, 1, winCol);
      if (Rn() < 0.32) { lc.fillStyle = warm[(Rn() * warm.length) | 0]; lc.fillRect(xx, yy, 1, 1); }
    }
    if (style === 'resort' && Rn() < 0.6) for (let yy = y0 + 3; yy < H - 2; yy += 4) R(c, x + 1, yy, bw - 2, 1, '#ffffff'); // balconies
    x += bw + ((Rn() * (style === 'metro' ? 2 : 4)) | 0);
  }
  return { cv, lit };
}
/* ---------------- landmarks (code-drawn, generic shapes) ---------------- */
function lm(type, scale = 1) {
  const s = scale; let cv, c;
  const mk = (w, h) => { [cv, c] = makeCanvas(Math.round(w * s), Math.round(h * s)); c.scale(s, s); };
  switch (type) {
    case 'chedi': mk(18, 30); R(c, 3, 24, 12, 6, '#e8d9b0'); for (let i = 0; i < 6; i++) R(c, 5 + i * 0.6, 12 + i * 2, 8 - i * 1.2, 2, '#e8b84a'); R(c, 8, 2, 2, 10, '#f2c94c'); R(c, 6, 18, 6, 6, '#f2c94c'); R(c, 7, 19, 1, 4, '#fff2b0'); break;
    case 'buddha': mk(26, 30); R(c, 4, 26, 18, 4, '#d8d2c4'); R(c, 5, 16, 16, 10, '#f3f1ec'); R(c, 8, 9, 10, 8, '#f3f1ec'); R(c, 10, 4, 6, 6, '#f3f1ec'); R(c, 12, 2, 2, 2, '#f3f1ec'); R(c, 6, 22, 14, 2, '#dcd8d0'); R(c, 15, 16, 1, 8, '#d8d4cc'); break;
    case 'torii': mk(26, 22); R(c, 1, 2, 24, 3, '#c83a2e'); R(c, 0, 1, 26, 1, '#2c2a33'); R(c, 3, 7, 20, 2, '#c83a2e'); R(c, 5, 5, 3, 17, '#c83a2e'); R(c, 18, 5, 3, 17, '#c83a2e'); R(c, 12, 5, 2, 2, '#c83a2e'); break;
    case 'candi': mk(24, 26); for (const x0 of [1, 14]) { for (let i = 0; i < 5; i++) R(c, x0 + i * 0.6, 4 + i * 4, 9 - i * 1.2, 4, i % 2 ? '#8a6e5a' : '#9e8068'); R(c, x0, 22, 9, 4, '#7a604e'); } break;
    case 'mosque': mk(34, 30); R(c, 6, 14, 22, 16, '#f2ede4'); c.fillStyle = '#e3b23c'; c.beginPath(); c.arc(17, 14, 8, Math.PI, 0); c.fill(); R(c, 16, 3, 2, 4, '#e3b23c'); R(c, 1, 6, 3, 24, '#f2ede4'); R(c, 0, 4, 5, 3, '#e3b23c'); for (let x = 9; x < 26; x += 4) R(c, x, 20, 2, 5, '#5a8aa8'); break;
    case 'ferris': mk(30, 32); c.strokeStyle = '#e8ecef'; c.lineWidth = 1; c.beginPath(); c.arc(15, 14, 12, 0, Math.PI * 2); c.stroke(); for (let i = 0; i < 8; i++) { const a = i * Math.PI / 4; c.beginPath(); c.moveTo(15, 14); c.lineTo(15 + Math.cos(a) * 12, 14 + Math.sin(a) * 12); c.stroke(); R(c, 14 + Math.cos(a) * 12, 13 + Math.sin(a) * 12, 2, 2, ['#e46b4a', '#5fb3df', '#f2c94c', '#a8cc6e'][i % 4]); } R(c, 9, 14, 1, 18, '#c0c6cc'); R(c, 21, 14, 1, 18, '#c0c6cc'); break;
    case 'tower': mk(14, 56); R(c, 6, 4, 2, 52, '#c8cfd6'); R(c, 4, 22, 6, 4, '#e8ecef'); R(c, 3, 26, 8, 2, '#c8cfd6'); R(c, 5, 10, 4, 3, '#e8ecef'); R(c, 6.5, 0, 1, 4, '#e46b4a'); R(c, 4, 44, 6, 12, '#b5bcc2'); break;
    case 'bridge': mk(120, 34); R(c, 0, 26, 120, 2, '#c8cfd6'); for (const px of [30, 90]) { R(c, px - 1, 2, 3, 30, '#e8ecef'); c.strokeStyle = 'rgba(220,226,232,0.9)'; for (let k = 1; k <= 6; k++) { c.beginPath(); c.moveTo(px, 4 + k); c.lineTo(px - k * 4.5, 26); c.moveTo(px, 4 + k); c.lineTo(px + k * 4.5, 26); c.stroke(); } } break;
    case 'cranes': mk(60, 36); for (const x0 of [4, 32]) { R(c, x0, 12, 2, 24, '#e46b4a'); R(c, x0 + 14, 12, 2, 24, '#e46b4a'); R(c, x0 - 4, 10, 26, 3, '#e46b4a'); R(c, x0 + 2, 6, 10, 2, '#c84a3a'); R(c, x0 + 8, 13, 1, 10, '#59646e'); } R(c, 0, 30, 60, 6, '#8a96a0'); for (let x = 2; x < 58; x += 7) R(c, x, 26, 6, 4, ['#d8463c', '#5a8aa8', '#e9c46a', '#5aa66e'][(x / 7 | 0) % 4]); break;
    /* ---- Thailand ---- */
    case 'sanctuary': mk(40, 40); { const wd = '#9a6a3e', dk = '#6e4a2a'; R(c, 2, 30, 36, 10, wd); for (let i = 0; i < 3; i++) R(c, 4 + i * 2, 24 - i * 3, 32 - i * 4, 3, i % 2 ? dk : wd); R(c, 17, 4, 6, 14, wd); for (let i = 0; i < 5; i++) R(c, 18 + (i % 2), 0 + i * 3, 4 - (i % 2) * 2, 2, dk); for (const x of [6, 30]) { R(c, x, 12, 4, 12, wd); R(c, x + 1, 8, 2, 4, dk); } for (let x = 5; x < 36; x += 4) R(c, x, 32, 2, 6, dk); } break;
    case 'pattayasign': mk(60, 14); R(c, 0, 12, 60, 2, '#5f8a62'); c.fillStyle = '#ffffff'; c.font = 'bold 9px monospace'; c.textBaseline = 'top'; c.fillText('PATTAYA CITY', 1, 2); break;
    case 'royalstation': mk(30, 22); R(c, 4, 12, 22, 10, '#f3efe6'); for (let x = 6; x < 25; x += 4) R(c, x, 14, 2, 8, '#c83a2e'); c.fillStyle = '#c83a2e'; c.beginPath(); c.moveTo(2, 12); c.lineTo(15, 2); c.lineTo(28, 12); c.fill(); R(c, 14, 0, 2, 3, '#e9c46a'); R(c, 4, 11, 22, 1, '#e9c46a'); break;
    case 'mermaid': mk(18, 22); c.fillStyle = '#8a8478'; c.beginPath(); c.ellipse(9, 19, 9, 4, 0, 0, Math.PI * 2); c.fill(); R(c, 6, 6, 6, 10, '#e0b340'); R(c, 7, 2, 4, 4, '#e0b340'); R(c, 5, 15, 9, 3, '#e0b340'); R(c, 6, 3, 1, 6, '#3a2a1a'); break;
    case 'carrier': mk(90, 22); { const H = (pts, col) => { c.beginPath(); pts.forEach(([x, y], i) => i ? c.lineTo(x, y) : c.moveTo(x, y)); c.closePath(); c.fillStyle = col; c.fill(); }; H([[2, 12], [84, 12], [90, 6], [86, 20], [8, 20]], '#7f8a92'); R(c, 0, 10, 82, 3, '#9aa4ac'); H([[74, 10], [88, 4], [90, 6], [80, 10]], '#9aa4ac'); R(c, 50, 2, 8, 8, '#8a959d'); R(c, 53, 0, 2, 3, '#59646e'); R(c, 10, 11, 60, 1, '#f4f4f2'); } break;
    case 'shophouse': mk(70, 22); for (let i = 0; i < 7; i++) { const x = i * 10, col = ['#f2c94c', '#7fc8b8', '#f4a6a0', '#a8d0e6', '#f3efe6', '#c8e0a0', '#f0b890'][i]; R(c, x, 6, 10, 16, col); R(c, x, 4, 10, 2, '#b85a48'); R(c, x + 2, 8, 2, 3, '#4a5a6a'); R(c, x + 6, 8, 2, 3, '#4a5a6a'); R(c, x + 2, 15, 6, 7, shade(col, -0.25)); R(c, x + 3, 14, 4, 1, '#ffffff'); } break;
    /* ---- Malaysia / Singapore / Brunei ---- */
    case 'petronas': mk(30, 64); for (const x0 of [3, 17]) { for (let i = 0; i < 6; i++) R(c, x0 + i * 0.4, 14 + i * 8, 10 - i * 0.8, 8, i % 2 ? '#b9c3cc' : '#d6dde3'); R(c, x0 + 2, 6, 6, 8, '#c8d0d8'); R(c, x0 + 4, 0, 2, 7, '#e8ecef'); } R(c, 13, 30, 4, 2, '#8a959d'); break;
    case 'kekloksi': mk(22, 40); for (let i = 0; i < 7; i++) { R(c, 3 + i, 34 - i * 5, 16 - i * 2, 4, ['#f3efe6', '#f2c94c'][i % 2]); R(c, 2 + i, 33 - i * 5, 18 - i * 2, 1, '#c83a2e'); } R(c, 10, 0, 2, 4, '#e0b340'); break;
    case 'eagle': mk(34, 30); R(c, 13, 22, 8, 8, '#8a7a6a'); c.fillStyle = '#8a4a2a'; c.beginPath(); c.moveTo(17, 8); c.lineTo(0, 2); c.lineTo(8, 12); c.lineTo(17, 18); c.lineTo(26, 12); c.lineTo(34, 2); c.closePath(); c.fill(); R(c, 14, 8, 6, 14, '#8a4a2a'); R(c, 15, 4, 4, 5, '#f3efe6'); R(c, 18, 6, 2, 1, '#e0b340'); break;
    case 'skybridge': mk(60, 36); c.fillStyle = '#5f8a62'; c.beginPath(); c.moveTo(0, 36); c.lineTo(10, 14); c.lineTo(22, 6); c.lineTo(34, 10); c.lineTo(50, 20); c.lineTo(60, 36); c.fill(); c.strokeStyle = '#d8dde1'; c.beginPath(); c.moveTo(14, 12); c.quadraticCurveTo(28, 20, 44, 14); c.stroke(); R(c, 28, 2, 1, 16, '#c0c6cc'); c.beginPath(); c.moveTo(28.5, 2); c.lineTo(16, 13); c.moveTo(28.5, 2); c.lineTo(42, 15); c.stroke(); break;
    case 'mbs': mk(64, 50); for (const x0 of [6, 26, 46]) { R(c, x0, 12, 10, 38, '#d6dde3'); R(c, x0 + 1, 12, 3, 38, '#eef2f4'); for (let y = 14; y < 48; y += 3) R(c, x0 + 1, y, 8, 1, '#a9b6c0'); } c.fillStyle = '#c8d0d8'; c.beginPath(); c.moveTo(0, 12); c.lineTo(64, 8); c.lineTo(64, 11); c.lineTo(0, 14); c.fill(); R(c, 0, 10, 4, 2, '#5f8a62'); break;
    case 'supertree': mk(46, 40); for (const [x, h] of [[6, 30], [18, 40], [32, 34], [42, 24]]) { R(c, x - 1, 40 - h + 6, 3, h - 6, '#7a6a8a'); c.fillStyle = '#5f6a8a'; c.beginPath(); c.moveTo(x - 7, 40 - h + 6); c.lineTo(x + 8, 40 - h + 6); c.lineTo(x + 2, 40 - h + 10); c.lineTo(x - 1, 40 - h + 10); c.fill(); R(c, x - 6, 40 - h + 5, 14, 1, '#8ab86a'); } break;
    case 'merlion': mk(22, 26); R(c, 3, 22, 16, 4, '#9aa4ac'); R(c, 7, 8, 8, 14, '#eef0ee'); R(c, 6, 3, 9, 7, '#eef0ee'); R(c, 4, 4, 3, 6, '#dfe2df'); R(c, 15, 6, 3, 2, '#bfe6f2'); R(c, 18, 7, 4, 1, '#bfe6f2'); R(c, 10, 2, 3, 2, '#dfe2df'); c.fillStyle = '#dfe2df'; c.beginPath(); c.moveTo(7, 20); c.lineTo(2, 16); c.lineTo(7, 14); c.fill(); break;
    case 'goldmosque': mk(48, 36); R(c, 4, 24, 40, 12, '#f3efe6'); c.fillStyle = '#e3b23c'; c.beginPath(); c.arc(24, 22, 10, Math.PI, 0); c.fill(); R(c, 23, 8, 2, 5, '#e3b23c'); R(c, 40, 4, 3, 30, '#f3efe6'); R(c, 39, 2, 5, 3, '#e3b23c'); R(c, 4, 33, 40, 3, '#5aa0c0'); for (let x = 8; x < 40; x += 5) R(c, x, 26, 2, 5, '#5a8aa8'); break;
    /* ---- Indonesia ---- */
    case 'monas': mk(16, 56); R(c, 1, 46, 14, 10, '#f3efe6'); R(c, 4, 42, 8, 4, '#e8e4da'); R(c, 6, 10, 4, 32, '#f3efe6'); R(c, 7, 10, 1, 32, '#ffffff'); R(c, 5, 8, 6, 3, '#e8e4da'); c.fillStyle = '#e3b23c'; c.beginPath(); c.moveTo(8, 0); c.lineTo(11, 8); c.lineTo(5, 8); c.fill(); break;
    case 'tanahlot': mk(40, 34); c.fillStyle = '#6a5a4a'; c.beginPath(); c.moveTo(2, 34); c.lineTo(6, 16); c.lineTo(16, 10); c.lineTo(28, 12); c.lineTo(36, 20); c.lineTo(38, 34); c.fill(); R(c, 8, 14, 24, 3, '#4f7a4a'); for (const [x, n] of [[14, 4], [24, 5]]) { for (let i = 0; i < n; i++) R(c, x - 4 + i, 12 - i * 2.5, 9 - i * 2, 2, '#3a2a22'); R(c, x, 12 - n * 2.5 - 2, 1, 3, '#3a2a22'); } break;
    case 'meru': mk(18, 30); R(c, 6, 24, 6, 6, '#8a6e5a'); for (let i = 0; i < 7; i++) R(c, 1 + i, 22 - i * 3, 16 - i * 2, 2, '#3a2a22'); R(c, 8, 0, 2, 3, '#3a2a22'); break;
    case 'granite': mk(50, 18); for (const [x, y, rx, ry, col] of [[10, 12, 10, 7, '#b8b0a4'], [26, 10, 12, 9, '#c8c0b4'], [40, 13, 9, 6, '#a8a094'], [18, 15, 6, 4, '#d0c8bc']]) { c.fillStyle = col; c.beginPath(); c.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2); c.fill(); } break;
    /* ---- Vietnam / Cambodia ---- */
    case 'dragonbridge': mk(120, 30); R(c, 0, 24, 120, 2, '#9aa4ac'); c.strokeStyle = '#e3b23c'; c.lineWidth = 2; c.beginPath(); for (let x = 4; x <= 116; x++) { const y = 18 - Math.abs(Math.sin((x - 4) / 112 * Math.PI * 3)) * 12; x === 4 ? c.moveTo(x, y) : c.lineTo(x, y); } c.stroke(); R(c, 112, 4, 8, 6, '#e3b23c'); R(c, 118, 6, 2, 2, '#c83a2e'); for (const x of [22, 60, 98]) R(c, x, 18, 2, 7, '#9aa4ac'); break;
    case 'goldenhands': mk(60, 36); c.fillStyle = '#4f7a4a'; c.beginPath(); c.moveTo(0, 36); c.lineTo(8, 18); c.lineTo(30, 12); c.lineTo(52, 18); c.lineTo(60, 36); c.fill(); c.strokeStyle = '#e3b23c'; c.lineWidth = 2; c.beginPath(); c.moveTo(6, 16); c.quadraticCurveTo(30, 4, 54, 14); c.stroke(); for (const x of [20, 34]) { R(c, x, 12, 6, 10, '#8a8a80'); R(c, x - 1, 10, 8, 3, '#9a9a90'); } break;
    case 'cham': mk(34, 30); for (const [x, h] of [[2, 22], [13, 30], [25, 20]]) { for (let i = 0; i < 4; i++) R(c, x + i, 30 - h + i * (h / 4), 9 - i * 2 < 3 ? 3 : 9 - i * 2, h / 4, i % 2 ? '#a4583a' : '#b8684a'); R(c, x + 3, 30 - h - 2, 3, 3, '#8a4a30'); } break;
    case 'christ': mk(22, 40); c.fillStyle = '#4f7a4a'; c.beginPath(); c.moveTo(0, 40); c.lineTo(11, 26); c.lineTo(22, 40); c.fill(); R(c, 9, 8, 4, 18, '#eef0ee'); R(c, 2, 10, 18, 2, '#eef0ee'); R(c, 9, 4, 4, 4, '#eef0ee'); break;
    case 'tubehouses': mk(60, 30); for (let i = 0; i < 10; i++) { const x = i * 6, h = 16 + ((i * 7) % 12), col = ['#f2c94c', '#f4a6a0', '#a8d0e6', '#f3efe6', '#c8e0a0', '#e8b8d8'][i % 6]; R(c, x, 30 - h, 6, h, col); R(c, x + 1, 30 - h + 2, 4, 2, '#4a5a6a'); R(c, x, 30 - h - 1, 6, 1, '#b85a48'); } break;
    case 'cablecar': mk(90, 40); c.strokeStyle = '#59646e'; c.beginPath(); c.moveTo(0, 30); c.lineTo(90, 6); c.stroke(); for (const x of [10, 80]) R(c, x, 40 - (x === 10 ? 10 : 34), 2, x === 10 ? 10 : 34, '#9aa4ac'); for (const t of [0.3, 0.65]) { const x = 90 * t, y = 30 - 24 * t; R(c, x, y, 1, 3, '#59646e'); R(c, x - 3, y + 3, 7, 5, '#e46b4a'); R(c, x - 2, y + 4, 5, 2, '#bfe6f2'); } break;
    case 'khmer': mk(30, 26); R(c, 2, 18, 26, 8, '#c8a878'); for (const [x, h] of [[4, 10], [12, 16], [20, 10]]) { for (let i = 0; i < 4; i++) R(c, x + i * 0.5, 18 - h + i * (h / 4), 6 - i, h / 4, '#b8946a'); } break;
    /* ---- Philippines / Borneo ---- */
    case 'nipa': mk(60, 20); for (let i = 0; i < 4; i++) { const x = 2 + i * 15; R(c, x, 12, 1, 8, '#6a5440'); R(c, x + 10, 12, 1, 8, '#6a5440'); R(c, x, 8, 11, 5, '#c8a870'); c.fillStyle = '#9a8048'; c.beginPath(); c.moveTo(x - 2, 9); c.lineTo(x + 5.5, 2); c.lineTo(x + 13, 9); c.fill(); R(c, x + 4, 9, 3, 3, '#4a3a2a'); } break;
    case 'cloud9': mk(70, 30); R(c, 0, 18, 56, 2, '#8a6e50'); for (let x = 2; x < 56; x += 6) R(c, x, 18, 1, 12, '#6a5440'); R(c, 54, 6, 14, 2, '#8a6e50'); R(c, 54, 8, 1, 22, '#6a5440'); R(c, 67, 8, 1, 22, '#6a5440'); c.fillStyle = '#9a8048'; c.beginPath(); c.moveTo(52, 6); c.lineTo(61, 0); c.lineTo(70, 6); c.fill(); break;
    case 'kinabalu': return null;
    /* ---- China / Hong Kong / Taiwan ---- */
    case 'pearl': mk(20, 60); R(c, 9, 0, 2, 12, '#c0c6cc'); c.fillStyle = '#d0507a'; c.beginPath(); c.arc(10, 14, 4, 0, Math.PI * 2); c.fill(); c.beginPath(); c.arc(10, 36, 7, 0, Math.PI * 2); c.fill(); R(c, 9, 18, 2, 12, '#c0c6cc'); R(c, 4, 42, 2, 18, '#c0c6cc'); R(c, 14, 42, 2, 18, '#c0c6cc'); R(c, 9, 42, 2, 18, '#c0c6cc'); c.fillStyle = '#d0507a'; c.beginPath(); c.arc(10, 54, 3, 0, Math.PI * 2); c.fill(); break;
    case 'shtower': mk(16, 70); c.fillStyle = '#9fb4c4'; c.beginPath(); c.moveTo(2, 70); c.lineTo(5, 10); c.lineTo(9, 2); c.lineTo(12, 8); c.lineTo(14, 70); c.fill(); c.strokeStyle = '#c8d8e4'; c.beginPath(); c.moveTo(5, 66); c.quadraticCurveTo(12, 40, 9, 6); c.stroke(); break;
    case 'ifc': mk(14, 68); R(c, 2, 12, 10, 56, '#b0c0cc'); R(c, 3, 6, 8, 6, '#c0ccd6'); R(c, 4, 2, 6, 4, '#c8d4dc'); for (let y = 14; y < 66; y += 4) R(c, 3, y, 8, 1, '#90a2b0'); break;
    case 'guanyin': mk(26, 44); c.fillStyle = '#8a8478'; c.beginPath(); c.ellipse(13, 40, 13, 4, 0, 0, Math.PI * 2); c.fill(); R(c, 9, 14, 8, 24, '#f3f1ec'); R(c, 10, 8, 6, 6, '#f3f1ec'); R(c, 8, 4, 10, 5, '#ece8e0'); R(c, 7, 20, 12, 3, '#ece8e0'); break;
    case 'gulangyu': mk(70, 30); c.fillStyle = '#5f8a62'; c.beginPath(); c.moveTo(0, 30); c.lineTo(20, 10); c.lineTo(44, 6); c.lineTo(70, 30); c.fill(); for (const [x, y] of [[12, 20], [24, 14], [38, 12], [50, 18], [30, 22]]) { R(c, x, y, 9, 7, '#f3efe6'); R(c, x - 1, y - 2, 11, 2, '#b85a48'); R(c, x + 2, y + 2, 2, 2, '#4a5a6a'); } break;
    case 'zhanqiao': mk(80, 22); R(c, 0, 16, 64, 2, '#c8c0b4'); for (let x = 2; x < 64; x += 6) R(c, x, 16, 1, 6, '#9a9286'); R(c, 62, 8, 14, 8, '#e8e0d0'); c.fillStyle = '#c86a3c'; c.beginPath(); c.moveTo(60, 8); c.lineTo(69, 0); c.lineTo(78, 8); c.fill(); break;
    case 'redroofs': mk(60, 24); for (let i = 0; i < 6; i++) { const x = i * 10; R(c, x + 1, 12, 8, 12, '#f0e8d8'); c.fillStyle = '#c8503c'; c.beginPath(); c.moveTo(x, 12); c.lineTo(x + 5, 5); c.lineTo(x + 10, 12); c.fill(); R(c, x + 3, 15, 2, 3, '#4a5a6a'); } break;
    case 'sky85': mk(24, 64); R(c, 2, 20, 8, 44, '#3a4a5e'); R(c, 14, 20, 8, 44, '#3a4a5e'); R(c, 6, 8, 12, 14, '#4a5a6e'); R(c, 10, 0, 4, 8, '#5a6a7e'); for (let y = 22; y < 62; y += 4) { R(c, 3, y, 6, 1, '#7a8aa0'); R(c, 15, y, 6, 1, '#7a8aa0'); } break;
    case 'dragontiger': mk(40, 30); for (const x of [6, 26]) { for (let i = 0; i < 7; i++) R(c, x + i * 0.5, 26 - i * 3.5, 8 - i, 3, i % 2 ? '#e3b23c' : '#c83a2e'); } R(c, 0, 26, 40, 4, '#5aa66e'); R(c, 4, 22, 6, 4, '#5aa66e'); R(c, 30, 22, 6, 4, '#e9a13c'); break;
    case 'basalt': mk(50, 22); for (let x = 0; x < 50; x += 3) { const h = 12 + ((x * 7) % 8); R(c, x, 22 - h, 3, h, x % 2 ? '#4a4a52' : '#5a5a62'); R(c, x, 22 - h, 3, 1, '#7a7a82'); } R(c, 0, 4, 50, 3, '#5f8a62'); break;
    /* ---- Japan / Okinawa ---- */
    case 'shuri': mk(44, 28); R(c, 4, 16, 36, 12, '#c83a2e'); for (let x = 6; x < 38; x += 4) R(c, x, 19, 2, 9, '#e3b23c'); c.fillStyle = '#b8503c'; c.beginPath(); c.moveTo(0, 16); c.lineTo(10, 6); c.lineTo(34, 6); c.lineTo(44, 16); c.fill(); c.beginPath(); c.moveTo(14, 6); c.lineTo(22, 0); c.lineTo(30, 6); c.fill(); R(c, 0, 26, 44, 2, '#e8e0d0'); break;
    case 'osakacastle': mk(34, 40); R(c, 2, 30, 30, 10, '#8a8478'); for (let i = 0; i < 4; i++) { R(c, 5 + i * 2, 24 - i * 6, 24 - i * 4, 6, '#f3f1ec'); R(c, 3 + i * 2, 23 - i * 6, 28 - i * 4, 2, '#4f8a72'); } R(c, 13, 2, 8, 3, '#e3b23c'); break;
    case 'fukuokatower': mk(14, 64); c.fillStyle = '#9fb8cc'; c.beginPath(); c.moveTo(2, 64); c.lineTo(7, 4); c.lineTo(12, 64); c.fill(); R(c, 6.5, 0, 1, 6, '#c0c6cc'); for (let y = 10; y < 60; y += 6) R(c, 5, y, 4, 1, '#d8e4ee'); break;
    case 'porttower': mk(16, 48); c.strokeStyle = '#c83a2e'; for (let k = 0; k < 9; k++) { c.beginPath(); c.moveTo(2 + k * 1.5, 48); c.quadraticCurveTo(8, 24, 2 + k * 1.5, 4); c.stroke(); } R(c, 3, 2, 10, 4, '#c83a2e'); R(c, 7, 0, 2, 3, '#e8ecef'); break;
    case 'landmark': mk(18, 66); R(c, 3, 8, 12, 58, '#c8d0d8'); R(c, 4, 4, 10, 6, '#d6dde3'); R(c, 6, 0, 6, 5, '#e0e6ea'); for (let y = 10; y < 64; y += 3) R(c, 4, y, 10, 1, '#a9b6c0'); break;
    case 'megane': mk(50, 16); R(c, 0, 4, 50, 4, '#9a9286'); c.fillStyle = '#2f6f84'; for (const x of [14, 36]) { c.beginPath(); c.arc(x, 8, 7, Math.PI, 0); c.lineTo(x + 7, 16); c.lineTo(x - 7, 16); c.fill(); } break;
    /* ---- Korea ---- */
    case 'seongsan': mk(60, 30); c.fillStyle = '#6a8a5a'; c.beginPath(); c.moveTo(0, 30); c.lineTo(8, 8); c.lineTo(52, 8); c.lineTo(60, 30); c.fill(); R(c, 12, 8, 36, 3, '#8aaa6a'); for (let x = 10; x < 50; x += 5) R(c, x, 12, 2, 14, '#7a6a5a'); break;
    case 'haeundae': mk(60, 60); for (const [x, h] of [[4, 56], [16, 60], [30, 50], [44, 58]]) { R(c, x, 60 - h, 10, h, '#9fb0c0'); R(c, x + 1, 60 - h, 3, h, '#c0ccd8'); for (let y = 62 - h; y < 58; y += 3) R(c, x + 1, y, 8, 1, '#7f90a0'); } break;
    case 'pagoda': return PX.pagoda(s);
    case 'temple': return PX.thaiTemple(s);
    case 'lighthouse': return PX.lighthouse();
    case 'stilt': mk(90, 26); R(c, 0, 18, 90, 2, '#8a6e50'); for (let x = 2; x < 90; x += 6) R(c, x, 18, 1, 8, '#6a5440'); for (let i = 0; i < 6; i++) { const hx = 2 + i * 15; R(c, hx, 10, 12, 8, ['#d9c9a8', '#c9d8c0', '#e0c8b8'][i % 3]); R(c, hx - 1, 7, 14, 3, ['#b85a48', '#5a7a8a', '#8a6a4a'][i % 3]); R(c, hx + 4, 13, 2, 3, '#4a3a2a'); } break;
    default: mk(4, 4);
  }
  return cv;
}
/* ---------------- boats & sea props ---------------- */
function boat(type, k = 1) {
  let cv, c; const mk = (w, h) => { [cv, c] = makeCanvas(w * k, h * k); c.scale(k, k); };
  const hull = (pts, col) => { c.beginPath(); pts.forEach(([x, y], i) => i ? c.lineTo(x, y) : c.moveTo(x, y)); c.closePath(); c.fillStyle = col; c.fill(); };
  switch (type) {
    case 'longtail': mk(34, 14); hull([[1, 8], [30, 8], [34, 4], [31, 12], [6, 12]], '#8a5a3c'); R(c, 2, 8, 28, 1, '#b07a50'); R(c, 31, 2, 1, 4, '#e46b4a'); R(c, 32, 2, 2, 1, '#5aa66e'); R(c, 32, 3, 2, 1, '#f2c94c'); R(c, 10, 4, 14, 1, '#4a8aa8'); R(c, 11, 5, 1, 3, '#7a5a40'); R(c, 22, 5, 1, 3, '#7a5a40'); R(c, 0, 9, 4, 1, '#59646e'); R(c, 0, 10, 1, 3, '#59646e'); break;
    case 'speed': mk(22, 10); hull([[1, 5], [18, 5], [22, 3], [19, 9], [3, 9]], '#f4f4f2'); R(c, 3, 6, 15, 1, '#3e86a8'); R(c, 9, 2, 6, 3, '#2e3a44'); break;
    case 'sail': mk(20, 26); hull([[1, 20], [18, 20], [15, 25], [4, 25]], '#f4f4f2'); R(c, 9, 2, 1, 18, '#7a848c'); hull([[10, 3], [10, 19], [18, 19]], '#ffffff'); hull([[9, 6], [9, 19], [3, 19]], '#eef2f4'); break;
    case 'junk': mk(30, 28); hull([[1, 20], [26, 20], [30, 16], [27, 26], [4, 26]], '#6a4630'); for (const [x, h] of [[9, 16], [17, 18], [24, 11]]) { R(c, x, 20 - h - 1, 1, h + 1, '#4a3424'); c.fillStyle = '#b8503c'; c.beginPath(); c.moveTo(x, 20 - h); c.lineTo(x + 7, 20 - h + 2); c.lineTo(x + 6, 19); c.lineTo(x, 19); c.closePath(); c.fill(); for (let y = 20 - h + 3; y < 19; y += 3) R(c, x, y, 6, 1, '#8a3a2c'); } break;
    case 'bangka': mk(34, 14); hull([[4, 8], [28, 8], [32, 5], [29, 12], [7, 12]], '#f4f4f2'); R(c, 5, 8, 24, 1, '#3e86a8'); R(c, 0, 11, 34, 1, '#8a6e50'); R(c, 4, 8, 1, 4, '#8a6e50'); R(c, 28, 8, 1, 4, '#8a6e50'); R(c, 13, 4, 8, 4, '#e46b4a'); break;
    case 'sampan': mk(22, 10); hull([[1, 5], [21, 5], [18, 9], [4, 9]], '#5a4a3a'); c.fillStyle = '#c9b48a'; c.beginPath(); c.arc(11, 5, 4, Math.PI, 0); c.fill(); break;
    case 'basket': mk(10, 7); c.fillStyle = '#8a6e50'; c.beginPath(); c.ellipse(5, 4, 5, 3, 0, 0, Math.PI * 2); c.fill(); R(c, 1, 3, 8, 1, '#b8956a'); break;
    case 'trawler': mk(32, 20); hull([[1, 13], [28, 13], [32, 9], [29, 18], [5, 18]], '#3e6e8a'); R(c, 2, 13, 26, 1, '#f4f4f2'); R(c, 16, 6, 9, 7, '#f4f4f2'); R(c, 18, 8, 2, 2, '#2e3a44'); R(c, 21, 8, 2, 2, '#2e3a44'); R(c, 8, 1, 1, 12, '#59646e'); R(c, 3, 5, 12, 1, '#59646e'); break;
    case 'squid': mk(32, 20); hull([[1, 13], [28, 13], [32, 9], [29, 18], [5, 18]], '#5a6a7a'); R(c, 18, 7, 8, 6, '#e8ecef'); R(c, 2, 4, 26, 1, '#59646e'); for (let x = 3; x < 28; x += 4) R(c, x, 5, 2, 2, '#c8f5c0'); break;
    case 'ferry': mk(50, 18); hull([[1, 11], [46, 11], [50, 7], [47, 16], [4, 16]], '#f4f4f2'); R(c, 3, 13, 42, 1, '#3e86a8'); R(c, 8, 5, 34, 6, '#f4f4f2'); R(c, 8, 7, 34, 2, '#2e3a44'); R(c, 16, 2, 16, 3, '#f4f4f2'); R(c, 30, 0, 3, 3, '#e46b4a'); break;
    case 'tug': mk(26, 16); hull([[1, 10], [22, 10], [26, 7], [23, 15], [4, 15]], '#d8463c'); R(c, 2, 10, 20, 1, '#2e3a44'); R(c, 9, 4, 8, 6, '#f4f4f2'); R(c, 12, 1, 3, 3, '#2e3a44'); break;
    case 'cargo': mk(96, 22); hull([[1, 14], [88, 14], [96, 8], [92, 21], [6, 21]], '#3a4a5e'); R(c, 2, 16, 88, 1, '#c84a3a'); for (let x = 22; x < 86; x += 6) R(c, x, 8 - ((x / 6) % 2), 5, 6 + ((x / 6) % 2), ['#d8463c', '#5a8aa8', '#e9c46a', '#5aa66e', '#e8ecef'][(x / 6 | 0) % 5]); R(c, 4, 3, 12, 11, '#f4f4f2'); R(c, 5, 5, 10, 2, '#2e3a44'); R(c, 8, 0, 3, 3, '#2e3a44'); break;
    case 'phinisi': mk(50, 34); hull([[2, 24], [42, 24], [50, 18], [44, 32], [8, 32]], '#7a4a2a'); R(c, 4, 24, 40, 1, '#c89a62'); for (const [x, h] of [[18, 20], [32, 22]]) { R(c, x, 24 - h, 1, h, '#4a3424'); hull([[x + 1, 24 - h + 2], [x + 12, 24 - h + 6], [x + 11, 22], [x + 1, 22]], '#f0e6d0'); } hull([[43, 18], [50, 8], [50, 18]], '#f0e6d0'); break;
    case 'paraw': mk(40, 30); hull([[8, 22], [30, 22], [34, 19], [31, 25], [11, 25]], '#f4f4f2'); R(c, 0, 26, 40, 1, '#8a6e50'); R(c, 6, 22, 1, 4, '#8a6e50'); R(c, 32, 22, 1, 4, '#8a6e50'); R(c, 19, 2, 1, 20, '#7a848c'); hull([[20, 3], [32, 20], [20, 20]], '#e46b4a'); R(c, 20, 10, 8, 2, '#f2c94c'); break;
    case 'redjunk': mk(30, 28); hull([[1, 20], [26, 20], [30, 16], [27, 26], [4, 26]], '#4a3424'); for (const [x, h] of [[9, 16], [17, 18], [24, 11]]) { R(c, x, 20 - h - 1, 1, h + 1, '#2a1a14'); c.fillStyle = '#c8302c'; c.beginPath(); c.moveTo(x, 20 - h); c.lineTo(x + 8, 20 - h + 1); c.lineTo(x + 7, 19); c.lineTo(x, 19); c.closePath(); c.fill(); for (let y = 20 - h + 3; y < 19; y += 3) R(c, x, y, 7, 1, '#8a1a18'); } break;
    case 'islet': { mk(40, 26); const ks = karst(Math.random() * 1e6 | 0, 40, 26, ['#8f8a7e', '#a9a294', '#c4bdac'], ['#3f6e4c', '#5a9060', '#7fae70'], { count: 1 }); c.drawImage(ks, 0, 0); break; }
    case 'torii_sea': return lm('torii', 1);
  }
  return cv;
}

/* ---------------- per-port layer sets ---------------- */
function gen(port) {
  const B = port.bi && RECIPE[port.bi] ? port.bi : 'gulf'; const rc = RECIPE[B], bio = BIOMES[B];
  const seed = [...port.id].reduce((a, ch) => (a * 31 + ch.charCodeAt(0)) >>> 0, 7); const Rn = rng(seed);
  const W = 960; const out = { biome: B, W, lit: {} };
  // far
  const farH = 120;
  const farKind = port.far || rc.far;
  switch (farKind) {
    case 'kinabalu': out.far = PX.ridge(seed, W, farH, ['#6f8aa0', '#86a0b4', '#9db4c6'], { peaks: 14, base: 0.98 }); break;
    case 'sakurajima': case 'agung': case 'rinjani': case 'hallasan': out.far = volcano(seed, W, farH, farKind === 'hallasan' ? ['#7f9aa8', '#93aebb', '#a8c0cc'] : ['#7a8ea4', '#8ea3b8', '#a3b8cb', '#b8cbdb']); break;
    case 'karst': out.far = karst(seed, W, farH, ['#7f98a4', '#8ea6b0', '#9db3bc'], ['#7a9c98', '#89aaa4', '#99b8b0'], { count: 11 }); break;
    case 'volcano': out.far = volcano(seed, W, farH, ['#8299b0', '#94abc0', '#a8bdcf', '#bccddc']); break;
    case 'fuji': out.far = volcano(seed, W, farH, ['#7f98b6', '#93abc6', '#a8bdd4', '#bccde0'], { fuji: true }); break;
    case 'jagged': out.far = PX.ridge(seed, W, farH, ['#7f9cb0', '#94afc0', '#aac2d0'], { peaks: 11, base: 0.95 }); break;
    case 'skyfar': { const s = city(seed + 9, W, 70, 'metro'); const [f, fc] = makeCanvas(W, farH); fc.globalAlpha = 0.55; fc.drawImage(PX.ridge(seed, W, farH, bio.far, { peaks: 4, base: 0.92 }), 0, 0); fc.globalAlpha = 0.6; fc.drawImage(s.cv, 0, farH - 70); out.far = f; break; }
    default: out.far = PX.ridge(seed, W, farH, bio.far || ['#9ab3c4', '#aec4d2', '#c2d4df'], { peaks: rc.far === 'mountain' ? 8 : 5, base: 0.9 });
  }
  if (port.far === 'sakurajima' || port.far === 'agung') { const fc = out.far.getContext('2d'); for (let i = 0; i < 18; i++) { const px = W * 0.2 + i * 3 + Math.sin(i) * 4, py = 30 - i * 2.2, r = 4 + i * 0.7; fc.fillStyle = `rgba(${150 + i * 3},${150 + i * 3},${155 + i * 3},${(0.55 - i * 0.02).toFixed(2)})`; fc.beginPath(); fc.arc(px, py, r, 0, Math.PI * 2); fc.fill(); } }
  if (port.lf?.length) { const fc = out.far.getContext('2d'); port.lf.forEach((t, i) => { const im = lm(t, 1); if (!im) return; const lx = Math.round(W * (0.3 + 0.4 * (i / Math.max(1, port.lf.length - 1 || 1)))); fc.globalAlpha = 0.85; fc.drawImage(im, lx, farH - im.height - 4); fc.globalAlpha = 1; }); }
  // mid
  const midH = 92; const [mid, mc] = makeCanvas(W, midH); const [midL, mlc] = makeCanvas(W, midH);
  const greens = ['#4f7f68', '#6a9a72', '#8cb47e'];
  switch (rc.mid) {
    case 'karst': mc.drawImage(karst(seed + 1, W, midH, ['#7d7a70', '#958f82', '#ada596', '#c4bba8'], ['#2f5e44', '#47805a', '#68a068', '#8cbc78'], { count: 8 }), 0, 0); break;
    case 'terrace': mc.drawImage(terraces(seed + 1, W, midH, ['#4f8a5a', '#6aa66a', '#8cc27a', '#b0d68e']), 0, 0); break;
    case 'jungle': mc.drawImage(PX.ridge(seed + 1, W, midH, ['#2f5b46', '#3f7a4f', '#5a9a5a', '#7fb46a'], { peaks: 7, base: 0.96 }), 0, 0); break;
    case 'pinehills': mc.drawImage(PX.ridge(seed + 1, W, midH, ['#3e6a58', '#557f66', '#6e9878'], { peaks: 6, base: 0.95 }), 0, 0); for (let x = 10; x < W; x += 22 + Rn() * 30) { const t = PX.pineTree(seed + x, 0.35); mc.drawImage(t, x, midH - 20 - Rn() * 18 - t.height * 0.6); } break;
    case 'resortcity': case 'metrocity': case 'lowcity': case 'apartments': {
      mc.drawImage(PX.ridge(seed + 1, W, midH, rc.mid === 'metrocity' ? ['#7a9a8a', '#8eaa98', '#a2baa8'] : greens, { peaks: 5, base: 0.97 }), 0, 0);
      const st = { resortcity: 'resort', metrocity: 'metro', lowcity: 'low', apartments: 'apt' }[rc.mid]; const s = city(seed + 2, W, rc.mid === 'metrocity' ? 82 : rc.mid === 'resortcity' ? 60 : 44, st);
      mc.drawImage(s.cv, 0, midH - s.cv.height); mlc.drawImage(s.lit, 0, midH - s.cv.height); break;
    }
    default: mc.drawImage(PX.ridge(seed + 1, W, midH, greens, { peaks: 6, base: 0.95 }), 0, 0);
  }
  out.mid = mid; out.lit.mid = midL;
  // near shoreline
  const nearH = 64; const [near, nc] = makeCanvas(W, nearH); const [nearL, nlc] = makeCanvas(W, nearH);
  const sand = { beach: '#f1e2b8', promenade: '#e8dcc0', port: '#9aa4ac', karstshore: '#c9bfa6', stilt: '#c9b48a', jtown: '#b9b0a0' }[rc.near] || '#e9d7ae';
  R(nc, 0, nearH - 7, W, 7, sand); R(nc, 0, nearH - 3, W, 3, shade(sand, -0.12)); for (let x = 0; x < W; x += 3) if (Rn() < 0.3) R(nc, x, nearH - 6, 1, 1, shade(sand, 0.15));
  if (rc.near !== 'port') R(nc, 0, nearH - 10, W, 3, rc.near === 'jtown' ? '#5f8a62' : '#6a9a5a');
  if (rc.near === 'port') { R(nc, 0, nearH - 9, W, 2, '#7a848c'); for (let x = 0; x < W; x += 140 + Rn() * 120) { const cr = lm('cranes', 1); nc.drawImage(cr, x, nearH - 7 - cr.height); } }
  if (rc.near === 'promenade') { const s = city(seed + 3, W, 30, 'resort'); nc.drawImage(s.cv, 0, nearH - 9 - 30); nlc.drawImage(s.lit, 0, nearH - 9 - 30); for (let x = 0; x < W; x += 9) { R(nc, x, nearH - 10, 1, 3, '#59646e'); nlc.fillStyle = '#ffe2a0'; nlc.fillRect(x, nearH - 11, 1, 1); } }
  if (rc.near === 'jtown') for (let x = 0; x < W; x += 16 + Rn() * 24) { const hw = 10 + (Rn() * 8 | 0); R(nc, x, nearH - 18, hw, 8, '#efe9dc'); R(nc, x - 2, nearH - 21, hw + 4, 3, '#4a5260'); R(nc, x + 3, nearH - 15, 2, 2, '#59646e'); if (Rn() < 0.5) { nlc.fillStyle = '#ffd98a'; nlc.fillRect(x + 3, nearH - 15, 2, 2); } }
  if (rc.near === 'stilt') { const v = lm('stilt', 1); nc.drawImage(v, W * 0.15, nearH - v.height + 2); nc.drawImage(v, W * 0.6, nearH - v.height + 2); }
  if (port.town) { const im = lm(port.town, 1); if (im) for (let x = (Rn() * 40) | 0; x < W; x += im.width + 30 + Rn() * 90) { nc.drawImage(im, x, nearH - 9 - im.height); if (nlc) { nlc.fillStyle = '#ffd98a'; for (let k = 0; k < 4; k++) nlc.fillRect(x + 3 + k * (im.width / 4), nearH - 9 - im.height * 0.5, 1, 1); } } }
  // trees
  let x = 2;
  while (x < W - 30) {
    const kind = rc.trees[(Rn() * rc.trees.length) | 0]; let spr = null;
    if (kind === 'palm') spr = PX.palmTree(seed + x, 0.62); else if (kind === 'pine') spr = PX.pineTree(seed + x, 0.5); else if (kind === 'sakura') spr = PX.sakuraTree(seed + x, 0.55); else spr = PX.bush(seed + x, 24, 11);
    if (spr && !(rc.near === 'port' && Rn() < 0.7)) nc.drawImage(spr, Math.round(x), nearH - 8 - spr.height + 2);
    x += (rc.near === 'port' ? 40 : 10) + Rn() * 26;
  }
  // houses / bungalows for beach biomes
  if (rc.near === 'beach' || rc.near === 'karstshore') for (let i = 0; i < 5; i++) { const hx = (Rn() * W) | 0, hw = 9 + (Rn() * 7 | 0); R(nc, hx, nearH - 16, hw, 7, ['#f3ead8', '#e9e2d6', '#f4d7c5'][i % 3]); R(nc, hx - 1, nearH - 19, hw + 2, 3, B === 'andaman' || B === 'gulf' ? '#a8703c' : '#c8553d'); nlc.fillStyle = '#ffd98a'; nlc.fillRect(hx + 3, nearH - 13, 2, 2); }
  // landmarks
  const land = port.lm || [];
  land.forEach((t, i) => { const im = lm(t, 1); if (!im) return; const lx = Math.round(W * (0.2 + 0.55 * ((i + 0.5) / land.length)) + (Rn() - 0.5) * 60); const onHill = ['buddha', 'chedi', 'tower', 'pagoda', 'kekloksi', 'cham', 'shuri', 'osakacastle', 'fukuokatower', 'pearl', 'landmark', 'gulangyu', 'royalstation'].includes(t);
    let hillY = -1;
    if (onHill) { const cx0 = clamp(lx + (im.width >> 1), 0, W - 1); const col = mc.getImageData(cx0 - 3, 0, 7, midH).data; for (let y = 0; y < midH; y++) { let solid = true; for (let k = 0; k < 7; k++) if (col[(y * 7 + k) * 4 + 3] < 200) solid = false; if (solid) { hillY = y; break; } } }
    if (onHill && hillY >= 0 && hillY < midH - 8) mc.drawImage(im, lx, hillY - im.height + 3); else nc.drawImage(im, lx, nearH - 7 - im.height + 1);
    if (t === 'tower' || t === 'ferris' || t === 'bridge') { const ly = hillY >= 0 && onHill ? hillY - im.height + 3 : null; (ly != null ? mlc : nlc).fillStyle = '#ff9a8a'; (ly != null ? mlc : nlc).fillRect(lx + (im.width >> 1), ly != null ? ly : nearH - 7 - im.height + 1, 1, 1); }
  });
  const lh = PX.lighthouse(); nc.drawImage(lh, Math.round(W * 0.9), nearH - 8 - lh.height + 2); nlc.fillStyle = '#fff6c8'; nlc.fillRect(Math.round(W * 0.9) + 4, nearH - 8 - lh.height + 5, 2, 2);
  out.near = near; out.lit.near = nearL; out.lighthouseX = Math.round(W * 0.9) + 5; out.lighthouseY = nearH - 8 - lh.height + 5;
  // marina pier with moored yachts
  const [pier, pc] = makeCanvas(W, 40);
  pc.fillStyle = '#9a8c70'; pc.fillRect(0, 28, W, 3); for (let px = 0; px < W; px += 16) { pc.fillStyle = '#6a5c48'; pc.fillRect(px, 28, 3, 12); }
  for (const [yx, col] of [[120, '#7cc8b8'], [520, '#f3f1ec'], [800, '#3e5a78']]) { pc.fillStyle = col; pc.beginPath(); pc.moveTo(yx, 18); pc.lineTo(yx + 120, 18); pc.lineTo(yx + 124, 10); pc.lineTo(yx + 124, 26); pc.lineTo(yx + 6, 27); pc.closePath(); pc.fill(); pc.fillStyle = '#f3f1ec'; pc.fillRect(yx + 20, 8, 80, 10); pc.fillRect(yx + 40, 2, 40, 6); pc.fillStyle = '#2e3a44'; pc.fillRect(yx + 24, 11, 70, 3); pc.fillRect(yx + 44, 4, 30, 2); }
  out.pier = pier;
  return out;
}

/* ---------------- runtime ---------------- */
export class BiomeRenderer {
  constructor(scene) { this.sc = scene; this.cache = new Map(); this.sets = []; this.props = []; this.fx = []; this.spawnT = 0; this.tintCache = new Map(); this.focus = null; this.boatCache = new Map(); this.birds = []; }
  setFor(port) {
    let s = this.cache.get(port.id);
    if (!s) {
      s = gen(port); this.cache.set(port.id, s);
      // keep only a few regions in memory (mobile browsers crash when total canvas memory grows unbounded)
      const keep = new Set(this.sets.map(x => x.port.id)); keep.add(port.id);
      for (const [id, old] of this.cache) { if (this.cache.size <= 4) break; if (keep.has(id)) continue; this.dispose(old); this.cache.delete(id); }
    } else { this.cache.delete(port.id); this.cache.set(port.id, s); } // LRU touch
    return s;
  }
  dispose(set) {
    for (const cv of [set.far, set.mid, set.near, set.pier, set.lit?.far, set.lit?.mid, set.lit?.near]) {
      if (!cv) continue; const t = this.tintCache.get(cv); if (t) { t.cv.width = t.cv.height = 0; this.tintCache.delete(cv); } cv.width = cv.height = 0;
    }
  }
  boatImg(type, k) { const key = type + k; if (!this.boatCache.has(key)) this.boatCache.set(key, boat(type, k)); return this.boatCache.get(key); }
  tint(img, css) { let e = this.tintCache.get(img); if (!e || e.css !== css) { const [t, tc] = makeCanvas(img.width, img.height); tc.drawImage(img, 0, 0); tc.globalCompositeOperation = 'source-in'; tc.fillStyle = css; tc.fillRect(0, 0, img.width, img.height); e = { css, cv: t }; this.tintCache.set(img, e); } return e.cv; }
  update(dt, env) {
    this.env = env;
    // horizon: per-bearing distance to land (real coastline scan), eased so land grows/shrinks smoothly as you sail
    const vis = this.vis = clamp(env.vis ?? 40, 3, 45);
    if (env.land) { if (!this.dd) this.dd = Float32Array.from(env.land.bins, d => Math.min(d, vis + 12));
      const k = clamp(dt * 0.6, 0, 1), view = ((env.heading ?? 0) + 90) % 360, docked = env.moored;
      for (let i = 0; i < 72; i++) { let t = Math.min(env.land.bins[i], vis + 12);
        if (docked && Math.abs(((i * 5 - view + 540) % 360) - 180) <= 80) t = Math.min(t, 0.4); // moored alongside: the quay and town fill the view
        this.dd[i] += (t - this.dd[i]) * (docked ? 1 : k); }
      this.landNear = env.land.min; }
    // focus port = nearest; it decides the region's art, water tint and wildlife
    const near = env.near; const p = near?.port; if (p) this.artPort = p;
    const prox = near ? (near.dist < 26 ? clamp(1 - (near.dist - 3) / 23, 0, 1) : near.dist < 110 ? clamp(1 - (near.dist - 26) / 84, 0, 1) * 0.22 : 0) : 0;
    this.region = p && prox > 0 ? BIOMES[p.bi] || BIOMES.gulf : BIOMES.open; this.regionKey = p && prox > 0 ? p.bi : 'open';
    if (p && prox > 0 && (!this.sets.length || this.sets[this.sets.length - 1].port !== p)) this.sets.push({ port: p, a: 0, prox });
    for (const s of this.sets) { const tgt = s === this.sets[this.sets.length - 1] && p === s.port ? prox : 0; s.prox += (tgt - s.prox) * clamp(dt * 0.8, 0, 1); s.a = clamp(s.a + (s === this.sets[this.sets.length - 1] ? dt : -dt) * 0.4, 0, 1); }
    this.sets = this.sets.filter((s, i) => i === this.sets.length - 1 ? s.prox > 0.002 || prox > 0 : s.a > 0.01);
    this.portBoats = p && prox > 0 ? p.boats : null;
    if (p && prox > 0.35 && this.focus !== p.id) { this.focus = p.id; this.onRegion?.(p, this.region); }
    if (prox < 0.05 && this.focus) { this.focus = null; this.onRegion?.(null, BIOMES.open); }
    this.prox = prox;
    // props: boats on the water + birds; spawn rate depends on region & proximity
    this.spawnT -= dt;
    const busy = this.regionKey === 'open' ? 0.25 : 0.4 + prox;
    if (this.spawnT <= 0 && this.props.length < 7) { this.spawnT = 6 / busy * (0.6 + Math.random()); this.spawn(env); }
    for (const b of this.props) { b.u += b.vx * dt; b.bob = Math.sin(performance.now() / 700 + b.ph) * 0.6; }
    if (Math.random() < dt * (this.region.birds === 'flock' ? 0.12 : 0.08) && this.birds.length < 4) this.spawnBirds(env);
    for (const f of this.birds) { f.u += f.vx * dt; f.t += dt; }
  }
  spawn(env) {
    const types = [...this.region.boats, ...(this.portBoats || [])]; let type = types[(Math.random() * types.length) | 0];
    if ((this.landNear ?? 99) < 15 && RECIPE[this.regionKey]?.islets && Math.random() < 0.35) type = 'islet';
    if (this.regionKey === 'japan' && Math.random() < 0.15) type = 'torii_sea';
    const d = Math.random(); const k = d > 0.62 ? 2 : 1; const par = 0.08 + d * 0.5;
    const dir = Math.random() < 0.5 ? -1 : 1; const W = this.sc.W || 400;
    const camU = (this.camX || 0) * par + (env.scroll || 0) * par;
    const moving = Math.abs(env.speed) > 0.5;
    const u = moving ? camU + W + 60 + Math.random() * 120 : camU + Math.random() * W;
    this.props.push({ type, d, k, par, u, vx: type === 'islet' || type === 'torii_sea' ? 0 : dir * (2 + Math.random() * 6) * k, dir, ph: Math.random() * 7, bob: 0 });
  }
  spawnBirds(env) {
    const W = this.sc.W || 400, flock = this.region.birds === 'flock'; const n = flock ? 5 + (Math.random() * 6 | 0) : 1 + (Math.random() * 3 | 0); const dir = Math.random() < 0.5 ? -1 : 1;
    const y = 10 + Math.random() * 60; const b = { u: dir > 0 ? -30 : W + 30, vx: dir * (14 + Math.random() * 12), y, t: 0, n, flock, dir, members: [] };
    for (let i = 0; i < n; i++) b.members.push(flock ? [-Math.abs(i - n / 2) * 5 * dir, Math.abs(i - n / 2) * 3] : [Math.random() * 30 - 15, Math.random() * 14 - 7]);
    this.birds.push(b);
  }
  waterTint() { const r = this.region || BIOMES.open; return { color: r.water, k: 0.35 + 0.35 * (this.prox || 0) }; }
  // coast layers, haze, far birds — drawn before the back sea so sunk parts are hidden by the water
  // what land is on this bearing: distance (nm) interpolated between the 5° scan bins
  landAt(bearing) { const f = ((bearing % 360) + 360) % 360 / 5, i = Math.floor(f) % 72, j = (i + 1) % 72, u = f - Math.floor(f); return this.dd[i] * (1 - u) + this.dd[j] * u; }
  // coast layers — only where land really lies on the horizon, sized by distance: close coast fills the view at
  // full height; an island 10 nm off is a small, narrow, hazy hump; past the visibility range (≈40 nm clear,
  // much less in fog/rain) it has sunk below the horizon. Drawn before the back sea so sunk parts are hidden.
  drawBack(c, l, o) {
    this.camX = o.camX;
    const { W, horizon, ambCss } = o; const env = this.env || {}; const port = this.artPort;
    if (port && this.dd) {
      const set = this.setFor(port), vis = this.vis || 40, view = ((env.heading ?? 0) + 90) % 360;
      // columns → spans of visible land (split where the distance changes a lot, so near and far land differ in size)
      const spans = []; let cur = null;
      for (let x = 0; x <= W; x += 2) {
        const rel = (x - W / 2) / (W * 0.55) * 80, d = this.landAt(view + rel), seen = d < vis && x < W;
        if (seen && cur && Math.abs(Math.log(d / cur.ref)) < 0.35) { cur.x1 = x + 2; cur.d = Math.min(cur.d, d); }
        else { if (cur) spans.push(cur); cur = seen ? { x0: x, x1: x + 2, d, ref: d } : null; }
      }
      if (cur) spans.push(cur);
      spans.sort((a, b) => b.d - a.d); // far first
      const maxH = Math.max(set.far?.height || 0, set.mid?.height || 0, set.near?.height || 0);
      if (!this.off || this.off.width < W || this.off.height < maxH) { [this.off, this.oc] = makeCanvas(Math.ceil(W), maxH); [this.off2, this.oc2] = makeCanvas(Math.ceil(W), maxH); this.oc.imageSmoothingEnabled = this.oc2.imageSmoothingEnabled = false; }
      const fog = clamp(1 - vis / 40, 0, 1);
      for (const sp of spans) {
        const d = Math.max(0.3, sp.d), a = clamp(2.6 / d, 0.06, 1), fade = clamp((vis - d) / (vis * 0.25), 0, 1);
        const haze = clamp((d - 1.5) / vis, 0, 1) * 0.8 + fog * 0.25;
        const sink = clamp((d - vis * 0.35) / (vis * 0.65), 0, 1) * 0.75; // earth's curvature hides the foot of distant land
        const L = [[set.far, set.lit?.far, 0.025, true], [set.mid, set.lit?.mid, 0.07, a > 0.45], [set.near, set.lit?.near, 0.16, a > 0.8]];
        L.forEach(([img, lit, par, show], i) => {
          if (!img || !show) return;
          const s = i === 0 ? a : clamp((a - (i === 1 ? 0.45 : 0.8)) / (i === 1 ? 0.55 : 0.2), 0, 1) * a; // closer layers grow in as you approach
          if (s < 0.04) return;
          const tw = Math.max(1, Math.round(img.width * s)), th = Math.max(1, Math.round(img.height * s));
          const y = Math.round(horizon + 2 + i * 4 * s - th + th * sink);
          const off = ((-(o.camX * par + o.scroll * par) * s) % tw + tw) % tw - tw;
          const x0 = Math.max(0, Math.floor(sp.x0)), x1 = Math.min(W, Math.ceil(sp.x1)), w = x1 - x0; if (w < 2) return;
          const oc = this.oc, oc2 = this.oc2;
          oc.globalCompositeOperation = 'source-over'; oc.clearRect(0, 0, W, th + 1);
          oc.save(); oc.beginPath(); oc.rect(x0, 0, w, th); oc.clip(); for (let x = off; x < x1; x += tw) if (x + tw > x0) oc.drawImage(img, Math.round(x), 0, tw, th); oc.restore();
          if (haze > 0.02) { oc.globalCompositeOperation = 'source-atop'; oc.globalAlpha = haze; oc.fillStyle = o.pal.bot; oc.fillRect(x0, 0, w, th); oc.globalAlpha = 1; }
          // soft ends where the land runs out (not at the screen edge)
          oc.globalCompositeOperation = 'destination-out'; const fw = Math.min(20 * s + 4, w / 3);
          if (x0 > 0) { const g = oc.createLinearGradient(x0, 0, x0 + fw, 0); g.addColorStop(0, 'rgba(0,0,0,1)'); g.addColorStop(1, 'rgba(0,0,0,0)'); oc.fillStyle = g; oc.fillRect(x0, 0, fw, th); }
          if (x1 < W) { const g = oc.createLinearGradient(x1 - fw, 0, x1, 0); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,1)'); oc.fillStyle = g; oc.fillRect(x1 - fw, 0, fw, th); }
          oc.globalCompositeOperation = 'source-over';
          const alpha = fade * (i === 0 ? 0.92 : 1);
          c.globalAlpha = alpha; c.drawImage(this.off, 0, 0, W, th, 0, y, W, th);
          oc2.globalCompositeOperation = 'source-over'; oc2.clearRect(0, 0, W, th + 1); oc2.drawImage(this.off, 0, 0); oc2.globalCompositeOperation = 'source-in'; oc2.fillStyle = ambCss; oc2.fillRect(0, 0, W, th); oc2.globalCompositeOperation = 'source-over';
          l.globalAlpha = alpha; l.drawImage(this.off2, 0, 0, W, th, 0, y, W, th);
          if (lit && o.night > 0.05) { // town lights, dimmer with distance
            const tl = 0.75 + 0.25 * Math.sin(o.t * 2 + i); c.save(); c.beginPath(); c.rect(x0, y, w, th); c.clip(); c.globalAlpha = alpha * o.night * tl * (1 - haze * 0.6);
            for (let x = off; x < x1; x += tw) if (x + tw > x0) c.drawImage(lit, Math.round(x), y, tw, th); c.restore();
          }
          if (i === 2 && o.night > 0.3 && set.lighthouseX != null && s > 0.6) {
            for (let x = off; x < x1; x += tw) { const bx = Math.round(x + set.lighthouseX * s), by = y + set.lighthouseY * s; if (bx < x0 || bx > x1) continue; const sw = Math.sin(o.t * 1.4); c.globalAlpha = alpha * o.night * 0.35; c.fillStyle = '#fff6c8'; c.beginPath(); c.moveTo(bx, by); c.lineTo(bx + sw * 90, by - 6); c.lineTo(bx + sw * 90, by + 4); c.closePath(); c.fill(); }
          }
        });
      }
      c.globalAlpha = 1; l.globalAlpha = 1;
    }
    // birds
    for (const f of this.birds) {
      const x0 = f.u; if (x0 < -80 || x0 > W + 80) continue;
      c.fillStyle = f.flock || o.night > 0.4 ? '#3a4652' : '#ffffff';
      f.members.forEach(([dx, dy], i) => { const x = Math.round(x0 + dx), y = Math.round(f.y + dy + Math.sin(f.t * 2 + i) * 1.5); const up = Math.floor(f.t * 6 + i) % 2; c.fillRect(x - 2, y - up, 2, 1); c.fillRect(x, y, 1, 1); c.fillRect(x + 1, y - up, 2, 1); });
    }
    this.birds = this.birds.filter(f => f.u > -120 && f.u < W + 120);
  }
  // boats, islets — sit on the water between the horizon and the yacht
  drawSea(c, l, o) {
    const { W, horizon, waterS, ambCss } = o;
    this.props.sort((a, b) => a.d - b.d);
    for (const b of this.props) {
      const img = this.boatImg(b.type, b.k); const sx = Math.round(b.u - (o.camX * b.par + o.scroll * b.par));
      b.sx = sx; if (sx < -img.width - 40 || sx > W + 200) continue;
      const y = Math.round(horizon + 2 + b.d * Math.max(6, (waterS - horizon) * 0.55) + b.bob);
      const flip = b.dir < 0 && b.type !== 'islet';
      c.save(); c.translate(sx + (flip ? img.width : 0), y - img.height); if (flip) c.scale(-1, 1); c.drawImage(img, 0, 0); c.restore();
      const ti = this.tint(img, ambCss); l.save(); l.translate(sx + (flip ? img.width : 0), y - img.height); if (flip) l.scale(-1, 1); l.drawImage(ti, 0, 0); l.restore();
      if (o.night > 0.3) { // running / work lights
        const lx = sx + (flip ? 2 : img.width - 3);
        c.fillStyle = b.type === 'squid' ? '#c8f5c0' : '#fff2c8'; c.fillRect(lx, y - img.height + 2, 1, 1);
        if (b.type === 'squid') { c.globalAlpha = 0.25 * o.night; c.fillStyle = '#c8f5c0'; c.fillRect(sx - 4, y - img.height - 4, img.width + 8, img.height + 4); c.globalAlpha = 1; l.globalCompositeOperation = 'lighter'; l.fillStyle = `rgba(60,110,60,${(0.6 * o.night).toFixed(2)})`; l.fillRect(sx - 6, y - img.height - 6, img.width + 12, img.height + 8); l.globalCompositeOperation = 'source-over'; }
        if (b.type === 'cargo' || b.type === 'ferry') { l.globalCompositeOperation = 'lighter'; l.fillStyle = 'rgba(90,80,60,0.6)'; l.fillRect(sx, y - img.height, img.width, 4); l.globalCompositeOperation = 'source-over'; c.globalAlpha = o.night * 0.8; c.fillStyle = '#ffe2a0'; for (let x = 4; x < img.width - 4; x += 5) c.fillRect(sx + x, y - img.height + 6, 1, 1); c.globalAlpha = 1; }
      }
      // small wake
      if (b.vx) { c.fillStyle = 'rgba(255,255,255,0.6)'; c.fillRect(flip ? sx + img.width : sx - 6, y - 2, 6, 1); }
    }
    this.props = this.props.filter(b => b.sx == null || (b.sx > -260 && b.sx < (W + 400)));
  }
  // foreground atmosphere: petals, fireflies, leaping fish, light shafts
  drawFront(c, l, o) {
    const { W, H, horizon } = o; const fx = this.region?.fx; const k = this.regionKey === 'open' ? 1 : clamp(this.prox * 1.5, 0, 1);
    if (o.q > 0 && fx === 'petal' && k > 0.1) { while (this.fx.length < 26 * k) this.fx.push({ x: Math.random() * W, y: -Math.random() * H, vx: -8 - Math.random() * 10, vy: 6 + Math.random() * 8, ph: Math.random() * 6 }); }
    if (o.q > 0 && fx === 'firefly' && k > 0.2 && o.night > 0.5) { while (this.fx.length < 18 * k) this.fx.push({ x: Math.random() * W, y: horizon - 10 - Math.random() * 30, vx: (Math.random() - 0.5) * 4, vy: (Math.random() - 0.5) * 2, ph: Math.random() * 6, ff: 1 }); }
    if (fx === 'fish' && Math.random() < o.dt * 0.25) this.fx.push({ fish: 1, x: Math.random() * W, y0: horizon + 10 + Math.random() * 30, t: 0 });
    for (const p of this.fx) {
      if (p.fish) { p.t += o.dt; const y = p.y0 - Math.sin(Math.min(1, p.t / 0.8) * Math.PI) * 10; c.fillStyle = '#c8d8e6'; c.fillRect(Math.round(p.x + p.t * 30), Math.round(y), 3, 1); continue; }
      p.x += (p.vx + Math.sin(o.t + p.ph) * 4) * o.dt; p.y += (p.vy + Math.cos(o.t * 0.7 + p.ph)) * o.dt;
      if (p.ff) { const a = 0.5 + 0.5 * Math.sin(o.t * 3 + p.ph); c.fillStyle = `rgba(230,255,140,${a.toFixed(2)})`; c.fillRect(Math.round(p.x), Math.round(p.y), 1, 1); l.fillStyle = 'rgb(200,200,160)'; l.fillRect(Math.round(p.x), Math.round(p.y), 1, 1); }
      else { c.fillStyle = (p.ph | 0) % 2 ? '#f6c9d6' : '#fbe1e8'; c.fillRect(Math.round(p.x), Math.round(p.y), 2, 1); }
    }
    this.fx = this.fx.filter(p => p.fish ? p.t < 0.8 : (p.x > -10 && p.y < H + 10 && p.x < W + 20) && !(p.ff && o.night < 0.4));
    // golden-hour light shafts from the sun
    if (o.q > 1 && o.golden > 0.4 && this.sc.sunX != null) { c.globalAlpha = 0.06 * o.golden; c.fillStyle = '#ffe2b0'; for (let i = 0; i < 4; i++) { const x = this.sc.sunX + (i - 1.5) * 40; c.beginPath(); c.moveTo(x, 0); c.lineTo(x + 30, 0); c.lineTo(x + 90 + i * 10, horizon); c.lineTo(x + 50 + i * 10, horizon); c.closePath(); c.fill(); } c.globalAlpha = 1; }
  }
  pier(port) { return this.setFor(port).pier; }
}
