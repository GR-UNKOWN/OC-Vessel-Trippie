// Each peer controls its own OC. The host supplies the shared yacht and voyage state.
// Absolute snapshots support interpolation without depending on earlier movement packets.
import { Bus, el, clamp, lerp } from './util.js';
import { connect, cleanPin, validPin, MAX_SPRITE } from './net.js';
import { FIXTURES } from './yacht.js';
import { G, switchYacht } from './main.js';

const ST = ['idle', 'walk', 'sit', 'sleep', 'talk', 'swim', 'shark', 'stair', 'look', 'interact', 'lie'];
const stCode = ch => ch.swim ? (ch.swim.phase === 'shark' ? 6 : 5) : ch.stair ? 7 : Math.max(0, ST.indexOf(ch.state));
const INTERP_MS = 110, EXTRAP_MS = 160;

export const Coop = {
  active: false, pending: false, host: false, pin: null, t: null, remotes: new Map(),
  get count() { return 1 + this.remotes.size; },

  create() { return this.start(true); },
  join(value) { return this.start(false, cleanPin(value)); },
  async start(host, pin) {
    if (this.active || this.pending || !G.player) return false;
    if (!host && !validPin(pin)) {
      Bus.emit('toast', 'กรอก PIN ให้ครบ 8 ตัวตามที่โฮสต์ส่งมา');
      return false;
    }
    const party = G.party;
    this.pending = true;
    try {
      const t = await connect({
        host, pin,
        onPeers: list => this.onPeers(list),
        onPing: rtt => this.onPing(rtt),
        onLost: message => {
          Bus.emit('toast', message);
          this.leave(true);
        },
      });
      if (G.screen !== 'game' || G.party !== party || !G.player) {
        t.leave();
        return false;
      }
      Object.assign(this, {
        active: true, host: t.host, pin: t.pin, t, rtt: null, seq: 0, lightSeq: 0,
        lightReq: null, lastHostReq: new Map(), lastSend: 0, lastSig: '',
        spriteFrame: null, pendingWorld: null, lastWorld: null, switching: false,
      });
      G.coop = { guest: !this.host, host: this.host };
      G.coopSolo = true;
      this.onPeers(t.peers());
      this.sendNow(true);
      this.bgIv = setInterval(() => {
        if (document.hidden) this.sendNow(true);
      }, 1500);
      Bus.emit('coop');
      Bus.emit('toast', this.host ? 'สร้างห้องแล้ว ส่งลิงก์เชิญให้เพื่อน' : 'เข้าห้อง ' + this.pin + ' แล้ว');
      return true;
    } catch (error) {
      if (this.active) this.leave(true);
      Bus.emit('toast', error.message);
      return false;
    } finally {
      this.pending = false;
    }
  },
  leave(silent) {
    if (!this.active) return;
    this.active = false;
    const t = this.t;
    this.t = null;
    clearInterval(this.bgIv);
    for (const r of this.remotes.values()) r.tag?.remove();
    this.remotes.clear();
    t.leave();
    G.coop = null;
    G.coopSolo = false;
    if (!silent) Bus.emit('toast', 'ออกจากห้อง Co-op แล้ว');
    Bus.emit('coop');
  },

  onPing(rtt) {
    if (!this.active) return;
    this.rtt = this.rtt ? Math.round(this.rtt * 0.6 + rtt * 0.4) : rtt;
  },
  onPeers(list) {
    if (!this.active) return;
    const now = performance.now();
    const seen = new Set();
    let changed = false;
    for (const { id, state } of list) {
      if (!state) continue;
      seen.add(id);
      let remote = this.remotes.get(id);
      if (!remote) {
        remote = new Remote(id);
        this.remotes.set(id, remote);
        changed = true;
      }
      if (remote.lastState === state) continue;
      remote.lastState = state;
      remote.ingest(state, now);
      if (!this.host && state.h && state.w) this.pendingWorld = state.w;
      if (this.host && state.y === G.yachtId && state.lr && state.lr.q !== this.lastHostReq.get(id)) {
        this.lastHostReq.set(id, state.lr.q);
        G.toggleRoomLights?.(state.lr.r, state.lr.on, true);
      }
    }
    for (const [id, remote] of this.remotes) {
      if (seen.has(id)) continue;
      remote.tag?.remove();
      this.remotes.delete(id);
      this.lastHostReq.delete(id);
      changed = true;
      Bus.emit('toast', remote.name + ' ออกจากห้อง');
    }
    if (changed) Bus.emit('coop:peers');
  },
  async followYacht(id) {
    if (this.switching || !G.player || !G.fleet[id]) return;
    const t = this.t;
    this.switching = true;
    try {
      await switchYacht(id, { followSlot: G.player.slot_ });
    } catch (error) {
      Bus.emit('toast', 'ย้ายไปเรือของโฮสต์ไม่ได้ ' + error.message);
      if (this.t === t) this.leave(true);
    } finally {
      if (this.t === t) this.switching = false;
    }
  },
  applyWorld(w) {
    if (w.y !== G.yachtId) {
      this.lightReq = null;
      this.followYacht(w.y);
      return;
    }
    if (this.switching || this.lastWorld === w) return;
    this.lastWorld = w;
    Object.assign(G.journey.s, { lat: w.la, lon: w.lo, heading: w.hd, speed: w.sp, status: w.st, dockedAt: w.dock });
    G.clock.tz = w.tz;
    Object.assign(G.clock.s, {
      mode: 'custom', base: w.utc, setAt: Date.now(), customHour: w.hr,
    });
    if (w.L?.length === FIXTURES.length) FIXTURES.forEach((f, i) => { G.lights[f.id] = w.L[i] === '1'; });
    G.Sink?.sync(w.sk);
    if (w.td && G.tender) {
      const t = G.tender;
      t.state = w.td;
      if (Number.isFinite(w.tx)) t.x = w.tx;
      if (Number.isFinite(w.ty)) t.y = w.ty;
      if (Number.isFinite(w.door)) t.door = w.door;
    }
  },

  stateObj() {
    const p = G.player;
    const [x, y] = p.pos();
    const st = {
      v: 1, y: G.yachtId, n: G.session?.username || p.name || 'ผู้เล่น', oc: p.name,
      p: [Math.round(x), Math.round(y), p.facing < 0 ? -1 : 1, p.inHeli ? 11 : stCode(p), ++this.seq],
      rtt: this.rtt || 0,
    };
    if (p.text) st.say = [p.text.id, p.text.s];
    if (this.lightReq) st.lr = this.lightReq;
    if (this.host) {
      const j = G.journey.s;
      const L = FIXTURES.map(f => G.lights[f.id] ? '1' : '0').join('');
      const t = G.tender;
      const tz = G.clock.s.mode === 'real' ? -new Date().getTimezoneOffset() / 60 : G.clock.tz;
      st.w = {
        y: G.yachtId, hr: G.clock.localHour(), utc: G.clock.utc(), tz,
        la: +j.lat.toFixed(4), lo: +j.lon.toFixed(4), hd: Math.round(j.heading), sp: +j.speed.toFixed(2),
        st: j.status, dock: j.dockedAt, L, td: t?.state, tx: t?.x, ty: t?.y, door: t?.door,
        sk: G.Sink?.active ? +G.Sink.T.toFixed(1) : null,
      };
    }
    return st;
  },
  sendNow(force) {
    if (!this.active || !G.player) return;
    const state = this.stateObj();
    const frame = G.player.spr?.frames?.[0] || null;
    if (frame !== this.spriteFrame) state.sp = spriteURL(frame);
    const sig = JSON.stringify([state.y, state.n, state.oc, state.p.slice(0, 4), state.say?.[0], state.lr?.q]);
    const now = performance.now();
    if (!force && !('sp' in state) && sig === this.lastSig && now - this.lastSend < 500) return;
    if (this.t.send(state)) {
      this.spriteFrame = frame;
      this.lastSig = sig;
      this.lastSend = now;
    }
  },
  requestLight(roomId, on) {
    if (this.active && !this.host) this.lightReq = { r: roomId, on, q: ++this.lightSeq };
  },

  update() {
    if (!this.active) return;
    if (!this.host && this.pendingWorld) this.applyWorld(this.pendingWorld);
    const now = performance.now();
    const moving = G.player && (G.player.state === 'walk' || G.player.stair || G.player.swim || G.player.inHeli || G.onTender(G.player));
    if (now - this.lastSend >= (moving ? 66 : 200)) this.sendNow(false);
    for (const r of this.remotes.values()) r.update(now);
  },
  draw(c) { if (!this.active) return; for (const r of this.remotes.values()) r.draw(c); updateTags(this.remotes); },
  list() { return [{ id: 'me', name: G.session?.username || 'ฉัน', host: this.host, ping: this.host ? 0 : this.rtt, me: true }, ...[...this.remotes.values()].map(r => ({ id: r.id, name: r.name, oc: r.oc, host: r.isHost, ping: r.isHost ? (this.host ? null : this.rtt) : r.rtt }))]; },
};

/* ---------- remote avatar ---------- */
class Remote {
  constructor(id) { this.id = id; this.buf = []; this.img = null; this.spSrc = null; this.name = ''; this.st = 0; this.facing = 1; this.x = 0; this.y = 0; this.text = null; this.sayId = null; }
  ingest(s, now) {
    if (this.yacht !== s.y) this.buf = [];
    this.name = s.n || 'ผู้เล่น'; this.oc = s.oc; this.yacht = s.y; this.isHost = !!s.h; this.rtt = s.rtt || null;
    if (s.sp !== this.spSrc) {
      this.spSrc = s.sp;
      this.img = null;
      if (s.sp) {
        const im = new Image();
        im.onload = () => { if (this.spSrc === s.sp) this.img = im; };
        im.src = s.sp;
      }
    }
    const p = s.p; if (Array.isArray(p) && Number.isFinite(p[0]) && Number.isFinite(p[1])) {
      const last = this.buf[this.buf.length - 1];
      if (!last || last.seq !== p[4]) { this.buf.push({ t: now, x: p[0], y: p[1], f: p[2], st: p[3], seq: p[4] }); if (this.buf.length > 12) this.buf.shift(); }
      const prevSt = this.st; this.st = p[3] | 0; if (this.st === 6 && prevSt !== 6 && this.yacht === G.yachtId) Bus.emit('coop:shark', this);
      if (!last || Math.hypot(p[0] - last.x, p[1] - last.y) > 140) { this.x = p[0]; this.y = p[1]; this.buf = [this.buf[this.buf.length - 1]]; }
    }
    if (Array.isArray(s.say) && s.say[0] !== this.sayId) { this.sayId = s.say[0]; this.text = { s: String(s.say[1] || '').slice(0, 80), t: 5, id: Math.random() }; this.textAt = now; }
  }
  update(now) {
    // render ~110 ms in the past between two snapshots; extrapolate briefly if the next one is late
    const rt = now - INTERP_MS, b = this.buf;
    if (!b.length) return;
    let i = b.length - 1; while (i > 0 && b[i - 1].t > rt) i--;
    const a = b[Math.max(0, i - 1)], c = b[i];
    if (c.t <= rt) { const prev = b[b.length - 2]; if (prev && now - c.t < EXTRAP_MS + INTERP_MS && c.st === 1) { const v = (c.x - prev.x) / Math.max(16, c.t - prev.t); this.x = c.x + v * Math.min(EXTRAP_MS, rt - c.t); } else this.x = c.x; this.y = c.y; }
    else if (a === c) { this.x = c.x; this.y = c.y; }
    else { const k = clamp((rt - a.t) / Math.max(1, c.t - a.t), 0, 1); this.x = lerp(a.x, c.x, k); this.y = lerp(a.y, c.y, k); }
    this.facing = c.f || 1;
    if (this.text && now - this.textAt > 5000) this.text = null;
  }
  draw(c) {
    if (this.yacht !== G.yachtId || this.st === 6 || this.st === 11) { this.bounds = null; return; }
    const im = this.img; const x = Math.round(this.x), y = Math.round(this.y);
    if (!im) { c.fillStyle = 'rgba(56,67,74,0.7)'; c.fillRect(x - 5, y - 30, 10, 30); this.bounds = [x - 5, y - 30, 10, 30]; return; }
    const w = im.width, h = im.height; const walk = this.st === 1 || this.st === 7; const bob = walk ? (Math.floor(performance.now() / 160) % 2) : 0;
    c.save();
    if (this.st === 3 || this.st === 10) { c.translate(x, y - 4); c.rotate(-Math.PI / 2); c.drawImage(im, -h + 4, -w / 2, w, h); c.restore(); this.bounds = [x - h / 2, y - w, h, w]; return; }
    const sit = this.st === 2; const crop = sit ? Math.round(h * 0.3) : 0; const sh = h - crop; const yy = y - sh - bob - (sit ? 6 : 0);
    c.translate(x, 0); if (this.facing < 0) c.scale(-1, 1);
    c.drawImage(im, 0, 0, w, sh, -Math.round(w / 2), yy, w, sh); c.restore();
    this.bounds = [x - w / 2, yy, w, sh];
  }
  pos() { return [this.x, this.y]; }
}
function spriteURL(frame) {
  if (!frame) return null;
  try {
    const url = frame.toDataURL('image/png');
    return url.length <= MAX_SPRITE ? url : null;
  } catch { return null; }
}
/* ---------- name tags (DOM, crisp at any zoom) ---------- */
let tagLayer = null;
function updateTags(remotes) {
  if (!tagLayer || !tagLayer.isConnected) { tagLayer = el('div', { class: 'tag-layer' }); document.body.append(tagLayer); }
  for (const r of remotes.values()) {
    if (!r.tag) { r.tag = el('div', { class: 'name-tag' }); tagLayer.append(r.tag); }
    if (!r.bounds || r.st === 6 || !G.worldToCss) { r.tag.hidden = true; continue; }
    const [cx, cy] = G.worldToCss(r.x, r.bounds[1] - 2);
    r.tag.hidden = false; r.tag.textContent = (r.isHost ? '★ ' : '') + r.name; r.tag.style.left = Math.round(cx) + 'px'; r.tag.style.top = Math.round(cy) + 'px';
  }
}
export function coopSpeakers() { return Coop.active ? [...Coop.remotes.values()].filter(r => r.text && r.bounds && r.st !== 6) : []; }
