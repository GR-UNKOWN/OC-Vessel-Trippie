// Deployment config. Fill these to switch from on-device accounts to Supabase email/password auth.
// (Supabase requests are blocked inside the claude.ai artifact sandbox; they work when self-hosted over HTTPS.)
export const CONFIG = {
  supabaseUrl: '',
  supabaseAnonKey: '',
  autosaveSeconds: 30,
};
