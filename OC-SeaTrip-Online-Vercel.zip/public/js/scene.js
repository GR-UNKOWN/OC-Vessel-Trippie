// Scene renderer: builds the low-res pixel frame (sky, clouds, coast parallax, sea, yacht, characters)
// and a per-room light map; both are handed to the WebGL2 presenter.
import { makeCanvas, rng, clamp, mixHex, hexToRgb, shade, lerp } from './util.js';
import * as PX from './pixel.js';
import { YW, YH, WL, ROOMS, LEVELS, FIXTURES, ROOM_WINDOWS, SPEC, TENDER, roomTop, drawInterior, drawExterior, drawTender, drawLiferaft, drawLifeboat } from './yacht.js';
import { skyPalette } from './timesys.js';
import { BiomeRenderer, BIOMES } from './biomes.js';
import { sinkDraw, sinkDrawSea } from './sink.js';
import { Weather } from './weather.js';
import { Helm } from './helm.js';
import { Bus } from './util.js';

export const DECOR_TYPES = {
  plant: { th: 'ต้นไม้กระถาง', w: 10, h: 16 }, rug: { th: 'พรม', w: 30, h: 3 }, painting: { th: 'ภาพแขวนผนัง', w: 16, h: 12, wall: true },
  lantern: { th: 'ตะเกียง', w: 6, h: 10, light: true }, books: { th: 'ชั้นหนังสือ', w: 14, h: 18 }, cushion: { th: 'เบาะนั่ง', w: 12, h: 5 },
  surfboard: { th: 'กระดานโต้คลื่น', w: 6, h: 26 }, guitar: { th: 'กีตาร์', w: 8, h: 18 },
};
function drawDecorSprite(type, col = '#7fb7c9') {
  const d = DECOR_TYPES[type]; const [cv, c] = makeCanvas(d.w, d.h); const R = (x, y, w, h, k) => { c.fillStyle = k; c.fillRect(x, y, w, h); };
  if (type === 'plant') { R(2, 10, 6, 6, '#c98a5c'); R(2, 10, 6, 1, '#e0a878'); const g = ['#3f7a4f', '#5a9a5a', '#86b866']; for (let i = 0; i < 14; i++) R(1 + (i * 7) % 8, 1 + (i * 5) % 9, 2, 2, g[i % 3]); }
  if (type === 'rug') { R(0, 0, 30, 3, col); for (let x = 1; x < 30; x += 4) R(x, 1, 2, 1, shade(col, 0.4)); }
  if (type === 'painting') { R(0, 0, 16, 12, '#c9a964'); R(1, 1, 14, 10, '#cfe7f2'); R(1, 7, 14, 4, '#5aa0c0'); R(6, 3, 4, 4, '#f4e2a8'); R(3, 8, 3, 2, '#ffffff'); }
  if (type === 'lantern') { R(2, 0, 2, 2, '#38434A'); R(1, 2, 4, 6, '#ffe2a0'); R(1, 2, 4, 1, '#38434A'); R(1, 8, 4, 2, '#38434A'); }
  if (type === 'books') { R(0, 0, 14, 18, '#8a5a3c'); for (let s = 0; s < 3; s++) { R(1, 1 + s * 6, 12, 5, '#3a2c24'); for (let b = 0; b < 5; b++) R(2 + b * 2, 2 + s * 6, 1, 4, ['#d8463c', '#7fb7c9', '#e9c46a', '#a8cc6e', '#f4efe9'][(b + s) % 5]); } }
  if (type === 'cushion') { R(0, 1, 12, 4, col); R(1, 0, 10, 1, shade(col, 0.3)); R(0, 4, 12, 1, shade(col, -0.3)); }
  if (type === 'surfboard') { R(1, 0, 4, 26, '#f4efe9'); R(2, 2, 2, 22, col); R(0, 2, 1, 22, '#c0c6cc'); }
  if (type === 'guitar') { R(3, 0, 2, 9, '#5a4034'); R(1, 9, 6, 9, '#c98a5c'); R(3, 12, 2, 2, '#3a2c24'); }
  return cv;
}

export class Scene {
  constructor(presenter) {
    this.P = presenter;
    [this.cv, this.c] = makeCanvas(320, 180);
    [this.lcv, this.l] = makeCanvas(320, 180);
    [this.tmp, this.tc] = makeCanvas(64, 64);
    this.coastCache = new Map(); this.decorCache = new Map();
    this.shell = {}; for (const r of ROOMS) this.shell[r.id] = 1;
    this.foam = [];
    this.bio = new BiomeRenderer(this); this.bio.onRegion = (port, b) => Bus.emit('region', { port, biome: b });
  }
  async init(progress = () => { }) {
    const pals = [['#c9d8e6', '#e3edf5', '#f6f9fc', '#ffffff'], ['#d48a84', '#e8a89a', '#f4c4ae', '#fbe0c8'], ['#2a3858', '#3a4a6e', '#4c5e86', '#5e7098']];
    this.clouds = pals.map(p => Array.from({ length: 9 }, (_, i) => PX.cloud(100 + i * 17, 60 + (i % 3) * 30, 22 + (i % 2) * 10, p)));
    progress(0.4);
    this.streaks = pals.map(p => Array.from({ length: 4 }, (_, i) => PX.streakCloud(300 + i, 120 + i * 20, 6, p[2])));
    const R = rng(42); this.cloudPos = Array.from({ length: 14 }, (_, i) => ({ k: i % 9, x: R() * 1600, y: R(), sp: 0.5 + R() }));
    this.stars = Array.from({ length: 160 }, () => ({ x: R(), y: R() * 0.9, b: R(), tw: R() * 6 }));
    this.tender = drawTender(); this.raft = drawLiferaft(); this.lifeboatImg = drawLifeboat();
    progress(1);
  }
  setPaint(paint) {
    this.interior = drawInterior(paint); this.exterior = drawExterior(paint);
    // static silhouette mask (union of interior + exterior) for the ambient light pass
    const [m, mc] = makeCanvas(YW, YH); mc.drawImage(this.interior, 0, 0); mc.drawImage(this.exterior, 0, 0);
    this.mask = m; this.maskTint = null; this.maskTintKey = ''; this.glowKey = '';
    // collision alpha (ignore the thin deck surfaces so helicopters can sit on pads)
    const d = mc.getImageData(0, 0, YW, YH).data; this.maskW = YW; this.maskH = YH; this.maskA = new Uint8Array(YW * YH);
    for (let i = 0; i < this.maskA.length; i++) this.maskA[i] = d[i * 4 + 3] > 100 ? 1 : 0;
  }
  solid(x, y) { x = Math.round(x); y = Math.round(y); if (!this.maskA || x < 0 || y < 0 || x >= this.maskW || y >= this.maskH) return false; return this.maskA[y * this.maskW + x] === 1; }
  decorSprite(item) { const k = item.type + (item.color || ''); if (!this.decorCache.has(k)) this.decorCache.set(k, drawDecorSprite(item.type, item.color)); return this.decorCache.get(k); }
  // yacht transform (rotation about waterline centre + bob)
  yachtXform(g) {
    const amp = g.reduceMotion ? 0 : 1;
    const t = g.time;
    const bob = Math.round((Math.sin(t * 0.9) * 1.2 + Math.sin(t * 0.47) * 0.8) * amp * g.seaState);
    // no rotation normally (pixel art stays square); the hidden foundering scenario trims and sinks the hull
    const ang = g.sink ? g.sink.ang : 0, sinkDy = g.sink ? Math.round(g.sink.dy) : 0;
    return { bob: bob + sinkDy, seaBob: bob, ang, px: YW / 2, py: WL };
  }
  worldToScreen(g, x, y) {
    const X = this.yx, W = this.W, H = this.H;
    const dx = x - X.px, dy = y - X.py; const ca = Math.cos(X.ang), sa = Math.sin(X.ang);
    const wx = X.px + dx * ca - dy * sa, wy = X.py + dx * sa + dy * ca + X.bob;
    return [wx - g.cam.x + W / 2, wy - g.cam.y + H / 2];
  }
  screenToYacht(g, sx, sy) {
    const X = this.yx; if (!X) return [0, 0];
    const wx = sx - this.W / 2 + g.cam.x, wy = sy - this.H / 2 + g.cam.y - X.bob;
    const dx = wx - X.px, dy = wy - X.py; const ca = Math.cos(-X.ang), sa = Math.sin(-X.ang);
    return [X.px + dx * ca - dy * sa, X.py + dx * sa + dy * ca];
  }
  // W×H = view size in world pixels; R = canvas pixels per world pixel (hi-res when zoomed in so OCs keep their detail)
  resize(W, H, R = 1) {
    const cw = W * R, ch = H * R;
    if (this.cv.width !== cw || this.cv.height !== ch) {
      this.cv.width = cw; this.cv.height = ch; this.lcv.width = cw; this.lcv.height = ch;
    }
    this.c.imageSmoothingEnabled = false; this.l.imageSmoothingEnabled = false;
    this.W = W; this.H = H; this.R = R; this.c.__R = R; this.l.__R = R;
  }
  tinted(img, color, key) {
    if (this.tmp.width < img.width || this.tmp.height < img.height) { this.tmp.width = Math.max(this.tmp.width, img.width); this.tmp.height = Math.max(this.tmp.height, img.height); }
    const t = this.tc; t.globalCompositeOperation = 'source-over'; t.clearRect(0, 0, this.tmp.width, this.tmp.height);
    t.drawImage(img, 0, 0); t.globalCompositeOperation = 'source-in'; t.fillStyle = color; t.fillRect(0, 0, img.width, img.height); t.globalCompositeOperation = 'source-over';
    return this.tmp;
  }

  render(g, dt) {
    const c = this.c, l = this.l, W = this.W, H = this.H, t = g.time; const RS = this.R || 1;
    c.setTransform(RS, 0, 0, RS, 0, 0); l.setTransform(RS, 0, 0, RS, 0, 0);
    const env = g.env; const pal = skyPalette(env.sunElev); this.pal = pal;
    const wm = Weather.ambientMul(); const amb = pal.amb.map(v => clamp(v * wm, 0, 3)); const ambCss = `rgb(${amb.map(v => Math.round(v * 255 / 3) * 3).join(',')})`;
    this.yx = this.yachtXform(g);
    const camX = g.cam.x, camY = g.cam.y;
    const waterS = WL - camY + H / 2; // screen y of waterline
    const horizon = Math.round(H / 2 + (WL - 16 - camY) * 0.55);
    const q = g.quality; // 0 low 1 med 2 high

    /* ---------- sky ---------- */
    const sg = c.createLinearGradient(0, 0, 0, horizon);
    sg.addColorStop(0, pal.top); sg.addColorStop(1, pal.bot);
    c.fillStyle = sg; c.fillRect(0, 0, W, horizon + 1);
    // dithered banding look: subtle horizontal bands
    if (q > 0) { c.fillStyle = 'rgba(255,255,255,0.035)'; for (let y = 0; y < horizon; y += 8) c.fillRect(0, y, W, 2); }
    // stars
    if (pal.night > 0.02) {
      for (const s of this.stars) {
        const a = pal.night * (0.4 + 0.6 * Math.abs(Math.sin(t * 0.7 + s.tw))) * s.b; if (a < 0.08) continue;
        c.fillStyle = `rgba(255,250,230,${a.toFixed(2)})`; const x = ((s.x * W * 1.3 - camX * 0.02) % W + W) % W, y = s.y * horizon;
        c.fillRect(x | 0, y | 0, 1, 1); if (s.b > 0.93) { c.fillRect((x | 0) - 1, y | 0, 3, 1); c.fillRect(x | 0, (y | 0) - 1, 1, 3); }
      }
    }
    // sun / moon
    const view = (env.heading + 90) % 360; // looking at starboard side
    const bodyXY = (az, el) => { let rel = ((az - view + 540) % 360) - 180; return [W / 2 + rel / 80 * W * 0.55, horizon - (el / 55) * (horizon - 8)]; };
    if (env.sunElev > -4) { const [sx, sy] = bodyXY(env.sunAz, env.sunElev); this.disc(c, sx, sy, 6, env.sunElev < 8 ? '#ffd7a0' : '#fff6d8', env.sunElev < 8 ? '#ffb88a' : '#fffbe9'); this.sunX = sx; } else this.sunX = null;
    const moonEl = -env.sunElev * 0.8 + 10, moonAz = (env.sunAz + 180) % 360;
    if (pal.night > 0.1 && moonEl > -3) { const [mx, my] = bodyXY(moonAz, moonEl); this.disc(c, mx, my, 5, '#f2f0e6', '#ffffff'); c.fillStyle = mixHex(pal.top, pal.bot, 0.3); c.beginPath(); c.arc((mx | 0) + 3, (my | 0) - 1, 5, 0, 7); c.fill(); }
    // clouds (3 palettes crossfaded)
    const drawClouds = (setIdx, alpha) => {
      if (alpha <= 0.01) return; c.globalAlpha = alpha;
      for (const s of this.streaks[setIdx].map((im, i) => ({ im, i }))) { const x = ((s.i * 260 - camX * 0.05 - t * 1.5) % (W + 300) + W + 300) % (W + 300) - 150; c.drawImage(s.im, x | 0, (horizon * (0.12 + s.i * 0.08)) | 0); }
      for (const p of this.cloudPos) { const im = this.clouds[setIdx][p.k]; const span = W + 200; const x = ((p.x - camX * 0.12 - t * p.sp * 2 - env.scroll * 0.08) % span + span) % span - 100; const y = p.y * (horizon * 0.75) + 4; c.drawImage(im, x | 0, (y - im.height * 0.5) | 0); }
      c.globalAlpha = 1;
    };
    if (q > 0 || true) { drawClouds(pal.cloudA, 1 - pal.cloudT); if (pal.cloudB !== pal.cloudA) drawClouds(pal.cloudB, pal.cloudT); }
    Weather.drawSky(c, W, horizon, pal);

    /* ---------- light map base ---------- */
    l.globalCompositeOperation = 'source-over'; l.fillStyle = 'rgb(128,128,128)'; l.fillRect(0, 0, W, H);

    /* ---------- regional backdrop (biome) ---------- */
    const golden = clamp(1 - Math.abs(env.sunElev - 3) / 12, 0, 1);
    const bo = { W, H, horizon, camX, camY, waterS, t, dt: g.dt || 0.016, env, pal, ambCss, q, night: pal.night, golden, scroll: env.scroll };
    this.bio.update(g.dt || 0.016, env);
    this.bio.drawBack(c, l, bo);
    Weather.drawFog(c, W, H, horizon, pal);
    const tint = this.bio.waterTint(); const tk = tint.k * (1 - pal.night * 0.7);
    const seaC = mixHex(pal.sea, tint.color, tk * 0.6), seaDC = mixHex(pal.seaD, shade(tint.color, -0.35), tk * 0.45);
    const coast = env.coast;

    /* ---------- back sea ---------- */
    const seaTop = horizon;
    for (let y = seaTop; y < H; y += 2) {
      const d = clamp((y - seaTop) / Math.max(20, H - seaTop), 0, 1);
      c.fillStyle = mixHex(mixHex(pal.bot, seaC, 0.6), seaDC, Math.pow(d, 0.7)); c.fillRect(0, y, W, 2);
    }
    c.fillStyle = shade(seaC, 0.25); c.fillRect(0, seaTop, W, 1);
    // wave dashes
    const nRows = q === 0 ? 10 : q === 1 ? 18 : 28;
    const R = rng(9);
    for (let i = 0; i < nRows; i++) {
      const d = i / nRows; const y = Math.round(seaTop + 2 + Math.pow(d, 1.6) * (H - seaTop));
      const len = 3 + d * 14, gap = 20 + d * 40, spd = (4 + d * 14) + env.speed * 0.8 * (0.3 + d);
      const ofs = ((R() * 500 - (camX * (0.1 + d * 0.9)) - t * spd) % gap + gap) % gap;
      c.fillStyle = `rgba(255,255,255,${(0.10 + d * 0.22).toFixed(2)})`;
      for (let x = ofs - gap; x < W; x += gap) c.fillRect(x | 0, y, len | 0, 1);
      if (q > 0) { c.fillStyle = `rgba(0,30,60,${(0.06 + d * 0.08).toFixed(2)})`; for (let x = ofs - gap * 0.5; x < W; x += gap) c.fillRect(x | 0, y + 1, (len * 0.8) | 0, 1); }
    }
    // sun glitter column
    if (this.sunX != null && q > 0 && !g.noReflection) {
      const sx = this.sunX; const glow = env.sunElev < 10 ? '#ffd7a0' : '#fffbe9';
      for (let k = 0; k < 40; k++) { const y = seaTop + 2 + ((k * 37 + (t * 20 | 0)) % Math.max(1, (H - seaTop))); const spread = 4 + (y - seaTop) * 0.25; const x = sx + Math.sin(k * 12.9 + t * 3) * spread; if ((k + (t * 6 | 0)) % 3 === 0) { c.fillStyle = glow; c.fillRect(x | 0, y | 0, 2, 1); } }
    }
    this.bio.drawSea(c, l, bo);
    // marina pier behind yacht
    if (coast?.docked) {
      const pier = this.bio.pier(coast.port); const off = ((-camX * 0.5) % pier.width + pier.width) % pier.width - pier.width;
      for (let x = off; x < W; x += pier.width) c.drawImage(pier, x | 0, Math.round(waterS - 34 - (WL - camY) * 0 - 6));
      const ti = this.tinted(pier, ambCss); for (let x = off; x < W; x += pier.width) l.drawImage(ti, 0, 0, pier.width, pier.height, x | 0, Math.round(waterS - 40));
    }

    /* ---------- yacht ---------- */
    const X = this.yx;
    const setYT = ctx => { ctx.setTransform(RS, 0, 0, RS, 0, 0); ctx.translate(Math.round(W / 2 - camX), Math.round(H / 2 - camY + X.bob)); ctx.translate(X.px, X.py); ctx.rotate(X.ang); ctx.translate(-X.px, -X.py); };
    setYT(c); setYT(l);
    // things floating on the sea (tender under way, swimmers, the shark) never tilt or sink with the hull
    const setST = ctx => { ctx.setTransform(RS, 0, 0, RS, 0, 0); ctx.translate(Math.round(W / 2 - camX), Math.round(H / 2 - camY + X.seaBob)); };
    this.setST = setST; this.setYT = setYT;
    const afloat = !['stowed', 'opening', 'sliding', 'returning', 'closing'].includes(g.tender.state);
    // reflection (simple flipped, faint)
    if (!g.noReflection && q > 1) { c.save(); c.globalAlpha = 0.12; c.translate(0, WL * 2 + 6); c.scale(1, -1); c.drawImage(this.exterior, 0, 0, YW, WL - 100, 0, 0, YW, WL - 100); c.restore(); }
    // cabin windows are real holes in the interior wall: the live backdrop drawn behind the yacht (sky, clouds,
    // the region's coastline, passing boats, the sea) shows straight through them
    c.drawImage(this.interior, 0, 0);
    // dynamic interior: screens & lamps
    this.drawDynamicInterior(c, g);
    // decor
    for (const d of g.decor) { if (!LEVELS[d.level]) continue; const im = this.decorSprite(d); const fy = LEVELS[d.level].y; const dt2 = DECOR_TYPES[d.type]; const y = dt2.wall ? fy - 30 : fy - im.height - (d.type === 'rug' ? 0 : 1); c.drawImage(im, Math.round(d.x - im.width / 2), Math.round(y)); }
    // tender in its garage + liferaft ride with the hull
    if (!afloat) this.drawTenderAndRaft(c, g); else this.drawRaft(c, g);
    // characters
    g.drawCharacters(c, l, this, ambCss);
    // flood water inside the rooms (hidden scenario)
    sinkDraw(c);
    // exterior shell with per-room fade
    this.drawShell(c, g);
    g.drawAfterShell?.(c, l, this, ambCss);
    // tender under way: in front of the hull, on the sea's own (level) frame
    if (afloat) { setST(c); setST(l); this.drawTenderAndRaft(c, g, true); l.drawImage(this.tinted(this.tender.front, ambCss), Math.round(g.tender.x - TENDER.ax), Math.round(g.tender.y - TENDER.ay)); setYT(c); setYT(l); }
    // hover highlight
    if (g.hoverObj) { const [x, y, w, h] = g.hoverObj.rect; c.strokeStyle = 'rgba(255,255,255,0.9)'; c.lineWidth = 1; c.setLineDash([2, 2]); c.strokeRect(x + 0.5, y + 0.5, w, h); c.setLineDash([]); }
    if (g.dropPreview) { const p = g.dropPreview; c.fillStyle = p.ok ? 'rgba(120,220,160,0.6)' : 'rgba(230,90,70,0.6)'; c.fillRect(p.x - 6, LEVELS[p.level].y - 2, 12, 2); }
    if (g.walkMarker && g.walkMarker.t > 0) { const m = g.walkMarker; c.fillStyle = `rgba(255,255,255,${m.t.toFixed(2)})`; c.fillRect(m.x - 3, LEVELS[m.level].y - 1, 7, 1); c.fillRect(m.x, LEVELS[m.level].y - 4, 1, 3); }

    // light pass (yacht space)
    this.lightPass(l, g, amb, ambCss, pal);
    c.setTransform(RS, 0, 0, RS, 0, 0); l.setTransform(RS, 0, 0, RS, 0, 0);

    /* ---------- front water ---------- */
    this.frontWater(c, g, pal, waterS, camX, W, H, X);
    if (g.drawUnderwater) { setST(c); sinkDrawSea(c); g.drawUnderwater(c); c.setTransform(RS, 0, 0, RS, 0, 0); }
    this.bio.drawFront(c, l, bo);
    c.setTransform(RS, 0, 0, RS, 0, 0); Weather.drawFront(c, W, H, horizon, waterS, pal);
  }

  disc(c, x, y, r, col, core) {
    x |= 0; y |= 0; c.fillStyle = col; c.globalAlpha = 0.25; c.beginPath(); c.arc(x, y, r + 4, 0, 7); c.fill(); c.globalAlpha = 1;
    for (let dy = -r; dy <= r; dy++) { const w = Math.round(Math.sqrt(r * r - dy * dy)); c.fillRect(x - w, y + dy, w * 2 + 1, 1); }
    c.fillStyle = core; c.fillRect(x - 2, y - 2, 3, 3);
  }

  drawDynamicInterior(c, g) {
    const t = g.time;
    // wheelhouse: live helm console (wheel, telegraphs, displays)
    for (const r of ROOMS) if (r.kind === 'wheelhouse') Helm.drawConsole(c, r, LEVELS[r.level].y, t);
    // lamps on/off
    for (const f of FIXTURES) {
      if (f.kind === 'nav') continue;
      const on = g.lights[f.id];
      if (f.kind === 'ceiling') { c.fillStyle = on ? '#fff1c4' : '#cfc6b4'; c.fillRect(f.x - 4, f.y - 2, 9, 1); }
      if (f.kind === 'lamp' || f.kind === 'bedside') { c.fillStyle = on ? '#ffe8a8' : '#e6dcc6'; c.fillRect(f.x - 2, f.y, 5, 3); }
    }
    // switches
    for (const r of ROOMS) if (r.type === 'in' && !r.stair) { const on = g.lights[r.id + ':ceiling']; const y = LEVELS[r.level].y - 24; c.fillStyle = '#e9e6e0'; c.fillRect(r.x1 + 4, y, 4, 6); c.fillStyle = on ? '#5ac46e' : '#9aa4ac'; c.fillRect(r.x1 + 5, y + (on ? 1 : 3), 2, 2); }
    // garage door state
    const td = g.tender, T = SPEC.tender; c.fillStyle = '#d6dbdf'; c.fillRect(T.doorX - 4, T.doorTop + 2, 3, Math.round((T.floorY - T.doorTop - 4) * (1 - td.door)));
  }

  drawRaft(c, g) { const lr = g.liferaft; if (lr.state !== 'stowed' && lr.state !== 'none') { const s = lr.t; c.save(); c.translate(Math.round(lr.x), Math.round(lr.y)); c.scale(Math.max(0.2, s), Math.max(0.2, s)); c.drawImage(this.raft, -20, -16); c.restore(); } }
  drawTenderAndRaft(c, g, onlyTender = false) {
    const td = g.tender, T = TENDER, ox = Math.round(td.x - T.ax), oy = Math.round(td.y - T.ay + (td.hop || 0));
    // driving: bow lifts when planing; the boat turns to face where it's going
    c.save(); const flip = (td.face || 1) < 0; c.translate(td.x, oy + T.ay); c.rotate((td.pitch || 0) * (flip ? -1 : 1)); if (flip) c.scale(-1, 1); c.translate(-td.x, -(oy + T.ay));
    // cabin interior → passengers seated inside → hull & glass (see-through when someone is aboard)
    const crew = [td.rider, ...(td.pax || [])].map(id => g.chars.find(k => k.id === id)).filter(Boolean);
    c.drawImage(this.tender.back, ox, oy);
    crew.forEach((ch, i) => {
      const sx = i === 0 && td.rider ? T.helm : (i - (td.rider ? 1 : 0)) < T.seats.length ? T.seats[i - (td.rider ? 1 : 0)] : T.deck[(i - (td.rider ? 1 : 0) - T.seats.length) % T.deck.length];
      const st = ch.state, sh = ch.seatH, fc = ch.facing, bub = ch.bubble; ch.state = 'sit'; ch.seatH = 3; ch.facing = 1;
      g.drawCharAt(c, ch, ox + sx, oy + T.floor); ch.state = st; ch.seatH = sh; ch.facing = fc; ch.bubble = bub;
    });
    c.drawImage(crew.length ? this.tender.clear : this.tender.front, ox, oy);
    c.restore();
    if (!onlyTender) this.drawRaft(c, g);
  }

  drawShell(c, g) {
    // Opaque everywhere except rooms that are being "looked into"; those get faded front walls.
    const faded = ROOMS.filter(r => r.type === 'in' && this.shell[r.id] < 0.99);
    c.save();
    if (faded.length) { c.beginPath(); c.rect(-10, -10, YW + 20, YH + 20); for (const r of faded) c.rect(r.x1 + 1, roomTop(r), r.x2 - r.x1 - 2, 40); c.clip('evenodd'); }
    c.drawImage(this.exterior, 0, 0); c.restore();
    for (const r of faded) {
      const a = this.shell[r.id]; const x = r.x1 + 1, y = roomTop(r), w = r.x2 - r.x1 - 2;
      c.globalAlpha = a; c.drawImage(this.exterior, x, y, w, 40, x, y, w, 40); c.globalAlpha = 1;
      // cutaway edge frame so the open room still reads as part of the hull
      c.fillStyle = 'rgba(40,46,52,0.55)'; c.fillRect(x, y, w, 1); c.fillRect(x, y + 39, w, 1);
    }
    // glowing windows at night for lit rooms
    const night = this.pal.night + clamp((8 - g.env.sunElev) / 16, 0, 0.6) * 0.5;
    for (const [rid, wins] of Object.entries(ROOM_WINDOWS)) {
      const lit = Math.max(this.roomLampLevel(g, rid), night > 0.6 ? 0.07 : 0); if (lit <= 0) continue; const a = this.shell[rid] ?? 1; // dim standby glow even with lamps off
      c.globalAlpha = clamp(a * night * 1.2 * Math.min(1, lit * 2.5), 0, 0.95); c.fillStyle = '#ffd89a';
      for (const [x, y, w, h] of wins) c.fillRect(x, y, w, h); c.globalAlpha = 1;
    }
    // nav lights
    if (g.lights.nav) for (const [x, y, k] of SPEC.nav) { c.fillStyle = k === 'g' ? '#5ce07a' : k === 'r' ? '#ff6a5a' : '#ffffff'; c.fillRect(x, y, 2, 2); }
  }
  roomLampLevel(g, rid) {
    let s = 0; for (const f of FIXTURES) if (f.room === rid && g.lights[f.id] && f.kind !== 'nav') s += f.kind === 'ceiling' ? 0.26 : f.kind === 'lamp' ? 0.14 : f.kind === 'bedside' ? 0.1 : 0.08;
    return s;
  }
  roomLight(g, r, amb) {
    // daylight through windows + fixtures; upper decks get more sky, lower deck is shaded by the hull
    const env = g.env; const view = (env.heading + 90) % 360; const rel = Math.cos(((env.sunAz - view) * Math.PI) / 180);
    const sunSide = env.sunElev > 0 ? 1 + 0.18 * rel : 1;
    const deck = r.level === 'D0' ? 0.85 : r.level === 'D2' ? 1.08 : 1;
    const day = (0.22 + 0.7 * (r.win ?? 0.3)) * sunSide * deck;
    const lamp = this.roomLampLevel(g, r.id);
    const warm = [1, 0.86, 0.62];
    // after dark the cabins never go pitch black: courtesy / standby lighting keeps a dim warm glow
    const dark = clamp((-env.sunElev - 2) / 12, 0, 1); const glow = dark * (r.kind === 'engine' || r.kind === 'utility' ? 0.16 : 0.24);
    const dim = [0.95, 0.82, 0.62];
    return amb.map((v, k) => clamp(Math.max(v * day, glow * dim[k]) + lamp * warm[k], 0, 0.72));
  }
  lightPass(l, g, amb, ambCss, pal) {
    // ambient on all yacht pixels
    const key = ambCss;
    if (this.maskTintKey !== key) { const [m, mc] = makeCanvas(YW, YH); mc.drawImage(this.mask, 0, 0); mc.globalCompositeOperation = 'source-in'; mc.fillStyle = ambCss; mc.fillRect(0, 0, YW, YH); this.maskTint = m; this.maskTintKey = key; }
    l.drawImage(this.maskTint, 0, 0);
    // tender / raft silhouettes
    const td = g.tender; if (['stowed', 'opening', 'sliding', 'returning', 'closing'].includes(td.state)) l.drawImage(this.tinted(this.tender.front, ambCss), Math.round(td.x - TENDER.ax), Math.round(td.y - TENDER.ay));
    // rooms
    for (const r of ROOMS) {
      if (r.type !== 'in') continue;
      const a = this.shell[r.id]; const L = this.roomLight(g, r, amb);
      const col = amb.map((v, k) => lerp(L[k], v, a));
      l.fillStyle = `rgb(${col.map(v => Math.round(v * 255)).join(',')})`;
      l.fillRect(r.x1 + 1, roomTop(r), r.x2 - r.x1 - 2, 40);
    }
    // what you see through a window is lit by the outdoors, not by the cabin lamps
    l.fillStyle = ambCss; for (const ws of Object.values(ROOM_WINDOWS)) for (const [x, y, w, h] of ws) l.fillRect(x, y, w, h);
    // emissive windows
    const night = pal.night + clamp((8 - g.env.sunElev) / 16, 0, 0.6) * 0.5;
    for (const [rid, wins] of Object.entries(ROOM_WINDOWS)) { const lit = this.roomLampLevel(g, rid); if (night < 0.05) continue; const k = lit > 0 ? 1 : (night > 0.6 ? 0.35 : 0); if (!k) continue; l.fillStyle = `rgba(200,185,150,${clamp((this.shell[rid] ?? 1) * night * k, 0, 1).toFixed(2)})`; for (const [x, y, w, h] of wins) l.fillRect(x, y, w, h); }
    // lamp pools (additive) — rendered into a scratch layer and masked to yacht pixels so light never spills onto the sky
    if (!this.glow || this.glow.width !== YW || this.glow.height !== YH) { [this.glow, this.gc] = makeCanvas(YW, YH); this.glowKey = ''; }
    const gk = FIXTURES.map(f => g.lights[f.id] ? 1 : 0).join('') + ROOMS.map(r => Math.round((this.shell[r.id] ?? 1) * 10)).join('') + Math.round(pal.night * 20) + YW;
    let anyGlow = this.glowAny || false;
    if (gk !== this.glowKey) {
    this.glowKey = gk;
    const gc = this.gc; gc.globalCompositeOperation = 'source-over'; gc.clearRect(0, 0, YW, YH); gc.globalCompositeOperation = 'lighter';
    anyGlow = false;
    for (const f of FIXTURES) {
      if (!g.lights[f.id] || f.kind === 'nav') continue; const room = ROOMS.find(r => r.id === f.room); if (!room) continue;
      const vis = room.type === 'out' ? 1 : (1 - this.shell[room.id]);
      const strength = (f.kind === 'deck' ? 0.4 : 0.22) * vis * (room.type === 'out' ? clamp(pal.night * 1.3 + 0.1, 0, 1) : 1);
      if (strength < 0.02) continue; anyGlow = true;
      const gr = gc.createRadialGradient(f.x, f.y, 1, f.x, f.y, f.radius);
      gr.addColorStop(0, `rgba(${Math.round(120 * strength)},${Math.round(100 * strength)},${Math.round(60 * strength)},1)`); gr.addColorStop(1, 'rgba(0,0,0,1)');
      gc.fillStyle = gr; gc.fillRect(f.x - f.radius, f.y - f.radius, f.radius * 2, f.radius * 2);
    }
    if (anyGlow) { gc.globalCompositeOperation = 'destination-in'; gc.drawImage(this.mask, 0, 0); gc.globalCompositeOperation = 'source-over'; }
    this.glowAny = anyGlow;
    }
    if (anyGlow) { l.globalCompositeOperation = 'lighter'; l.drawImage(this.glow, 0, 0); }
    l.globalCompositeOperation = 'lighter';
    if (g.lights.nav && pal.night > 0.2) { l.fillStyle = 'rgb(140,140,140)'; for (const [x, y] of SPEC.nav) l.fillRect(x - 2, y - 2, 6, 6); }
    l.globalCompositeOperation = 'source-over';
  }

  frontWater(c, g, pal, waterS, camX, W, H, X) {
    const t = g.time, q = g.quality;
    const seaCol = mixHex(pal.sea, pal.seaD, 0.35);
    const amp = g.reduceMotion ? 0.5 : 1.4 * g.seaState;
    const hullL = Math.round(SPEC.hullX1 - camX + W / 2), hullR = Math.round(SPEC.hullX2 - camX + W / 2);
    const step = q === 0 ? 3 : q === 1 ? 2 : 1;
    const rgb = hexToRgb(seaCol);
    for (let x = 0; x < W; x += step) {
      const wx = x + camX; const h = Math.sin(wx * 0.09 + t * 1.6) * amp + Math.sin(wx * 0.033 - t * 0.9) * amp * 0.8 + (q > 1 ? Math.sin(wx * 0.21 + t * 2.7) * 0.4 : 0);
      const inHull = x >= hullL && x <= hullR;
      const top = Math.round(waterS + h + (inHull ? 9 : 0) + X.bob * 0);
      c.fillStyle = `rgba(${rgb[0]},${rgb[1]},${rgb[2]},0.93)`; c.fillRect(x, top, step, H - top);
      c.fillStyle = 'rgba(255,255,255,0.55)'; c.fillRect(x, top, step, 1);
      if (inHull) { c.fillStyle = 'rgba(255,255,255,0.35)'; c.fillRect(x, Math.round(waterS + h * 0.6) + 1, step, 1); }
    }
    // wake & bow wave & ripples
    const sp = g.env.speed;
    if (sp > 0.5 || g.tender.state === 'cruise') {
      if (this.foam.length < (q === 0 ? 40 : 120)) for (let i = 0; i < Math.min(6, sp * 0.5 + 1); i++) {
        this.foam.push({ x: SPEC.hullX1 - 12 + Math.random() * 6, y: WL + Math.random() * 10, vx: -(8 + sp * 3) * (0.5 + Math.random()), life: 1 + Math.random() * 1.5 });
        if (sp > 0.5 && Math.random() < 0.6) this.foam.push({ x: SPEC.hullX2 + 2, y: WL + Math.random() * 4, vx: -(2 + Math.random() * 4), life: 0.6 + Math.random() });
      }
    }
    c.fillStyle = '#ffffff';
    const dt = g.dt;
    this.foam = this.foam.filter(f => (f.life -= dt) > 0);
    for (const f of this.foam) { f.x += f.vx * dt; const s = [f.x - camX + W / 2, f.y - g.cam.y + H / 2]; c.globalAlpha = clamp(f.life, 0, 1) * 0.8; c.fillRect(s[0] | 0, s[1] | 0, 2, 1); }
    c.globalAlpha = 1;
    // gentle ripples around hull when idle
    if (sp < 0.5 && q > 0) { c.fillStyle = 'rgba(255,255,255,0.4)'; for (let k = 0; k < 6; k++) { const x = (k * 113 + t * 6) % 700; const s = x - camX + W / 2; c.fillRect(s | 0, (waterS + 4 + (k % 3) * 2) | 0, 4 + (k % 2) * 3, 1); } }
  }
}
function smoothstep(x) { x = clamp(x, 0, 1); return x * x * (3 - 2 * x); }
