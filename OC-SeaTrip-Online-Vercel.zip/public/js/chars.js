// OC characters: sprite processing, floor/stair pathfinding, interaction state machine, Utility-AI bots.
import { makeCanvas, clamp, loadImage, rand, Bus } from './util.js';
import { lineFor, personaOf } from './persona.js';
import { LEVELS, STAIRS, OBJECTS, ROOMS, roomAt, roomById, FIXTURES, SPEC } from './yacht.js';
export const SIT_KINDS = ['sofa', 'dining', 'lounger', 'bar', 'cinema', 'desk'];

export const SPRITE_PRESETS = {
  standard: { th: 'Standard OC (9:16)', ar: 9 / 16, h: 34 },
  chibi: { th: 'Chibi OC (3:4)', ar: 3 / 4, h: 28 },
  tiny: { th: 'Tiny OC (1:1)', ar: 1, h: 20 },
  custom: { th: 'Custom OC', ar: null, h: 32 },
};
// character height standard: 20 px ≈ 1 m. Rooms are 40 px tall, so 38 px (≈1.90 m) is the ceiling-safe maximum.
export const PX_PER_M = 20, CHAR_MIN = 16, CHAR_MAX = 38, CHAR_MAX_W = 46, CHAR_STD = 34;
export const HEIGHT_PRESETS = [
  { id: 'tiny', th: 'ตัวจิ๋ว / สัตว์เลี้ยง', px: 16 }, { id: 'chibi', th: 'จิบิ', px: 22 }, { id: 'child', th: 'เด็ก', px: 25 },
  { id: 'teen', th: 'วัยรุ่น', px: 31 }, { id: 'adult', th: 'ผู้ใหญ่ (มาตรฐาน)', px: 34 }, { id: 'tall', th: 'สูง', px: 37 },
];
export const pxToM = px => (px / PX_PER_M).toFixed(2);
// top edge of the lying body for every column of the (head-left) lying sprite, cached on the canvas
function lieProfile(L) {
  if (L.__prof) return L.__prof; const w = L.width, h = L.height; let d;
  try { d = L.getContext('2d').getImageData(0, 0, w, h).data; } catch { return null; }
  const top = new Int16Array(w).fill(-1);
  for (let x = 0; x < w; x++) for (let y = 0; y < h; y++) if (d[(y * w + x) * 4 + 3] > 40) { top[x] = y; break; }
  return (L.__prof = top);
}
// where the head ends on a head-left lying sprite: the thinnest column (the neck) in the middle third
function chinOf(L) {
  if (L.__chin != null) return L.__chin; const top = lieProfile(L), w = L.width; let d; try { d = L.getContext('2d').getImageData(0, 0, w, L.height).data; } catch { return (L.__chin = Math.round(w * 0.45)); }
  let best = Math.round(w * 0.45), bt = 1e9;
  for (let x = Math.round(w * 0.3); x <= Math.round(w * 0.6); x++) { let n = 0; for (let y = 0; y < L.height; y++) if (d[(y * w + x) * 4 + 3] > 40) n++; if (n > 0 && n < bt) { bt = n; best = x; } }
  return (L.__chin = best);
}
const BLANKET = { crew: ['#4f6478', '#6f87a0', '#36465a', '#dfe4ea'], guest: ['#8fb9cc', '#bcd9e6', '#6a95aa', '#f6f3ec'], def: ['#e4d8c4', '#fbf6ec', '#c2b39b', '#ffffff'] };
// body shape under the duvet, along its length (0 = chin, 1 = toes): shoulders, chest, waist, hips, legs, feet
const MOUND = [[0, 0.55], [0.08, 0.95], [0.22, 1], [0.4, 0.82], [0.55, 0.9], [0.7, 0.66], [0.86, 0.62], [0.93, 0.78], [1, 0.35]];
const moundAt = t => { for (let i = 0; i < MOUND.length - 1; i++) { const [a, ha] = MOUND[i], [b, hb] = MOUND[i + 1]; if (t <= b) { const u = (t - a) / (b - a), s = (1 - Math.cos(u * Math.PI)) / 2; return ha + (hb - ha) * s; } } return 0.35; };
// a soft duvet over the sleeper: rounded body mound (no box), turned-down cuff under the chin, creases,
// falls over the mattress edge and rolls down at the foot end with rounded corners.
function drawBlanket(c, ch, bounds, flip, L) {
  const prof = lieProfile(L); if (!prof) return;
  const [bx, by, w] = bounds, bedTop = ch.bedY, hang = 5, chin = chinOf(L);
  const kind = roomAt(ch.level, ch.x)?.kind; const [base, hi, dark, cuff] = BLANKET[kind === 'crew' ? 'crew' : kind === 'guest' || kind === 'vip' ? 'guest' : 'def'];
  let headTop = 1e9; for (let x = 0; x < chin; x++) if (prof[x] >= 0) headTop = Math.min(headTop, by + prof[x]);
  const H = clamp(Math.round((bedTop - headTop) * 0.5), 5, 12);                 // body thickness under the duvet
  // the duvet reaches the foot of the mattress (or, in a shared bed, up to the next sleeper's space)
  const o = ch.slot && OBJECTS.find(q => q.id === ch.slot.obj); let reach = w + 2;
  if (o?.rect) { const [ox, , ow] = o.rect, dir = flip ? -1 : 1, headX = flip ? bx + w - 1 : bx;
    const shared = (PARTY?.occupants(o) || []).filter(id => id && id !== ch.id).length > 0;
    const end = shared ? ch.x + dir * (ow * 0.33 - 3) : (dir > 0 ? ox + ow - 4 : ox + 2);
    reach = Math.max(w + 2, Math.round(Math.abs(end - headX))); }
  const bodyN = w + 2 - (chin - 1), s = chin - 1, e = s + Math.max(bodyN, reach - (chin - 1)), n = e - s + 1, X = lx => flip ? bx + (w - 1 - lx) : bx + lx;
  for (let i = 0; i < n; i++) {
    const lx = s + i, x = X(lx), t = Math.min(1, i / (bodyN - 1));
    let top = i < bodyN ? Math.round(bedTop - 1 - H * moundAt(t)) : Math.round(bedTop - 1 - H * 0.3); // body mound, then the empty duvet lying flat
    const fromEnd = Math.min(i, n - 1 - i);
    if (i >= n - 3) top = Math.max(top, bedTop - 1 + (i - (n - 3)) * 2);       // rolls over the foot end
    const bottom = bedTop + hang - (fromEnd === 0 ? 3 : fromEnd === 1 ? 1 : 0) + ((lx >> 2) % 3 === 0 && fromEnd > 1 ? 1 : 0);
    if (bottom <= top) continue;
    c.fillStyle = base; c.fillRect(x, top, 1, bottom - top);
    c.fillStyle = hi; c.fillRect(x, top, 1, Math.min(2, bottom - top));          // light on the top of the mound
    c.fillStyle = dark; c.fillRect(x, bedTop, 1, 1);                             // where it bends over the mattress edge
    if (bottom - top > 3) c.fillRect(x, bottom - 1, 1, 1);                       // hem
    if (i > 4 && i < n - 4 && (lx + 2) % 8 === 0) c.fillRect(x, top + 2, 1, Math.max(1, bedTop - top - 3)); // soft creases
    if (i < 3) { c.fillStyle = i === 2 ? dark : cuff; c.fillRect(x, top, 1, Math.min(bedTop - top + 1, 5)); } // turned-down sheet
  }
  c.fillStyle = 'rgba(0,0,0,0.16)'; for (let i = 2; i < n - 2; i++) c.fillRect(X(s + i), bedTop + hang + 1, 1, 1); // shadow on the mattress side
}
export const ANIMS = ['idle', 'walk', 'sit', 'lie', 'sleep', 'look', 'interact'];
export const ANIM_TH = { idle: 'ยืน (Idle)', walk: 'เดิน (Walking)', sit: 'นั่ง (Sitting)', lie: 'นอนเล่น (Lying)', sleep: 'หลับ (Sleeping)', look: 'มองวิว (Looking)', interact: 'ใช้งาน (Interacting)' };
export const PREFS = { view: 'ชมวิวทะเล', relax: 'นั่งพักผ่อน', talk: 'พูดคุย', cook: 'ทำอาหาร', explore: 'สำรวจเรือ' };

export function defaultTransform() {
  return { scale: 1, width: 0, height: 0, lockAspect: true, rotation: 0, flip: false, groundOffset: 0, autoGround: true, colW: 10, colH: 30, speed: 1, pivotX: 0.5, pivotY: 1, z: 0 };
}

// lowest opaque row of an image region (for auto ground alignment)
function bottomOpaqueRow(img, sx = 0, sy = 0, sw = img.width, sh = img.height) {
  const [cv, c] = makeCanvas(sw, sh); c.drawImage(img, sx, sy, sw, sh, 0, 0, sw, sh);
  const d = c.getImageData(0, 0, sw, sh).data;
  for (let y = sh - 1; y >= 0; y--) for (let x = 0; x < sw; x++) if (d[(y * sw + x) * 4 + 3] > 40) return y;
  return sh - 1;
}
function downscale(img, sx, sy, sw, sh, w, h, rot, flip) {
  // stepwise high-quality downscale for clean pixel results; enlarging (hi-res zoom beyond the source) uses nearest-neighbour
  let src = img, cw = sw, ch = sh, ox = sx, oy = sy;
  if (w >= sw && h >= sh && !rot) {
    const [out, oc] = makeCanvas(w, h); oc.imageSmoothingEnabled = false;
    if (flip) { oc.translate(w, 0); oc.scale(-1, 1); } oc.drawImage(img, sx, sy, sw, sh, 0, 0, w, h);
    return { cv: out, pad: 0 };
  }
  while (cw / 2 > w * 1.5 && ch / 2 > h * 1.5) {
    const [t, tc] = makeCanvas(Math.round(cw / 2), Math.round(ch / 2)); tc.imageSmoothingEnabled = true; tc.imageSmoothingQuality = 'high';
    tc.drawImage(src, ox, oy, cw, ch, 0, 0, t.width, t.height); src = t; cw = t.width; ch = t.height; ox = 0; oy = 0;
  }
  const pad = rot ? Math.ceil(Math.max(w, h) * 0.3) : 0;
  const [out, oc] = makeCanvas(w + pad * 2, h + pad * 2); oc.imageSmoothingEnabled = true; oc.imageSmoothingQuality = 'high';
  oc.translate(out.width / 2, out.height / 2); if (rot) oc.rotate(rot * Math.PI / 180); if (flip) oc.scale(-1, 1);
  oc.drawImage(src, ox, oy, cw, ch, -w / 2, -h / 2, w, h);
  // harden alpha for crisp pixel edges
  const id = oc.getImageData(0, 0, out.width, out.height), d = id.data; for (let i = 3; i < d.length; i += 4) d[i] = d[i] > 110 ? 255 : 0;
  oc.setTransform(1, 0, 0, 1, 0, 0); oc.putImageData(id, 0, 0);
  return { cv: out, pad };
}

function opaqueBox(img, cells) {
  // union of opaque bounds across all frame cells, relative to a cell
  const [cv, cx] = makeCanvas(img.width, img.height); cx.drawImage(img, 0, 0); const d = cx.getImageData(0, 0, img.width, img.height).data;
  let x1 = 1e9, y1 = 1e9, x2 = -1, y2 = -1;
  for (const [sx, sy, fw, fh] of cells) for (let y = 0; y < fh; y++) for (let x = 0; x < fw; x++) if (d[((sy + y) * img.width + sx + x) * 4 + 3] > 40) { if (x < x1) x1 = x; if (x > x2) x2 = x; if (y < y1) y1 = y; if (y > y2) y2 = y; }
  return x2 < 0 ? null : { x: x1, y: y1, w: x2 - x1 + 1, h: y2 - y1 + 1 };
}
// final in-game size: standard-height based, clamped so OCs never exceed the cabin ceiling or get absurdly wide
export function charSize(tf, presetH, bw, bh) {
  const want = Math.round((tf.height || presetH) * (tf.scale || 1));
  let h = clamp(want, CHAR_MIN, CHAR_MAX), w;
  if (tf.width && !tf.lockAspect) w = clamp(Math.round(tf.width * (tf.scale || 1)), 6, CHAR_MAX_W);
  else { w = Math.max(4, Math.round(h * bw / bh)); if (w > CHAR_MAX_W) { w = CHAR_MAX_W; h = clamp(Math.round(w * bh / bw), 8, CHAR_MAX); } }
  return { w, h, want, clamped: want !== h };
}
export async function buildSprites(oc) {
  const img = await loadImage(oc.image);
  const tf = Object.assign(defaultTransform(), oc.transform || {});
  const preset = SPRITE_PRESETS[oc.preset] || SPRITE_PRESETS.standard;
  const sheet = oc.sheet && oc.sheet.cols > 0 && oc.sheet.rows > 0 ? oc.sheet : null;
  const cw = sheet ? Math.floor(img.width / sheet.cols) : img.width, ch = sheet ? Math.floor(img.height / sheet.rows) : img.height;
  const cells = []; const nCells = sheet ? sheet.cols * sheet.rows : 1;
  for (let i = 0; i < nCells; i++) cells.push([sheet ? (i % sheet.cols) * cw : 0, sheet ? Math.floor(i / sheet.cols) * ch : 0, cw, ch]);
  // trim transparent padding so the height standard measures the character itself, not the empty canvas
  const bb = opaqueBox(img, cells) || { x: 0, y: 0, w: cw, h: ch };
  const fw = bb.w, fh = bb.h;
  const size = charSize(tf, preset.h, fw, fh); const w = size.w, h = size.h;
  const frames = [];
  const n = sheet ? sheet.cols * sheet.rows : 1;
  let ground = 0;
  for (let i = 0; i < n; i++) {
    const sx = cells[i][0] + bb.x, sy = cells[i][1] + bb.y;
    const { cv, pad } = downscale(img, sx, sy, fw, fh, w, h, tf.rotation, tf.flip); cv.__cell = [sx, sy];
    if (i === 0) { const b = tf.autoGround ? bottomOpaqueRow(cv) : (h + pad - 1); ground = (cv.height - 1 - b); }
    frames.push(cv);
  }
  const anims = {};
  for (const a of ANIMS) {
    const r = sheet?.anims?.[a];
    anims[a] = r && r.length === 2 ? frames.slice(clamp(r[0], 0, n - 1), clamp(r[1], 0, n - 1) + 1) : [frames[0]];
    if (!anims[a].length) anims[a] = [frames[0]];
  }
  // lying pose: built once from the source image at 70% and turned exactly 90° (no runtime scaling → no broken pixels)
  const ld = downscale(img, cells[0][0] + bb.x, cells[0][1] + bb.y, fw, fh, Math.max(4, Math.round(w * 0.7)), Math.max(6, Math.round(h * 0.7)), 0, tf.flip).cv;
  const [lie, lc] = makeCanvas(ld.height, ld.width); lc.translate(0, ld.width); lc.rotate(-Math.PI / 2); lc.drawImage(ld, 0, 0);
  return { frames, anims, lie, w: frames[0].width, h: frames[0].height, ground: ground - (tf.groundOffset || 0), fps: sheet?.fps || 6, multi: !!sheet, size, src: img, fw, fh, tf, lieCell: [cells[0][0] + bb.x, cells[0][1] + bb.y], hi: {} };
}
// hi-resolution copy of a sprite frame for zoomed-in rendering: rebuilt from the original image at R× the in-game size,
// so the OC keeps its real detail instead of showing enlarged 34-px blocks. Same footprint, same pivot → no distortion.
const HI_SRC_MAX = 4; // never enlarge a source more than 4× (beyond that it is pure pixel duplication anyway)
export function hiFrame(spr, img, R) {
  if (R <= 1 || !spr?.src) return null;
  const cache = spr.hi[R] || (spr.hi[R] = new Map()); let hi = cache.get(img); if (hi !== undefined) return hi;
  hi = null;
  try {
    const isLie = img === spr.lie, tf = spr.tf;
    const tw = img.width * R, th = img.height * R;
    if (tw <= spr.fw * HI_SRC_MAX && cache.size < 64) {
      if (isLie) {
        const ld = downscale(spr.src, spr.lieCell[0], spr.lieCell[1], spr.fw, spr.fh, th, tw, 0, tf.flip).cv;
        const [lie, lc] = makeCanvas(ld.height, ld.width); lc.translate(0, ld.width); lc.rotate(-Math.PI / 2); lc.drawImage(ld, 0, 0); hi = lie;
      } else if (img.__cell) {
        const pad = tf.rotation ? Math.ceil(Math.max(spr.w, spr.h) * 0.3) : 0; const iw = (img.width - pad * 2) * R, ih = (img.height - pad * 2) * R;
        const r = downscale(spr.src, img.__cell[0], img.__cell[1], spr.fw, spr.fh, iw, ih, tf.rotation, tf.flip).cv;
        if (r.width === tw && r.height === th) hi = r; else { const [o, oc] = makeCanvas(tw, th); oc.drawImage(r, Math.round((tw - r.width) / 2), Math.round((th - r.height) / 2)); hi = o; }
      }
    }
  } catch (e) { hi = null; }
  cache.set(img, hi); return hi;
}

/* ---------------- Pathfinding over decks + stairs ---------------- */
let ADJ = {}, adjFor = null;
function adj() { if (adjFor !== STAIRS) { ADJ = {}; for (const s of STAIRS) { (ADJ[s.a] ||= []).push({ s, from: 'a', to: s.b }); (ADJ[s.b] ||= []).push({ s, from: 'b', to: s.a }); } adjFor = STAIRS; } return ADJ; }
export function planPath(fromLevel, fromX, toLevel, toX) {
  const L = LEVELS[toLevel]; toX = clamp(toX, L.x1, L.x2);
  if (fromLevel === toLevel) return [{ t: 'walk', level: toLevel, x: toX }];
  const prev = { [fromLevel]: null }; const q = [fromLevel];
  while (q.length) { const cur = q.shift(); if (cur === toLevel) break; for (const e of adj()[cur] || []) if (!(e.to in prev)) { prev[e.to] = { lv: cur, e }; q.push(e.to); } }
  if (!(toLevel in prev)) return null;
  const edges = []; for (let lv = toLevel; prev[lv]; lv = prev[lv].lv) edges.unshift(prev[lv]);
  const steps = [];
  for (const { lv, e } of edges) {
    const up = e.from === 'a';
    steps.push({ t: 'walk', level: lv, x: up ? e.s.ax : e.s.bx });
    steps.push({ t: 'stair', s: e.s, up });
  }
  steps.push({ t: 'walk', level: toLevel, x: toX });
  return steps;
}

/* ---------------- Character ---------------- */
let NEXT_Z = 0;

export class Character {
  constructor(oc, spr, st = {}) {
    this.id = oc.key; this.oc = oc; this.spr = spr; this.name = oc.name;
    const tf = Object.assign(defaultTransform(), oc.transform || {});
    this.tf = tf;
    this.mode = st.mode || 'bot';
    this.level = st.level && LEVELS[st.level] ? st.level : SPEC.spawn.level; this.x = st.x ?? (SPEC.spawn.x1 + Math.random() * (SPEC.spawn.x2 - SPEC.spawn.x1));
    this.facing = st.facing || 1; this.state = 'idle'; this.path = []; this.action = null; this.stair = null;
    this.needs = Object.assign({ energy: 80, comfort: 70, hunger: 20, social: 30, curiosity: 40, sleepiness: 10 }, st.needs || {});
    this.pref = oc.pref || 'view'; this.slot = null; this.bubble = null; this.anim = 0; this.thinkT = rand(0.5, 2); this.idleT = 0;
    this.z = (tf.z || 0) * 1000 + (NEXT_Z++);
    this.yOff = 0; this.drag = null;
    if (st.state === 'sleep' && st.slot) { this.pendingSleep = st.slot; }
  }
  get speed() { return 30 * (this.tf.speed || 1) * personaOf(this).speed * (this.wade || 1); }
  get room() { return roomAt(this.level, this.x); }
  pos() {
    if (this.stair) { const { s, up, p } = this.stair; const t = up ? p : 1 - p; return [s.ax + (s.bx - s.ax) * t, LEVELS[s.a].y + (LEVELS[s.b].y - LEVELS[s.a].y) * t]; }
    if (this.swim) return [this.swim.x, this.swim.y];
    return [this.x, LEVELS[this.level].y];
  }
  toJSON() { return { mode: this.mode, level: this.level, x: Math.round(this.x), facing: this.facing, needs: this.needs, state: this.state === 'sleep' ? 'sleep' : 'idle', slot: this.state === 'sleep' ? this.slot : null }; }
  say(kind, t = 2.5) { this.bubble = { kind, t }; }
  // spoken text (rendered by the UI as a crisp pixel-font speech bubble above the head)
  speak(text, t) { if (!text) return; text = String(text).slice(0, 80); this.text = { s: text, t: t ?? clamp(1.8 + text.length * 0.09, 2.2, 6), id: (this.text?.id || 0) + 1 }; }
}

/* ---------------- Party manager (movement, interactions, AI) ---------------- */
let PARTY = null;
export class Party {
  constructor(game) { this.g = game; this.chars = []; this.occ = {}; this.convos = []; PARTY = this; }
  clear() { this.chars = []; this.occ = {}; this.convos = []; }
  add(ch) { this.chars.push(ch); if (ch.pendingSleep) { const { obj, i } = ch.pendingSleep; const o = OBJECTS.find(k => k.id === obj); if (o) this.occupy(ch, o, i, 'sleep'); ch.pendingSleep = null; } }
  occupants(o) { return this.occ[o.id] || (this.occ[o.id] = []); }
  freeSlot(o) { const n = o.slots || 1; const oc = this.occupants(o); for (let i = 0; i < n; i++) if (!oc[i]) return i; return -1; }
  release(ch) { if (ch.slot) { const oc = this.occ[ch.slot.obj]; if (oc && oc[ch.slot.i] === ch.id) oc[ch.slot.i] = null; ch.slot = null; } }
  occupy(ch, o, i, state) {
    this.occupants(o)[i] = ch.id; ch.slot = { obj: o.id, i }; ch.state = state;
    const xs = o.sleepX || o.sitX; if (xs) ch.x = xs[i] ?? o.x; ch.level = roomById[o.room].level;
    ch.bedY = o.bedY; ch.seatH = state === 'sit' && o.kind === 'bed' ? 16 : o.seatH ?? 8;
  }
  // command: walk to level/x then do action
  goto(ch, level, x, action = null) {
    if (ch.state === 'sleep' || ch.state === 'sit' || ch.state === 'lie') this.standUp(ch);
    const p = planPath(ch.stair ? (ch.stair.up ? ch.stair.s.b : ch.stair.s.a) : ch.level, ch.x, level, x);
    if (!p) return false;
    if (ch.stair) { // finish current stair first
      const st = ch.stair; ch.path = p; ch.action = action; return true;
    }
    ch.path = p; ch.action = action; ch.state = 'walk'; return true;
  }
  standUp(ch) { this.release(ch); ch.state = 'idle'; ch.yOff = 0; }
  interact(ch, o, verb) {
    if (o.kind === 'bed' || SIT_KINDS.includes(o.kind)) {
      const i = this.freeSlot(o);
      if (i < 0 && !(ch.slot && ch.slot.obj === o.id)) { if (ch === this.g.player) Bus.emit('toast', o.th + ' ไม่ว่าง มีคนใช้อยู่'); ch.say('dots'); return false; }
    }
    const xs = o.sleepX || o.sitX; const tx = xs ? xs[Math.max(0, this.freeSlot(o))] ?? o.x : o.x;
    return this.goto(ch, roomById[o.room].level, tx, { obj: o, verb });
  }
  line(ch, cat, other = null, p = 1) { if (Math.random() < p * personaOf(ch).chatty && this.g.isVisible?.(ch)) ch.speak(lineFor(ch, cat, other, this.g.rel)); }
  arrive(ch) {
    const a = ch.action; ch.action = null; ch.state = 'idle';
    if (!a) return;
    if (a.talkTo) { const other = this.chars.find(k => k.id === a.talkTo); if (other && other.state !== 'sleep' && Math.abs(other.x - ch.x) < 30 && other.level === ch.level) { this.startTalk(ch, other); } return; }
    const o = a.obj, verb = a.verb; const g = this.g;
    if (o.kind === 'svcpanel') { if (ch === g.player) Bus.emit('secret:panel', o); return; }
    if (o.kind === 'logbook') { if (ch === g.player) Bus.emit('secret:logbook', o); return; }
    switch (o.kind) {
      case 'bed': { const i = this.freeSlot(o); if (i < 0) return ch.say('dots'); this.occupy(ch, o, i, verb === 'sit' ? 'sit' : 'sleep'); if (ch.state === 'sleep') { ch.say('zzz', 4); this.line(ch, 'sleep', null, 0.4); if (ch === g.player) Bus.emit('player:sleep', ch); } break; }
      case 'sofa': case 'dining': case 'lounger': case 'bar': case 'cinema': case 'desk': { const i = this.freeSlot(o); if (i < 0) return ch.say('dots'); this.occupy(ch, o, i, verb === 'lie' && o.kind !== 'dining' ? 'lie' : 'sit'); if (o.kind === 'dining' || o.kind === 'bar') { ch.eatT = 6; ch.say('food', 4); this.line(ch, 'eat', null, 0.35); } else if (o.kind === 'cinema' || o.kind === 'desk') ch.say('note', 3); else ch.say('heart', 2); break; }
      case 'window': case 'view': ch.state = 'look'; ch.lookT = 8 * personaOf(ch).patience; this.line(ch, 'view', null, 0.3); ch.facing = o.kind === 'view' ? (o.x > 350 ? 1 : -1) : 1; ch.say('note', 3); break;
      case 'switch': ch.state = 'interact'; ch.busy = 0.8; g.toggleRoomLights(o.room); break;
      case 'stove': ch.state = 'interact'; ch.busy = 5; ch.say('food', 5); ch.onDone = () => { ch.needs.hunger = clamp(ch.needs.hunger - 35, 0, 100); }; break;
      case 'fridge': ch.state = 'interact'; ch.busy = 2; ch.onDone = () => { ch.needs.hunger = clamp(ch.needs.hunger - 15, 0, 100); }; break;
      case 'pool': ch.state = 'interact'; ch.busy = 6; ch.say('drop', 5); this.line(ch, 'fun', null, 0.35); ch.onDone = () => { ch.needs.comfort = clamp(ch.needs.comfort + 35, 0, 100); ch.needs.energy = clamp(ch.needs.energy - 5, 0, 100); }; break;
      case 'gym': ch.state = 'interact'; ch.busy = 7; ch.say('heart', 3); this.line(ch, 'fun', null, 0.35); ch.onDone = () => { ch.needs.energy = clamp(ch.needs.energy - 12, 0, 100); ch.needs.curiosity = clamp(ch.needs.curiosity - 10, 0, 100); ch.needs.comfort = clamp(ch.needs.comfort + 10, 0, 100); }; break;
      case 'shower': ch.state = 'interact'; ch.busy = 5; ch.say('drop', 4); ch.onDone = () => { ch.needs.comfort = clamp(ch.needs.comfort + 30, 0, 100); }; break;
      default: ch.state = 'interact'; ch.busy = 1.2; if (ch === g.player || ch.mode !== 'bot') g.openObjectPanel(o); else if (o.kind === 'navlights') { } break;
    }
  }
  startTalk(a, b) {
    // a short scripted exchange: greet → reply → chat → reply; length depends on how chatty both are
    const turns = Math.round(clamp(2 + (personaOf(a).chatty + personaOf(b).chatty) + Math.random() * 1.5, 2, 6));
    const steps = []; let t = 0;
    for (let i = 0; i < turns; i++) { const sp = i % 2 ? b : a, ls = i % 2 ? a : b; const cat = i === 0 ? 'greet' : i % 2 ? 'reply' : 'chat'; steps.push({ at: t, sp, ls, cat }); t += 2.6; }
    const dur = t + 0.6;
    for (const [x, y] of [[a, b], [b, a]]) { x.state = 'talk'; x.talkT = dur; x.facing = Math.sign(y.x - x.x) || 1; this.release(x); }
    this.convos = this.convos.filter(c => c.a !== a && c.b !== a && c.a !== b && c.b !== b);
    this.convos.push({ a, b, t: 0, steps });
    const rel = this.g.relationships; const k = [a.id, b.id].sort().join('|'); rel[k] = (rel[k] || 0) + 1;
    const grp = this.g.rel?.group(a.slot_, b.slot_); if (grp === 'love') setTimeout(() => { a.say('heart', 2.5); b.say('heart', 2.5); }, dur * 1000 - 400);
  }
  updateConvos(dt) {
    for (const cv of this.convos) {
      cv.t += dt;
      while (cv.steps.length && cv.steps[0].at <= cv.t) { const s = cv.steps.shift(); if (s.sp.state === 'talk') { if (this.g.isVisible?.(s.sp)) s.sp.speak(lineFor(s.sp, s.cat, s.ls, this.g.rel), 2.5); else s.sp.say('chat', 2.5); } }
    }
    this.convos = this.convos.filter(cv => cv.steps.length && cv.a.state === 'talk' && cv.b.state === 'talk');
  }
  wake(ch) { if (ch.state === 'sleep') { this.standUp(ch); ch.say('sun', 2); this.line(ch, 'wake', null, 0.5); } }

  update(dt, gameHours, hour) {
    this.updateConvos(dt);
    for (const ch of this.chars) {
      if (ch.text && (ch.text.t -= dt) <= 0) ch.text = null;
      if (this.g.onTender?.(ch) || ch.inHeli || ch.swim || ch.lost || (this.g.coopSolo && ch !== this.g.player)) continue;
      this.needs(ch, gameHours, dt);
      if (ch.bubble && (ch.bubble.t -= dt) <= 0) ch.bubble = null;
      ch.anim += dt;
      // movement
      if (ch.stair && (!LEVELS[ch.stair.s.a] || !LEVELS[ch.stair.s.b])) { ch.stair = null; ch.path = []; }
      if (!LEVELS[ch.level] || !Number.isFinite(ch.x)) { ch.level = LEVELS[ch.level] ? ch.level : SPEC.spawn.level; ch.x = SPEC.spawn.x1 + 10; ch.path = []; ch.stair = null; ch.state = 'idle'; }
      if (ch.path.length && ch.path[0].t === 'walk' && !Number.isFinite(ch.path[0].x)) ch.path = [];
      if (ch.stair) {
        const st = ch.stair; const len = Math.hypot(st.s.bx - st.s.ax, LEVELS[st.s.b].y - LEVELS[st.s.a].y);
        st.p += ch.speed * 0.7 * dt / len;
        ch.facing = Math.sign((st.up ? 1 : -1) * (st.s.bx - st.s.ax)) || ch.facing;
        if (st.p >= 1) { ch.level = st.up ? st.s.b : st.s.a; ch.x = st.up ? st.s.bx : st.s.ax; ch.stair = null; }
        continue;
      }
      if (ch.path.length) {
        ch.state = 'walk'; const step = ch.path[0];
        if (step.t === 'walk') {
          const dx = step.x - ch.x; const mv = ch.speed * dt;
          if (Math.abs(dx) <= mv) { ch.x = step.x; ch.path.shift(); } else { ch.x += Math.sign(dx) * mv; ch.facing = Math.sign(dx); }
        } else { ch.stair = { s: step.s, up: step.up, p: 0 }; ch.path.shift(); }
        if (!ch.path.length && !ch.stair) this.arrive(ch);
        continue;
      }
      // timed states
      if (ch.busy > 0) { ch.busy -= dt; if (ch.busy <= 0) { ch.state = 'idle'; ch.onDone?.(); ch.onDone = null; if (ch.after) { const f = ch.after; ch.after = null; f(); } } continue; }
      if (ch.state === 'look' && (ch.lookT -= dt) <= 0) ch.state = 'idle';
      if (ch.state === 'talk' && (ch.talkT -= dt) <= 0) ch.state = 'idle';
      if (ch.eatT > 0 && (ch.eatT -= dt) <= 0) { ch.needs.hunger = clamp(ch.needs.hunger - 45, 0, 100); }
      // AI
      const ai = !ch.boardHeli && !ch.mustering && (ch.mode === 'bot' || (ch.mode === 'assisted' && ch.idleT > 25));
      if (ch.state === 'idle' || ch.state === 'sit' || ch.state === 'look' || ch.state === 'lie' || ch.state === 'sleep') ch.idleT += dt; else ch.idleT = 0;
      if (ch.state !== 'sleep' && ch.state !== 'talk' && (ch.muteT = (ch.muteT ?? rand(15, 40)) - dt) <= 0) { ch.muteT = rand(25, 70) / personaOf(ch).chatty; if (ch.mode === 'bot' && !ch.text) this.line(ch, 'idle', null, 0.6); }
      if (ai) { ch.thinkT -= dt * (this.g.isVisible(ch) ? 1 : 0.35); if (ch.thinkT <= 0) { ch.thinkT = rand(3, 6) * personaOf(ch).patience; this.think(ch, hour); } }
    }
  }
  needs(ch, gh, dt) {
    const n = ch.needs; const h = gh + dt * 0.004; // tiny real-time drift keeps bots lively in real-time mode
    if (ch.state === 'sleep') { n.energy += 16 * h; n.sleepiness -= 15 * h; n.hunger += 3 * h; }
    else {
      n.energy -= 4 * h; n.sleepiness += 4.5 * h; n.hunger += 7 * h; n.social += (ch.state === 'talk' ? -40 : 5) * h; n.curiosity += (ch.state === 'look' ? -45 : 6) * h;
      n.comfort += (ch.state === 'sit' || ch.state === 'lie' ? 25 : -3) * h;
      if (ch.state === 'talk') { n.social -= dt * 2; }
      if (ch.state === 'look') { n.curiosity -= dt * 2; }
      if (ch.state === 'sit' || ch.state === 'lie') { n.comfort += dt * 1.2; n.energy += dt * 0.2; }
    }
    for (const k in n) n[k] = clamp(n[k], 0, 100);
  }
  think(ch, hour) {
    const n = ch.needs, g = this.g; const night = hour >= 22 || hour < 6;
    // waking up
    if (ch.state === 'sleep') { if ((n.energy > 85 && n.sleepiness < 25 && hour >= 6.5 && hour < 22) || n.hunger > 90) this.wake(ch); else return; }
    const routine = hour >= 7 && hour < 8 ? 'wake' : hour >= 8 && hour < 9 ? 'eat' : hour >= 9 && hour < 11 ? 'deck' : hour >= 12 && hour < 14 ? 'relax' : hour >= 15 && hour < 17 ? 'sea' : hour >= 18 && hour < 21 ? 'lounge' : hour >= 21 && hour < 23 ? 'prep' : night ? 'sleep' : '';
    const others = this.chars.filter(o => o !== ch && o.state !== 'sleep' && !g.onTender?.(o) && !o.mustering && !o.inHeli && !o.swim && !g.coopSolo && !o.boardHeli);
    const opts = [];
    const freeBed = OBJECTS.filter(o => o.kind === 'bed' && this.freeSlot(o) >= 0);
    if (freeBed.length) opts.push({ k: 'sleep', s: n.sleepiness / 90 + (n.energy < 25 ? 0.5 : 0) + (routine === 'sleep' ? 0.6 : 0), o: freeBed[(Math.random() * freeBed.length) | 0] });
    const eats = OBJECTS.filter(o => (o.kind === 'dining' || o.kind === 'bar') && this.freeSlot(o) >= 0); const eat = eats[(Math.random() * eats.length) | 0];
    if (eat) opts.push({ k: 'eat', s: n.hunger / 85 + (routine === 'eat' ? 0.35 : 0), o: eat });
    const stoves = OBJECTS.filter(o => o.kind === 'stove'); if (stoves.length) opts.push({ k: 'cook', s: n.hunger / 120 + (ch.pref === 'cook' ? 0.3 : 0), o: stoves[(Math.random() * stoves.length) | 0] });
    const fun = OBJECTS.filter(o => o.kind === 'pool' || o.kind === 'gym' || ((o.kind === 'cinema' || o.kind === 'desk') && this.freeSlot(o) >= 0)); if (fun.length) opts.push({ k: 'fun', s: 0.2 + n.curiosity / 220 + (100 - n.comfort) / 300 + (ch.pref === 'relax' ? 0.1 : 0), o: fun[(Math.random() * fun.length) | 0] });
    const seats = OBJECTS.filter(o => (o.kind === 'sofa' || o.kind === 'lounger') && this.freeSlot(o) >= 0);
    const loungeSeat = seats.find(o => roomById[o.room]?.kind === 'lounge');
    if (seats.length) opts.push({ k: 'relax', s: (100 - n.comfort) / 100 + (routine === 'relax' || routine === 'lounge' ? 0.35 : 0) + (ch.pref === 'relax' ? 0.25 : 0), o: routine === 'lounge' ? (loungeSeat || seats[0]) : seats[(Math.random() * seats.length) | 0] });
    const views = OBJECTS.filter(o => o.kind === 'view' || o.kind === 'window');
    opts.push({ k: 'view', s: n.curiosity / 100 + (routine === 'deck' || routine === 'sea' ? 0.35 : 0) + (ch.pref === 'view' ? 0.25 : 0) - (night ? 0.2 : 0), o: views[(Math.random() * views.length) | 0] });
    const P = personaOf(ch);
    if (others.length) {
      // prefer people we're close to: partner > best friend > family > friend > stranger (shy OCs avoid strangers)
      const bond = o => { const gr = g.rel?.group(ch.slot_, o.slot_); return gr === 'love' ? 0.35 : gr === 'bff' ? 0.25 : gr === 'family' ? 0.18 : gr === 'friend' ? 0.1 : (ch.oc?.persona === 'shy' ? -0.15 : 0); };
      const ranked = others.map(o => ({ o, s: bond(o) + Math.random() * 0.3 })).sort((x, y) => y.s - x.s);
      opts.push({ k: 'talk', s: n.social / 100 + (ch.pref === 'talk' ? 0.25 : 0) + (routine === 'relax' ? 0.15 : 0) + P.social + ranked[0].s * 0.6, who: ranked[0].o });
    }
    const showers = OBJECTS.filter(o => o.kind === 'shower'); if (routine === 'prep' && showers.length) opts.push({ k: 'shower', s: 0.55 + (100 - n.comfort) / 300, o: showers[(Math.random() * showers.length) | 0] });
    opts.push({ k: 'explore', s: 0.18 + (ch.pref === 'explore' ? 0.3 : 0) + P.explore });
    for (const o of opts) if (o.k === 'relax') o.s += P.relax; else if (o.k === 'fun') o.s += P.explore * 0.5 - P.relax * 0.3;
    // lights: dark room without light
    const r = ch.room; const dark = g.env.sunElev < 2;
    const sw = r && OBJECTS.find(o => o.kind === 'switch' && o.room === r.id); if (sw && dark && !g.lights[r.id + ':ceiling'] && ch.state !== 'sleep') opts.push({ k: 'lighton', s: 0.95, o: sw });
    for (const o of opts) o.s += (Math.random() - 0.5) * 0.18;
    opts.sort((a, b) => b.s - a.s); const best = opts[0];
    // keep doing current relaxing state unless clearly better
    if ((ch.state === 'sit' || ch.state === 'look' || ch.state === 'lie') && best.s < 0.75 / Math.max(0.5, 1.3 - P.patience * 0.3)) return;
    switch (best.k) {
      case 'sleep': {
        // turn off the bedroom light first if it's on (sequence)
        const room = best.o.room; const sw2 = OBJECTS.find(o => o.kind === 'switch' && o.room === room); if (g.lights[room + ':ceiling'] && dark && sw2) { this.interact(ch, sw2); ch.after = () => this.interact(ch, best.o, 'sleep'); }
        else this.interact(ch, best.o, 'sleep'); break;
      }
      case 'talk': this.goto(ch, best.who.level, best.who.x + (best.who.x > ch.x ? -14 : 14), { talkTo: best.who.id }); break;
      case 'explore': { const rs = ROOMS.filter(r => !r.stair && r.kind !== 'lifeboat'); const rr = rs[(Math.random() * rs.length) | 0]; this.goto(ch, rr.level, rand(rr.x1 + 8, rr.x2 - 8)); break; }
      default: if (best.o) this.interact(ch, best.o, best.k === 'relax' && Math.random() < 0.2 ? 'lie' : best.k);
    }
  }
}

/* ---------------- Drawing ---------------- */
function bubble(c, x, y, kind, t) {
  x = Math.round(x); y = Math.round(y);
  const R = (a, b, w, h, k) => { c.fillStyle = k; c.fillRect(x + a, y + b, w, h); };
  if (kind === 'zzz') { const k = (t * 1.5) % 3; c.fillStyle = '#ffffff'; for (let i = 0; i < 3; i++) { if (i > k) continue; const zx = x + i * 4, zy = y - i * 4; c.fillRect(zx, zy, 3, 1); c.fillRect(zx + 1, zy + 1, 1, 1); c.fillRect(zx, zy + 2, 3, 1); } return; }
  R(-6, -9, 13, 9, '#ffffff'); R(-7, -8, 15, 7, '#ffffff'); R(-1, 0, 2, 2, '#ffffff'); R(-6, -9, 13, 1, '#d8dde0');
  const ic = '#38434A';
  if (kind === 'heart') { R(-3, -7, 2, 1, '#e46b8a'); R(1, -7, 2, 1, '#e46b8a'); R(-4, -6, 7, 2, '#e46b8a'); R(-3, -4, 5, 1, '#e46b8a'); R(-1, -3, 1, 1, '#e46b8a'); }
  else if (kind === 'chat' || kind === 'dots') { for (let i = 0; i < 3; i++) if (kind === 'dots' || ((t * 3 | 0) % 3) >= i) R(-4 + i * 3, -5, 2, 2, ic); }
  else if (kind === 'food') { R(-4, -5, 8, 3, '#c98a5c'); R(-3, -7, 6, 2, '#f2c94c'); R(-4, -2, 8, 1, ic); }
  else if (kind === 'note') { R(0, -8, 1, 5, ic); R(1, -8, 2, 1, ic); R(-2, -4, 2, 2, ic); }
  else if (kind === 'drop') { R(0, -8, 1, 1, '#5aa0c0'); R(-1, -7, 3, 2, '#5aa0c0'); R(-2, -5, 5, 2, '#5aa0c0'); }
  else if (kind === 'sun') { R(-2, -7, 4, 4, '#f2c94c'); R(-4, -5, 1, 1, '#f2c94c'); R(3, -5, 1, 1, '#f2c94c'); R(0, -9, 1, 1, '#f2c94c'); }
}

export function frameFor(ch) {
  const a = ch.spr.anims; const key = ch.state === 'talk' ? 'interact' : ch.state === 'sleep' ? 'sleep' : ch.state in a ? ch.state : 'idle';
  const fr = a[key] || a.idle; return { img: fr[Math.floor(ch.anim * ch.spr.fps) % fr.length], key, sheet: ch.spr.multi && fr.length > 1 };
}

// Draws a character in yacht coordinates. Returns screen-agnostic bounds for picking.
export function drawChar(c, ch, x, y, opts = {}) {
  const { img, key, sheet } = frameFor(ch);
  const spr = ch.spr; const w = img.width, h = img.height;
  let bob = 0;
  if (!sheet) {
    if (ch.state === 'walk' || ch.stair) bob = (Math.floor(ch.anim * 8) % 2);
    else if (ch.state === 'idle' || ch.state === 'look') bob = (Math.floor(ch.anim * 1.2) % 2) ? 0 : 0;
    else if (ch.state === 'interact' || ch.state === 'talk') bob = (Math.floor(ch.anim * 5) % 2);
  }
  const flip = ch.facing < 0;
  const px = Math.round(x - w * (ch.tf.pivotX ?? 0.5)), gy = Math.round(y + spr.ground);
  const R = c.__R || 1; const HI = (im) => (R > 1 && hiFrame(spr, im, R)) || im;
  c.save();
  if (opts.alpha != null) c.globalAlpha = opts.alpha;
  // shadow
  if (!opts.silhouette && ch.state !== 'sleep' && ch.state !== 'lie') { c.fillStyle = 'rgba(0,0,0,0.22)'; c.fillRect(Math.round(x - w * 0.3), Math.round(y) - 1, Math.round(w * 0.6), 1); }
  let bounds;
  if ((ch.state === 'sleep' || ch.state === 'lie') && !sheet) {
    // lying pose: exact 90° rotation (lossless for pixel art) placed on the mattress
    const bedY = ch.bedY ?? (y - 8); const L = spr.lie;
    const bx = Math.round(x - L.width / 2), by = Math.round(bedY - L.height + 2);
    c.translate(bx + (flip ? L.width : 0), by); if (flip) c.scale(-1, 1);
    const tucked = ch.state === 'sleep' && ch.bedY != null && !opts.silhouette && lieProfile(L);
    if (tucked) { const chin = chinOf(L), hiL = HI(L), k = hiL.width / L.width; c.drawImage(hiL, 0, 0, (chin + 1) * k, hiL.height, 0, 0, chin + 1, L.height); } // only the head shows; the body is under the duvet
    else c.drawImage(HI(L), 0, 0, L.width, L.height);
    bounds = [bx, by, L.width, L.height];
  } else if (ch.state === 'sit' && !sheet) {
    // seated, whole body visible: upper body rests on the seat (hips at seat height), the lower legs hang
    // from the seat front down to the floor; on high seats (bar stools, bed edge) the feet dangle.
    const leg = Math.round(h * 0.3), seatY = Math.round(y - (ch.seatH ?? 6)), floorY = gy;
    c.translate(px + (flip ? w : 0), 0); if (flip) c.scale(-1, 1);
    const hi = HI(img), k = hi.width / w, top = h - leg;
    c.drawImage(hi, 0, 0, w * k, top * k, 0, seatY - top, w, top);                       // head → hips
    const room = floorY - seatY, lh = room >= leg ? leg : Math.max(2, room);              // shins: real length, or folded to fit a low seat
    c.drawImage(hi, 0, top * k, w * k, leg * k, 0, seatY, w, lh);
    bounds = [px, seatY - top, w, top + lh];
  } else {
    c.translate(px + (flip ? w : 0), 0); if (flip) c.scale(-1, 1);
    c.drawImage(HI(img), 0, gy - h - bob, w, h);
    bounds = [px, gy - h - bob, w, h];
  }
  c.restore();
  if (ch.state === 'sleep' && ch.bedY != null && !sheet && !opts.silhouette) drawBlanket(c, ch, bounds, flip, spr.lie);
  if (!opts.silhouette) {
    if (ch.bubble) bubble(c, x, bounds[1] - 3, ch.bubble.kind, ch.anim);
    if (opts.marker) { c.fillStyle = '#ffd86a'; const mx = Math.round(x), my = Math.round(bounds[1] - (ch.bubble ? 14 : 4)); c.fillRect(mx - 2, my - 3, 5, 1); c.fillRect(mx - 1, my - 2, 3, 1); c.fillRect(mx, my - 1, 1, 1); }
  }
  return bounds;
}
