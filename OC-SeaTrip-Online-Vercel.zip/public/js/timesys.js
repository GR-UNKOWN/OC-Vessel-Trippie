// Clock modes + solar position model (used for sky colour, light direction and room daylight).
import { clamp, lerp, mixHex } from './util.js';

const RAD = Math.PI / 180;
export function solarPosition(utcMs, lat, lon) {
  const jd = utcMs / 86400000 + 2440587.5, n = jd - 2451545.0;
  const L = (280.460 + 0.9856474 * n) % 360, g = ((357.528 + 0.9856003 * n) % 360) * RAD;
  const lam = (L + 1.915 * Math.sin(g) + 0.020 * Math.sin(2 * g)) * RAD;
  const eps = (23.439 - 0.0000004 * n) * RAD;
  const ra = Math.atan2(Math.cos(eps) * Math.sin(lam), Math.cos(lam));
  const dec = Math.asin(Math.sin(eps) * Math.sin(lam));
  const gmst = ((18.697374558 + 24.06570982441908 * n) % 24 + 24) % 24;
  const H = (gmst * 15 + lon) * RAD - ra;
  const phi = lat * RAD;
  const elev = Math.asin(Math.sin(phi) * Math.sin(dec) + Math.cos(phi) * Math.cos(dec) * Math.cos(H));
  const az = Math.atan2(-Math.sin(H), Math.tan(dec) * Math.cos(phi) - Math.sin(phi) * Math.cos(H));
  return { elev: elev / RAD, az: ((az / RAD) + 360) % 360 };
}

export const PRESETS = [
  { id: 'dawn', th: 'รุ่งสาง', h: 5.75 }, { id: 'morning', th: 'เช้า', h: 7.5 }, { id: 'late', th: 'สาย', h: 10.5 },
  { id: 'afternoon', th: 'บ่าย', h: 14 }, { id: 'evening', th: 'เย็น', h: 17 }, { id: 'dusk', th: 'พลบค่ำ', h: 18.6 },
  { id: 'night', th: 'กลางคืน', h: 21 }, { id: 'late_night', th: 'ดึก', h: 1.5 },
];
export const TIME_MODES = [
  { id: 'real', th: 'เวลาจริง (นาฬิกาเครื่อง)' }, { id: 'local', th: 'เวลาท้องถิ่นของพื้นที่เดินเรือ' },
  { id: 'custom', th: 'กำหนดเวลาเอง' }, { id: 'preset', th: 'ช่วงเวลาสำเร็จรูป' }, { id: 'accel', th: 'เร่งเวลาจำลอง' },
];

export class Clock {
  constructor(state) { this.s = Object.assign({ mode: 'accel', base: Date.now(), setAt: Date.now(), speed: 60, preset: 'morning', customHour: 9 }, state || {}); this.tz = 7; }
  toJSON() { return { ...this.s, base: this.utc(), setAt: Date.now() }; }
  utc() {
    const s = this.s, now = Date.now();
    if (s.mode === 'real' || s.mode === 'local') return now;
    if (s.mode === 'preset') return s.base;
    if (s.mode === 'accel') return s.base + (now - s.setAt) * s.speed;
    return s.base + (now - s.setAt);
  }
  setMode(mode, opts = {}) {
    const cur = this.utc();
    this.s.mode = mode; Object.assign(this.s, opts);
    if (mode === 'preset') this.s.base = this.utcForLocalHour(PRESETS.find(p => p.id === this.s.preset)?.h ?? 9);
    else if (mode === 'custom') this.s.base = this.utcForLocalHour(this.s.customHour);
    else this.s.base = cur;
    this.s.setAt = Date.now();
  }
  utcForLocalHour(h) {
    const now = Date.now();
    const localDayStart = Math.floor((now + this.tz * 3600e3) / 86400e3) * 86400e3 - this.tz * 3600e3;
    return localDayStart + h * 3600e3;
  }
  // skip time forward (e.g. sleeping) in non-real modes
  advance(hours) { if (this.s.mode === 'real' || this.s.mode === 'local') return false; this.s.base = this.utc() + hours * 3600e3; this.s.setAt = Date.now(); return true; }
  localHour() {
    const u = this.utc();
    if (this.s.mode === 'real') { const d = new Date(u); return d.getHours() + d.getMinutes() / 60 + d.getSeconds() / 3600; }
    const h = ((u / 3600e3 + this.tz) % 24 + 24) % 24; return h;
  }
  tzLabel() { return this.s.mode === 'real' ? 'เวลาเครื่อง' : 'UTC' + (this.tz >= 0 ? '+' : '') + this.tz; }
}

export function periodName(h) {
  if (h >= 5 && h < 6.5) return 'รุ่งสาง'; if (h < 9) return h >= 5 ? 'เช้า' : 'ดึก'; if (h < 12) return 'สาย';
  if (h < 16) return 'บ่าย'; if (h < 18) return 'เย็น'; if (h < 19.3) return 'พลบค่ำ'; if (h < 23) return 'กลางคืน'; return 'ดึก';
}
export function lightCondition(elev) {
  if (elev > 20) return 'แดดจ้า'; if (elev > 6) return 'แสงอ่อน'; if (elev > -2) return 'แสงทอง'; if (elev > -8) return 'แสงสนธยา'; return 'มืด';
}

// sky / ambient palette from sun elevation (deg)
const KEYS = [
  // deep night: sky and everything outdoors go properly dark (cabins keep their own dim glow, see scene.roomLight)
  { e: -18, top: '#04070f', bot: '#0c1426', sea: '#080f1c', seaD: '#040811', amb: [0.075, 0.085, 0.14], cloud: 2 },
  { e: -13, top: '#0b1428', bot: '#1c2b4c', sea: '#13223a', seaD: '#0a1426', amb: [0.14, 0.15, 0.23], cloud: 2 },
  { e: -8, top: '#1e2a52', bot: '#5a5a82', sea: '#26365a', seaD: '#142040', amb: [0.24, 0.24, 0.33], cloud: 2 },
  { e: -2, top: '#4a5f96', bot: '#f0a88e', sea: '#5a6a96', seaD: '#2c3c66', amb: [0.38, 0.33, 0.36], cloud: 1 },
  { e: 4, top: '#86a9d0', bot: '#f8cfa8', sea: '#7aa4bf', seaD: '#3f6c8e', amb: [0.48, 0.42, 0.38], cloud: 1 },
  { e: 14, top: '#86c6e8', bot: '#d4ecf6', sea: '#7fbfd6', seaD: '#3e86a8', amb: [0.5, 0.49, 0.47], cloud: 0 },
  { e: 50, top: '#6bb6e6', bot: '#c9e7f2', sea: '#73b8d2', seaD: '#2f7ea6', amb: [0.52, 0.52, 0.5], cloud: 0 },
];
export function skyPalette(elev) {
  elev = clamp(elev, -18, 50);
  let i = 0; while (i < KEYS.length - 2 && elev > KEYS[i + 1].e) i++;
  const a = KEYS[i], b = KEYS[i + 1]; const t = clamp((elev - a.e) / (b.e - a.e), 0, 1);
  return {
    top: mixHex(a.top, b.top, t), bot: mixHex(a.bot, b.bot, t), sea: mixHex(a.sea, b.sea, t), seaD: mixHex(a.seaD, b.seaD, t),
    amb: a.amb.map((v, k) => lerp(v, b.amb[k], t)), cloudA: a.cloud, cloudB: b.cloud, cloudT: t,
    night: clamp((-elev - 2) / 10, 0, 1),
  };
}
