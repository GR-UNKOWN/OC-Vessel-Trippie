// Pixel-art helm console: everything is plotted on a 200×140 canvas with integer fillRects only (no curves,
// no anti-aliasing, a hand-made 3×5 bitmap font) and scaled up with nearest-neighbour — same look as the game.
import { clamp } from './util.js';
import { Helm, DETENTS, detentOf } from './helm.js';
import { G } from './main.js';

export const PW = 200, PH = 140;
const FONT = {
  '0': '111101101101111', '1': '010110010010111', '2': '111001111100111', '3': '111001111001111', '4': '101101111001001', '5': '111100111001111',
  '6': '111100111101111', '7': '111001001010010', '8': '111101111101111', '9': '111101111001111', A: '010101111101101', B: '110101110101110',
  C: '011100100100011', D: '110101101101110', E: '111100110100111', F: '111100110100100', G: '011100101101011', H: '101101111101101',
  I: '111010010010111', J: '001001001101010', K: '101101110101101', L: '100100100100111', M: '101111111101101', N: '110101101101101',
  O: '010101101101010', P: '110101110100100', Q: '010101101110011', R: '110101110101101', S: '011100010001110', T: '111010010010010',
  U: '101101101101111', V: '101101101101010', W: '101101111111101', X: '101101010101101', Y: '101101010010010', Z: '111001010100111',
  '.': '000000000000010', '-': '000000111000000', '+': '000010111010000', '°': '010101010000000', '/': '001001010100100', ':': '000010000010000', ' ': '000000000000000',
};
const C = { bg: '#1b232b', bez: '#2c3a46', hi: '#3e5262', lo: '#10161c', scr: '#0b1a14', scr2: '#0d2230', txt: '#8fb3c8', dim: '#4a6274', amb: '#ffd166', cy: '#5ad0e6', gr: '#5ac46e', rd: '#ff6a5a', yl: '#f2c94c', wood: '#a8743e', woodD: '#6e4622', woodL: '#d6a464', brass: '#d9b45a', brassD: '#8a6a2a' };

let c = null;
const R = (x, y, w, h, col) => { c.fillStyle = col; c.fillRect(x | 0, y | 0, w | 0, h | 0); };
const P = (x, y, col) => R(Math.round(x), Math.round(y), 1, 1, col);
function text(s, x, y, col, k = 1) { s = String(s).toUpperCase(); let cx = x; for (const ch of s) { const g = FONT[ch] || FONT[' ']; for (let i = 0; i < 15; i++) if (g[i] === '1') R(cx + (i % 3) * k, y + ((i / 3) | 0) * k, k, k, col); cx += 4 * k; } return cx - x; }
const tw = (s, k = 1) => String(s).length * 4 * k - k;
function line(x0, y0, x1, y1, col) { x0 = Math.round(x0); y0 = Math.round(y0); x1 = Math.round(x1); y1 = Math.round(y1); const dx = Math.abs(x1 - x0), dy = -Math.abs(y1 - y0), sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1; let e = dx + dy; for (; ;) { P(x0, y0, col); if (x0 === x1 && y0 === y1) break; const e2 = 2 * e; if (e2 >= dy) { e += dy; x0 += sx; } if (e2 <= dx) { e += dx; y0 += sy; } } }
function ring(cx, cy, r, col, from = 0, to = Math.PI * 2) { const n = Math.ceil(r * 8); let lx = null, ly = null; for (let i = 0; i <= n; i++) { const a = from + (to - from) * i / n, x = Math.round(cx + Math.cos(a) * r), y = Math.round(cy + Math.sin(a) * r); if (x !== lx || y !== ly) P(x, y, col); lx = x; ly = y; } }
function disc(cx, cy, r, col) { for (let y = -r; y <= r; y++) { const w = Math.floor(Math.sqrt(r * r - y * y + r * 0.8)); R(cx - w, cy + y, w * 2 + 1, 1, col); } }
function bezel(x, y, w, h, fill = C.bez) { R(x, y, w, h, C.lo); R(x + 1, y + 1, w - 2, h - 2, fill); R(x + 1, y + 1, w - 2, 1, C.hi); R(x + 1, y + 1, 1, h - 2, C.hi); }
function screen(x, y, w, h, fill = C.scr2) { R(x, y, w, h, C.lo); R(x + 1, y + 1, w - 2, h - 2, fill); for (let yy = y + 2; yy < y + h - 1; yy += 2) R(x + 1, yy, w - 2, 1, 'rgba(255,255,255,0.025)'); }

// geometry shared with input handling
export const GEO = { tele: [{ x: 4, lever: 26, name: 'PORT', col: C.rd }, { x: 156, lever: 158, name: 'STBD', col: C.gr }], slotTop: 60, slotBot: 120, wheel: { x: 100, y: 92, r: 28 } };
// detents are evenly spaced on the lever arc (like a real telegraph dial), whatever their power value
const N = DETENTS.length - 1, step = () => (GEO.slotBot - GEO.slotTop) / N;
export const leverValue = y => DETENTS[N - clamp(Math.round((y - GEO.slotTop) / step()), 0, N)][0];
const idxOf = v => { let k = 0; for (let i = 0; i <= N; i++) if (Math.abs(DETENTS[i][0] - v) < Math.abs(DETENTS[k][0] - v)) k = i; return k; };
const detentY = v => { const f = (() => { for (let i = 0; i < N; i++) { const a = DETENTS[i][0], b = DETENTS[i + 1][0]; if (v >= a && v <= b) return i + (v - a) / (b - a || 1); } return v < 0 ? 0 : N; })(); return Math.round(GEO.slotBot - f * step()); };
const SHORT = { 'FULL AHEAD': 'FULL', 'HALF AHEAD': 'HALF', 'SLOW AHEAD': 'SLOW', 'DEAD SLOW AHEAD': 'DSLW', STOP: 'STOP', 'DEAD SLOW ASTERN': 'DSLW', 'SLOW ASTERN': 'SLOW', 'HALF ASTERN': 'HALF', 'FULL ASTERN': 'FULL' };

export function drawHelm(ctx, s, t) {
  c = ctx; c.imageSmoothingEnabled = false;
  R(0, 0, PW, PH, C.bg);
  // ---------- heading: big digits + compass tape ----------
  bezel(2, 2, 76, 40); text('HDG', 6, 5, C.dim); if (Helm.hold != null) text('HOLD', 46, 5, C.gr); else if (s.autopilot) text('AUTO', 46, 5, C.gr);
  screen(5, 11, 70, 16, C.scr2); const hd = String(Math.round(s.heading) % 360).padStart(3, '0'); text(hd, 40 - (tw(hd, 3) + 6) / 2, 12, C.amb, 3); P(40 + (tw(hd, 3) + 6) / 2 - 3, 13, C.amb); P(40 + (tw(hd, 3) + 6) / 2 - 2, 12, C.amb); P(40 + (tw(hd, 3) + 6) / 2 - 1, 13, C.amb); P(40 + (tw(hd, 3) + 6) / 2 - 2, 14, C.amb);
  screen(5, 29, 70, 11, C.scr2); c.save(); c.beginPath(); c.rect(6, 30, 68, 9); c.clip();
  for (let d = -40; d <= 40; d += 5) { const h = Math.round(s.heading / 5) * 5 + d, x = Math.round(40 + (h - s.heading) * 0.8), n = ((h % 360) + 360) % 360; R(x, 36, 1, n % 10 ? 2 : 3, C.txt); if (n % 30 === 0) { const lab = { 0: 'N', 90: 'E', 180: 'S', 270: 'W' }[n] ?? String(n / 10 | 0); text(lab, x - tw(lab) / 2, 30, n % 90 ? C.dim : C.txt); } }
  c.restore(); P(40, 39, C.amb); R(39, 40, 3, 1, C.amb);
  // ---------- speed log ----------
  bezel(80, 2, 46, 40); text('SOG', 84, 5, C.dim); text('KN', 112, 5, C.dim);
  screen(83, 11, 40, 16, C.scr); const sp = Math.abs(s.speed).toFixed(1); text(sp, 103 - tw(sp, 2) / 2, 14, s.speed < -0.05 ? C.yl : C.cy, 2);
  if (s.speed < -0.05) text('AST', 86, 29, C.yl); else text('AHD', 86, 29, C.dim);
  const rot = Math.round(Helm.rot * 60); text('ROT', 86, 35, C.dim); text((rot > 0 ? '+' : '') + rot, 101, 35, rot > 2 ? C.gr : rot < -2 ? C.rd : C.txt);
  // ---------- rudder angle indicator ----------
  bezel(128, 2, 42, 40); text('RUD', 132, 5, C.dim);
  const rx = 149, ry = 36, rr = 17;
  ring(rx, ry, rr, C.rd, Math.PI, Math.PI * 1.5 - 0.05); ring(rx, ry, rr, C.gr, Math.PI * 1.5 + 0.05, Math.PI * 2); ring(rx, ry, rr - 1, C.dim, Math.PI, Math.PI * 2);
  for (const deg of [-30, -20, -10, 0, 10, 20, 30]) { const a = -Math.PI / 2 + deg / 35 * Math.PI * 0.45; line(rx + Math.cos(a) * (rr - 3), ry + Math.sin(a) * (rr - 3), rx + Math.cos(a) * (rr - 1), ry + Math.sin(a) * (rr - 1), deg ? C.dim : C.txt); }
  const ra = -Math.PI / 2 + Helm.rudder / 35 * Math.PI * 0.45; line(rx, ry, rx + Math.cos(ra) * (rr - 4), ry + Math.sin(ra) * (rr - 4), C.amb); R(rx - 1, ry - 1, 3, 2, C.brass);
  const oa = -Math.PI / 2 + Helm.wheel * Math.PI * 0.45; R(Math.round(rx + Math.cos(oa) * (rr + 2)) - 1, Math.round(ry + Math.sin(oa) * (rr + 2)) - 1, 2, 2, C.cy);
  const rl = (Helm.rudder < -0.5 ? 'P' : Helm.rudder > 0.5 ? 'S' : '') + Math.abs(Helm.rudder).toFixed(0); text(rl, 166 - tw(rl), 5, Helm.rudder < -0.5 ? C.rd : Helm.rudder > 0.5 ? C.gr : C.txt);
  // ---------- status lamps ----------
  bezel(172, 2, 26, 40);
  const blink = (t * 4 | 0) % 2 === 0;
  [['ENG', s.engine, C.gr], ['MRD', s.status === 'docked', C.cy], ['THR', Helm.thruster !== 0, C.amb], ['LND', !!Helm.alarm && blink, C.rd], ['GAL', (G.Weather?.p.wind || 0) > 0.6, '#f2994a']]
    .forEach(([l, on, col], i) => { const y = 5 + i * 7; R(175, y, 4, 4, C.lo); R(176, y + 1, 2, 2, on ? col : '#2a3138'); if (on) R(176, y, 2, 1, '#ffffff55'); text(l, 181, y, on ? C.txt : C.dim); });
  // ---------- engine order telegraphs ----------
  for (let i = 0; i < 2; i++) {
    const T = GEO.tele[i], x = T.x; bezel(x, 46, 40, 92);
    text(T.name, x + 20 - tw(T.name) / 2, 50, T.col);
    const sx = i === 0 ? x + 28 : x + 6, labX = i === 0 ? x + 3 : x + 14;
    R(sx, GEO.slotTop - 2, 6, GEO.slotBot - GEO.slotTop + 4, C.lo); R(sx + 2, GEO.slotTop - 1, 2, GEO.slotBot - GEO.slotTop + 2, '#000');
    for (const d of DETENTS) { const y = detentY(d[0]), sel = detentOf(Helm.thr[i])[0] === d[0]; const lab = SHORT[d[1]];
      R(i === 0 ? sx - 2 : sx + 6, y, 2, 1, d[0] === 0 ? C.brass : C.dim); text(lab, labX, y - 2, sel ? (d[0] < 0 ? C.yl : d[0] > 0 ? C.cy : C.brass) : d[0] === 0 ? C.brassD : C.dim); }
    R(i === 0 ? sx - 3 : sx + 7, GEO.slotTop - 1, 1, (GEO.slotBot - GEO.slotTop) / 2, '#2f6f84'); R(i === 0 ? sx - 3 : sx + 7, GEO.slotTop + (GEO.slotBot - GEO.slotTop) / 2 + 1, 1, (GEO.slotBot - GEO.slotTop) / 2, '#7a5a1a'); // ahead / astern sectors
    // lever handle (moves smoothly toward the ordered detent)
    const shown = (T.shown ??= Helm.thr[i]); T.shown += (Helm.thr[i] - shown) * 0.3; const ly = detentY(T.shown);
    R(sx - 1, ly - 3, 8, 6, C.lo); R(sx, ly - 2, 6, 4, T.col); R(sx, ly - 2, 6, 1, '#ffffff66'); R(sx + 1, ly + 1, 4, 1, '#00000055');
    // shaft revs + gear
    const r = Helm.rpm[i]; R(x + 4, 125, 32, 4, C.lo); R(x + 5, 126, Math.round(Math.abs(r) * 30), 2, r < 0 ? C.yl : C.cy);
    const gear = Helm.shift[i] > 0 ? (blink ? 'SHFT' : '') : Helm.gear[i] > 0 ? 'AHD' : Helm.gear[i] < 0 ? 'AST' : 'NEUT'; text(gear, x + 20 - tw(gear) / 2, 132, Helm.gear[i] ? C.txt : C.dim);
  }
  // ---------- ship's wheel (8 spokes, turned rim, brass hub) ----------
  const W = GEO.wheel, ang = Helm.wheel * Math.PI * 3; // ±1.5 turns lock to lock
  bezel(48, 46, 104, 92, '#24303a');
  R(W.x - 3, W.y + W.r - 2, 7, 138 - (W.y + W.r) - 2, C.bez); // pedestal
  for (let k = 0; k < 8; k++) { const a = ang + k * Math.PI / 4, ca = Math.cos(a), sa = Math.sin(a);
    line(W.x + ca * 4, W.y + sa * 4, W.x + ca * (W.r - 2), W.y + sa * (W.r - 2), C.woodD); line(W.x + ca * 4 + 0.6, W.y + sa * 4 + 0.6, W.x + ca * (W.r - 2) + 0.6, W.y + sa * (W.r - 2) + 0.6, C.wood);
    const hx = W.x + ca * (W.r + 4), hy = W.y + sa * (W.r + 4); line(W.x + ca * (W.r + 1), W.y + sa * (W.r + 1), hx, hy, C.woodD); R(Math.round(hx) - 1, Math.round(hy) - 1, 3, 3, k === 0 ? C.brass : C.wood); P(hx, hy - 1, C.woodL); }
  for (const [d, col] of [[0, C.woodD], [-1, C.wood], [-2, C.wood], [-3, C.woodD]]) ring(W.x, W.y, W.r + d, col);
  ring(W.x, W.y, W.r - 1, C.woodL, Math.PI * 1.1, Math.PI * 1.6); // highlight
  disc(W.x, W.y, 4, C.brassD); disc(W.x, W.y, 3, C.brass); P(W.x - 1, W.y - 1, '#fff2c0'); P(W.x, W.y, C.brassD);
  // midships mark on the top spoke handle + order readout
  const ord = Math.round(Helm.wheel * 35), ol = ord === 0 ? 'MID' : (ord < 0 ? 'P' : 'S') + Math.abs(ord); text(ol, W.x - tw(ol) / 2, 49, ord === 0 ? C.brass : ord < 0 ? C.rd : C.gr);
  if (Helm.thruster) { const dir = Helm.thruster; for (let k = 0; k < 3; k++) { const ax = W.x + dir * (40 + k * 3); line(ax, 128, ax + dir * 2, 130, C.amb); line(ax, 132, ax + dir * 2, 130, C.amb); } }
  if (Helm.alarm && blink) { R(52, 128, 30, 7, '#5a1a16'); text('LAND', 54, 129, C.rd); }
}
