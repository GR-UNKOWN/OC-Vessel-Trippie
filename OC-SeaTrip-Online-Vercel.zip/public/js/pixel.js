// Procedural pixel-art generators (code-drawn, no generated images): clouds, trees, islands, skylines, default OC sprites.
import { rng, makeCanvas, hexToRgb, clamp } from './util.js';

// Bayer 4x4 dither
const BAYER = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5].map(v => (v + 0.5) / 16);
const dith = (x, y) => BAYER[(y & 3) * 4 + (x & 3)];

function paintClumps(w, h, clumps, palette, opts = {}) {
  // clumps: [{x,y,rx,ry}] ; palette: array of hex from dark->light
  const [c, ctx] = makeCanvas(w, h);
  const img = ctx.createImageData(w, h); const d = img.data;
  const pal = palette.map(hexToRgb);
  const R = rng(opts.seed || 7);
  const noise = new Float32Array(w * h); for (let i = 0; i < noise.length; i++) noise[i] = R();
  const light = opts.light || [-0.5, -0.8];
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    let best = -1, bv = 0;
    for (let i = clumps.length - 1; i >= 0; i--) {
      const k = clumps[i]; const dx = (x - k.x) / k.rx, dy = (y - k.y) / k.ry; const q = dx * dx + dy * dy;
      // jagged edge
      if (q < 1 - (noise[y * w + x] * (opts.rough ?? 0.35))) { best = i; bv = (-dx * light[0] - dy * light[1]) * 0.5 + 0.5 - q * 0.25; break; }
    }
    if (best < 0) continue;
    const k = clumps[best];
    let t = clamp(bv + (k.tone || 0) + (noise[y * w + x] - 0.5) * 0.25, 0, 0.999);
    t = t * pal.length; let idx = Math.floor(t); const f = t - idx;
    if (f > dith(x, y) && idx < pal.length - 1 && opts.dither !== false) idx++;
    idx = clamp(idx, 0, pal.length - 1);
    const p = pal[idx]; const o = (y * w + x) * 4; d[o] = p[0]; d[o + 1] = p[1]; d[o + 2] = p[2]; d[o + 3] = 255;
  }
  ctx.putImageData(img, 0, 0);
  return c;
}

export function cloud(seed, w = 90, h = 34, palette = ['#c9d8e6', '#e3edf5', '#f6f9fc', '#ffffff']) {
  const R = rng(seed); const clumps = [];
  const n = 5 + Math.floor(R() * 5);
  for (let i = 0; i < n; i++) {
    const rx = 8 + R() * (w * 0.18), ry = rx * (0.6 + R() * 0.3);
    const x = rx + R() * (w - rx * 2), y = h - ry - R() * (h * 0.35);
    clumps.push({ x, y, rx, ry, tone: (h - y) / h * 0.15 });
  }
  clumps.push({ x: w / 2, y: h - 4, rx: w / 2 - 2, ry: 5, tone: -0.1 });
  return paintClumps(w, h, clumps, palette, { seed, rough: 0.25, light: [-0.2, -1] });
}

export function streakCloud(seed, w = 140, h = 6, color = '#eef4f8') {
  const R = rng(seed); const [c, ctx] = makeCanvas(w, h); ctx.fillStyle = color;
  let x = 0; for (let row = 0; row < h; row += 2) { const len = w * (0.4 + R() * 0.6); x = R() * (w - len); ctx.fillRect(x | 0, row, len | 0, 1); ctx.globalAlpha = 0.6; ctx.fillRect((x + 4) | 0, row + 1, (len * 0.7) | 0, 1); ctx.globalAlpha = 1; }
  return c;
}

export function pineTree(seed, scale = 1) {
  const R = rng(seed); const w = Math.round(70 * scale), h = Math.round(64 * scale);
  const [c, ctx] = makeCanvas(w, h);
  // trunk & branches
  const trunk = ['#4a3a32', '#6a5446', '#8a7262'];
  const tx = w * (0.4 + R() * 0.2);
  for (let y = h * 0.35; y < h; y++) {
    const off = Math.sin(y * 0.08 + seed) * 2;
    ctx.fillStyle = trunk[1]; ctx.fillRect((tx + off) | 0, y | 0, Math.max(3, 4 * scale) | 0, 1);
    ctx.fillStyle = trunk[0]; ctx.fillRect((tx + off) | 0, y | 0, 1, 1);
  }
  const clumps = [];
  const layers = 3 + Math.floor(R() * 2);
  for (let i = 0; i < layers; i++) {
    const y = h * 0.12 + i * (h * 0.16);
    const spread = (w * 0.22) + i * w * 0.05;
    for (let j = 0; j < 3; j++) {
      const x = tx + (j - 1) * spread * (0.7 + R() * 0.4);
      clumps.push({ x, y: y + R() * 4, rx: 10 * scale + R() * 8 * scale, ry: 5 * scale + R() * 3 * scale, tone: 0.05 });
    }
  }
  const leaf = paintClumps(w, h, clumps, ['#2f5b46', '#3f7a4f', '#5a9a5a', '#86b866', '#b8d47c'], { seed, rough: 0.5, light: [-0.4, -1] });
  ctx.drawImage(leaf, 0, 0);
  return c;
}

export function sakuraTree(seed, scale = 1) {
  const R = rng(seed); const w = Math.round(64 * scale), h = Math.round(64 * scale);
  const [c, ctx] = makeCanvas(w, h);
  const tx = w / 2;
  ctx.fillStyle = '#5a4a4a';
  for (let y = h * 0.45; y < h; y++) ctx.fillRect((tx - 2 + Math.sin(y * 0.1) * 1.5) | 0, y | 0, 4, 1);
  ctx.fillStyle = '#6e5a58'; ctx.fillRect(tx - 1, h * 0.45, 1, h * 0.55);
  // branches
  ctx.fillStyle = '#5a4a4a';
  for (let i = 0; i < 4; i++) { const ang = -Math.PI / 2 + (i - 1.5) * 0.6; for (let k = 0; k < 14 * scale; k++) ctx.fillRect((tx + Math.cos(ang) * k) | 0, (h * 0.5 + Math.sin(ang) * k) | 0, 2, 1); }
  const clumps = [];
  for (let i = 0; i < 9; i++) clumps.push({ x: tx + (R() - 0.5) * w * 0.7, y: h * 0.22 + R() * h * 0.28, rx: 9 * scale + R() * 7 * scale, ry: 7 * scale + R() * 5 * scale, tone: 0 });
  ctx.drawImage(paintClumps(w, h, clumps, ['#a8667f', '#c77e98', '#df9db3', '#f0c0cf', '#fbe1e8'], { seed, rough: 0.55 }), 0, 0);
  return c;
}

export function palmTree(seed, scale = 1) {
  const R = rng(seed); const w = Math.round(50 * scale), h = Math.round(64 * scale);
  const [c, ctx] = makeCanvas(w, h);
  const lean = (R() - 0.5) * 14 * scale; let topx = w / 2, topy = h * 0.25;
  for (let i = 0; i <= 40; i++) {
    const t = i / 40; const x = w / 2 + lean * t * t, y = h - t * (h * 0.75);
    ctx.fillStyle = i % 3 ? '#8a6a4e' : '#6a503c'; ctx.fillRect((x - 1.5) | 0, y | 0, 3, 2);
    topx = x; topy = y;
  }
  const greens = ['#2f6a3c', '#3e8a46', '#5aa64e', '#8cc461'];
  for (let f = 0; f < 7; f++) {
    const a = Math.PI + (f / 6) * Math.PI + (R() - 0.5) * 0.3;
    const len = (14 + R() * 8) * scale;
    for (let k = 0; k < len; k++) {
      const x = topx + Math.cos(a) * k, y = topy + Math.sin(a) * k * 0.6 + (k * k) / (len * 3.5);
      ctx.fillStyle = greens[1 + (k % 3 === 0 ? 1 : 0)]; ctx.fillRect(x | 0, y | 0, 2, 1);
      if (k % 2 === 0) { ctx.fillStyle = greens[0]; ctx.fillRect(x | 0, (y + 1) | 0, 1, 2); ctx.fillStyle = greens[3]; ctx.fillRect((x + 1) | 0, (y - 1) | 0, 1, 1); }
    }
  }
  ctx.fillStyle = '#6a503c'; ctx.fillRect(topx - 2, topy, 4, 3);
  return c;
}

export function bush(seed, w = 30, h = 14, pal = ['#2f5b46', '#3f7a4f', '#6aa65a', '#a8cc6e']) {
  const R = rng(seed); const cl = [];
  for (let i = 0; i < 5; i++) cl.push({ x: 5 + R() * (w - 10), y: h - 4 - R() * 4, rx: 5 + R() * 5, ry: 4 + R() * 3 });
  return paintClumps(w, h, cl, pal, { seed, rough: 0.5 });
}

// Wide tiling mountain / island silhouette strip
export function ridge(seed, w, h, pal, opts = {}) {
  const R = rng(seed); const [c, ctx] = makeCanvas(w, h);
  const img = ctx.createImageData(w, h), d = img.data; const P = pal.map(hexToRgb);
  const peaks = []; const n = opts.peaks || 6;
  for (let i = 0; i < n; i++) peaks.push({ x: R() * w, hgt: h * (0.35 + R() * 0.6), wid: w * (0.08 + R() * 0.16) });
  const top = new Float32Array(w);
  for (let x = 0; x < w; x++) {
    let y = h * (opts.base ?? 0.85);
    for (const p of peaks) { for (const off of [-w, 0, w]) { const dx = (x - p.x - off) / p.wid; const v = opts.karst ? Math.max(0, 1 - Math.pow(Math.abs(dx), 6)) : Math.max(0, 1 - dx * dx); y = Math.min(y, h - p.hgt * v); } }
    top[x] = y + Math.sin(x * 0.3 + seed) * 0.8 + (R() - 0.5) * 1.2;
  }
  for (let x = 0; x < w; x++) for (let y = Math.max(0, top[x] | 0); y < h; y++) {
    const slope = (top[(x + 1) % w] - top[(x + w - 1) % w]);
    let t = clamp(0.55 - slope * 0.15 - (y - top[x]) / h * 0.6, 0, 0.999) * P.length;
    let i = Math.floor(t); if (t - i > dith(x, y) && i < P.length - 1) i++;
    const p = P[clamp(i, 0, P.length - 1)]; const o = (y * w + x) * 4; d[o] = p[0]; d[o + 1] = p[1]; d[o + 2] = p[2]; d[o + 3] = 255;
  }
  ctx.putImageData(img, 0, 0);
  return c;
}

export function skyline(seed, w, h, pal = ['#a9cbe0', '#bcd8ea', '#d3e6f2', '#e9f3f9']) {
  const R = rng(seed); const [c, ctx] = makeCanvas(w, h);
  let x = 0;
  while (x < w) {
    const bw = 8 + (R() * 18) | 0, bh = (h * (0.25 + R() * 0.7)) | 0;
    const tone = R() < 0.3 ? 0 : 1;
    ctx.fillStyle = pal[tone]; ctx.fillRect(x, h - bh, bw, bh);
    ctx.fillStyle = pal[tone + 1]; ctx.fillRect(x, h - bh, 2, bh);
    ctx.fillStyle = pal[3];
    for (let yy = h - bh + 3; yy < h - 2; yy += 3) for (let xx = x + 3; xx < x + bw - 2; xx += 3) if (R() < 0.55) ctx.fillRect(xx, yy, 1, 1);
    if (R() < 0.2) { ctx.fillStyle = pal[0]; ctx.fillRect(x + (bw >> 1), h - bh - 6, 1, 6); }
    x += bw + ((R() * 3) | 0);
  }
  return c;
}

export function pagoda(scale = 1, roof = '#b4544a', wall = '#efe6d6') {
  const w = 30 * scale, h = 42 * scale; const [c, ctx] = makeCanvas(w, h);
  for (let i = 0; i < 3; i++) {
    const y = h - 8 - i * 12 * scale, ww = (24 - i * 5) * scale, x = (w - ww) / 2;
    ctx.fillStyle = wall; ctx.fillRect(x + 3, y - 6 * scale, ww - 6, 8 * scale);
    ctx.fillStyle = '#7a5a4a'; ctx.fillRect(x + ww / 2 - 1, y - 4 * scale, 2, 6 * scale);
    ctx.fillStyle = roof; ctx.fillRect(x - 2, y - 8 * scale, ww + 4, 2 * scale); ctx.fillRect(x, y - 10 * scale, ww, 2 * scale);
    ctx.fillStyle = '#7e3a34'; ctx.fillRect(x - 2, y - 6 * scale, ww + 4, 1);
  }
  ctx.fillStyle = '#7e3a34'; ctx.fillRect(w / 2 - 0.5, 2, 1, 8 * scale);
  return c;
}
export function thaiTemple(scale = 1) {
  const w = 40 * scale, h = 40 * scale; const [c, ctx] = makeCanvas(w, h);
  ctx.fillStyle = '#f3ead8'; ctx.fillRect(6, h - 14, w - 12, 14);
  ctx.fillStyle = '#c8553d'; for (let i = 0; i < 3; i++) { const inset = 2 + i * 5; ctx.fillRect(inset, h - 16 - i * 6, w - inset * 2, 4); }
  ctx.fillStyle = '#e3b24c'; ctx.fillRect(w / 2 - 1, h - 36, 2, 10); ctx.fillRect(2, h - 18, 2, 3); ctx.fillRect(w - 4, h - 18, 2, 3);
  ctx.fillStyle = '#a07a3a'; for (let x = 10; x < w - 10; x += 5) ctx.fillRect(x, h - 10, 2, 8);
  return c;
}
export function lighthouse() {
  const [c, ctx] = makeCanvas(10, 34);
  for (let y = 6; y < 34; y++) { ctx.fillStyle = (Math.floor(y / 5) % 2) ? '#d65a4a' : '#f6f1e8'; const ww = 4 + (y - 6) / 8; ctx.fillRect(5 - ww / 2, y, ww, 1); }
  ctx.fillStyle = '#3c4a52'; ctx.fillRect(3, 2, 4, 4); ctx.fillStyle = '#ffe9a8'; ctx.fillRect(4, 3, 2, 2);
  return c;
}

/* ---------- Default OC pixel sprites (code-drawn) ---------- */
export const OC_PRESETS = [
  { name: 'นามิ', hair: '#5d8fb8', hairDark: '#3e6a8e', skin: '#f6d8c4', top: '#f4efe4', bottom: '#4f6f8c', eye: '#2b5d86', style: 'long' },
  { name: 'โซระ', hair: '#e9e4ec', hairDark: '#b9b0c4', skin: '#f8e0d0', top: '#7fb7c9', bottom: '#f2ede2', eye: '#3aa2b6', style: 'bob' },
  { name: 'ไค', hair: '#5a4034', hairDark: '#3d2a22', skin: '#e9c2a6', top: '#ffffff', bottom: '#2f3d4f', eye: '#4a3328', style: 'short', cap: true },
];
export function drawDefaultOC(p) {
  const W = 20, H = 34; const [c, x] = makeCanvas(W, H);
  const O = '#2c2a33';
  const r = (cx, cy, w, h, col) => { x.fillStyle = col; x.fillRect(cx, cy, w, h); };
  // legs & shoes
  r(7, 26, 3, 6, p.bottom); r(10, 26, 3, 6, p.bottom); r(6, 31, 4, 2, O); r(10, 31, 4, 2, O); r(7, 26, 1, 5, '#00000022');
  // body
  r(6, 17, 8, 10, p.top); r(5, 18, 1, 7, p.top); r(14, 18, 1, 7, p.top);
  r(6, 17, 8, 1, '#ffffff55'); r(13, 18, 1, 8, '#0000001a');
  if (p.cap) { r(9, 18, 2, 1, '#2f3d4f'); r(6, 21, 8, 1, '#d9c27a'); }
  r(4, 19, 2, 6, p.skin); r(14, 19, 2, 6, p.skin); // arms
  // head
  r(5, 5, 10, 11, p.skin); r(4, 7, 1, 7, p.skin); r(15, 7, 1, 7, p.skin);
  // hair
  r(4, 3, 12, 4, p.hair); r(3, 5, 2, 6, p.hair); r(15, 5, 2, 6, p.hair); r(5, 2, 10, 1, p.hair);
  r(6, 7, 3, 1, p.hair); r(11, 7, 2, 1, p.hair);
  if (p.style === 'long') { r(3, 10, 2, 12, p.hair); r(15, 10, 2, 12, p.hair); r(3, 18, 2, 4, p.hairDark); r(15, 18, 2, 4, p.hairDark); }
  if (p.style === 'bob') { r(3, 10, 2, 5, p.hair); r(15, 10, 2, 5, p.hair); r(3, 14, 2, 1, p.hairDark); r(15, 14, 2, 1, p.hairDark); }
  r(4, 3, 12, 1, p.hairDark); r(6, 4, 4, 1, '#ffffff44');
  if (p.cap) { r(4, 1, 12, 3, '#f4f4f4'); r(4, 3, 14, 1, '#2f3d4f'); r(9, 1, 2, 1, '#d9c27a'); }
  // eyes & mouth
  r(7, 10, 2, 2, p.eye); r(11, 10, 2, 2, p.eye); r(7, 10, 1, 1, '#ffffff'); r(11, 10, 1, 1, '#ffffff');
  r(6, 12, 1, 1, '#f2a7a0'); r(13, 12, 1, 1, '#f2a7a0'); r(9, 13, 2, 1, '#c77a70');
  // outline pass
  const id = x.getImageData(0, 0, W, H), d = id.data, out = new Uint8ClampedArray(d);
  const oc = hexToRgb(O);
  for (let yy = 0; yy < H; yy++) for (let xx = 0; xx < W; xx++) {
    const i = (yy * W + xx) * 4; if (d[i + 3] > 0) continue;
    const n = [[1, 0], [-1, 0], [0, 1], [0, -1]].some(([a, b]) => { const X = xx + a, Y = yy + b; return X >= 0 && Y >= 0 && X < W && Y < H && d[(Y * W + X) * 4 + 3] > 200; });
    if (n) { out[i] = oc[0]; out[i + 1] = oc[1]; out[i + 2] = oc[2]; out[i + 3] = 255; }
  }
  x.putImageData(new ImageData(out, W, H), 0, 0);
  return c;
}
