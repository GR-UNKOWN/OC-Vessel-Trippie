// Hidden scenario: the yacht founders. Started only by the room owner from the engine-room service panel
// (4-digit code) and only when the "ระบบลับ" setting is on. Deliberately silent — no announcements.
//
// Flooding model (per room, 20 px = 1 m) — water only ever comes from the SEA and never rises above it:
//   • A room takes water only when it is connected to the sea (the engine-room breach, a broken window, or an
//     open path from a flooded neighbour on its deck / through a stairwell) AND its floor is below the surface.
//     Inside, the water stands level with the outside sea; it can't climb higher than the sea does.
//   • The weight of that water settles and trims the hull (stern-down), which puts more rooms under the
//     surface — progressive flooding — until she loses her reserve buoyancy and plunges.
//   • Every room starts full of air. Water entering compresses that air (Boyle: V = n / P, P = 1 + depth/10 atm),
//     so a room that is sealed keeps an AIR POCKET under its ceiling that shrinks as the hull goes deeper.
//   • Air escapes through doors/stairs (open rooms vent fast) or barely at all (sealed rooms: cinema, baths, stores).
//   • Inflow speed follows the water pressure at the opening (∝ √depth). Glass gives way at its pressure limit
//     (big panes ≈ 1.5 m, portholes ≈ 4 m): shards blow in, jets roar through, the trapped air bursts out as
//     a column of bubbles that rises to the surface.
//   • Deep down, compartments that still hold air implode. The hull trims by the stern, settles, then plunges.
//   • Anyone whose head is under water loses breath; an air pocket lets you breathe again.
import { Bus, clamp, lerp, el } from './util.js';
import { ROOMS, LEVELS, FIXTURES, SPEC, YW, YH, WL, ROOM_WINDOWS, STAIRS, YACHTS } from './yacht.js';
import { G } from './main.js';
import { Audio } from './audio.js';
import { heliSprite } from './heli.js';

const PLUNGE = 22;
export const SINK_CODE = '1912';
const SEALED = new Set(['cinema', 'bath', 'utility', 'captain']);
const sstep = x => x * x * (3 - 2 * x);
const M_PER_PX = 1 / 20, BREATH_S = 14;
const fx = []; // shards, jets, bubbles, debris (world coords unless .yacht)

export const Sink = {
  active: false, T: 0, plan: null, savedLights: null, noiseT: 0, done: false, restored: false, M: 0,

  canStart() { return !G.coop?.guest && G.settings.secretSink !== false && !this.active; },
  start(T0 = 0) {
    if (this.active) return;
    const inRooms = ROOMS.filter(r => r.type === 'in');
    const eng = inRooms.find(r => r.kind === 'engine') || inRooms[0];
    this.plan = inRooms.map(r => {
      const wins = (ROOM_WINDOWS[r.id] || []).map(([x, y, w, h]) => ({ x, y, w, h, limit: (w * h > 150 ? 1.5 : 4) / M_PER_PX, broken: false }));
      return { r, area: (r.x2 - r.x1) * 40, f: 0, n: 1, sealed: SEALED.has(r.kind), open: r === eng, openT: 0, wins, imploded: false, nb: [], up: [], down: [] };
    });
    // who touches whom: neighbours along a deck (doors), and decks linked by stairwells
    const at = (lv, x) => this.plan.find(p => p.r.level === lv && x >= p.r.x1 - 1 && x <= p.r.x2 + 1);
    for (const p of this.plan) for (const q of this.plan) if (p !== q && p.r.level === q.r.level && (Math.abs(p.r.x2 - q.r.x1) <= 2 || Math.abs(q.r.x2 - p.r.x1) <= 2)) p.nb.push(q);
    for (const st of STAIRS) { const lo = LEVELS[st.a]?.y > LEVELS[st.b]?.y ? at(st.a, st.ax) : at(st.b, st.bx), hi = lo === at(st.a, st.ax) ? at(st.b, st.bx) : at(st.a, st.ax); if (lo && hi && lo !== hi) { lo.up.push(hi); hi.down.push(lo); } }
    const lowY = Math.max(...inRooms.map(r => LEVELS[r.level].y));
    this.lowArea = this.plan.filter(p => LEVELS[p.r.level].y === lowY).reduce((a, p) => a + p.area, 0) || 1;
    this.totArea = this.plan.reduce((a, p) => a + p.area, 0) || 1;
    fx.length = 0;
    this.savedLights = { ...G.lights };
    this.rescue = null; G.rescueHeli = null; this.bindClip?.(false);
    this.active = true; this.T = 0; this.done = false; this.restored = false; this.noiseT = 2; this.M = 0; this.plunged = false; this.dy = 0; this.ang = 0; this.ending = null;
    G.sink = { ang: 0, dy: 0, T: 0 }; G.breath = 1;
    if (T0 > 0) for (let k = 0; k < T0 / 0.25; k++) this.step(0.25, true); // co-op guest joining late: catch up
    Audio.creak?.(1);
  },
  stop(restoreNow = true) {
    if (!this.active) return;
    this.active = false; G.sink = null; fx.length = 0; G.breath = 1; setVignette(0);
    if (this.rescue) { const p = G.player; if (p) { p.inHeli = false; p.hoist = null; } } this.bindClip(false); this.rescue = null; G.rescueHeli = null; Audio.rotor?.(0, 0);
    for (const ch of G.chars || []) { ch.wade = 1; ch.underT = 0; }
    if (restoreNow) restoreWorld(this.savedLights);
  },
  /* ---------- geometry: yacht-space point → world (same transform the renderer uses) ---------- */
  world(x, y) { const s = G.sink || { ang: 0, dy: 0 }; const ca = Math.cos(s.ang), sa = Math.sin(s.ang), dx = x - YW / 2, dy = y - WL; return [YW / 2 + dx * ca - dy * sa, WL + dx * sa + dy * ca + s.dy]; },
  depth(x, y) { return this.world(x, y)[1] - WL; }, // px below the sea surface (negative = above)
  update(dt) {
    if (!this.active) return;
    if (G.settings.secretSink === false) { this.stop(true); return; }
    this.step(dt, false);
  },
  step(dt, silent) {
    const T = (this.T += dt);
    /* ---- rooms: water comes only from the sea and stands level with it ---- */
    let Vw = 0, mom = 0;
    for (const p of this.plan) {
      const r = p.r, fy = LEVELS[r.level].y, cx = (r.x1 + r.x2) / 2;
      const dFloor = this.depth(cx, fy), dTop = this.depth(cx, fy - 40), dMid = (dFloor + dTop) / 2;
      // glass fails at its pressure limit once the sea is outside it
      for (const w of p.wins) if (!w.broken && this.depth(w.x + w.w / 2, w.y + w.h / 2) > w.limit && p.f < 0.97) {
        w.broken = true; p.open = true; p.vent = 0.7; if (!silent) { breakGlass(this, w); Audio.crack?.(); }
      }
      // doors and stairwells: a flooded neighbour opens the way (after the door gives, a few seconds)
      if (!p.open) {
        const wet = p.nb.some(q => q.open && q.f > 0.03) || p.down.some(q => q.open && q.f > 0.97) || p.up.some(q => q.open && q.f > 0.05);
        if (wet) { p.openT += dt; if (p.openT > (p.sealed ? 9 : 3)) p.open = true; }
      }
      if (!p.imploded && p.n > 0.35 && dMid > 18 / M_PER_PX) { p.imploded = true; p.open = true; p.vent = 1.5; if (!silent) { implode(this, p); Audio.boom?.(); } }
      // the most the room can hold right now: everything below the outside sea surface…
      const belowSea = clamp(dFloor / 40, 0, 1);
      // …minus the trapped air, squeezed by the pressure at the pocket (Boyle)
      const P = 1 + Math.max(0, dMid) * M_PER_PX / 10;
      const vent = p.vent || (p.open ? (p.sealed ? 0.004 : 0.1) : 0);
      p.n = Math.max(0, p.n - p.n * vent * dt);
      const target = p.open ? Math.min(belowSea, 1 - clamp(p.n / P, 0, 1)) : 0;
      // inflow ∝ √(pressure head); outflow too if the room now sits above the sea
      const head = Math.max(0.2, Math.abs(target - p.f) * 40 * M_PER_PX + Math.max(0, dFloor) * M_PER_PX);
      p.f = clamp(p.f + (target - p.f) * clamp(dt * (p.f < target ? 0.07 : 0.2) * Math.sqrt(head), 0, 1), 0, 1);
      if (p.vent > 0.2) p.vent = Math.max(0.1, p.vent - dt * 0.25);
      if (!silent && dTop > 0 && p.open && p.n > 0.02 && Math.random() < dt * (2 + vent * 30)) { const [wx, wy] = this.world(r.x1 + Math.random() * (r.x2 - r.x1), fy - 40); bubble(wx, wy, 1 + Math.random() * 2); }
      Vw += p.f * p.area; mom += p.f * p.area * (YW / 2 - cx);
    }
    const M = Vw / this.totArea; this.M = M;
    /* ---- hull: the water's weight settles her and trims her by the stern ---- */
    const dyEq = 3 + Vw / this.lowArea * 38 + T * 0.04;              // slow loss of reserve buoyancy keeps it moving
    const angEq = -0.01 - mom / (this.totArea * YW) * 1.4;
    this.dy += (dyEq - this.dy) * clamp(dt * 0.35, 0, 1); this.ang += (angEq - this.ang) * clamp(dt * 0.3, 0, 1);
    if (!this.plunged && (M > 0.42 || T > 170)) { this.plunged = true; this.plungeT = T; this.dyA = this.dy; this.angA = this.ang; if (!silent) { Audio.boom?.(); for (let i = 0; i < 40; i++) setTimeout(() => this.active && bubble(YW * 0.15 + Math.random() * YW * 0.7, WL + 20 + Math.random() * 40, 2 + Math.random() * 2), i * 60); } }
    let ang = this.ang, dy = this.dy;
    if (this.plunged) { const u = clamp((T - this.plungeT) / PLUNGE, 0, 1), e = u * u; ang = lerp(this.angA, -0.42, sstep(u)); dy = this.dyA + e * (YH + 180); }
    G.sink.ang = ang; G.sink.dy = dy; G.sink.T = T;
    if (silent) return;
    /* ---- electrics ---- */
    if (!G.coop?.guest) {
      for (const p of this.plan) if (p.f > 0.45) for (const f of FIXTURES) if (f.room === p.r.id) G.lights[f.id] = false;
      if (M > 0.55) for (const f of FIXTURES) G.lights[f.id] = M < 0.62 ? Math.random() < 0.3 && this.savedLights[f.id] : false;
    }
    if ((this.noiseT -= dt) <= 0) { this.noiseT = 4 + Math.random() * (8 - M * 5); Audio.creak?.(0.5 + M + Math.max(0, dy) / 200); }
    /* ---- people: wading, breath, drowning ---- */
    for (const ch of G.chars) {
      if (ch.swim || ch.lost || G.onTender?.(ch) || ch.inHeli || ch.hoist) { ch.wade = 1; continue; }
      const p = !ch.stair && this.plan.find(p => p.r.level === ch.level && ch.x >= p.r.x1 && ch.x < p.r.x2);
      const fy = LEVELS[ch.level]?.y ?? 0; const lvl = p ? this.surfaceY(p, ch.x) : 1e9; // yacht-space water surface
      const head = fy - (ch.spr?.h || 34) + 4, waist = fy - (ch.spr?.h || 34) * 0.45;
      // decks open to the sea: under once the deck itself is below the surface
      const outsideUnder = !p && this.depth(ch.x, head) > 2;
      const under = outsideUnder || lvl < head;
      ch.wade = under ? 0.45 : lvl < waist ? 0.6 : 1;
      ch.underT = under ? (ch.underT || 0) + dt : Math.max(0, (ch.underT || 0) - dt * 2);
      if (under && Math.random() < dt * 3) { const [wx, wy] = this.world(ch.x, head); bubble(wx, wy, 0.6); }
      if (ch.underT > BREATH_S) { ch.lost = true; ch.wade = 1; if (ch === G.player) setVignette(1); }
    }
    if (G.player && !this.ending) { const b = clamp(1 - (G.player.underT || 0) / BREATH_S, 0, 1); G.breath = b; setVignette(G.player.lost ? 1 : (1 - b) * 0.85); }
    /* ---- crew climbs toward the highest dry deck ---- */
    if (!G.coop) for (const ch of G.chars) {
      if (ch === G.player || ch.swim || ch.lost || G.onTender?.(ch) || ch.mode !== 'bot') continue;
      if ((ch.fleeT = (ch.fleeT ?? 0) - dt) > 0) continue; ch.fleeT = 3 + Math.random() * 3;
      const here = this.plan.find(p => p.r.level === ch.level && ch.x >= p.r.x1 && ch.x < p.r.x2);
      if (here && here.f > 0.15) { const top = ROOMS.filter(r => r.type === 'out').sort((a, b) => LEVELS[a.level].y - LEVELS[b.level].y)[0]; if (top) G.party.goto(ch, top.level, (top.x1 + top.x2) / 2 + (Math.random() - 0.5) * 30); }
    }
    this.updateRescue(dt);
    /* ---- the end: cut straight to one of the endings ---- */
    if (!this.ending && G.player) {
      if (G.player.inHeli && this.rescue?.phase === 'depart' && this.rescue.t > 2.2) this.end('rescued');
      else if (G.player.lost) this.end('drowned');                                         // ran out of air aboard
      else if (this.plunged && T >= this.plungeT + PLUNGE * 0.75 && !G.player.inHeli && this.rescue?.phase !== 'hoist') this.end(G.onTender?.(G.player) ? 'survived' : 'drowned');
    }
    /* ---- particles ---- */
    for (const q of fx) {
      q.t += dt;
      if (q.kind === 'bubble') { q.vy = Math.max(q.vy - 40 * dt, -46); q.y += q.vy * dt; q.x += Math.sin(q.t * 5 + q.ph) * 6 * dt; if (q.y <= WL + 1) { q.dead = true; if (Math.random() < 0.3) foam(q.x); } }
      else if (q.kind === 'debris') { q.y = Math.max(WL + 1, q.y - 22 * dt); q.x += Math.sin(T * 0.4 + q.ph) * 3 * dt; }
      else { q.x += q.vx * dt; q.y += q.vy * dt; q.vx *= 0.92; q.vy *= 0.92; }
      if (q.t > q.life) q.dead = true;
    }
    for (let i = fx.length - 1; i >= 0; i--) if (fx[i].dead) fx.splice(i, 1);
  },
  /* ---------- SOS: the wheelhouse radio calls a rescue helicopter ---------- */
  radioOk() { const p = this.plan?.find(p => p.r.kind === 'wheelhouse'); return !p || p.f < 0.55; },
  sos() {
    if (!this.active || this.rescue || this.ending) return false;
    if (!this.radioOk()) return 'dead';
    // the crew only get the yacht's position, not where you are aboard: they come in from the horizon, hover over
    // the highest open deck the hoist line can reach, lower the rescue strop and wait. You have to get to it.
    this.rescue = { phase: 'inbound', t: 0, x: YW + 1700, y: -420, cable: 0, face: -1, target: null, retarget: 0 }; G.rescueHeli = this.rescue;
    this.pickHover(true); this.bindClip(true);
    return true;
  },
  // open deck with clear sky above (line can reach), deck still above water; highest first, helideck/sundeck preferred
  pickHover(force) {
    const H = this.rescue; if (!H) return;
    const cands = [];
    for (const r of ROOMS) {
      if (r.io !== 'out' || r.stair || r.x2 - r.x1 < 30 || r.kind === 'swim' || r.kind === 'lifeboat' || r.kind === 'liferaft') continue;
      const fy = LEVELS[r.level]?.y; if (fy == null) continue; const cx = r.kind === 'flybridge' || r.kind === 'mastdeck' ? r.x1 + (r.x2 - r.x1) * 0.22 : (r.x1 + r.x2) / 2; // keep the line clear of the radar mast
      const roofed = ROOMS.some(q => q !== r && LEVELS[q.level]?.y < fy && q.x1 < cx + 8 && q.x2 > cx - 8);
      if (roofed) continue;
      const [, wy] = this.world(cx, fy); if (wy > WL - 6) continue;                                // awash
      cands.push({ r, cx, fy, score: fy - (r.kind === 'helideck' ? 400 : r.kind === 'foredeck' ? 200 : r.kind === 'sundeck' ? 10 : 0) });
    }
    cands.sort((a, b) => a.score - b.score);
    const best = cands[0] ? { room: cands[0].r, x: cands[0].cx, fy: cands[0].fy } : { room: null, x: YW + 80, fy: null }; // nothing left: hover beside the wreck, line in the water
    if (force || !H.target || H.target.room !== best.room) { H.target = best; if (!force) H.moved = (H.moved || 0) + 1; }
  },
  // where the strop should hang: on the target deck (yacht frame → sea frame), or at the sea surface
  stropGoal() { const T = this.rescue.target; if (T.room) return this.world(T.x, T.fy); return [T.x, WL]; },
  playerFeet() {
    const p = G.player; if (!p) return null;
    if (G.onTender?.(p)) return [G.tender.x, G.tender.y - 4];
    if (p.swim) return [p.swim.x, p.swim.y];
    if (p.stair) return null; const fy = LEVELS[p.level]?.y; if (fy == null) return null; return this.world(p.x, fy);
  },
  bindClip(on) {
    if (on && !this._clipKey) { this._clipKey = e => { if ((e.key === 'e' || e.key === 'E' || e.key === 'Enter') && this.canClip) { e.preventDefault(); this.clip(); } }; addEventListener('keydown', this._clipKey); }
    if (!on) { if (this._clipKey) removeEventListener('keydown', this._clipKey); this._clipKey = null; this._clipBtn?.remove(); this._clipBtn = null; this.canClip = false; }
  },
  showClip(show) {
    if (show && !this._clipBtn) { const b = this._clipBtn = el('button', { class: 'hoist-btn', onclick: () => this.clip() }, 'เกี่ยวสายรอกเข้ากับตัว (E)'); document.body.append(b); }
    if (!show && this._clipBtn) { this._clipBtn.remove(); this._clipBtn = null; }
  },
  clip() {
    const H = this.rescue, p = G.player; if (!H || H.phase !== 'wait' || !this.canClip || !p) return;
    H.phase = 'hoist'; H.t = 0; H.len0 = H.cable; this.canClip = false; this.showClip(false); Audio.click?.(300);
    p.path = []; p.stair = null; p.state = 'idle';
  },
  updateRescue(dt) {
    const H = this.rescue; if (!H) return; H.t += dt; const p = G.player;
    if ((H.retarget -= dt) <= 0 && H.phase !== 'hoist' && H.phase !== 'depart') { H.retarget = 2.5; this.pickHover(false); }
    const [gx, gy] = H.phase === 'hoist' || H.phase === 'depart' ? [H.x, H.y + 160] : this.stropGoal();
    const hoverY = Math.min(gy - 130, WL - 120), sway = Math.sin(G.time * 0.7) * 6;
    this.canClip = false;
    if (H.phase === 'inbound') {
      const dx = gx - H.x, dy = hoverY - H.y, d = Math.hypot(dx, dy); const sp = Math.min(190, 40 + d * 0.4);
      H.x += dx / Math.max(1, d) * sp * dt; H.y += dy / Math.max(1, d) * sp * dt; H.face = dx < 0 ? -1 : 1; H.pitch = clamp(dx / 900, -0.14, 0.14);
      if (d < 6) { H.phase = 'wait'; H.t = 0; }
    } else if (H.phase === 'wait') {
      // station-keep over the deck (with a little drift in the downwash) and pay the strop out to deck level
      H.x = lerp(H.x, gx + sway, dt * 1.2); H.y = lerp(H.y, hoverY, dt * 1.5); H.pitch = lerp(H.pitch || 0, clamp((gx - H.x) / 600, -0.08, 0.08), dt * 3);
      const need = Math.max(10, gy - 3 - (H.y + 18)); H.cable = H.cable < need ? Math.min(need, H.cable + 60 * dt) : lerp(H.cable, need, dt * 2);
      const f = this.playerFeet(), sx = H.x, sy = H.y + 18 + H.cable;
      if (f && p && !p.lost && !p.inHeli && H.cable > need - 6 && Math.abs(f[0] - sx) < 12 && sy > f[1] - 40 && sy < f[1] + 8) this.canClip = true;
    } else if (H.phase === 'hoist') {
      H.cable = Math.max(0, H.len0 * (1 - H.t / 3)); H.pitch = lerp(H.pitch || 0, 0, dt * 3);
      if (p) p.hoist = { x: H.x, y: H.y + 18 + H.cable };
      if (H.t > 3 && p) { p.inHeli = true; p.hoist = null; if (G.tender.rider === p.id) G.tender.rider = null; p.swim = null; H.phase = 'depart'; H.t = 0; }
    } else if (H.phase === 'depart') {
      H.x += 150 * dt * (H.face || 1); H.y -= 40 * dt; H.pitch = 0.12 * (H.face || 1);
    }
    this.showClip(this.canClip);
    if (H.y > WL - 160 && Math.random() < dt * 30) bubbleSpray(H.x + (Math.random() - 0.5) * 80);
    const near = clamp(1 - Math.hypot(H.x - G.cam.x, H.y - G.cam.y) / 2600, 0.05, 1); Audio.rotor?.(near, 1);
  },
  rescueStatus() {
    const H = this.rescue; if (!H) return null;
    if (H.phase === 'inbound') return 'Rescue 1-1: กำลังบินเข้าหาตำแหน่งเรือ เราไม่เห็นตัวคุณ — ออกไปที่ดาดฟ้าโล่งชั้นบนสุด';
    if (H.phase === 'wait') return `Rescue 1-1: ลอยลำเหนือ${H.target?.room ? H.target.room.th || 'ดาดฟ้าบน' : 'ทะเลข้างเรือ'} หย่อนสายรอกแล้ว — ไปที่ปลายสายแล้วเกี่ยวเข้ากับตัวเอง`;
    if (H.phase === 'hoist') return 'Rescue 1-1: กำลังกว้านขึ้น';
    return 'Rescue 1-1: รับตัวแล้ว กำลังกลับฐาน';
  },
  drawRescue(c) {
    const H = this.rescue; if (!H) return; const im = heliSprite('skyblue');
    c.save(); c.translate(Math.round(H.x), Math.round(H.y)); c.rotate(H.pitch || 0); if ((H.face || 1) > 0) c.scale(-1, 1);
    c.drawImage(im.cv, -Math.round(im.ax), -Math.round(im.ay));
    const bl = 94 * Math.abs(Math.cos(G.time * 31)); c.fillStyle = 'rgba(60,66,72,0.35)'; c.fillRect(-94, -77, 188, 1); c.fillStyle = '#3f474f'; c.fillRect(-Math.round(bl), -78, Math.round(bl * 2), 2); c.restore();
    if (H.cable > 0) { const x = Math.round(H.x), y0 = Math.round(H.y + 18), y1 = Math.round(H.y + 18 + H.cable); c.fillStyle = '#2a2e33'; c.fillRect(x, y0, 1, y1 - y0);
      if (H.phase !== 'hoist') { c.fillStyle = '#ef7a2e'; c.fillRect(x - 4, y1 - 2, 9, 3); c.fillRect(x - 4, y1 - 6, 2, 4); c.fillRect(x + 3, y1 - 6, 2, 4); c.fillStyle = '#c9a964'; c.fillRect(x - 1, y1 - 4, 3, 2);
        if (this.canClip) { c.strokeStyle = `rgba(255,214,102,${0.5 + 0.4 * Math.sin(G.time * 6)})`; c.lineWidth = 1; c.strokeRect(x - 7.5, y1 - 9.5, 16, 12); } } }
  },
  end(kind) {
    this.ending = kind; setVignette(0);
    const aboard = G.chars;
    const saved = G.chars.filter(c => G.onTender?.(c) || (c === G.player && c.inHeli)).length;
    showEnding(kind, { T: this.T, saved, total: aboard.length, yacht: YACHTS[G.yachtId]?.name || 'เรือ', place: G.env?.near?.port?.th || 'ทะเลเปิด' }, () => this.stop(true));
  },
  // yacht-space water surface height in a room at x (kept level with the real horizon while the hull tilts)
  surfaceY(p, x) { const fy = LEVELS[p.r.level].y, cx = (p.r.x1 + p.r.x2) / 2; return fy - p.f * 40 + (x - cx) * Math.tan(-(G.sink?.ang || 0)); },
  roomFill(roomId) { if (!this.active) return 0; const p = this.plan.find(p => p.r.id === roomId); return p ? p.f : 0; },

  /* ---------- drawing inside the hull (yacht space) ---------- */
  draw(c) {
    if (!this.active) return;
    const t = G.time;
    for (const p of this.plan) {
      const r = p.r, fy = LEVELS[r.level].y, top = fy - 40;
      // seepage / jets through windows that are under the sea
      for (const w of p.wins) {
        const under = this.depth(w.x + w.w / 2, w.y + w.h) > 0;
        if (w.broken && p.f < 0.98) { c.fillStyle = 'rgba(210,240,250,0.85)'; for (let i = 0; i < 6; i++) { const yy = w.y + 1 + ((i * 3 + Math.floor(t * 30)) % Math.max(2, w.h - 2)); const len = 6 + ((i * 7 + Math.floor(t * 40)) % 14); c.fillRect(w.x + w.w, yy, len, 1); } }
        else if (!w.broken && under && p.f < 0.98) { c.fillStyle = 'rgba(190,230,245,0.7)'; const dx = w.x + ((Math.floor(t * 3) * 5) % w.w); const dl = (t * 30) % 12; c.fillRect(dx, w.y + w.h + dl, 1, 2); } // drip
        if (w.broken) { c.fillStyle = 'rgba(20,40,50,0.6)'; c.fillRect(w.x, w.y, w.w, 1); c.fillRect(w.x + 2, w.y + w.h - 1, w.w - 4, 1); } // shattered frame
      }
      if (p.f <= 0.005) continue;
      const yAt = x => this.surfaceY(p, x) + Math.sin(t * 2 + x * 0.15) * (p.open && p.f < 0.97 ? 1.2 : 0.5);
      c.save(); c.beginPath(); c.rect(r.x1, top, r.x2 - r.x1, 40); c.clip();
      c.beginPath(); c.moveTo(r.x1, yAt(r.x1)); for (let x = r.x1 + 4; x <= r.x2; x += 4) c.lineTo(x, yAt(x)); c.lineTo(r.x2, fy + 2); c.lineTo(r.x1, fy + 2); c.closePath();
      const deep = clamp(this.depth((r.x1 + r.x2) / 2, fy) / 160, 0, 1);
      c.fillStyle = `rgba(${Math.round(28 - deep * 18)},${Math.round(96 - deep * 50)},${Math.round(124 - deep * 50)},${(0.62 + deep * 0.25).toFixed(2)})`; c.fill();
      // the surface: bright where an air pocket sits above it
      if (p.f < 0.995) { c.strokeStyle = p.f > 0.8 ? 'rgba(235,250,255,0.95)' : 'rgba(190,232,244,0.75)'; c.lineWidth = 1; c.beginPath(); c.moveTo(r.x1, yAt(r.x1)); for (let x = r.x1 + 4; x <= r.x2; x += 4) c.lineTo(x, yAt(x)); c.stroke(); }
      // compressed air pocket: silvery sheen under the ceiling
      if (p.f > 0.6 && p.f < 0.995) { c.fillStyle = 'rgba(210,235,245,0.16)'; c.fillRect(r.x1, top, r.x2 - r.x1, Math.max(1, (1 - p.f) * 40)); }
      // bubbles streaming up inside the flooded part
      c.fillStyle = 'rgba(220,245,250,0.7)'; for (let i = 0; i < 5; i++) { const bx = r.x1 + ((i * 37 + Math.floor(t * 20) * 7) % Math.max(1, r.x2 - r.x1)); const by = fy - ((t * 18 + i * 9) % Math.max(1, p.f * 40)); c.fillRect(Math.round(bx), Math.round(by), 1, 1); }
      c.restore();
    }
    for (const q of fx) if (q.yacht) { c.globalAlpha = clamp(1 - q.t / q.life, 0, 1); c.fillStyle = q.c; c.fillRect(Math.round(q.x), Math.round(q.y), q.s || 1, q.s || 1); } c.globalAlpha = 1;
  },
  /* ---------- drawing in the sea (world space, level frame) ---------- */
  drawSea(c) {
    this.drawRescue(c);
    if (!fx.length) return;
    for (const q of fx) {
      if (q.yacht) continue; const a = clamp(1 - q.t / q.life, 0, 1);
      if (q.kind === 'bubble') { const s = Math.max(1, Math.round(q.s)); c.fillStyle = 'rgba(225,246,252,0.85)'; c.fillRect(Math.round(q.x), Math.round(q.y), s, s); if (s > 1) { c.fillStyle = 'rgba(255,255,255,0.9)'; c.fillRect(Math.round(q.x), Math.round(q.y), 1, 1); } }
      else if (q.kind === 'debris') { c.fillStyle = q.c; c.fillRect(Math.round(q.x), Math.round(q.y) - q.h, q.w, q.h); }
      else { c.globalAlpha = a; c.fillStyle = q.c; c.fillRect(Math.round(q.x), Math.round(q.y), 1, 1); c.globalAlpha = 1; }
    }
  },
  sync(T) { if (T == null) { if (this.active) this.stop(true); return; } if (!this.active) this.start(T); else if (Math.abs(this.T - T) > 1.5) this.T = T; },
};

/* ---------- effects ---------- */
function bubble(x, y, s) { if (fx.length < 900) fx.push({ kind: 'bubble', x, y, vy: -8, s, t: 0, life: 12, ph: Math.random() * 6 }); }
function bubbleSpray(x) { fx.push({ kind: 'spray', x, y: WL - 1, vx: (Math.random() - 0.5) * 80, vy: -20 - Math.random() * 30, t: 0, life: 0.6, c: '#ffffff' }); }
function foam(x) { for (let i = 0; i < 3; i++) fx.push({ kind: 'spray', x: x + (Math.random() - 0.5) * 4, y: WL - 1, vx: (Math.random() - 0.5) * 20, vy: -10 - Math.random() * 10, t: 0, life: 0.5, c: '#ffffff' }); }
function breakGlass(S, w) {
  for (let i = 0; i < 18; i++) fx.push({ yacht: 1, x: w.x + Math.random() * w.w, y: w.y + Math.random() * w.h, vx: 20 + Math.random() * 60, vy: (Math.random() - 0.5) * 50, t: 0, life: 0.9, c: Math.random() < 0.5 ? '#d8f0f8' : '#9fc8d8', s: 1 });
  const [wx, wy] = S.world(w.x + w.w / 2, w.y); for (let i = 0; i < 16; i++) bubble(wx + (Math.random() - 0.5) * w.w, wy - Math.random() * 6, 1.5 + Math.random() * 2.5);
}
function implode(S, p) {
  const r = p.r, fy = LEVELS[r.level].y; for (let i = 0; i < 40; i++) { const [wx, wy] = S.world(r.x1 + Math.random() * (r.x2 - r.x1), fy - Math.random() * 40); bubble(wx, wy, 2 + Math.random() * 3); }
  G.shake = Math.max(G.shake || 0, 0.35);
}
function debris(x) { const kinds = [['#f3efe6', 8, 3], ['#c8703c', 10, 2], ['#ef7a2e', 4, 4], ['#5f8a62', 3, 3], ['#e8dcc0', 6, 2]]; const [c, w, h] = kinds[(Math.random() * kinds.length) | 0]; fx.push({ kind: 'debris', x, y: WL + 30 + Math.random() * 40, c, w, h, t: 0, life: 60, ph: Math.random() * 6 }); }

let vig = null;
function setVignette(a) {
  if (!vig || !vig.isConnected) { if (a <= 0.01) return; vig = el('div', { class: 'drown-vig' }); document.body.append(vig); }
  vig.style.opacity = a.toFixed(2);
}
function restoreWorld(saved) {
  if (saved) for (const f of FIXTURES) G.lights[f.id] = !!saved[f.id];
  const aft = SPEC.rooms.find(r => r.io === 'out' && r.type_ === 'aftdeck');
  for (const ch of G.chars || []) {
    if (G.onTender?.(ch) || ch.inHeli) continue;
    ch.lost = false; ch.swim = null; ch.stair = null; ch.path = []; ch.state = 'idle'; ch.underT = 0; ch.wade = 1;
    if (aft) { ch.level = aft.level; ch.x = aft.x1 + 20 + Math.random() * (aft.x2 - aft.x1 - 40); }
  }
  Bus.emit('lights');
}
function fadeAndRestore(fn) {
  const f = el('div', { class: 'sink-fade' }); document.body.append(f);
  setTimeout(() => { try { fn(); } catch (e) { console.error(e); } }, 1300);
  setTimeout(() => f.remove(), 3200);
}
export const sinkDraw = c => Sink.draw(c);
export const sinkDrawSea = c => Sink.drawSea(c);

/* ---------------- endings ---------------- */
function showEnding(kind, info, onContinue) {
  const W = 320, H = 180; const cv = document.createElement('canvas'); cv.width = W; cv.height = H; cv.className = 'ending-cv';
  const x = cv.getContext('2d'); x.imageSmoothingEnabled = false;
  const ok = kind !== 'drowned', heli = kind === 'rescued';
  const mm = Math.floor(info.T / 60), ss = String(Math.floor(info.T % 60)).padStart(2, '0');
  const box = el('div', { class: 'ending ' + kind },
    cv,
    el('div', { class: 'ending-text' },
      el('h1', {}, heli ? 'รอดชีวิต — กู้ภัยทางอากาศ' : ok ? 'รอดชีวิต' : 'จมน้ำเสียชีวิต'),
      el('p', {}, heli ? `คุณไปถึงห้องเดินเรือและส่ง SOS ได้ทัน… เฮลิคอปเตอร์กู้ภัยรอกคุณขึ้นมาก่อน ${info.yacht} จะจมหายไปใกล้${info.place}` : ok ? `คุณขึ้นเรือเล็กได้ทัน… ขณะที่ ${info.yacht} จมหายลงสู่ก้นทะเลใกล้${info.place}` : `คุณไม่ได้ขึ้นเรือเล็ก… และจมลงไปพร้อมกับ ${info.yacht} ใกล้${info.place}`),
      el('small', {}, `เวลาตั้งแต่ตัวเรือรั่ว ${mm}:${ss} นาที · ผู้รอดชีวิต ${info.saved}/${info.total} คน`),
      el('div', { class: 'row' },
        el('button', { class: 'btn primary', onclick: () => { stopAnim(); box.remove(); onContinue(); } }, 'กู้เรือแล้วเล่นต่อ'),
        el('button', { class: 'btn', onclick: () => { stopAnim(); box.remove(); onContinue(); G.quitToMenu?.(); } }, 'กลับเมนูหลัก'))));
  document.body.append(box);
  if (ok) Audio.creak?.(0.4); else Audio.boom?.();
  let raf = 0, t0 = performance.now();
  const bubbles = Array.from({ length: 40 }, () => ({ x: Math.random() * W, y: H + Math.random() * H, s: 1 + (Math.random() * 2 | 0), v: 8 + Math.random() * 18 }));
  // borrow the game's own sprites: the tender, the hull, and your OC
  const sc0 = window.__scene, art = { tender: sc0?.tender, me: G.player?.spr?.frames?.[0] || null, heli: heliSprite('skyblue').cv };
  const darken = (img, col) => { if (!img) return null; const c = document.createElement('canvas'); c.width = img.width; c.height = img.height; const k = c.getContext('2d'); k.drawImage(img, 0, 0); k.globalCompositeOperation = 'source-atop'; k.fillStyle = col; k.fillRect(0, 0, c.width, c.height); return c; };
  art.hull = darken(sc0?.exterior, 'rgba(3,12,18,0.93)'); art.meDark = darken(art.me, 'rgba(10,30,40,0.7)');
  const frame = () => {
    const t = (performance.now() - t0) / 1000;
    if (ok) {
      // dawn over the spot where she went down; the tender drifts on the swell among debris
      const g = x.createLinearGradient(0, 0, 0, 96); g.addColorStop(0, '#f6b27a'); g.addColorStop(0.55, '#f9d9a8'); g.addColorStop(1, '#bfe0e6'); x.fillStyle = g; x.fillRect(0, 0, W, 96);
      x.fillStyle = '#ffe9b0'; x.beginPath(); x.arc(230, 92, 16, Math.PI, 0); x.fill();
      x.fillStyle = '#4f8fa8'; x.fillRect(0, 96, W, H - 96); for (let y = 100; y < H; y += 6) { x.fillStyle = 'rgba(255,255,255,0.18)'; x.fillRect(((y * 37 + t * 12) % 60) - 30, y, W + 60, 1); }
      x.fillStyle = 'rgba(255,236,190,0.35)'; for (let y = 98; y < H; y += 3) x.fillRect(222 + Math.sin(y + t * 3) * 6, y, 16 - (y - 96) * 0.08, 1);
      for (let i = 0; i < 9; i++) { const dx = (i * 37 + 40) % W, dy = 101 + (i * 13) % 20 + Math.sin(t + i) * 1; x.fillStyle = ['#f3efe6', '#c8703c', '#ef7a2e', '#e8dcc0'][i % 4]; x.fillRect(dx, dy, 4 + (i % 3) * 2, 2); }
      const bx = Math.round(98 + Math.sin(t * 0.4) * 6), by = Math.round(70 + Math.sin(t * 1.2) * 1.5);
      if (heli && art.heli) { const hx = 150 + Math.sin(t * 0.5) * 10, hy = 34 + Math.sin(t * 1.3) * 2; const sc = 0.55; x.save(); x.translate(hx, hy); x.scale(-sc, sc); x.drawImage(art.heli, -art.heli.width / 2, -art.heli.height / 2); x.restore(); for (let i = 0; i < 6; i++) { x.fillStyle = 'rgba(255,255,255,0.6)'; x.fillRect(hx - 30 + ((i * 17 + t * 40) % 60), 98, 3, 1); } }
      else if (art.tender) { x.drawImage(art.tender.back, bx, by); if (art.me) x.drawImage(art.me, 0, 0, art.me.width, Math.round(art.me.height * 0.7), bx + 104 - Math.round(art.me.width / 2), by + 25 - Math.round(art.me.height * 0.7), art.me.width, Math.round(art.me.height * 0.7)); x.drawImage(art.tender.clear, bx, by); }
      x.fillStyle = 'rgba(79,143,168,0.55)'; x.fillRect(bx - 4, by + 33, 132, 8);
    } else {
      // under the surface: light shafts fading, the yacht's silhouette gone into the dark, slow bubbles
      const g = x.createLinearGradient(0, 0, 0, H); g.addColorStop(0, '#1d5a74'); g.addColorStop(0.5, '#0c2a3c'); g.addColorStop(1, '#02080e'); x.fillStyle = g; x.fillRect(0, 0, W, H);
      x.fillStyle = 'rgba(180,230,240,0.06)'; for (let i = 0; i < 5; i++) { const sx = 40 + i * 60 + Math.sin(t * 0.3 + i) * 10; x.beginPath(); x.moveTo(sx, 0); x.lineTo(sx + 14, 0); x.lineTo(sx + 40, H); x.lineTo(sx + 10, H); x.fill(); }
      // the real hull, dark against the deep, sliding stern-first into the abyss
      if (art.hull) { x.save(); x.translate(W / 2, 112 + t * 3); x.rotate(-0.38 - t * 0.004); const sc = W * 0.9 / art.hull.width; x.scale(sc, sc); x.drawImage(art.hull, -art.hull.width / 2, -art.hull.height / 2); x.restore(); }
      if (art.me) { const fy2 = Math.round(54 + Math.min(70, t * 2.5)); x.save(); x.translate(176, fy2); x.rotate(Math.sin(t * 0.5) * 0.3 + 0.4); x.globalAlpha = 0.9; x.drawImage(art.meDark, -Math.round(art.me.width / 2), -art.me.height); x.restore(); }
      for (const b of bubbles) { b.y -= b.v * 0.016; if (b.y < -4) { b.y = H + 4; b.x = 150 + (Math.random() - 0.5) * 60; } x.fillStyle = 'rgba(210,240,250,0.7)'; x.fillRect(Math.round(b.x + Math.sin(b.y * 0.1) * 2), Math.round(b.y), b.s, b.s); }
    }
    raf = requestAnimationFrame(frame);
  };
  const stopAnim = () => cancelAnimationFrame(raf);
  frame();
}
