// Helm: hands-on ship handling for the wheelhouse.
//  • Twin engine telegraphs (port / starboard), 9 detents from FULL ASTERN to FULL AHEAD. Engines spool up and
//    down over several seconds and must pass through neutral before the gearbox shifts between ahead and astern.
//  • Wheel → electro-hydraulic steering gear: the rudder follows the helm order at a fixed rate (max 35°).
//  • Yaw follows a first-order Nomoto model: turn rate grows with rudder × water flow over the rudder (speed plus
//    propeller wash), so the ship barely steers when stopped and steers in reverse when going astern.
//  • Splitting the throttles (one ahead, one astern) twists the ship on the spot; the bow thruster pushes the bow
//    sideways but only works below ~5 kn.
//  • Quadratic hull resistance gives a realistic top speed and long coast-down. Sharp turns bleed speed.
//  • Weather (wind / sea state) slows the ship and pushes the heading around.
//  • Heading-hold autopilot (HDG), shallow / land-ahead alarm, grounding, docking alongside when slow near a port.
import { clamp, lerp } from './util.js';
import { G } from './main.js';
import { Audio } from './audio.js';
import { Bus } from './util.js';
import { SPEC } from './yacht.js';
import { Geo, Journey } from './navmap.js';

export const DETENTS = [
  [-1, 'FULL ASTERN', 'ถอยหลังเต็มกำลัง'], [-0.6, 'HALF ASTERN', 'ถอยหลังครึ่งกำลัง'], [-0.35, 'SLOW ASTERN', 'ถอยหลังช้า'], [-0.18, 'DEAD SLOW ASTERN', 'ถอยหลังช้ามาก'],
  [0, 'STOP', 'หยุดเครื่อง'], [0.18, 'DEAD SLOW AHEAD', 'เดินหน้าช้ามาก'], [0.35, 'SLOW AHEAD', 'เดินหน้าช้า'], [0.6, 'HALF AHEAD', 'เดินหน้าครึ่งกำลัง'], [1, 'FULL AHEAD', 'เดินหน้าเต็มกำลัง'],
];
export const detentOf = v => DETENTS.reduce((b, d) => Math.abs(d[0] - v) < Math.abs(b[0] - v) ? d : b, DETENTS[4]);

function params() {
  const L = SPEC?.lengthM || 80, big = L > 110;
  return { vmax: big ? 18.5 : 16, vast: big ? 7 : 6.5, tau: big ? 75 : 48, rmax: big ? 1.9 : 3.0, Tn: big ? 11 : 6.5, gearRate: 6, spoolUp: big ? 0.09 : 0.13, spoolDn: 0.25, twin: big ? 0.9 : 1.4, bow: big ? 1.3 : 1.8, L };
}

export const Helm = {
  thr: [0, 0], wheel: 0, thruster: 0, linked: true,      // controls
  rpm: [0, 0], gear: [0, 0], shift: [0, 0], rudder: 0, rot: 0, hold: null, // state
  alarm: null, alarmT: 0, agroundT: 0, depth: 50, sog: 0,

  reset() { this.thr = [0, 0]; this.rpm = [0, 0]; this.gear = [0, 0]; this.shift = [0, 0]; this.wheel = 0; this.rudder = 0; this.rot = 0; this.thruster = 0; this.hold = null; },
  setThr(i, v) { v = clamp(v, -1, 1); const before = this.thr.join(); if (i === 'both' || this.linked) this.thr = [v, v]; else this.thr[i] = v; if (this.thr.join() !== before) this.ring(); this.takeControl(); },
  // engine-order telegraph: bridge rings the order, the engine room answers a moment later
  ring() { Audio.telegraph?.(); clearTimeout(this._ans); this._ans = setTimeout(() => Audio.telegraph?.(0.6), 650); },
  stepThr(i, dir) { const cur = i === 'both' ? (this.thr[0] + this.thr[1]) / 2 : this.thr[i]; const k = DETENTS.indexOf(detentOf(cur)); const d = DETENTS[clamp(k + dir, 0, DETENTS.length - 1)]; this.setThr(i, d[0]); },
  setWheel(v) { this.wheel = clamp(v, -1, 1); if (this.hold != null && Math.abs(v) > 0.05) this.hold = null; this.takeControl(); },
  allStop() { this.thr = [0, 0]; this.thruster = 0; this.takeControl(); },
  takeControl() { const j = G.journey; if (j.s.autopilot) { const v = clamp(j.s.speed / params().vmax, 0, 1); this.rpm = [v, v]; this.gear = v > 0 ? [1, 1] : [0, 0]; if (this.thr[0] === 0 && this.thr[1] === 0) this.thr = [v, v]; j.s.autopilot = false; Bus.emit('toast', 'ปลดออโต้ไพลอตเส้นทาง — ควบคุมด้วยมือ'); } if (j.s.status === 'docked' && (Math.abs(this.thr[0]) + Math.abs(this.thr[1]) > 0 || this.thruster)) { j.s.status = 'sailing'; j.s.dockedAt = null; Bus.emit('toast', 'ปลดเชือก ออกจากท่าแล้ว'); } j.s.engine = true; },
  holdHeading(on) { this.hold = on ? Math.round(G.journey.s.heading) : null; },

  // called by Journey.update when the route autopilot is off. Real-time dynamics; position integrates with timeMult.
  step(s, dtReal) {
    const P = params(), dt = Math.min(dtReal, 0.1), W = G.Weather?.p || { wind: 0, sea: 1 };
    // engines: gearbox must be in neutral (rpm ~0) to change direction; then spool toward the telegraph order
    for (let i = 0; i < 2; i++) {
      const want = s.engine ? this.thr[i] : 0, dir = Math.sign(want);
      if (dir !== this.gear[i]) {
        if (Math.abs(this.rpm[i]) > 0.06) this.rpm[i] -= Math.sign(this.rpm[i]) * P.spoolDn * dt;   // run down first
        else if ((this.shift[i] += dt) > 1.4) { this.gear[i] = dir; this.shift[i] = 0; if (dir) Audio.click(180); } // clunk into gear
      } else {
        this.shift[i] = 0; const tgt = Math.abs(want) * dir, d = tgt - this.rpm[i];
        this.rpm[i] += clamp(d, -P.spoolDn * dt, (Math.abs(tgt) > Math.abs(this.rpm[i]) ? P.spoolUp : P.spoolDn) * dt);
      }
    }
    // steering gear
    this.rudder += clamp(this.wheel * 35 - this.rudder, -P.gearRate * dt, P.gearRate * dt);
    // heading-hold autopilot drives the helm order
    if (this.hold != null) { const err = ((this.hold - s.heading + 540) % 360) - 180; this.wheel = clamp(err * 0.09 - this.rot * 0.9, -0.6, 0.6); }
    // surge: thrust ∝ n|n| (astern props are ~60% as effective), resistance ∝ u|u|, rough seas add drag
    const thrust = this.rpm.reduce((a, n) => a + n * Math.abs(n) * (n < 0 ? 0.6 : 1), 0) / 2;
    let u = s.speed; const rough = 1 + Math.max(0, W.sea - 1) * 0.18;
    const res = (u / P.vmax) * Math.abs(u / P.vmax) * rough;
    u += (thrust - res) * (P.vmax / P.tau) * dt * 2.2;
    u -= Math.abs(this.rot) / P.rmax * 0.035 * u * dt;                                   // speed lost in a hard turn
    if (Math.abs(u) < 0.02 && Math.abs(thrust) < 0.001) u = 0;
    // yaw: rudder needs water flow — ship speed plus prop wash from engines turning ahead
    const wash = Math.max(0, (this.rpm[0] + this.rpm[1]) / 2) * 6, flow = u + wash;
    const rRud = (this.rudder / 35) * P.rmax * clamp(flow / P.vmax, -0.6, 1.15);
    const rTwin = (this.rpm[0] - this.rpm[1]) * P.twin * (1 - clamp(Math.abs(u) / 10, 0, 0.7));
    const rBow = this.thruster * P.bow * clamp(1 - Math.abs(u) / 5, 0, 1);
    const gust = (Math.sin(G.time * 0.31) + Math.sin(G.time * 0.73 + 1.7) * 0.6) * W.wind * W.wind * 0.35;
    const rTgt = rRud + rTwin + rBow + gust;
    this.rot += (rTgt - this.rot) * clamp(dt / P.Tn, 0, 1);
    s.heading = (s.heading + this.rot * dt + 360) % 360;
    s.speed = u; s.targetSpeed = Math.max(0, thrust) * P.vmax; s.rudder = this.rudder / 35;
    this.sog = u;
    // sounder + collision avoidance look-ahead (land within ~5 minutes of run, or < 0.4 nm)
    this.alarmT -= dt; this.agroundT -= dt;
    if (Geo.ready && (this._scanT = (this._scanT || 0) - dt) <= 0) {
      this._scanT = 0.5; let near = 99; const t = Math.PI / 180, dirH = u >= 0 ? s.heading : s.heading + 180;
      for (const nm of [0.15, 0.3, 0.5, 0.8, 1.2]) { const la = s.lat + (nm / 60) * Math.cos(dirH * t), lo = s.lon + (nm / 60) * Math.sin(dirH * t) / Math.cos(s.lat * t); if (Geo.isLand(la, lo)) { near = nm; break; } }
      this.depth = near < 99 ? Math.round(3 + near * 40) : Math.round(60 + 40 * Math.abs(Math.sin(s.lat * 13 + s.lon * 7)));
      const ttc = Math.abs(u) > 0.5 ? near / Math.abs(u) * 60 : 99;
      this.alarm = near < 99 && (ttc < 5 || near <= 0.3) ? 'LAND AHEAD' : null;
      if (this.alarm && this.alarmT <= 0) { this.alarmT = 1.2; Audio.click(1250); setTimeout(() => Audio.click(1250), 160); }
    }
    // engine-room drone follows the shaft revs
    const rev = (Math.abs(this.rpm[0]) + Math.abs(this.rpm[1])) / 2; Audio.engine?.(rev, s.engine && G.screen === 'game');
  },
  aground() { if (this.agroundT > 0) return; this.agroundT = 5; const hard = Math.abs(this.sog) > 3; Audio.creak?.(); if (hard) Audio.boom?.(); Bus.emit('toast', hard ? 'เรือเกยตื้น! ใช้เครื่องถอยหลังเพื่อออกจากที่ตื้น' : 'หัวเรือชนตลิ่ง — ถอยหลังออก'); G.shake = (G.shake || 0) + (hard ? 0.6 : 0.25); this.rot = 0; },

  // docking: alongside the nearest port when slow and close
  dockable() { const j = G.journey; if (j.s.status === 'docked') return null; const np = j.nearestPort(); return np.dist < 0.8 && Math.abs(j.s.speed) < 1.5 ? np.port : null; },
  dock() {
    const p = this.dockable(); if (!p) return false; const s = G.journey.s;
    Object.assign(s, { lat: p.lat, lon: p.lon, speed: 0, targetSpeed: 0, autopilot: false, waypoints: [], wp: 0, dest: null, status: 'docked', dockedAt: p.id });
    if (!s.discovered.includes(p.id)) s.discovered.push(p.id); this.reset(); Bus.emit('journey:arrived', p); return true;
  },

  /* ---------- live wheelhouse console (scene space, drawn over the static furniture) ---------- */
  drawConsole(c, r, fy, t) {
    const F = fy - 4, hx = r.x2 - 36, cx = Math.round((r.x1 + r.x2) / 2), s = G.journey.s;
    // helm wheel on the aft face of the console, seen almost edge-on; spokes show the helm order
    const wx = hx - 2, wy = F - 11, ang = this.wheel * 2.2 + (s.autopilot || this.hold != null ? Math.sin(t * 0.8) * 0.05 : 0);
    c.fillStyle = '#8a6a4a'; c.fillRect(wx, wy - 7, 2, 15); c.fillRect(wx - 1, wy - 7, 1, 1); c.fillRect(wx - 1, wy + 7, 1, 1);
    for (let k = 0; k < 6; k++) { const a = ang + k * Math.PI / 3, yy = Math.round(wy + Math.sin(a) * 7); if (Math.cos(a) > -0.2) { c.fillStyle = '#c9a964'; c.fillRect(wx - 1, yy, 1, 1); } }
    c.fillStyle = '#3a4046'; c.fillRect(wx + 2, wy - 1, 3, 2);
    // throttle levers on the console top: angle = telegraph order
    for (let i = 0; i < 2; i++) { const px = r.x2 - 16 + i * 4, py = F - 16, a = this.thr[i] * 0.7; c.strokeStyle = '#9aa4ac'; c.lineWidth = 1; c.beginPath(); c.moveTo(px + 0.5, py); c.lineTo(px + 0.5 + Math.sin(a) * 6, py - Math.cos(a) * 6); c.stroke(); c.fillStyle = i ? '#5ac46e' : '#e65b4a'; c.fillRect(Math.round(px + Math.sin(a) * 6) - 1, Math.round(py - Math.cos(a) * 6) - 1, 2, 2); }
    // console displays: speed bar, rudder indicator, rate-of-turn, alarm lamp
    c.fillStyle = '#0f1a22'; c.fillRect(hx + 8, F - 15, 12, 4); c.fillRect(hx + 21, F - 15, 6, 4);
    const sp = clamp(Math.abs(s.speed) / 18, 0, 1); c.fillStyle = s.speed < -0.1 ? '#f2c94c' : '#5ad0e6'; c.fillRect(hx + 9, F - 13, Math.max(1, Math.round(sp * 10)), 1);
    c.fillStyle = '#9fe0ee'; c.fillRect(hx + 13 + Math.round(this.rudder / 35 * 5), F - 14, 1, 1);
    c.fillStyle = this.rot > 0.05 ? '#5ac46e' : this.rot < -0.05 ? '#e65b4a' : '#59646e'; c.fillRect(hx + 23, F - 14, 2, 2);
    if (this.alarm) { c.fillStyle = (t * 4 | 0) % 2 ? '#ff4a3c' : '#5a1a16'; c.fillRect(hx + 7, F - 17, 2, 2); }
    // chart plotter: own-ship arrow on a moving sea chart
    const px = cx - 8, py = F - 25; c.fillStyle = '#16324a'; c.fillRect(px, py, 16, 9);
    c.fillStyle = '#2a5a3a'; for (let k = 0; k < 3; k++) c.fillRect(px + ((k * 7 + s.lon * 90) % 16 + 16) % 16 | 0, py + ((k * 5 + s.lat * 90) % 9 + 9) % 9 | 0, 3, 2);
    const hr = s.heading * Math.PI / 180; c.fillStyle = '#f2f2f2'; c.fillRect(px + 8, py + 4, 1, 1); c.fillStyle = '#ffd166'; c.fillRect(Math.round(px + 8 + Math.sin(hr) * 3), Math.round(py + 4 - Math.cos(hr) * 3), 1, 1);
    // overhead repeaters: radar sweep + heading tape
    for (const mx of [cx - 30, cx + 14]) if (mx > r.x1 + 42 && mx + 16 < hx) {
      c.fillStyle = '#0d2a1a'; c.fillRect(mx + 1, fy - 34, 14, 6);
      if (mx < cx) { const a = t * 2.5; c.fillStyle = '#3ad06a'; c.fillRect(mx + 8 + Math.round(Math.cos(a) * 5), fy - 31 + Math.round(Math.sin(a) * 2), 1, 1); c.fillRect(mx + 8, fy - 31, 1, 1); }
      else { c.fillStyle = '#9fe0ee'; for (let k = 0; k < 5; k++) c.fillRect(mx + 2 + ((k * 3 - s.heading * 0.3) % 15 + 15) % 13 | 0, fy - 32, 1, 2); c.fillStyle = '#ffd166'; c.fillRect(mx + 8, fy - 33, 1, 4); }
    }
    if (s.autopilot || this.hold != null) { c.fillStyle = '#5ac46e'; c.fillRect(hx + 23, F - 17, 3, 1); }
  },
};

// route autopilot drives the levers visually (it has its own speed governor in Journey.update)
export function helmFollowAuto(s) { if (!s.autopilot) return; const v = clamp(s.targetSpeed / params().vmax, 0, 1); Helm.thr = [v, v]; const r = clamp(s.speed / params().vmax, 0, 1); Helm.rpm = [r, r]; Helm.gear = r > 0.01 ? [1, 1] : [0, 0]; Helm.wheel = 0; Helm.rudder *= 0.95; Helm.rot = 0; Audio.engine?.(r, s.engine && G.screen === 'game'); }
Journey.prototype.manualStep = function (s, dt) { Helm.step(s, dt); };
Journey.prototype.onAground = function () { Helm.aground(); };
