// Weather: clear · fog · overcast · cloudy · rain · heavy rain · thunderstorm · heavy monsoon.
// Modes (Settings → สภาพอากาศ):
//   off    — always fair weather
//   custom — the player picks the weather
//   real   — live weather for the yacht's current position (Open-Meteo, no key). If the network is blocked it
//            falls back to a climate model of that exact sea area and today's real date/time (monsoons,
//            typhoon season, afternoon thunderstorms, winter sea fog…).
// Everything blends smoothly between states; rendering, sound and sea state read the blended parameters.
import { clamp, lerp, mixHex } from './util.js';
import { G } from './main.js';
import { Audio } from './audio.js';

export const WEATHER = {
  clear: { th: 'ปกติ (ฟ้าโปร่ง)', cloud: 0.15, dark: 0, fog: 0, rain: 0, wind: 0.15, bolt: 0, sea: 1 },
  fog: { th: 'หมอก', cloud: 0.35, dark: 0.12, fog: 0.9, rain: 0, wind: 0.05, bolt: 0, sea: 0.8 },
  overcast: { th: 'ครึ้ม', cloud: 0.95, dark: 0.32, fog: 0.15, rain: 0, wind: 0.3, bolt: 0, sea: 1.1 },
  cloudy: { th: 'เมฆมาก', cloud: 0.7, dark: 0.12, fog: 0.05, rain: 0, wind: 0.25, bolt: 0, sea: 1 },
  rain: { th: 'ฝนตก', cloud: 0.95, dark: 0.42, fog: 0.25, rain: 0.45, wind: 0.35, bolt: 0, sea: 1.25 },
  heavyrain: { th: 'ฝนตกหนัก', cloud: 1, dark: 0.58, fog: 0.42, rain: 0.85, wind: 0.5, bolt: 0.15, sea: 1.5 },
  storm: { th: 'พายุฝนฟ้าคะนอง', cloud: 1, dark: 0.7, fog: 0.35, rain: 0.9, wind: 0.75, bolt: 1, sea: 1.9 },
  monsoon: { th: 'มรสุมหนัก', cloud: 1, dark: 0.76, fog: 0.5, rain: 1, wind: 1, bolt: 0.45, sea: 2.4 },
};
const KEYS = ['cloud', 'dark', 'fog', 'rain', 'wind', 'bolt', 'sea'];

export const Weather = {
  type: 'clear', src: 'off', p: { ...WEATHER.clear }, info: null, flash: 0, bolt: null, nextBolt: 6, drops: [], splashes: [], fetchAt: 0, fetchKey: '', live: null, liveAt: 0,

  mode() { return G.settings?.weatherMode || 'off'; },
  update(dt) {
    const mode = this.mode();
    let target = 'clear';
    if (mode === 'custom') { target = G.settings.weatherType || 'rain'; this.src = 'custom'; }
    else if (mode === 'real') { target = this.realType(); }
    else this.src = 'off';
    this.type = target;
    const T = WEATHER[target] || WEATHER.clear, k = clamp(dt * 0.25, 0, 1);
    for (const key of KEYS) this.p[key] = lerp(this.p[key], T[key], k);
    // lightning
    this.flash = Math.max(0, this.flash - dt * 3.5);
    if (this.p.bolt > 0.05 && (this.nextBolt -= dt * this.p.bolt) <= 0) {
      this.nextBolt = 4 + Math.random() * 12; this.flash = 1; const dist = Math.random();
      this.bolt = { x: Math.random(), t: 0.35, seed: Math.random() * 1e5, near: dist < 0.35 };
      setTimeout(() => Audio.thunder?.(1 - dist), 300 + dist * 3500);
    }
    if (this.bolt && (this.bolt.t -= dt) <= 0) this.bolt = null;
    Audio.weather?.(this.p.rain, this.p.wind);
    G.seaWeather = this.p.sea;
  },

  /* ---------- real weather ---------- */
  realType() {
    const j = G.journey?.s; if (!j) return 'clear';
    const key = (Math.round(j.lat * 2) / 2) + ',' + (Math.round(j.lon * 2) / 2);
    const now = Date.now();
    if ((key !== this.fetchKey || now - this.fetchAt > 15 * 60e3) && now - this.fetchAt > 20e3) { this.fetchKey = key; this.fetchAt = now; this.fetchLive(j.lat, j.lon, key); }
    if (this.live && this.live.key === key && now - this.liveAt < 40 * 60e3) { this.src = 'live'; this.info = this.live; return this.live.type; }
    this.src = 'model'; const m = climate(j.lat, j.lon, new Date()); this.info = m; return m.type;
  },
  async fetchLive(lat, lon, key) {
    try {
      const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat.toFixed(2)}&longitude=${lon.toFixed(2)}&current=weather_code,cloud_cover,precipitation,wind_speed_10m,wind_gusts_10m,visibility&timezone=auto`;
      const ctl = new AbortController(); const to = setTimeout(() => ctl.abort(), 6000);
      const r = await fetch(url, { signal: ctl.signal }); clearTimeout(to); if (!r.ok) throw new Error(r.status);
      const d = (await r.json()).current || {};
      const code = d.weather_code ?? 0, wind = d.wind_speed_10m ?? 0, gust = d.wind_gusts_10m ?? wind, pr = d.precipitation ?? 0, cc = d.cloud_cover ?? 0, vis = d.visibility ?? 20000;
      let type = 'clear';
      if (code >= 95) type = gust > 70 || wind > 50 ? 'monsoon' : 'storm';
      else if ([65, 67, 82, 86].includes(code) || pr > 6) type = gust > 60 ? 'monsoon' : 'heavyrain';
      else if ((code >= 51 && code <= 64) || (code >= 80 && code <= 81) || pr > 0.2) type = 'rain';
      else if (code === 45 || code === 48 || vis < 1500) type = 'fog';
      else if (code === 3 || cc > 85) type = 'overcast';
      else if (code === 2 || cc > 45) type = 'cloudy';
      this.live = { key, type, wind: Math.round(wind), gust: Math.round(gust), rain: pr, cloud: cc, live: true }; this.liveAt = Date.now();
    } catch (e) { /* offline / blocked → climate model keeps running */ }
  },

  /* ---------- rendering (screen space on the scene canvas) ---------- */
  drawSky(c, W, horizon, pal) {
    const p = this.p; if (p.dark < 0.01 && p.cloud < 0.2) return;
    // grey-out the sky, then a low cloud deck rolling in from the top
    c.fillStyle = `rgba(${pal.night > 0.5 ? '20,24,32' : '96,104,114'},${(p.dark * 0.75).toFixed(3)})`; c.fillRect(0, 0, W, horizon + 1);
    const deck = Math.round(horizon * (0.12 + p.cloud * 0.4)); const t = G.time;
    const base = pal.night > 0.5 ? '#1c2230' : mixHex('#d8dde2', '#4a5260', p.dark);
    const under = mixHex(base, '#000000', 0.22), lit = mixHex(base, '#ffffff', pal.night > 0.5 ? 0.04 : 0.18);
    const a = clamp(p.cloud * 0.95, 0, 0.96); c.globalAlpha = a;
    // solid cloud sheet with a darker underside
    const g = c.createLinearGradient(0, 0, 0, deck); g.addColorStop(0, lit); g.addColorStop(1, base); c.fillStyle = g; c.fillRect(0, 0, W, Math.round(deck * 0.62));
    // two layers of lumpy cloud bases drifting with the wind at different speeds (parallax)
    for (const [sp, yy, rx, col] of [[3 + p.wind * 18, 0.62, 46, base], [6 + p.wind * 34, 0.78, 34, under]]) {
      const per = rx * 1.3, off = (t * sp) % per;
      for (let x = -per * 2 + off; x < W + per * 2; x += per) {
        const k = Math.floor((x - off) / per); const j = Math.abs(Math.sin(k * 12.9898 + yy * 78.2) * 43758.5) % 1;
        c.fillStyle = col; c.beginPath(); c.ellipse(Math.round(x), Math.round(deck * yy), rx * (0.8 + j * 0.5), deck * (0.12 + j * 0.14), 0, 0, Math.PI * 2); c.fill();
      }
    }
    // virga / rain shafts hanging under the deck
    if (p.rain > 0.2) { c.globalAlpha = p.rain * 0.22; c.fillStyle = under; for (let i = 0; i < 5; i++) { const x = ((i * 211 + t * (4 + p.wind * 20)) % (W + 120)) - 60; c.beginPath(); c.moveTo(x, deck * 0.8); c.lineTo(x + 50, deck * 0.8); c.lineTo(x + 30 - p.wind * 30, horizon); c.lineTo(x - 10 - p.wind * 30, horizon); c.fill(); } }
    c.globalAlpha = 1;
    if (this.bolt) {
      const b = this.bolt; let x = b.x * W, y = 0; let s = b.seed;
      const rnd = () => (s = (s * 9301 + 49297) % 233280) / 233280;
      c.strokeStyle = `rgba(235,240,255,${clamp(b.t * 3, 0, 1).toFixed(2)})`; c.lineWidth = 1; c.beginPath(); c.moveTo(x, y);
      while (y < horizon - 2) { x += (rnd() - 0.5) * 14; y += 4 + rnd() * 8; c.lineTo(Math.round(x), Math.round(Math.min(y, horizon))); }
      c.stroke();
    }
  },
  drawFog(c, W, H, horizon, pal) {
    const p = this.p; if (p.fog < 0.02) return;
    const col = pal.night > 0.5 ? '42,50,62' : '214,220,224';
    const g = c.createLinearGradient(0, horizon - 60, 0, horizon + 30); g.addColorStop(0, `rgba(${col},0)`); g.addColorStop(0.6, `rgba(${col},${(p.fog * 0.85).toFixed(2)})`); g.addColorStop(1, `rgba(${col},${(p.fog * 0.55).toFixed(2)})`);
    c.fillStyle = g; c.fillRect(0, horizon - 60, W, 90);
  },
  drawFront(c, W, H, horizon, waterS, pal) {
    const p = this.p;
    // veil (fog / heavy rain) over the whole view
    const veil = p.fog * 0.28 + p.rain * 0.12;
    if (veil > 0.01) { c.fillStyle = pal.night > 0.5 ? `rgba(30,38,50,${veil.toFixed(3)})` : `rgba(200,208,214,${veil.toFixed(3)})`; c.fillRect(0, 0, W, H); }
    // rain: wind-slanted streaks + splashes on the sea
    const want = Math.round(p.rain * (G.quality >= 2 ? 520 : G.quality === 1 ? 320 : 180));
    const D = this.drops; while (D.length < want) D.push({ x: Math.random() * (W + 80) - 40, y: Math.random() * H, v: 160 + Math.random() * 120, l: 3 + Math.random() * 4 });
    if (D.length > want) D.length = want;
    const slant = 0.25 + p.wind * 0.9, dt = G.dt || 0.016;
    c.strokeStyle = pal.night > 0.5 ? 'rgba(150,170,190,0.45)' : 'rgba(225,235,245,0.55)'; c.lineWidth = 1; c.beginPath();
    for (const d of D) {
      d.y += d.v * dt; d.x -= d.v * dt * slant;
      if (d.y > waterS + 4 && d.y > horizon && Math.random() < 0.15) { if (this.splashes.length < 160) this.splashes.push({ x: d.x, y: Math.min(d.y, H - 2), t: 0 }); d.y = -10; d.x = Math.random() * (W + 120); }
      if (d.y > H || d.x < -40) { d.y = -10 - Math.random() * 40; d.x = Math.random() * (W + 120); }
      c.moveTo(Math.round(d.x), Math.round(d.y)); c.lineTo(Math.round(d.x + d.l * slant), Math.round(d.y - d.l));
    }
    c.stroke();
    c.fillStyle = 'rgba(235,245,250,0.6)';
    for (const s of this.splashes) { s.t += dt; const r = Math.round(s.t * 8); c.fillRect(Math.round(s.x) - r, Math.round(s.y), r * 2 + 1, 1); }
    this.splashes = this.splashes.filter(s => s.t < 0.25);
    // lightning flash
    if (this.flash > 0.01) { c.fillStyle = `rgba(230,236,255,${(this.flash * 0.45).toFixed(2)})`; c.fillRect(0, 0, W, H); }
  },
  // how dark the weather makes the outdoors (used by the lightmap and auto-lights)
  ambientMul() { return 1 - this.p.dark * 0.5 + this.flash * 0.8; },
  label() {
    if (this.mode() === 'off') return null;
    const th = WEATHER[this.type]?.th || '';
    const tag = this.src === 'live' ? 'ตามจริง' : this.src === 'model' ? 'จำลองตามฤดูกาลของพื้นที่' : 'กำหนดเอง';
    const w = this.info?.wind != null ? ` · ลม ${this.info.wind} กม./ชม.` : '';
    return `${th}${w} (${tag})`;
  },
};

/* ---------- climate model for the actual sea area, real date & local hour ---------- */
function hash(n) { n = (n ^ 61) ^ (n >>> 16); n = n + (n << 3); n = n ^ (n >>> 4); n = Math.imul(n, 0x27d4eb2d); n = n ^ (n >>> 15); return (n >>> 0) / 4294967295; }
export function climate(lat, lon, now) {
  const tz = Math.round(lon / 15); const local = new Date(now.getTime() + tz * 3600e3);
  const m = local.getUTCMonth() + 1, h = local.getUTCHours() + local.getUTCMinutes() / 60;
  const day = Math.floor(local.getTime() / 864e5);
  // seasonal wetness (0..1) and storm risk for each part of the region
  let wet = 0.25, typhoon = 0, fogS = 0, name = 'ทะเลเปิด';
  const inM = (...ms) => ms.includes(m);
  if (lon < 100.2 && lat < 14 && lat > 1) { name = 'อันดามัน / ช่องแคบมะละกา'; wet = inM(5, 6, 7, 8, 9, 10) ? 0.7 : inM(11, 4) ? 0.4 : 0.15; }
  else if (lon >= 99 && lon < 103 && lat > 5 && lat < 14) { name = 'อ่าวไทย'; wet = inM(10, 11, 12) ? 0.72 : inM(5, 6, 7, 8, 9) ? 0.42 : 0.18; }
  else if (lon >= 105 && lon < 110 && lat >= 10 && lat < 17.5) { name = 'ชายฝั่งภาคกลางเวียดนาม'; wet = inM(9, 10, 11, 12) ? 0.75 : 0.2; typhoon = inM(9, 10, 11) ? 0.3 : 0; }
  else if (lon >= 105 && lat >= 17.5 && lat < 23) { name = 'อ่าวตังเกี๋ย'; wet = inM(5, 6, 7, 8, 9) ? 0.55 : 0.2; fogS = inM(1, 2, 3, 4) ? 0.5 : 0; typhoon = inM(7, 8, 9) ? 0.25 : 0; }
  else if (lat < 6 && lat > -11) { name = 'แถบเส้นศูนย์สูตร'; wet = inM(11, 12, 1, 2, 3) ? 0.65 : 0.45; }
  else if (lon >= 116 && lon < 128 && lat >= 5 && lat < 20) { name = 'ฟิลิปปินส์'; wet = inM(6, 7, 8, 9, 10, 11) ? 0.65 : 0.25; typhoon = inM(7, 8, 9, 10, 11) ? 0.35 : 0.05; }
  else if (lat >= 20 && lat < 27) { name = 'ไต้หวัน / โอกินาวา / จีนตอนใต้'; wet = inM(5, 6, 8, 9) ? 0.55 : 0.3; typhoon = inM(7, 8, 9, 10) ? 0.35 : 0; fogS = inM(2, 3, 4) ? 0.3 : 0; }
  else if (lat >= 27) { name = 'ญี่ปุ่น / เกาหลี / จีนตอนเหนือ'; wet = inM(6, 7) ? 0.7 : inM(9) ? 0.45 : 0.25; typhoon = inM(8, 9) ? 0.3 : 0; fogS = inM(4, 5, 6, 7) ? 0.35 : 0; }
  // weather systems last a few hours: hash per 3-hour block and 2° cell
  const cell = Math.round(lat / 2) * 1000 + Math.round(lon / 2); const blk = Math.floor((day * 24 + h) / 3);
  const r1 = hash(cell * 7919 + blk), r2 = hash(cell * 104729 + blk * 3 + 1), r3 = hash(cell * 31 + day);
  const afternoon = h >= 13 && h <= 19 ? 0.18 : h < 7 ? -0.05 : 0;
  const pRain = clamp(wet + afternoon, 0, 0.95);
  let type = 'clear';
  if (r3 < typhoon * 0.35) type = r1 < 0.6 ? 'monsoon' : 'storm';
  else if (r1 < pRain * 0.45) type = r2 < 0.25 + afternoon ? 'storm' : r2 < 0.55 ? 'heavyrain' : 'rain';
  else if (r1 < pRain) type = r2 < 0.5 ? 'overcast' : 'rain';
  else if (h < 9 && r2 < fogS) type = 'fog';
  else type = r2 < 0.35 ? 'cloudy' : r2 < 0.45 ? 'overcast' : 'clear';
  const wind = Math.round({ clear: 12, cloudy: 16, overcast: 20, fog: 6, rain: 24, heavyrain: 34, storm: 48, monsoon: 75 }[type] * (0.8 + r2 * 0.4));
  return { type, wind, area: name, live: false };
}
