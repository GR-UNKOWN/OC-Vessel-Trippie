// Small UI kit: buttons, toasts, modal dialogs, confirm, draggable windows with minimise / maximise / close.
import { el, Bus } from './util.js';
import { icon } from './icons.js';

export function btn(label, opts = {}) {
  const b = el('button', { class: 'btn ' + (opts.cls || ''), type: 'button', title: opts.title || (typeof label === 'string' ? label : ''), 'aria-label': opts.title || (typeof label === 'string' ? label : '') });
  b.innerHTML = (opts.icon ? icon(opts.icon, opts.size || 18) : '') + (label ? `<span>${label}</span>` : '');
  if (opts.onclick) b.addEventListener('click', e => { Bus.emit('ui:click'); opts.onclick(e); });
  if (opts.disabled) b.disabled = true;
  return b;
}
export function iconBtn(name, title, onclick, cls = '') { return btn('', { icon: name, title, onclick, cls: 'icon ' + cls, size: 20 }); }

let toastBox;
export function toast(msg, kind = 'info', ms = 2600) {
  if (!toastBox) { toastBox = el('div', { class: 'toasts', role: 'status', 'aria-live': 'polite' }); document.body.append(toastBox); }
  const t = el('div', { class: 'toast ' + kind, html: icon(kind === 'error' ? 'info' : kind === 'ok' ? 'check' : 'info', 16) + `<span></span>` });
  t.querySelector('span').textContent = msg; toastBox.append(t);
  setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 400); }, ms);
}
Bus.on('toast', m => toast(m));

export function modal({ title, body, actions = [], cls = '', onClose, closable = true }) {
  const back = el('div', { class: 'modal-back' });
  const box = el('div', { class: 'modal ' + cls, role: 'dialog', 'aria-modal': 'true' });
  const head = el('div', { class: 'modal-head' }, el('h3', {}, title));
  const close = () => { back.remove(); onClose?.(); };
  if (closable) head.append(iconBtn('close', 'ปิด', close));
  const bodyEl = el('div', { class: 'modal-body' }); if (typeof body === 'string') bodyEl.innerHTML = body; else if (body) bodyEl.append(body);
  const foot = el('div', { class: 'modal-foot' });
  for (const a of actions) foot.append(btn(a.label, { icon: a.icon, cls: a.cls, onclick: async () => { const r = await a.onclick?.(); if (r !== false) close(); } }));
  box.append(head, bodyEl); if (actions.length) box.append(foot);
  back.append(box); document.body.append(back);
  if (closable) back.addEventListener('pointerdown', e => { if (e.target === back) close(); });
  return { close, box, body: bodyEl };
}
export function confirmBox(title, text, okLabel = 'ยืนยัน', danger = false) {
  return new Promise(res => {
    modal({ title, body: el('p', {}, text), onClose: () => res(false), actions: [{ label: 'ยกเลิก', cls: 'ghost', onclick: () => res(false) }, { label: okLabel, icon: danger ? 'delete' : 'check', cls: danger ? 'danger' : 'primary', onclick: () => res(true) }] });
  });
}

/* ---------- windows ---------- */
const wins = new Map(); let zTop = 50;
export function openWindow(id, title, build, opts = {}) {
  if (wins.has(id)) { const w = wins.get(id); w.el.classList.remove('min'); w.el.style.zIndex = ++zTop; w.el.hidden = false; w.refresh?.(); return w; }
  const box = el('section', { class: 'win ' + (opts.cls || ''), role: 'dialog', 'aria-label': title });
  const head = el('header', { class: 'win-head' });
  const h = el('h3', { html: (opts.icon ? icon(opts.icon, 18) : '') + `<span></span>` }); h.querySelector('span').textContent = title;
  const ctr = el('div', { class: 'win-ctr' });
  const body = el('div', { class: 'win-body' });
  const w = { id, el: box, body, close: () => { box.remove(); wins.delete(id); opts.onClose?.(); }, refresh: null };
  const bMin = iconBtn('minimize', 'ย่อ', () => { box.classList.toggle('min'); box.classList.remove('max'); });
  const bMax = iconBtn('maximize', 'ขยาย', () => { box.dataset.autoMax = box.classList.contains('max') ? '1' : '0'; box.classList.toggle('max'); box.classList.remove('min'); bMax.innerHTML = icon(box.classList.contains('max') ? 'restore' : 'maximize', 20); w.onResize?.(); });
  ctr.append(bMin, bMax, iconBtn('close', 'ปิด', w.close));
  head.append(h, ctr); box.append(head, body);
  document.getElementById('windows').append(box);
  box.style.zIndex = ++zTop;
  const vw = innerWidth, vh = innerHeight; const ww = Math.min(opts.w || 420, vw - 16), wh = Math.min(opts.h || 480, Math.max(200, vh - 140));
  box.style.width = ww + 'px'; if (opts.h) box.style.height = wh + 'px';
  box.style.left = Math.max(8, (vw - ww) / 2 + (wins.size * 18) % 90) + 'px'; box.style.top = Math.max(56, (vh - wh) / 2 - 30 + (wins.size * 18) % 90) + 'px';
  if (vw < 640 || vh < 520) box.classList.add('max'); // phones (either orientation): window fills the free area
  box.addEventListener('pointerdown', () => box.style.zIndex = ++zTop);
  let drag = null;
  head.addEventListener('pointerdown', e => { if (e.target.closest('button') || box.classList.contains('max')) return; drag = { x: e.clientX, y: e.clientY, l: box.offsetLeft, t: box.offsetTop }; head.setPointerCapture(e.pointerId); });
  head.addEventListener('pointermove', e => { if (!drag) return; box.style.left = Math.min(innerWidth - 60, Math.max(-box.offsetWidth + 80, drag.l + e.clientX - drag.x)) + 'px'; box.style.top = Math.min(innerHeight - 40, Math.max(0, drag.t + e.clientY - drag.y)) + 'px'; });
  head.addEventListener('pointerup', () => drag = null);
  head.addEventListener('dblclick', () => bMax.click());
  build(body, w);
  wins.set(id, w);
  return w;
}
export const getWindow = id => wins.get(id);
export function closeAllWindows() { for (const w of [...wins.values()]) w.close(); }

export function field(label, input, hint) {
  const f = el('label', { class: 'field' }, el('span', { class: 'lab' }, label), input);
  if (hint) f.append(el('small', { class: 'hint' }, hint));
  return f;
}
export function slider(min, max, step, val, oninput) {
  const wrap = el('div', { class: 'slider' });
  const i = el('input', { type: 'range', min, max, step, value: val }); const o = el('output', {}, String(val));
  i.addEventListener('input', () => { o.textContent = i.value; oninput(+i.value); });
  wrap.append(i, o); wrap.input = i; wrap.set = v => { i.value = v; o.textContent = v; }; return wrap;
}
export function select(options, val, onchange) {
  const s = el('select', {}); for (const [v, t] of options) { const o = el('option', { value: v }, t); if (String(v) === String(val)) o.selected = true; s.append(o); }
  s.addEventListener('change', () => onchange(s.value)); return s;
}
export function toggle(label, val, onchange) {
  const i = el('input', { type: 'checkbox' }); i.checked = !!val; i.addEventListener('change', () => onchange(i.checked));
  return el('label', { class: 'toggle' }, i, el('span', { class: 'tg' }), el('span', {}, label));
}
export function tabs(defs) {
  const bar = el('div', { class: 'tabs', role: 'tablist' }), panes = el('div', { class: 'tabpanes' }); const map = {};
  defs.forEach((d, i) => {
    const b = el('button', { class: 'tab' + (i ? '' : ' on'), type: 'button', role: 'tab', html: (d.icon ? icon(d.icon, 16) : '') + `<span>${d.label}</span>` });
    const p = el('div', { class: 'pane' + (i ? '' : ' on'), role: 'tabpanel' }); d.build(p);
    b.addEventListener('click', () => { bar.querySelectorAll('.tab').forEach(x => x.classList.remove('on')); panes.querySelectorAll('.pane').forEach(x => x.classList.remove('on')); b.classList.add('on'); p.classList.add('on'); d.onShow?.(); });
    bar.append(b); panes.append(p); map[d.id || i] = p;
  });
  return el('div', { class: 'tabwrap' }, bar, panes);
}

// after a rotation / resize keep every window on screen (and switch to the full-area layout on small screens)
addEventListener('resize', () => {
  const vw = innerWidth, vh = innerHeight, small = vw < 640 || vh < 520;
  for (const w of document.querySelectorAll('#windows .win')) {
    if (small) { w.classList.add('max'); continue; }
    if (w.classList.contains('max') && w.dataset.autoMax !== '0') w.classList.remove('max');
    const ww = Math.min(w.offsetWidth, vw - 16); w.style.width = ww + 'px';
    if (w.style.height) w.style.height = Math.min(parseFloat(w.style.height), vh - 120) + 'px';
    w.style.left = Math.min(Math.max(8, w.offsetLeft), Math.max(8, vw - ww - 8)) + 'px';
    w.style.top = Math.min(Math.max(8, w.offsetTop), Math.max(8, vh - 120)) + 'px';
  }
});
