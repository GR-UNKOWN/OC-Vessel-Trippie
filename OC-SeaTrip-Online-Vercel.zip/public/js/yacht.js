// Data-driven yachts (side cutaway, bow to the right).
//  - SouthCozy SeaLife: 6-deck expedition yacht modelled on the copper/charcoal/white references.
//  - Big Orcasia: 9-deck white superyacht modelled on the long-hull, stacked-tier references (two helipads, davit lifeboats, internal tender bay).
// Every export below is a live binding re-pointed by setYacht(), so other modules always see the active yacht.
import { makeCanvas, shade, mixHex, rng } from './util.js';

export let SPEC = null, YW = 1000, YH = 372, WL = 330;
export let LEVELS = {}, LEVEL_ORDER = [], STAIRS = [], ROOMS = [], roomById = {}, OBJECTS = [], FIXTURES = [], ROOM_WINDOWS = {}, PADS = [];

export const PARTS = [
  { id: 'hull', th: 'ตัวเรือ (Hull)' }, { id: 'super', th: 'โครงสร้างบน (Superstructure)' }, { id: 'roof', th: 'หลังคา / แผงขอบชั้น (Roof)' },
  { id: 'trim', th: 'ขอบดาดฟ้า / สีใต้น้ำ (Deck Trimming)' }, { id: 'frames', th: 'กรอบ & แถบหน้าต่าง (Window Frames)' }, { id: 'rails', th: 'ราวกันตก (Railings)' },
  { id: 'iwall', th: 'ผนังภายใน (Interior Walls)' }, { id: 'furn', th: 'เฟอร์นิเจอร์ (Furniture)' }, { id: 'floor', th: 'พื้นห้อง (Cabin Flooring)' },
];

/* ======================================================================= */
/*  Yacht definitions                                                       */
/* ======================================================================= */
const R_ = (id, type, level, x1, x2, th, io = 'in', extra = {}) => ({ id, type, level, x1, x2, th, type_: type, io, ...extra });

const SOUTHCOZY = {
  id: 'southcozy', name: 'SouthCozy SeaLife', th: 'เรือเอ็กซ์เพดิชันขนาดกลาง-ใหญ่ 6 ชั้น', lengthM: 79,
  W: 1000, H: 372, WL: 330, hullX1: 40, hullX2: 960, hullDecks: { D0: 'square' },
  levels: { swim: [328, 'ชานท้ายเรือ'], D0: [340, 'ชั้นล่าง (Lower Deck)'], D1: [296, 'ชั้นหลัก (Main Deck)'], D2: [252, 'ชั้นบน (Upper Deck)'], D3: [208, 'ชั้นเลานจ์ & กัปตัน (Owner Deck)'], D4: [164, 'ชั้นสะพานเดินเรือ (Bridge Deck)'], D5: [120, 'ฟลายบริดจ์ (Top Deck)'] },
  rooms: [
    R_('swim', 'swim', 'swim', 0, 40, 'ชานท้ายเรือ', 'out'),
    R_('garage', 'garage', 'D0', 44, 200, 'โรงเก็บเรือเล็ก'), R_('engine', 'engine', 'D0', 200, 330, 'ห้องเครื่องยนต์'), R_('crew', 'crew', 'D0', 330, 420, 'ห้องลูกเรือ'),
    R_('stair0', 'stair', 'D0', 420, 456, 'บันได'), R_('utility', 'utility', 'D0', 456, 520, 'ห้องเก็บอุปกรณ์'), R_('guest1', 'vip', 'D0', 520, 620, 'ห้องพัก VIP'),
    R_('guest2', 'guest', 'D0', 620, 720, 'ห้องพัก OC (เตียงสองชั้น)'), R_('bath', 'bath', 'D0', 720, 780, 'ห้องน้ำ'), R_('gym', 'gym', 'D0', 780, 920, 'ห้องออกกำลังกาย'),
    R_('aftdeck', 'aftdeck', 'D1', 40, 190, 'ดาดฟ้าท้าย', 'out'), R_('dining', 'dining', 'D1', 190, 320, 'ห้องรับประทานอาหาร'), R_('lounge', 'lounge', 'D1', 320, 420, 'ห้องนั่งเล่น'),
    R_('stair1', 'stair', 'D1', 420, 456, 'บันได'), R_('galley', 'galley', 'D1', 456, 560, 'ห้องครัว'), R_('master', 'master', 'D1', 560, 760, 'ห้องนอนหลัก'),
    R_('mbath', 'bath', 'D1', 760, 820, 'ห้องน้ำห้องนอนหลัก'), R_('bow', 'bow', 'D1', 820, 950, 'จุดชมวิวหัวเรือ', 'out'),
    R_('liferaft', 'liferaft', 'D2', 44, 110, 'ที่เก็บแพชูชีพ', 'out'), R_('deck2', 'aftdeck', 'D2', 110, 300, 'ดาดฟ้าใต้ลานจอด ฮ.', 'out'), R_('skylounge', 'skylounge', 'D2', 300, 420, 'สกายเลานจ์'),
    R_('stair2', 'stair', 'D2', 420, 456, 'บันได'), R_('library', 'library', 'D2', 456, 540, 'ห้องสมุด'), R_('cinema', 'cinema', 'D2', 540, 680, 'ห้องฉายภาพยนตร์'), R_('vip2', 'vip', 'D2', 680, 820, 'ห้องพักแขก'), R_('bow2', 'bow', 'D2', 820, 944, 'ระเบียงหัวเรือชั้นบน', 'out'),
    R_('helideck', 'helideck', 'D3', 44, 330, 'ลานจอดเฮลิคอปเตอร์', 'out'), R_('bar', 'bar', 'D3', 330, 420, 'บาร์'), R_('stair3', 'stair', 'D3', 420, 456, 'บันได'),
    R_('observation', 'skylounge', 'D3', 456, 640, 'เลานจ์ชมวิว'), R_('captain', 'captain', 'D3', 640, 700, 'ห้องกัปตัน'), R_('fwdbalcony', 'bow', 'D3', 700, 750, 'ระเบียงหน้า', 'out'),
    // the navigation bridge sits on the highest enclosed deck, right under the mast — as on the reference expedition yacht
    R_('sundeck', 'sundeck', 'D4', 300, 420, 'ดาดฟ้าอาบแดด', 'out'), R_('stair4', 'stair', 'D4', 420, 456, 'บันได'), R_('wheelhouse', 'wheelhouse', 'D4', 456, 600, 'ห้องสะพานเดินเรือ (Wheelhouse)'), R_('wing', 'wing', 'D4', 600, 640, 'ปีกสะพานเดินเรือ', 'out'), R_('sun2', 'sundeck', 'D4', 640, 692, 'ลานอาบแดดหน้า', 'out'),
    R_('stair5', 'stair', 'D5', 420, 456, 'ทางขึ้นฟลายบริดจ์', 'out'), R_('flybridge', 'flybridge', 'D5', 456, 600, 'ฟลายบริดจ์', 'out'),
  ],
  stairs: [['s01', 'D0', 424, 'D1', 452], ['s12', 'D1', 452, 'D2', 424], ['s23', 'D2', 424, 'D3', 452], ['s34', 'D3', 452, 'D4', 424], ['s45', 'D4', 424, 'D5', 452], ['ladder', 'swim', 28, 'D1', 50]],
  spawn: { level: 'D1', x1: 330, x2: 560 },
  pads: [{ id: 'heli', th: 'ลานจอดท้ายเรือ (Upper Aft)', room: 'helideck', x1: 64, x2: 320, y: 208, cx: 196, face: 1, from: -1 }],
  tender: { stowX: 122, floorY: 340, doorX: 40, doorTop: 300 },
  liferaft: { x: 77, y: 236 },
  lifeboats: [],
  nav: [[527, 12, 'w'], [636, 150, 'g'], [633, 153, 'r'], [42, 290, 'w']],
  paint: {
    hull: { color: '#c48a5c', color2: '#9c6a44', pattern: 'solid' }, super: { color: '#f3f1ec', color2: '#d9d6cf', pattern: 'solid' },
    roof: { color: '#fbfaf7', color2: '#e5e2da', pattern: 'solid' }, trim: { color: '#3a3f45', color2: '#f6f4ef', pattern: 'solid' },
    frames: { color: '#353b42', color2: '#4b535c', pattern: 'solid' }, rails: { color: '#e9ecef', color2: '#b9c0c6', pattern: 'solid' },
    iwall: { color: '#efe6d6', color2: '#d8c8b0', pattern: 'solid' }, furn: { color: '#8a5a3c', color2: '#c9a27c', pattern: 'solid' }, floor: { color: '#c9a77c', color2: '#b08a60', pattern: 'solid' },
  },
};

const ORCASIA = {
  id: 'orcasia', name: 'Big Orcasia', th: 'ซูเปอร์ยอร์ช 9 ชั้น', lengthM: 142,
  W: 1800, H: 480, WL: 436, hullX1: 60, hullX2: 1714, hullDecks: { L0: 'dot', L1: 'port', L2: 'pair' },
  levels: { swim: [434, 'ชานท้ายเรือ'], L0: [444, 'ชั้น 1 ห้องเครื่อง (Tank Deck)'], L1: [400, 'ชั้น 2 ล่าง (Lower Deck)'], L2: [356, 'ชั้น 3 หลัก (Main Deck)'], L3: [312, 'ชั้น 4 บน (Upper Deck)'], L4: [268, 'ชั้น 5 สะพานเดินเรือ (Bridge Deck)'], L5: [224, 'ชั้น 6 เจ้าของเรือ (Owner Deck)'], L6: [180, 'ชั้น 7 อาบแดด / ลานจอด ฮ.'], L7: [136, 'ชั้น 8 ดาดฟ้าบนสุด'], L8: [92, 'ชั้น 9 ดาดฟ้าเสากระโดง'] },
  rooms: [
    R_('swim', 'swim', 'swim', 0, 60, 'ชานท้ายเรือ', 'out'),
    R_('engine', 'engine', 'L0', 100, 420, 'ห้องเครื่องยนต์หลัก'), R_('gen', 'utility', 'L0', 420, 560, 'ห้องเครื่องปั่นไฟ'), R_('sA0', 'stair', 'L0', 560, 596, 'บันไดท้าย'),
    R_('laundry', 'utility', 'L0', 596, 700, 'ห้องซักรีด'), R_('crew0a', 'crew', 'L0', 700, 850, 'ห้องลูกเรือ A'), R_('crew0b', 'crew', 'L0', 850, 1000, 'ห้องลูกเรือ B'),
    R_('store', 'utility', 'L0', 1000, 1120, 'ห้องเก็บเสบียง'), R_('mess', 'crew', 'L0', 1120, 1240, 'ห้องอาหารลูกเรือ'), R_('sF0', 'stair', 'L0', 1240, 1276, 'บันไดหน้า'), R_('thruster', 'engine', 'L0', 1276, 1600, 'ห้องเครื่องหัวเรือ'),
    R_('beach', 'beachclub', 'L1', 60, 240, 'บีชคลับ'), R_('garage', 'garage', 'L1', 240, 500, 'โรงเก็บเรือเล็กภายใน'), R_('gym1', 'gym', 'L1', 500, 560, 'ห้องฟิตเนส'), R_('sA1', 'stair', 'L1', 560, 596, 'บันไดท้าย'),
    R_('cinema1', 'cinema', 'L1', 596, 760, 'โรงภาพยนตร์'), R_('guestA', 'vip', 'L1', 760, 900, 'ห้องพักแขก A'), R_('guestB', 'vip', 'L1', 900, 1040, 'ห้องพักแขก B'), R_('guestC', 'guest', 'L1', 1040, 1180, 'ห้องพัก OC'),
    R_('bath1', 'bath', 'L1', 1180, 1240, 'ห้องน้ำ'), R_('sF1', 'stair', 'L1', 1240, 1276, 'บันไดหน้า'), R_('crew1', 'crew', 'L1', 1276, 1450, 'ห้องลูกเรือ'), R_('utility1', 'utility', 'L1', 1450, 1680, 'ห้องเก็บเชือกและสมอ'),
    R_('aft2', 'aftdeck', 'L2', 64, 300, 'ดาดฟ้าท้ายหลัก', 'out'), R_('dining2', 'dining', 'L2', 300, 560, 'ห้องอาหารหลัก'), R_('sA2', 'stair', 'L2', 560, 596, 'บันไดท้าย'), R_('salon', 'lounge', 'L2', 596, 860, 'ห้องโถงใหญ่'),
    R_('galley2', 'galley', 'L2', 860, 1000, 'ห้องครัว'), R_('suite1', 'master', 'L2', 1000, 1120, 'สวีทแขก 1'), R_('suite2', 'master', 'L2', 1120, 1240, 'สวีทแขก 2'), R_('sF2', 'stair', 'L2', 1240, 1276, 'บันไดหน้า'),
    R_('library2', 'library', 'L2', 1276, 1400, 'ห้องสมุด'), R_('guestD', 'vip', 'L2', 1400, 1560, 'ห้องพักแขกหัวเรือ'), R_('bath2', 'bath', 'L2', 1560, 1640, 'ห้องน้ำ'),
    R_('aft3', 'aftdeck', 'L3', 120, 220, 'ดาดฟ้าท้ายชั้นบน', 'out'), R_('bar3', 'bar', 'L3', 220, 340, 'บาร์'), R_('spa3', 'spa', 'L3', 340, 560, 'สปาและสระในร่ม'), R_('sA3', 'stair', 'L3', 560, 596, 'บันไดท้าย'),
    R_('lounge3', 'lounge', 'L3', 596, 820, 'เลานจ์ชั้นบน'), R_('dining3', 'dining', 'L3', 820, 980, 'ห้องอาหารส่วนตัว'), R_('office3', 'library', 'L3', 980, 1100, 'ห้องทำงาน'), R_('guestE', 'vip', 'L3', 1100, 1240, 'ห้องพักแขก E'),
    R_('sF3', 'stair', 'L3', 1240, 1276, 'บันไดหน้า'), R_('gym3', 'gym', 'L3', 1276, 1450, 'ฟิตเนสชั้นบน'), R_('foredeck', 'foredeck', 'L3', 1450, 1745, 'ดาดฟ้าหัวเรือ / ลานจอด ฮ. หน้า', 'out'),
    R_('aft4', 'aftdeck', 'L4', 300, 420, 'ดาดฟ้าท้ายชั้นสะพาน', 'out'), R_('sky4', 'skylounge', 'L4', 420, 560, 'สกายเลานจ์'), R_('sA4', 'stair', 'L4', 560, 596, 'บันไดท้าย'),
    R_('lifeboat1', 'lifeboat', 'L4', 596, 760, 'เดวิทเรือ Tender / ชูชีพ 1', 'out'), R_('bar4', 'bar', 'L4', 760, 960, 'บาร์ชั้นสะพาน'), R_('lifeboat2', 'lifeboat', 'L4', 960, 1120, 'เดวิทเรือ Tender / ชูชีพ 2', 'out'),
    R_('captain4', 'captain', 'L4', 1120, 1240, 'ห้องกัปตัน'), R_('sF4', 'stair', 'L4', 1240, 1276, 'บันไดหน้า'), R_('wheelhouse', 'wheelhouse', 'L4', 1276, 1400, 'ห้องควบคุมเรือ'), R_('wing4', 'wing', 'L4', 1400, 1440, 'ปีกสะพานเดินเรือ', 'out'),
    R_('aft5', 'aftdeck', 'L5', 420, 560, 'ดาดฟ้าส่วนตัว', 'out'), R_('sA5', 'stair', 'L5', 560, 596, 'บันไดท้าย'), R_('ownerlounge', 'lounge', 'L5', 596, 800, 'เลานจ์เจ้าของเรือ'),
    R_('owner', 'master', 'L5', 800, 1000, 'ห้องนอนเจ้าของเรือ'), R_('sU5', 'stair', 'L5', 1000, 1036, 'บันไดบน'), R_('ownerbath', 'bath', 'L5', 1036, 1110, 'ห้องน้ำเจ้าของเรือ'), R_('study', 'library', 'L5', 1110, 1240, 'ห้องทำงานส่วนตัว'),
    R_('helideck', 'helideck', 'L6', 520, 820, 'ลานจอด ฮ. ท้าย', 'out'), R_('sunlounge', 'skylounge', 'L6', 820, 1000, 'ซันเลานจ์'), R_('sU6', 'stair', 'L6', 1000, 1036, 'บันไดบน'), R_('bar6', 'bar', 'L6', 1036, 1160, 'สกายบาร์'),
    R_('obs7', 'skylounge', 'L7', 900, 1000, 'ห้องชมวิวบนสุด'), R_('sU7', 'stair', 'L7', 1000, 1036, 'บันไดบน'), R_('top7', 'sundeck', 'L7', 1036, 1150, 'ดาดฟ้าบนสุด', 'out'),
    R_('sU8', 'stair', 'L8', 1000, 1036, 'ทางขึ้นเสากระโดง', 'out'), R_('mast8', 'mastdeck', 'L8', 1036, 1100, 'ดาดฟ้าเสากระโดง', 'out'),
  ],
  stairs: [
    ['sA01', 'L0', 564, 'L1', 592], ['sA12', 'L1', 592, 'L2', 564], ['sA23', 'L2', 564, 'L3', 592], ['sA34', 'L3', 592, 'L4', 564], ['sA45', 'L4', 564, 'L5', 592],
    ['sF01', 'L0', 1244, 'L1', 1272], ['sF12', 'L1', 1272, 'L2', 1244], ['sF23', 'L2', 1244, 'L3', 1272], ['sF34', 'L3', 1272, 'L4', 1244],
    ['sU56', 'L5', 1004, 'L6', 1032], ['sU67', 'L6', 1032, 'L7', 1004], ['sU78', 'L7', 1004, 'L8', 1032], ['ladder', 'swim', 36, 'L1', 72],
  ],
  spawn: { level: 'L2', x1: 600, x2: 850 },
  pads: [
    { id: 'heli', th: 'ลานจอดท้าย (ชั้น 7)', room: 'helideck', x1: 540, x2: 800, y: 180, cx: 676, face: 1, from: -1 },
    { id: 'fore', th: 'ลานจอดหัวเรือ (ชั้น 4)', room: 'foredeck', x1: 1490, x2: 1700, y: 312, cx: 1600, face: -1, from: 1 },
  ],
  tender: { stowX: 372, floorY: 400, doorX: 60, doorTop: 362 },
  liferaft: null,
  lifeboats: [{ id: 'lb1', room: 'lifeboat1', x: 678, y: 268, th: 'เรือ Tender / ชูชีพ 1' }, { id: 'lb2', room: 'lifeboat2', x: 1040, y: 268, th: 'เรือ Tender / ชูชีพ 2' }],
  nav: [[1066, 8, 'w'], [1438, 254, 'g'], [1435, 257, 'r'], [64, 340, 'w']],
  paint: {
    hull: { color: '#f5f5f2', color2: '#dfe3e6', pattern: 'solid' }, super: { color: '#f8f8f5', color2: '#e3e5e6', pattern: 'solid' },
    roof: { color: '#ffffff', color2: '#e8eaec', pattern: 'solid' }, trim: { color: '#1f2b3c', color2: '#f4f2ec', pattern: 'solid' },
    frames: { color: '#28323b', color2: '#3a4752', pattern: 'solid' }, rails: { color: '#edf0f2', color2: '#b9c0c6', pattern: 'solid' },
    iwall: { color: '#efe9de', color2: '#d8c8b0', pattern: 'solid' }, furn: { color: '#7a5238', color2: '#c9a27c', pattern: 'solid' }, floor: { color: '#d4b48a', color2: '#b08a60', pattern: 'solid' },
  },
};
export const YACHTS = { southcozy: SOUTHCOZY, orcasia: ORCASIA };
export const YACHT_IDS = Object.keys(YACHTS);
export const DEFAULT_PAINT = SOUTHCOZY.paint;
export const defaultPaint = id => structuredClone(YACHTS[id].paint);

/* ======================================================================= */
/*  Room types: furniture art, interaction points, light fixtures           */
/* ======================================================================= */
function bedGeom(r, small) { const w = r.x2 - r.x1, bw = Math.min(small ? 64 : 78, w - 48); return { bw, bx: Math.round((r.x1 + r.x2) / 2 - bw / 2 + 2) }; }
const OUT_DECK_LIGHT = new Set(['aftdeck', 'sundeck', 'helideck', 'bow', 'foredeck', 'flybridge', 'wing', 'swim', 'lifeboat', 'mastdeck', 'liferaft']);
function objectsFor(r) {
  const fy = LEVELS[r.level].y, w = r.x2 - r.x1, cx = (r.x1 + r.x2) / 2, o = [];
  const add = (kind, th, x, rect, extra = {}) => o.push({ id: r.id + '_' + kind + o.length, room: r.id, kind, th, x: Math.round(x), rect: rect.map(Math.round), ...extra });
  switch (r.type) {
    case 'lounge': case 'skylounge': { const sw = Math.min(88, w - 44), sx = r.x1 + 18; add('sofa', 'โซฟา', sx + sw / 2, [sx, fy - 24, sw, 22], { slots: 3, sitX: [sx + sw * 0.2, sx + sw * 0.5, sx + sw * 0.8].map(Math.round), seatH: 10, bedY: fy - 14 }); if (w >= 200) { const ax = sx + sw + 24; add('sofa', 'อาร์มแชร์', ax + 28, [ax, fy - 24, 56, 22], { slots: 2, sitX: [ax + 9, ax + 47], seatH: 10 }); } if (w > 120) add('window', 'มองออกนอกหน้าต่าง', r.x2 - 18, [r.x2 - 34, fy - 36, 28, 14]); break; }
    case 'dining': { const n = w > 150 ? 6 : 4, tw = Math.min(w - 40, n * 15), tx = cx - tw / 2; add('dining', 'โต๊ะอาหาร', cx, [tx, fy - 18, tw, 18], { slots: n, sitX: Array.from({ length: n }, (_, i) => Math.round(tx + 4 + i * (tw - 8) / (n - 1))), seatH: 7 }); break; }
    case 'galley': add('stove', 'เตาและเคาน์เตอร์ครัว', r.x1 + 28, [r.x1 + 8, fy - 24, 42, 24]); add('fridge', 'ตู้เย็น', r.x2 - 16, [r.x2 - 28, fy - 36, 22, 36]); break;
    case 'master': case 'vip': { const { bw, bx } = bedGeom(r, r.type !== 'master'); add('bed', r.type === 'master' ? 'เตียงใหญ่' : 'เตียงคู่', bx + bw / 2, [bx, fy - 28, bw, 28], { slots: 2, sleepX: [Math.round(bx + bw * 0.33), Math.round(bx + bw * 0.66)], bedY: fy - 24 }); if (w > 110) add('window', 'มองออกนอกหน้าต่าง', r.x2 - 14, [r.x2 - 26, fy - 34, 20, 12]); break; }
    case 'guest': { const bx = r.x1 + 10, bw = Math.min(74, w - 24); add('bed', 'เตียงชั้นบน', bx + bw / 2, [bx, fy - 34, bw, 12], { slots: 1, sleepX: [Math.round(bx + bw / 2)], bedY: fy - 30 }); add('bed', 'เตียงชั้นล่าง', bx + bw / 2, [bx, fy - 16, bw, 16], { slots: 1, sleepX: [Math.round(bx + bw / 2)], bedY: fy - 12 }); break; }
    case 'captain': { const bx = r.x1 + 8, bw = Math.min(46, w - 16); add('bed', 'เตียงกัปตัน', bx + bw / 2, [bx, fy - 18, bw, 18], { slots: 1, sleepX: [Math.round(bx + bw / 2)], bedY: fy - 14 }); add('logbook', 'สมุดบันทึกกัปตัน', r.x2 - 10, [r.x2 - 16, fy - 23, 12, 5]); break; }
    case 'crew': { const bx = r.x1 + 8, bw = Math.min(60, w - 50); add('bed', 'เตียงลูกเรือ', bx + bw / 2, [bx, fy - 16, bw, 16], { slots: 1, sleepX: [Math.round(bx + bw / 2)], bedY: fy - 12 }); if (w > 110) add('dining', 'โต๊ะอาหารลูกเรือ', r.x2 - 26, [r.x2 - 44, fy - 16, 36, 16], { slots: 2, sitX: [r.x2 - 38, r.x2 - 16], seatH: 7 }); break; }
    case 'bath': add('shower', 'ฝักบัว', r.x2 - 16, [r.x2 - 30, fy - 36, 28, 36]); break;
    case 'utility': add('utility', 'ชั้นเก็บอุปกรณ์', r.x1 + 24, [r.x1 + 4, fy - 36, 46, 36]); break;
    case 'engine': add('engine', 'เครื่องยนต์', cx, [r.x1 + 10, fy - 28, w - 40, 28]); add('svcpanel', 'แผงบริการ', r.x2 - 21, [r.x2 - 27, fy - 31, 11, 9]); break;
    case 'garage': add('garage', 'แผงควบคุมโรงเก็บเรือ', r.x2 - 12, [r.x2 - 18, fy - 30, 12, 14]); break;
    case 'wheelhouse': add('wheel', 'แท่นบังคับเรือ (Helm)', r.x2 - 42, [r.x2 - 60, fy - 28, 58, 28]); add('mapscreen', 'จอแผนที่', cx, [cx - 14, fy - 28, 28, 16]); add('navlights', 'แผงไฟนำร่อง', r.x1 + 12, [r.x1 + 4, fy - 28, 14, 12]); add('helipanel', 'วิทยุติดต่อเฮลิคอปเตอร์', r.x1 + 34, [r.x1 + 24, fy - 28, 16, 12]); break;
    case 'gym': add('gym', 'ลู่วิ่งและเครื่องออกกำลังกาย', r.x1 + 26, [r.x1 + 6, fy - 22, 40, 22]); break;
    case 'cinema': { const sx = r.x1 + 30, sw = Math.min(w - 44, 90); add('cinema', 'เก้าอี้ชมภาพยนตร์', sx + sw / 2, [sx, fy - 16, sw, 16], { slots: 4, sitX: Array.from({ length: 4 }, (_, i) => Math.round(sx + 8 + i * (sw - 16) / 3)), seatH: 9 }); break; }
    case 'spa': case 'beachclub': add('pool', 'สระว่ายน้ำ', cx + (r.type === 'beachclub' ? 10 : 0), [r.x1 + 30, fy - 10, w - 60, 10]); if (w > 150) add('lounger', 'เก้าอี้พักริมสระ', r.x1 + 22, [r.x1 + 6, fy - 12, 34, 12], { slots: 1, sitX: [r.x1 + 22], seatH: 6, bedY: fy - 8 }); break;
    case 'bar': { const bx = r.x1 + 14, bw = Math.min(w - 30, 70); add('bar', 'เคาน์เตอร์บาร์', bx + bw / 2, [bx, fy - 22, bw, 22], { slots: 3, sitX: [bx + 10, bx + bw / 2, bx + bw - 10].map(Math.round), seatH: 12 }); break; }
    case 'library': add('desk', 'โต๊ะอ่านหนังสือ', r.x2 - 26, [r.x2 - 44, fy - 20, 36, 20], { slots: 1, sitX: [r.x2 - 30], seatH: 8 }); break;
    case 'aftdeck': { const sw = Math.min(56, w - 30), sx = r.x1 + 20; add('sofa', 'โซฟากลางแจ้ง', sx + sw / 2, [sx, fy - 18, sw, 18], { slots: 3, sitX: [sx + 10, sx + sw / 2, sx + sw - 10].map(Math.round), seatH: 9, bedY: fy - 12 }); if (w > 120) add('view', 'ชมวิวท้ายเรือ', r.x2 - 20, [r.x2 - 36, fy - 30, 30, 30]); break; }
    case 'sundeck': { const n = Math.max(1, Math.floor((w - 20) / 50)); for (let i = 0; i < n; i++) { const lx = r.x1 + 10 + i * 50; add('lounger', 'เก้าอี้อาบแดด', lx + 20, [lx, fy - 12, 40, 12], { slots: 1, sitX: [lx + 20], seatH: 6, bedY: fy - 7 }); } break; }
    case 'flybridge': add('sofa', 'โซฟาฟลายบริดจ์', r.x2 - 40, [r.x2 - 66, fy - 18, 54, 18], { slots: 2, sitX: [r.x2 - 52, r.x2 - 28], seatH: 9, bedY: fy - 12 }); add('view', 'จุดชมวิวด้านบน', r.x1 + 20, [r.x1 + 8, fy - 30, 24, 30]); break;
    case 'bow': case 'wing': case 'swim': case 'mastdeck': add('view', 'ชมวิว', r.type === 'swim' ? cx : r.x2 - 20, [r.x2 - 36, fy - 30, 30, 30]); break;
    case 'foredeck': add('view', 'ชมวิวหัวเรือ', r.x2 - 40, [r.x2 - 60, fy - 30, 30, 30]); add('helipad', 'ลานจอดเฮลิคอปเตอร์หน้า', r.x1 + 60, [r.x1 + 30, fy - 6, 60, 6]); break;
    case 'helideck': add('helipad', 'ลานจอดเฮลิคอปเตอร์', r.x1 + 30, [r.x1 + 16, fy - 10, 30, 10]); break;
    case 'liferaft': add('liferaft', 'แพชูชีพ', cx, [r.x1 + 10, fy - 20, w - 20, 20]); break;
    case 'lifeboat': add('lifeboat', 'เรือ Tender / ชูชีพ (เดวิท)', r.x1 + 16, [r.x1 + 6, fy - 30, w - 12, 30]); break;
  }
  if (r.io === 'in' && r.type !== 'stair') add('switch', 'สวิตช์ไฟ ' + r.th, r.x1 + 6, [r.x1 + 3, fy - 24, 6, 8]);
  return o;
}
function fixturesFor(r) {
  const fy = LEVELS[r.level].y, w = r.x2 - r.x1, cx = (r.x1 + r.x2) / 2, f = [];
  if (r.io === 'in') f.push({ id: r.id + ':ceiling', room: r.id, kind: 'ceiling', th: 'ไฟเพดาน', x: cx, y: fy - 37, radius: Math.max(30, w * 0.6) });
  if (r.type === 'lounge' || r.type === 'skylounge') f.push({ id: r.id + ':lamp', room: r.id, kind: 'lamp', th: 'โคมไฟตั้งพื้น', x: r.x1 + 12, y: fy - 24, radius: 40 });
  if (r.type === 'master' || r.type === 'vip' || r.type === 'guest' || r.type === 'captain') f.push({ id: r.id + ':bedside', room: r.id, kind: 'bedside', th: 'ไฟหัวเตียง', x: r.x1 + 12, y: fy - 20, radius: 28 });
  if (r.type === 'stair') f.push({ id: r.id + ':corridor', room: r.id, kind: 'corridor', th: 'ไฟทางเดิน', x: cx, y: fy - 4, radius: 24 });
  if (r.io === 'out' && OUT_DECK_LIGHT.has(r.type)) f.push({ id: r.id + ':deck', room: r.id, kind: 'deck', th: 'ไฟดาดฟ้า', x: cx, y: fy - 34, radius: Math.min(80, Math.max(36, w * 0.45)) });
  return f;
}

/* ======================================================================= */
/*  setYacht — repoint every live binding                                   */
/* ======================================================================= */
export function setYacht(id) {
  const s = YACHTS[id] || SOUTHCOZY; SPEC = s; YW = s.W; YH = s.H; WL = s.WL;
  LEVELS = {}; for (const [lid, [y, name]] of Object.entries(s.levels)) LEVELS[lid] = { y, name, x1: 1e9, x2: -1e9 };
  ROOMS = s.rooms.map(r => ({ ...r, type: r.type_, typeIO: r.io, ...(r.io === 'in' ? { win: ({ engine: 0.05, utility: 0.15, garage: 0.15, stair: 0.3, bath: 0.3, crew: 0.3, cinema: 0.05, gym: 0.5 })[r.type_] ?? 0.7 } : {}) }));
  // `type` keeps backwards compat: 'in' / 'out' for shell logic, room style lives in `kind`
  for (const r of ROOMS) { r.kind = r.type_; r.type = r.io; r.stair = r.kind === 'stair'; const L = LEVELS[r.level]; L.x1 = Math.min(L.x1, r.x1 + 4); L.x2 = Math.max(L.x2, r.x2 - 4); }
  LEVEL_ORDER = Object.keys(LEVELS).filter(k => k !== 'swim').sort((a, b) => LEVELS[b].y - LEVELS[a].y);
  STAIRS = s.stairs.map(([sid, a, ax, b, bx]) => ({ id: sid, a, ax, b, bx }));
  roomById = Object.fromEntries(ROOMS.map(r => [r.id, r]));
  OBJECTS = []; FIXTURES = [];
  for (const r of ROOMS) { const rr = { ...r, type: r.kind }; OBJECTS.push(...objectsFor(rr)); FIXTURES.push(...fixturesFor(rr)); }
  FIXTURES.push({ id: 'nav', room: ROOMS.find(r => r.kind === 'wheelhouse')?.id, kind: 'nav', th: 'ไฟนำร่องเรือ', x: s.nav[0][0], y: s.nav[0][1], radius: 10 });
  PADS = s.pads; ROOM_WINDOWS = computeWindows(s);
  // "look out of the window" spots stand in front of a real window of that room
  for (const o of OBJECTS) if (o.kind === 'window') { const ws = ROOM_WINDOWS[o.room]; if (!ws?.length) { o.kind = 'view'; continue; } const [x, y, w, h] = ws[ws.length - 1]; o.x = Math.round(x + w / 2); o.rect = [x, y, w, h]; }
  return s;
}

/* ---------------- windows: one layout shared by the exterior shell AND the interior wall ----------------
   Every window belongs to exactly one room, is centred symmetrically inside it, never crosses a bulkhead
   and keeps clear of tall furniture, so what you see from outside is exactly what you see from inside. */
export const WIN_STYLES = {
  pano: { y: -34, h: 26, pw: 16, gap: 2, band: 1 },          // salons, dining, bars, sky lounges
  cabin: { y: -33, h: 15, pw: 20, gap: 5, band: 1, max: 4 }, // master / VIP / gym
  small: { y: -31, h: 11, pw: 12, gap: 6, band: 1, max: 5 }, // guest, crew, captain, library
  bridge: { y: -34, h: 24, pw: 13, gap: 5, band: 2 },        // raked wheelhouse glazing
  stair: { y: -31, h: 10, pw: 8, gap: 0, max: 1, band: 1 },
  blind: { y: -31, h: 11, pw: 12, gap: 6, band: 1, max: 5, blind: 1 },   // rooms kept dark (cinema, stores): blinds closed
  frost: { y: -32, h: 8, pw: 10, gap: 6, band: 1, max: 2, frost: 1 },   // bathrooms: frosted glass
  square: { y: -31, h: 9, pw: 10, gap: 10, max: 5 },         // hull windows (copper expedition hull)
  pair: { y: -30, h: 10, pw: 6, gap: 2, pairGap: 10 },       // paired hull windows (white superyacht)
  port: { y: -28, h: 5, pw: 5, gap: 9 },                     // lower-deck portholes
  dot: { y: -26, h: 3, pw: 3, gap: 15 },                     // tank-deck deadlights
};
const KIND_WIN = { galley: 'small', cinema: 'blind', utility: 'blind', bath: 'frost', lounge: 'pano', skylounge: 'pano', dining: 'pano', bar: 'pano', spa: 'pano', master: 'cabin', vip: 'cabin', gym: 'cabin', guest: 'small', crew: 'small', captain: 'small', library: 'small', wheelhouse: 'bridge', stair: 'stair' };
// span of back wall that is free of tall furniture, per room kind
function winSpan(r) {
  const w = r.x2 - r.x1;
  switch (r.kind) {
    case 'library': return [r.x1 + 6 + Math.max(1, Math.floor((w - 50) / 18)) * 18 + 2, r.x2];
    case 'bar': return [r.x1 + 36, r.x2];
    case 'galley': return [r.x1 + 36, r.x2 - 30];
    case 'bath': return [r.x2 - 32, r.x2 + 4];
    case 'spa': return [r.x1, r.x2 - 30];
    case 'crew': return [r.x1, r.x2 - 48];
    case 'guest': return [r.x1, r.x2 - 14];
    case 'wheelhouse': return [r.x1 + 6, r.x2];
    default: return [r.x1, r.x2];
  }
}
function computeWindows(s) {
  const out = {};
  for (const r of ROOMS) {
    if (r.type !== 'in') continue;
    let st = KIND_WIN[r.kind]; if (!st) continue;
    const hd = s.hullDecks?.[r.level]; if (hd && r.kind !== 'wheelhouse') st = hd === 'dot' && r.kind !== 'crew' ? null : hd;
    if (!st) continue; const S = WIN_STYLES[st]; const fy = LEVELS[r.level].y;
    r.winBlind = !!(WIN_STYLES[KIND_WIN[r.kind]]?.blind); r.winFrost = !!(WIN_STYLES[KIND_WIN[r.kind]]?.frost);
    let [a, b] = winSpan(r); a += 6; b -= 6; const span = b - a; if (span < S.pw) continue;
    const list = [];
    if (st === 'pair') {
      const gw = S.pw * 2 + S.gap; let n = Math.floor((span + S.pairGap) / (gw + S.pairGap)); if (n < 1) continue;
      const tot = n * gw + (n - 1) * S.pairGap, x0 = Math.round((a + b) / 2 - tot / 2);
      for (let i = 0; i < n; i++) { const x = x0 + i * (gw + S.pairGap); list.push([x, fy + S.y, S.pw, S.h], [x + S.pw + S.gap, fy + S.y, S.pw, S.h]); }
    } else {
      let pw = S.pw, n = Math.floor((span + S.gap) / (pw + S.gap)); if (S.max) n = Math.min(n, S.max); if (n < 1) continue;
      if (st === 'pano') { n = Math.max(1, Math.floor((span + S.gap) / (pw + S.gap))); pw = Math.floor((span - (n - 1) * S.gap) / n); }
      const tot = n * pw + (n - 1) * S.gap, x0 = Math.round((a + b) / 2 - tot / 2);
      for (let i = 0; i < n; i++) list.push([x0 + i * (pw + S.gap), fy + S.y, pw, S.h]);
    }
    r.winStyle = st; out[r.id] = list;
  }
  return out;
}
// exterior glazing for every room, drawn on the shell
function drawRoomWindows(c, P) {
  const fr = P.frames.color, glass = '#2e3a44', hi = '#3e5260';
  for (const r of ROOMS) {
    const ws = ROOM_WINDOWS[r.id]; if (!ws?.length) continue; const S = WIN_STYLES[r.winStyle]; const fy = LEVELS[r.level].y;
    // one continuous dark glazing band per tier (as on both reference yachts), broken only by a slim pillar at each bulkhead
    if (S.band === 1) { const x1 = r.x1 + 2, x2 = r.x2 - 2; R(c, x1, fy - 36, x2 - x1, 30, fr); R(c, x1, fy - 36, x2 - x1, 1, shade(fr, 0.35)); R(c, x1, fy - 7, x2 - x1, 1, shade(fr, -0.3)); }
    if (S.band === 2) { const top = fy - 38; poly(c, [[r.x1, top], [r.x2 + 12, top], [r.x2, fy], [r.x1, fy]]); c.fillStyle = makeFill(c, P.frames, [r.x1, top, r.x2 - r.x1 + 12, 38]); c.fill(); }
    for (const [x, y, w, h] of ws) {
      if (S.band === 2) { poly(c, [[x, y], [x + w, y], [x + w - 1, y + h], [x + 1, y + h]]); c.fillStyle = glass; c.fill(); R(c, x + 1, y + 1, w - 2, 2, hi); continue; }
      if (!S.band) { R(c, x - 1, y - 1, w + 2, h + 2, shade(P.hull.color, -0.45)); }
      const g2 = S.band ? shade(glass, -0.12) : glass; R(c, x, y, w, h, g2); R(c, x, y, w, 1, hi); if (w > 6 && h > 6) R(c, x + 2, y + 3, 1, h - 5, hi);
      if (S.band) { R(c, x - 1, y - 1, w + 2, 1, shade(fr, 0.2)); R(c, x - 1, y + h, w + 2, 1, shade(fr, 0.2)); }
    }
  }
}
setYacht('southcozy');
export function roomTop(r) { return LEVELS[r.level].y - 40; }
export function roomAt(level, x) { return ROOMS.find(r => r.level === level && x >= r.x1 && x < r.x2) || null; }

/* ======================================================================= */
/*  Drawing helpers                                                         */
/* ======================================================================= */
function R(c, x, y, w, h, col) { c.fillStyle = col; c.fillRect(Math.round(x), Math.round(y), Math.round(w), Math.round(h)); }
function box(c, x, y, w, h, base, outline = true) {
  x = Math.round(x); y = Math.round(y); w = Math.round(w); h = Math.round(h); if (w <= 0 || h <= 0) return;
  R(c, x, y, w, h, base); R(c, x, y, w, 1, shade(base, 0.25)); R(c, x, y + h - 1, w, 1, shade(base, -0.25)); R(c, x + w - 1, y, 1, h, shade(base, -0.15));
  if (outline && w > 2 && h > 2) { c.strokeStyle = shade(base, -0.5); c.lineWidth = 1; c.strokeRect(x + 0.5, y + 0.5, w - 1, h - 1); }
}
function poly(c, pts) { c.beginPath(); c.moveTo(pts[0][0], pts[0][1]); for (let i = 1; i < pts.length; i++) c.lineTo(pts[i][0], pts[i][1]); c.closePath(); }
function rrect(c, x, y, w, h, r) { c.beginPath(); c.moveTo(x + r, y); c.lineTo(x + w - r, y); c.quadraticCurveTo(x + w, y, x + w, y + r); c.lineTo(x + w, y + h - r); c.quadraticCurveTo(x + w, y + h, x + w - r, y + h); c.lineTo(x + r, y + h); c.quadraticCurveTo(x, y + h, x, y + h - r); c.lineTo(x, y + r); c.quadraticCurveTo(x, y, x + r, y); c.closePath(); }

const patternCache = new Map();
export function makeFill(c, cfg, bounds) {
  const p = cfg.pattern || 'solid';
  if (p === 'solid') return cfg.color;
  if (p === 'twotone') { const g = c.createLinearGradient(0, bounds[1], 0, bounds[1] + bounds[3]); g.addColorStop(0, cfg.color); g.addColorStop(0.5, cfg.color); g.addColorStop(0.5, cfg.color2); g.addColorStop(1, cfg.color2); return g; }
  if (p === 'stripe') { const g = c.createLinearGradient(0, bounds[1], 0, bounds[1] + bounds[3]); g.addColorStop(0, cfg.color); g.addColorStop(0.42, cfg.color); g.addColorStop(0.42, cfg.color2); g.addColorStop(0.58, cfg.color2); g.addColorStop(0.58, cfg.color); g.addColorStop(1, cfg.color); return g; }
  const key = p + cfg.color + cfg.color2 + (cfg.tile ? cfg.tile : '') + (cfg.tileData ? cfg.tileData.length + cfg.tileData.slice(-32) : '');
  let tile = patternCache.get(key);
  if (!tile) {
    if (p === 'geo') { const [t, x] = makeCanvas(8, 8); R(x, 0, 0, 8, 8, cfg.color); x.fillStyle = cfg.color2; for (let i = 0; i < 4; i++) { x.fillRect(i, 3 - i, 1, 1); x.fillRect(4 + i, 4 + i, 1, 1); } x.fillRect(0, 7, 8, 1); tile = t; }
    else if (p === 'image' && cfg.tileCanvas) tile = cfg.tileCanvas;
    else if (p === 'custom' && cfg.tile) { const [t, x] = makeCanvas(8, 8); R(x, 0, 0, 8, 8, cfg.color); x.fillStyle = cfg.color2; for (let i = 0; i < 64; i++) if (cfg.tile[i] === '1') x.fillRect(i % 8, (i / 8) | 0, 1, 1); tile = t; }
    else return cfg.color;
    if (p !== 'image') patternCache.set(key, tile);
  }
  return c.createPattern(tile, 'repeat');
}

/* ======================================================================= */
/*  Interior (behind characters)                                            */
/* ======================================================================= */
export function drawInterior(paint) {
  const [cv, c] = makeCanvas(YW, YH);
  const wall = paint.iwall.color, furn = paint.furn.color, flr = paint.floor.color;
  const K = { wall, furn, flr, walnut: mixHex(furn, '#6e4430', 0.3), steel: '#c6ccd2', cream: '#f3ece0' };
  for (const r of ROOMS) backdrop(c, r, K);
  drawStairs(c);
  for (const r of ROOMS) { const f = FURN[r.kind]; if (f) f(c, r, LEVELS[r.level].y, K); }
  return cv;
}
const WALL_BY = { engine: '#9aa3ab', garage: '#e8ecef', utility: '#dfe3e5', crew: '#ddd6c8', bath: '#eef0f0', wheelhouse: '#4a525a', gym: '#e4e8ea', cinema: '#3e3438', spa: '#dcecef', beachclub: '#e3efee' };
const FLOOR_BY = { engine: '#8c949b', utility: '#8c949b', garage: '#b48a5a', bath: '#d8dcdc', spa: '#d8dcdc', wheelhouse: '#5a6067', cinema: '#5a3a3a', gym: '#8a8f94', beachclub: '#c89a62' };
function backdrop(c, r, K) {
  const fy = LEVELS[r.level].y, top = fy - 40, w = r.x2 - r.x1;
  if (r.type === 'out') {
    if (r.kind === 'lifeboat') { R(c, r.x1, top, w, 40, '#c9ced2'); for (let x = r.x1 + 8; x < r.x2; x += 16) R(c, x, top, 1, 40, '#b5bbc0'); R(c, r.x1, top, w, 3, '#e4e7ea'); }
    const deck = r.kind === 'helideck' ? '#7f8a86' : (r.kind === 'lifeboat' || r.kind === 'mastdeck') ? '#9aa4ac' : '#c89a62';
    R(c, r.x1, fy - 3, w, 3, deck); if (deck === '#c89a62') for (let x = r.x1; x < r.x2; x += 6) R(c, x, fy - 3, 1, 3, '#8e6a42');
    R(c, r.x1, fy - 3, w, 1, shade(deck, 0.25));
    return;
  }
  let wc = WALL_BY[r.kind] || K.wall;
  if (['master', 'vip', 'guest', 'captain'].includes(r.kind)) wc = mixHex(K.wall, K.walnut, 0.55);
  else if (r.kind === 'galley') wc = mixHex(K.wall, K.walnut, 0.35); else if (r.kind === 'bar' || r.kind === 'library') wc = mixHex(K.wall, K.walnut, 0.45);
  R(c, r.x1, top, w, 40, wc);
  for (let x = r.x1 + 6; x < r.x2 - 2; x += (r.kind === 'lounge' || r.kind === 'skylounge' ? 4 : 12)) R(c, x, top + 2, 1, 30, shade(wc, -0.07));
  R(c, r.x1, top, w, 3, shade(wc, 0.2)); R(c, r.x1, top + 3, w, 1, shade(wc, -0.25));
  for (let x = r.x1 + 10; x < r.x2 - 6; x += 22) R(c, x, top + 1, 3, 1, '#fff6dc');
  // window openings: the same rectangles as on the exterior. Glass is left transparent so the scene can paint
  // the live sky / sea behind it (it follows day, night and the region you're sailing through)
  for (const [x, y, ww, hh] of ROOM_WINDOWS[r.id] || []) {
    const frm = r.kind === 'wheelhouse' ? '#2c3036' : shade(wc, -0.35);
    R(c, x - 2, y - 2, ww + 4, hh + 4, frm); R(c, x - 2, y + hh + 1, ww + 4, 1, shade(wc, 0.3)); // frame + sill
    if (r.winBlind) { R(c, x, y, ww, hh, '#c9c2b4'); for (let yy = y + 1; yy < y + hh; yy += 2) R(c, x, yy, ww, 1, '#b3ab9c'); R(c, x + (ww >> 1), y + hh - 2, 1, 2, '#8a8070'); continue; } // closed blinds
    if (r.winFrost) { R(c, x, y, ww, hh, '#e6eef1'); R(c, x + 1, y + 1, 2, hh - 2, '#f8fbfc'); continue; }                                                                 // frosted glass
    c.clearRect(x, y, ww, hh);
    if (ww >= 14 && hh >= 14 && r.winStyle !== 'bridge') R(c, x + Math.floor(ww / 2), y, 1, hh, frm); // mullion
  }
  const fc = FLOOR_BY[r.kind] || K.flr;
  R(c, r.x1, fy - 4, w, 4, fc); for (let x = r.x1 + 3; x < r.x2; x += 9) R(c, x, fy - 4, 1, 4, shade(fc, -0.18)); R(c, r.x1, fy - 4, w, 1, shade(fc, 0.18));
  R(c, r.x1, fy - 6, w, 2, shade(wc, -0.2)); R(c, r.x1, top, 2, 40, shade(wc, -0.4));
}
function drawStairs(c) {
  for (const s of STAIRS) {
    const y1 = LEVELS[s.a].y, y2 = LEVELS[s.b].y; const ladder = s.id === 'ladder'; const steps = ladder ? 7 : 9; const col = ladder ? '#d9dde0' : '#b98d60';
    const dx = (s.bx - s.ax) / steps, dy = (y2 - y1) / steps;
    for (let i = 0; i < steps; i++) { const x = s.ax + dx * i, y = y1 + dy * i; box(c, Math.min(x, x + dx), y + dy, Math.abs(dx) + 3, 2, col, false); }
    c.strokeStyle = ladder ? '#cfd6db' : '#8e6a42'; c.lineWidth = 1; c.beginPath(); c.moveTo(s.ax, y1 - 10); c.lineTo(s.bx, y2 - 10); c.stroke();
  }
}
function sofa(c, x, F, w, seats, fab, fabD, fabL, K) {
  R(c, x + 3, F - 2, 2, 2, '#3a2c24'); R(c, x + w - 5, F - 2, 2, 2, '#3a2c24');                                     // legs
  box(c, x + 3, F - 22, w - 6, 12, fabD);                                                                              // back
  const sw = (w - 12) / seats; for (let i = 0; i < seats; i++) { const bx = Math.round(x + 6 + i * sw); box(c, bx, F - 21, Math.round(sw) - 1, 10, fab); R(c, bx + 1, F - 20, Math.round(sw) - 3, 1, fabL); }
  box(c, x + 2, F - 10, w - 4, 8, fabD);                                                                               // base
  for (let i = 0; i < seats; i++) { const bx = Math.round(x + 6 + i * sw); box(c, bx, F - 12, Math.round(sw) - 1, 4, fab); R(c, bx + 1, F - 12, Math.round(sw) - 3, 1, fabL); }
  for (const ax of [x, x + w - 7]) { box(c, ax, F - 16, 7, 14, fab); R(c, ax + 1, F - 16, 5, 1, fabL); R(c, ax + 1, F - 15, 5, 1, fabD); }
}
function armchair(c, x, F, fab, K) { R(c, x + 2, F - 2, 2, 2, '#3a2c24'); R(c, x + 14, F - 2, 2, 2, '#3a2c24'); box(c, x + 2, F - 20, 14, 10, fab); box(c, x + 1, F - 10, 16, 8, shade(fab, -0.08)); box(c, x + 3, F - 12, 12, 3, shade(fab, 0.08)); box(c, x, F - 15, 4, 13, fab); box(c, x + 14, F - 15, 4, 13, fab); }
function sideTable(c, x, F, K) { box(c, x, F - 10, 10, 10, K.walnut); R(c, x + 1, F - 6, 8, 1, shade(K.walnut, 0.3)); R(c, x + 4, F - 13, 2, 3, '#c9a964'); box(c, x + 1, F - 19, 8, 6, '#f6eedb'); c.fillStyle = 'rgba(255,230,170,0.18)'; c.fillRect(x - 2, F - 20, 14, 8); }
function plant(c, x, F) { box(c, x, F - 7, 8, 7, '#c98a5c'); for (let i = 0; i < 11; i++) R(c, x - 2 + (i * 5) % 12, F - 18 + (i * 3) % 11, 2, 3, ['#3f7a4f', '#5a9a5a', '#86b866'][i % 3]); }
function recliner(c, x, F) { const red = '#8a2f3a'; box(c, x - 7, F - 22, 14, 11, red); R(c, x - 5, F - 21, 10, 1, shade(red, 0.2)); box(c, x - 7, F - 11, 14, 5, '#a03a46'); box(c, x - 6, F - 6, 12, 6, '#5a1f27'); box(c, x - 9, F - 14, 3, 10, '#3a2c2e'); box(c, x + 6, F - 14, 3, 10, '#3a2c2e'); R(c, x - 9, F - 15, 3, 1, '#9aa4ac'); R(c, x + 6, F - 15, 3, 1, '#9aa4ac'); }
const FURN = {
  lounge(c, r, fy, K, sky) {
    // front-facing three-seat sofa: back cushions, seat cushions, rolled arms, short legs; side tables with lamps
    const w = r.x2 - r.x1, sw = Math.min(88, w - 44), sx = r.x1 + 18, F = fy - 4;
    const fab = sky || r.kind === 'skylounge' ? '#d9d2c4' : '#e2dcd0', fabD = shade(fab, -0.12), fabL = shade(fab, 0.1);
    sofa(c, sx, F, sw, 3, fab, fabD, fabL, K);
    for (const [px, col] of [[sx + 8, '#3f6f8a'], [sx + sw - 15, '#c98a5c']]) { box(c, px, F - 18, 7, 6, col); R(c, px + 1, F - 17, 5, 1, shade(col, 0.25)); } // throw pillows lean on the back
    R(c, sx + Math.round(sw / 2) - 10, F - 1, 20, 1, '#c9b48a');                                                              // rug edge
    sideTable(c, sx - 13, F, K); sideTable(c, sx + sw + 3, F, K);
    if (w >= 200) { // big salons get a second seating group: two armchairs around a round table, facing the room
      const ax = sx + sw + 24; armchair(c, ax, F, fabD, K); armchair(c, ax + 38, F, fabD, K);
      box(c, ax + 21, F - 9, 14, 2, '#f4efe9'); R(c, ax + 27, F - 7, 2, 7, '#c9a964'); R(c, ax + 24, F - 1, 8, 1, '#c9a964'); R(c, ax + 26, F - 13, 4, 4, '#c8e2ec');
    }
    if (w > 153) { const tx = r.x2 - 32; box(c, tx, F - 10, 28, 10, K.walnut); R(c, tx + 2, F - 6, 24, 1, shade(K.walnut, 0.3)); R(c, tx + 13, F - 4, 2, 2, '#c9a964'); // media unit standing on the floor
      box(c, tx + 3, F - 26, 22, 14, '#24282d'); R(c, tx + 5, F - 24, 18, 10, '#3b4a56'); R(c, tx + 6, F - 23, 6, 1, '#5d7384'); R(c, tx + 13, F - 12, 2, 2, '#24282d'); }
    if (sky || r.kind === 'skylounge') { plant(c, r.x1 + 3, F); if (w > 120) plant(c, r.x2 - (w > 153 ? 44 : 14), F); }
  },
  skylounge(c, r, fy, K) { FURN.lounge(c, r, fy, K, true); },
  dining(c, r, fy, K) {
    const w = r.x2 - r.x1, n = w > 150 ? 6 : 4, tw = Math.min(w - 40, n * 15), cx = (r.x1 + r.x2) / 2, tx = cx - tw / 2;
    box(c, tx, fy - 14, tw, 4, '#f1ece6'); for (let k = 0; k < tw / 10; k++) R(c, tx + 4 + k * 10, fy - 13, 4, 1, '#c79a86');
    box(c, cx - 2, fy - 10, 4, 10, '#c9a964'); box(c, cx - 12, fy - 2, 24, 2, '#c9a964');
    for (let i = 0; i < n; i++) { const x = tx + 4 + i * (tw - 8) / (n - 1); box(c, x - 4, fy - 18, 8, 10, K.cream); box(c, x - 3, fy - 8, 6, 3, K.cream); R(c, x - 3, fy - 5, 1, 5, '#c9a964'); }
    R(c, cx - 2, fy - 20, 4, 6, '#c8e2ec'); R(c, cx - 4, fy - 24, 8, 4, '#e9a23c'); R(c, cx - 3, fy - 25, 2, 2, '#d8463c'); R(c, cx + 1, fy - 25, 2, 2, '#f2c94c');
    for (const sx of [r.x1 + 4, r.x2 - 18]) { box(c, sx, fy - 22, 14, 18, K.walnut); for (let k = 0; k < 2; k++) R(c, sx + 2, fy - 18 + k * 7, 10, 1, shade(K.walnut, 0.3)); R(c, sx + 5, fy - 26, 4, 4, '#c8e2ec'); } // matching sideboards
  },
  galley(c, r, fy, K) {
    const w = r.x2 - r.x1;
    box(c, r.x1 + 4, fy - 36, 30, 12, K.walnut); R(c, r.x1 + 19, fy - 35, 1, 10, shade(K.walnut, -0.3)); R(c, r.x1 + 16, fy - 30, 2, 1, '#c9a964'); R(c, r.x1 + 21, fy - 30, 2, 1, '#c9a964');
    box(c, r.x1 + 6, fy - 14, w - 40, 14, K.walnut); box(c, r.x1 + 4, fy - 18, w - 36, 4, '#e8e6e2'); for (let x = r.x1 + 6; x < r.x2 - 34; x += 6) R(c, x, fy - 17, 1, 1, '#a8a6a2');
    box(c, r.x1 + 10, fy - 24, 16, 6, K.steel); R(c, r.x1 + 12, fy - 23, 3, 1, '#2c3036'); R(c, r.x1 + 18, fy - 23, 3, 1, '#2c3036');
    R(c, r.x1 + 32, fy - 24, 1, 6, '#c0c6cc'); R(c, r.x1 + 32, fy - 24, 4, 1, '#c0c6cc');
    if (w > 110) { box(c, r.x2 - 48, fy - 30, 16, 30, K.steel); R(c, r.x2 - 46, fy - 26, 12, 8, '#2c3036'); R(c, r.x2 - 46, fy - 14, 12, 10, '#2c3036'); }
    box(c, r.x2 - 28, fy - 36, 22, 36, K.steel); R(c, r.x2 - 18, fy - 34, 1, 32, '#9aa4ac'); R(c, r.x2 - 20, fy - 26, 1, 6, '#7a848c'); R(c, r.x2 - 16, fy - 26, 1, 6, '#7a848c');
    R(c, r.x1 + 40, fy - 22, 4, 4, '#f2c94c'); R(c, r.x1 + 44, fy - 21, 3, 3, '#a8cc6e');
  },
  master(c, r, fy, K, small) {
    // bed centred in the cabin; headboard + base stand on the floor (fy-4); matching nightstands at both ends
    const { bx, bw } = bedGeom(r, small); const F = fy - 4;
    box(c, bx - 4, F - 26, 6, 26, K.walnut); R(c, bx - 3, F - 24, 4, 20, mixHex(K.walnut, K.cream, 0.5));                 // headboard
    box(c, bx + bw - 3, F - 14, 4, 14, K.walnut);                                                                            // footboard
    box(c, bx, F - 13, bw, 13, K.walnut); R(c, bx + 2, F - 2, 2, 2, shade(K.walnut, -0.4)); R(c, bx + bw - 4, F - 2, 2, 2, shade(K.walnut, -0.4)); // base + legs
    R(c, bx + 1, F - 20, bw - 4, 7, '#fbf8f2'); R(c, bx + Math.round(bw * 0.45), F - 20, Math.round(bw * 0.53) - 3, 7, '#e9e2d6'); R(c, bx + Math.round(bw * 0.45), F - 20, 2, 7, '#cbbfae'); // mattress + duvet
    R(c, bx + 3, F - 23, 12, 3, '#ffffff'); R(c, bx + 16, F - 23, 10, 3, '#e8e2d8');                                       // pillows
    for (const nx of [bx - 18, bx + bw + 4]) if (nx >= r.x1 + 3 && nx + 14 <= r.x2 - 3) { box(c, nx, F - 13, 14, 13, K.walnut); R(c, nx + 2, F - 8, 10, 1, shade(K.walnut, 0.3)); R(c, nx + 5, F - 19, 4, 6, '#f4e2a8'); }
  },
  vip(c, r, fy, K) { FURN.master(c, r, fy, K, true); },
  guest(c, r, fy, K) {
    const bx = r.x1 + 10, bw = Math.min(74, r.x2 - r.x1 - 24);
    box(c, bx - 3, fy - 38, 3, 34, K.walnut); box(c, bx + bw, fy - 38, 3, 34, K.walnut);                       // bunk posts to the floor
    for (let y = fy - 34; y < fy - 6; y += 5) R(c, bx + bw - 7, y, 6, 1, shade(K.walnut, 0.25)); R(c, bx + bw - 8, fy - 34, 1, 30, K.walnut); R(c, bx + bw - 1, fy - 34, 1, 30, K.walnut); // ladder
    box(c, bx, fy - 36, bw, 3, K.walnut); box(c, bx, fy - 24, bw, 3, K.walnut);
    R(c, bx + 2, fy - 30, bw - 4, 6, K.cream); R(c, bx + 2, fy - 31, 10, 2, '#ffffff'); R(c, bx + bw - 24, fy - 30, 22, 6, '#77706a');
    box(c, bx, fy - 6, bw, 6, K.walnut); R(c, bx + 2, fy - 12, bw - 4, 6, K.cream); R(c, bx + 2, fy - 13, 10, 2, '#ffffff'); R(c, bx + bw - 24, fy - 12, 22, 6, '#77706a');
    R(c, bx + 12, fy - 30, 8, 4, '#b98d60'); R(c, bx + 12, fy - 12, 8, 4, '#b98d60'); box(c, r.x2 - 12, fy - 24, 10, 24, K.walnut);
  },
  captain(c, r, fy, K) { const bx = r.x1 + 8, bw = Math.min(46, r.x2 - r.x1 - 16); box(c, bx, fy - 8, bw, 8, K.walnut); R(c, bx + 2, fy - 14, bw - 4, 6, K.cream); R(c, bx + 2, fy - 15, 8, 2, '#fff'); R(c, bx + bw * 0.5, fy - 14, bw * 0.45, 6, '#3f5a78'); box(c, bx - 2, fy - 22, 3, 18, K.walnut); box(c, r.x2 - 16, fy - 18, 12, 14, K.walnut); R(c, r.x2 - 6, fy - 22, 3, 4, '#f4e2a8'); R(c, r.x2 - 15, fy - 20, 8, 2, '#6a2a24'); R(c, r.x2 - 15, fy - 21, 8, 1, '#e8dcc0'); },
  crew(c, r, fy, K) {
    // steel bunk with ladder, a row of floor-standing lockers, and the crew mess table with stools
    const w = r.x2 - r.x1, F = fy - 4, bx = r.x1 + 8, bw = Math.min(60, w - 50), st = '#8f99a1';
    R(c, bx - 2, F - 34, 2, 34, st); R(c, bx + bw, F - 34, 2, 34, st);
    box(c, bx, F - 6, bw, 4, st); R(c, bx + 1, F - 2, 2, 2, shade(st, -0.3)); R(c, bx + bw - 3, F - 2, 2, 2, shade(st, -0.3));
    box(c, bx + 1, F - 10, bw - 2, 4, '#ece8e0'); R(c, bx + Math.round(bw * 0.42), F - 10, Math.round(bw * 0.56), 4, '#4f6478'); box(c, bx + 2, F - 13, 10, 3, '#ffffff');
    box(c, bx, F - 24, bw, 3, st); box(c, bx + 1, F - 28, bw - 2, 4, '#ece8e0'); R(c, bx + Math.round(bw * 0.42), F - 28, Math.round(bw * 0.56), 4, '#4f6478'); box(c, bx + 2, F - 31, 10, 3, '#ffffff');
    R(c, bx, F - 33, Math.round(bw * 0.6), 1, st); R(c, bx + Math.round(bw * 0.6) - 1, F - 33, 1, 5, st);                     // top safety rail
    const lx = bx + bw - 8; R(c, lx, F - 30, 1, 26, '#6f7a82'); R(c, lx + 6, F - 30, 1, 26, '#6f7a82'); for (let y = F - 28; y < F - 4; y += 5) R(c, lx, y, 7, 1, '#9aa4ac'); // ladder
    const l0 = bx + bw + 5, l1 = w > 110 ? r.x2 - 48 : r.x2 - 4, n = Math.max(1, Math.min(6, Math.floor((l1 - l0) / 11)));
    for (let i = 0; i < n; i++) { const x = l0 + i * 11; box(c, x, F - 32, 10, 32, '#b7c0c6'); for (let k = 0; k < 3; k++) R(c, x + 2, F - 30 + k * 2, 6, 1, '#8f99a1'); R(c, x + 7, F - 18, 1, 4, '#5a646c'); R(c, x + 3, F - 4, 4, 1, '#8f99a1'); }
    if (w > 110) { const tx = r.x2 - 44; box(c, tx, F - 10, 36, 3, '#d7c4a0'); R(c, tx + 17, F - 7, 2, 7, '#8a7452'); R(c, tx + 12, F - 1, 12, 1, '#8a7452'); R(c, tx + 14, F - 12, 4, 2, '#f4efe9'); R(c, tx + 22, F - 13, 3, 3, '#c8e2ec');
      for (const sxx of [r.x2 - 41, r.x2 - 19]) { box(c, sxx, F - 3, 8, 2, '#5a6a7a'); R(c, sxx + 3, F - 1, 2, 1, '#3a4046'); } }
  },
  bath(c, r, fy, K) {
    const w = r.x2 - r.x1, F = fy - 4, x0 = r.x1;
    for (let y = fy - 36; y < F; y += 5) R(c, x0 + 2, y, w - 34, 1, '#dfe4e4');                                       // tiled splash wall
    // vanity: cabinet on the floor, basin + tap on top, mirror and light above
    box(c, x0 + 4, F - 12, 15, 12, K.walnut); R(c, x0 + 6, F - 8, 11, 1, shade(K.walnut, 0.3)); R(c, x0 + 11, F - 6, 1, 2, '#c9a964');
    box(c, x0 + 3, F - 14, 17, 2, '#f2f2ee'); R(c, x0 + 7, F - 16, 9, 2, '#fbfbf9'); R(c, x0 + 11, F - 19, 1, 3, '#b8c0c6'); R(c, x0 + 11, F - 19, 3, 1, '#b8c0c6');
    box(c, x0 + 5, F - 31, 13, 10, '#9fb8c2'); R(c, x0 + 7, F - 29, 2, 6, '#d8eaf0'); R(c, x0 + 6, F - 33, 11, 1, '#fff4c8');
    // toilet seen from the front: cistern on the wall, round bowl on a pedestal
    const tx = x0 + 21; box(c, tx, F - 17, 9, 6, '#f4f4f0'); R(c, tx + 3, F - 18, 3, 1, '#c0c6cc');
    box(c, tx - 1, F - 11, 11, 3, '#eeeeea'); box(c, tx + 1, F - 8, 7, 8, '#f8f8f4'); R(c, tx + 2, F - 8, 5, 1, '#d6d9d9');
    R(c, x0 + 3, F - 22, 1, 1, '#9aa4ac'); R(c, tx + 10 < r.x2 - 31 ? tx + 10 : tx + 9, F - 24, 1, 6, '#b8c0c6');      // towel hook
    // walk-in shower: tray on the floor, tiled niche, rain head, glass panel with frame and reflection
    const sx = r.x2 - 30; R(c, sx, fy - 36, 28, 32, '#cfe3ea'); for (let y = fy - 34; y < F; y += 4) R(c, sx + 1, y, 26, 1, '#b9d2db'); for (let x = sx + 4; x < sx + 28; x += 6) R(c, x, fy - 36, 1, 32, '#b9d2db');
    box(c, sx, F - 2, 28, 2, '#f4f4f0'); R(c, sx + 13, F - 2, 3, 1, '#9aa4ac');
    R(c, sx + 18, fy - 36, 1, 5, '#b8c0c6'); R(c, sx + 13, fy - 31, 9, 2, '#c8ced3'); for (let i = 0; i < 4; i++) R(c, sx + 14 + i * 2, fy - 28 + (i % 2) * 2, 1, 2, '#e4f2f7');
    R(c, sx + 24, fy - 22, 2, 6, '#b8c0c6');
    c.fillStyle = 'rgba(214,238,246,0.35)'; c.fillRect(sx, fy - 36, 28, 34); R(c, sx, fy - 36, 1, 34, '#9fb4bd'); R(c, sx + 27, fy - 36, 1, 34, '#9fb4bd');
    c.fillStyle = 'rgba(255,255,255,0.35)'; c.beginPath(); c.moveTo(sx + 4, F - 4); c.lineTo(sx + 7, F - 4); c.lineTo(sx + 16, fy - 34); c.lineTo(sx + 13, fy - 34); c.fill();
  },
  utility(c, r, fy, K) {
    R(c, r.x1 + 3, fy - 38, 2, 34, '#7a848c'); R(c, r.x1 + 37, fy - 38, 2, 34, '#7a848c'); for (let k = 0; k < 3; k++) R(c, r.x1 + 4, fy - 32 + k * 8, 34, 2, '#9aa4ac');
    for (let k = 0; k < 8; k++) box(c, r.x1 + 6 + (k % 4) * 8, fy - 38 + Math.floor(k / 4) * 8, 6, 6, ['#d9c27a', '#7fb7c9', '#e7a27c', '#a8cc6e'][k % 4], false);
    if (r.x2 - r.x1 > 60) { box(c, r.x1 + 44, fy - 18, 16, 18, '#f2f4f5'); R(c, r.x1 + 48, fy - 14, 8, 8, '#7a848c'); R(c, r.x1 + 49, fy - 13, 6, 6, '#9fd3e3'); }
    box(c, r.x1 + 6, fy - 14, 30, 10, '#cfd6db');
    if (r.x2 - r.x1 > 160) for (let x = r.x1 + 70; x < r.x2 - 20; x += 30) { box(c, x, fy - 22, 22, 22, '#b8a07a'); R(c, x + 2, fy - 12, 18, 1, '#8a7452'); }
  },
  engine(c, r, fy, K) {
    for (let ex = r.x1 + 10; ex + 34 < r.x2 - 6; ex += 42) { box(c, ex, fy - 26, 34, 22, '#6f7a82'); box(c, ex + 4, fy - 32, 26, 8, '#8a959d'); for (let k = 0; k < 4; k++) R(c, ex + 6 + k * 6, fy - 30, 3, 3, '#545e66'); R(c, ex + 2, fy - 12, 30, 2, '#e6b84a'); }
    R(c, r.x1 + 2, fy - 37, r.x2 - r.x1 - 4, 2, '#b46a4a'); R(c, r.x1 + 2, fy - 34, r.x2 - r.x1 - 4, 1, '#5d8fb8');
    box(c, r.x2 - 12, fy - 30, 10, 26, '#d8463c'); R(c, r.x2 - 9, fy - 26, 4, 2, '#fff');
    // unmarked grey service panel (four screws, a tiny dead LED)
    box(c, r.x2 - 27, fy - 31, 11, 9, '#7f8a92'); R(c, r.x2 - 26, fy - 30, 1, 1, '#5a646c'); R(c, r.x2 - 18, fy - 30, 1, 1, '#5a646c'); R(c, r.x2 - 26, fy - 24, 1, 1, '#5a646c'); R(c, r.x2 - 18, fy - 24, 1, 1, '#5a646c'); R(c, r.x2 - 22, fy - 28, 2, 1, '#3a1a1a');
  },
  garage(c, r, fy, K) {
    const w = r.x2 - r.x1;
    for (let i = 0; i < Math.floor((w - 40) / 14); i++) box(c, r.x1 + 16 + i * 14, fy - 36, 10, 8, '#f0f2f4');
    box(c, r.x2 - 18, fy - 30, 12, 14, '#3a4046'); R(c, r.x2 - 16, fy - 28, 6, 4, '#7fd0e0'); R(c, r.x2 - 16, fy - 22, 2, 2, '#e65b4a'); R(c, r.x2 - 12, fy - 22, 2, 2, '#5ac46e');
    R(c, r.x1 + 4, fy - 38, w - 8, 2, '#9aa4ac'); for (let x = r.x1 + 10; x < r.x2 - 4; x += 10) R(c, x, fy - 36, 1, 2, '#7a848c');
    const jx = r.x2 - 52; R(c, jx + 2, fy - 5, 20, 1, '#7a848c'); box(c, jx, fy - 12, 24, 7, '#2f3438'); box(c, jx + 6, fy - 17, 10, 5, '#3a4046'); R(c, jx + 2, fy - 10, 6, 2, '#d8463c'); R(c, jx + 14, fy - 19, 1, 3, '#c0c6cc');
    if (w > 200) { const jx2 = jx - 34; R(c, jx2 + 2, fy - 5, 20, 1, '#7a848c'); box(c, jx2, fy - 12, 24, 7, '#e9ecef'); box(c, jx2 + 6, fy - 17, 10, 5, '#3a4046'); R(c, jx2 + 2, fy - 10, 6, 2, '#2f7ea6'); }
  },
  wheelhouse(c, r, fy, K) {
    // bow is to the right. Aft: nav-light panel + radio on floor consoles. Middle: chart table with plotter.
    // Forward: the helm console under the windows with the chair behind it, facing the bow.
    // (Wheel, throttles and screens are animated live by the helm system on top of this.)
    const w = r.x2 - r.x1, F = fy - 4, cx = Math.round((r.x1 + r.x2) / 2);
    box(c, r.x1 + 4, F - 24, 14, 24, '#2c3036'); R(c, r.x1 + 6, F - 22, 10, 6, '#1d2126'); R(c, r.x1 + 7, F - 21, 2, 2, '#e65b4a'); R(c, r.x1 + 11, F - 21, 2, 2, '#5ac46e'); R(c, r.x1 + 7, F - 18, 2, 1, '#f6f1e8'); R(c, r.x1 + 6, F - 12, 10, 1, '#3a4046');
    box(c, r.x1 + 24, F - 24, 16, 24, '#2c3036'); R(c, r.x1 + 26, F - 22, 12, 4, '#3e86a8'); R(c, r.x1 + 27, F - 17, 10, 1, '#9fe0ee'); R(c, r.x1 + 26, F - 14, 2, 2, '#c9a964'); R(c, r.x1 + 34, F - 26, 1, 4, '#1d2126'); // VHF/radio
    box(c, cx - 14, F - 13, 28, 13, '#3a4046'); box(c, cx - 15, F - 15, 30, 2, '#59646e'); R(c, cx - 12, F - 9, 24, 1, '#2c3036');            // chart table
    box(c, cx - 9, F - 26, 18, 11, '#1d2126'); R(c, cx - 1, F - 15, 2, 2, '#1d2126');                                                       // plotter on a stalk
    const hx = r.x2 - 36;
    poly(c, [[hx, F], [hx, F - 10], [hx + 6, F - 16], [r.x2 - 3, F - 16], [r.x2 - 3, F]]); c.fillStyle = '#2c3036'; c.fill(); c.strokeStyle = '#1d2126'; c.lineWidth = 1; c.stroke(); // sloped helm console
    R(c, hx + 6, F - 16, r.x2 - 9 - hx, 1, '#59646e');
    box(c, r.x2 - 58, F - 12, 12, 3, '#e9e2d6'); box(c, r.x2 - 60, F - 26, 4, 15, '#e9e2d6'); R(c, r.x2 - 59, F - 24, 2, 10, '#d4cbbb');    // helm chair (back to the stern)
    R(c, r.x2 - 53, F - 9, 2, 9, '#9aa4ac'); R(c, r.x2 - 57, F - 1, 10, 1, '#9aa4ac'); R(c, r.x2 - 49, F - 18, 4, 2, '#d4cbbb');              // pedestal + armrest
    for (const mx of [cx - 30, cx + 14]) if (mx > r.x1 + 42 && mx + 16 < hx) { R(c, mx + 7, fy - 38, 2, 3, '#1d2126'); box(c, mx, fy - 35, 16, 8, '#1d2126'); } // overhead repeaters
  },
  gym(c, r, fy, K) {
    // treadmill in profile (running towards the bow), then a dumbbell rack, a flat bench and a wall mirror in bigger gyms
    const F = fy - 4, x = r.x1 + 6, w = r.x2 - r.x1;
    R(c, x, F - 2, 40, 2, '#2a2e33'); box(c, x + 1, F - 5, 32, 3, '#3a4046'); R(c, x + 2, F - 5, 30, 1, '#22262a'); for (let k = x + 4; k < x + 32; k += 5) R(c, k, F - 4, 1, 1, '#4a5258');
    box(c, x + 31, F - 8, 9, 6, '#2f3438');                                                                                 // motor hood
    c.strokeStyle = '#59646e'; c.lineWidth = 2; c.beginPath(); c.moveTo(x + 36, F - 7); c.lineTo(x + 33, F - 24); c.stroke();  // upright
    box(c, x + 28, F - 28, 11, 5, '#2f3438'); R(c, x + 30, F - 27, 5, 2, '#5ac46e');                                         // console
    R(c, x + 18, F - 20, 15, 1, '#7a848c'); R(c, x + 18, F - 20, 1, 3, '#7a848c');                                         // handrail
    if (w > 90) {
      c.fillStyle = 'rgba(200,225,235,0.55)'; c.fillRect(x + 50, fy - 34, 36, 22); R(c, x + 49, fy - 35, 38, 1, '#9aa4ac'); R(c, x + 49, fy - 12, 38, 1, '#9aa4ac'); // wall mirror
      const rx = x + 52; R(c, rx, F - 14, 2, 14, '#7a848c'); R(c, rx + 30, F - 14, 2, 14, '#7a848c'); R(c, rx, F - 14, 32, 2, '#9aa4ac'); R(c, rx, F - 6, 32, 2, '#9aa4ac'); // two-tier rack
      for (let i = 0; i < 5; i++) { const dx = rx + 3 + i * 6; R(c, dx, F - 17, 4, 3, '#2f3438'); R(c, dx + 1, F - 16, 2, 1, '#59646e'); R(c, dx, F - 9, 4, 3, '#2f3438'); }
      if (w > 120) { const bx2 = r.x2 - 32; box(c, bx2, F - 8, 24, 3, '#4f6478'); R(c, bx2 + 3, F - 5, 2, 5, '#7a848c'); R(c, bx2 + 19, F - 5, 2, 5, '#7a848c'); R(c, bx2 - 2, F - 1, 28, 1, '#5a6a7a'); } // bench on a mat
    }
  },
  cinema(c, r, fy, K) {
    // the screen is on the 'fourth wall' (towards the viewer), so seats face us; the projector shines out of a port in the back wall
    const w = r.x2 - r.x1, F = fy - 4, sx = r.x1 + 30, sw = Math.min(w - 44, 90);
    for (let x = r.x1 + 4; x < r.x2 - 4; x += 10) { R(c, x, fy - 34, 8, 24, '#4a3c41'); R(c, x, fy - 34, 8, 1, '#5a4a50'); }             // acoustic panels
    const px = Math.round((r.x1 + r.x2) / 2); box(c, px - 7, fy - 37, 14, 7, '#1d2126'); R(c, px - 2, fy - 35, 4, 3, '#fff4c8');      // projector port
    c.fillStyle = 'rgba(255,244,200,0.10)'; c.beginPath(); c.arc(px, fy - 33, 9, 0, Math.PI * 2); c.fill(); c.fillStyle = 'rgba(255,244,200,0.06)'; c.beginPath(); c.arc(px, fy - 33, 15, 0, Math.PI * 2); c.fill();
    for (const x of [r.x1 + 8, r.x2 - 10]) { R(c, x, fy - 30, 3, 4, '#c9a964'); c.fillStyle = 'rgba(255,214,140,0.18)'; c.fillRect(x - 2, fy - 26, 7, 6); } // sconces
    for (let i = 0; i < 4; i++) recliner(c, Math.round(sx + 8 + i * (sw - 16) / 3), F);
    for (let x = r.x1 + 6; x < r.x2 - 4; x += 8) R(c, x, F - 1, 2, 1, '#e9a23c');                                                   // aisle step lights
    if (r.x2 - (sx + sw) >= 18) { const cx = r.x2 - 15; box(c, cx, F - 18, 12, 18, '#b23a3a'); box(c, cx + 1, F - 17, 10, 8, '#f6efd8'); R(c, cx + 2, F - 12, 8, 3, '#f2c94c'); R(c, cx + 2, F - 2, 2, 2, '#2c3036'); R(c, cx + 8, F - 2, 2, 2, '#2c3036'); } // popcorn cart
  },
  spa(c, r, fy, K) {
    const w = r.x2 - r.x1; R(c, r.x1 + 30, fy - 10, w - 60, 8, '#6ec3d8'); R(c, r.x1 + 30, fy - 10, w - 60, 1, '#bfeaf4'); R(c, r.x1 + 28, fy - 10, 2, 10, '#e8ecee'); R(c, r.x2 - 30, fy - 10, 2, 10, '#e8ecee');
    for (let x = r.x1 + 34; x < r.x2 - 34; x += 12) R(c, x, fy - 7, 5, 1, '#a8e2ee');
    if (w > 150) { box(c, r.x1 + 6, fy - 12, 34, 4, '#f3efe6'); box(c, r.x1 + 32, fy - 16, 8, 4, '#f3efe6'); R(c, r.x1 + 8, fy - 8, 2, 4, '#9aa4ac'); R(c, r.x1 + 36, fy - 8, 2, 4, '#9aa4ac'); }
    R(c, r.x2 - 26, fy - 36, 18, 26, '#9fd0c4'); for (let i = 0; i < 8; i++) R(c, r.x2 - 24 + (i * 5) % 14, fy - 34 + (i * 7) % 20, 3, 3, ['#3f7a4f', '#5a9a5a', '#86b866'][i % 3]);
  },
  beachclub(c, r, fy, K) { FURN.spa(c, r, fy, K); box(c, r.x2 - 52, fy - 20, 22, 20, K.walnut); R(c, r.x2 - 50, fy - 26, 18, 2, '#e8e6e2'); },
  bar(c, r, fy, K) {
    const w = r.x2 - r.x1, bx = r.x1 + 14, bw = Math.min(w - 30, 70);
    box(c, bx, fy - 16, bw, 16, K.walnut); box(c, bx - 2, fy - 18, bw + 4, 3, '#e8e6e2');
    for (const x of [bx + 10, bx + bw / 2, bx + bw - 10]) { box(c, x - 4, fy - 14, 8, 3, '#2c7a8a'); R(c, x - 1, fy - 11, 2, 11, '#9aa4ac'); }
    // back-bar: floor-standing bottle cabinet against the aft bulkhead (keeps the windows clear)
    box(c, r.x1 + 3, fy - 38, 30, 34, K.walnut); for (let row = 0; row < 3; row++) { R(c, r.x1 + 5, fy - 36 + row * 9, 26, 7, '#3a2c24'); for (let i = 0; i < 6; i++) R(c, r.x1 + 6 + i * 4, fy - 35 + row * 9 + (i % 2), 2, 6 - (i % 2), ['#e9c46a', '#4a8a5a', '#f4efe9', '#c98a7a'][(i + row) % 4]); }
    R(c, r.x1 + 5, fy - 9, 26, 1, '#c9a964');
  },
  library(c, r, fy, K) {
    const w = r.x2 - r.x1; const shelves = Math.max(1, Math.floor((w - 50) / 18));
    for (let s = 0; s < shelves; s++) { const x = r.x1 + 6 + s * 18; box(c, x, fy - 36, 16, 36, K.walnut); for (let row = 0; row < 4; row++) { R(c, x + 1, fy - 34 + row * 9, 14, 7, '#3a2c24'); for (let b = 0; b < 6; b++) R(c, x + 2 + b * 2, fy - 33 + row * 9, 1, 6, ['#d8463c', '#7fb7c9', '#e9c46a', '#a8cc6e', '#f4efe9', '#b48ac8'][(b + row + s) % 6]); } }
    box(c, r.x2 - 44, fy - 16, 36, 4, K.walnut); R(c, r.x2 - 42, fy - 12, 2, 12, K.walnut); R(c, r.x2 - 12, fy - 12, 2, 12, K.walnut); R(c, r.x2 - 30, fy - 20, 8, 4, '#f4efe9'); R(c, r.x2 - 18, fy - 22, 2, 6, '#c9a964'); R(c, r.x2 - 20, fy - 24, 6, 2, '#ffe2a0');
  },
  aftdeck(c, r, fy, K) {
    const w = r.x2 - r.x1, sw = Math.min(56, w - 30), sx = r.x1 + 20;
    box(c, sx, fy - 12, sw, 8, '#f0ece4'); box(c, sx, fy - 18, sw, 6, '#e6e0d4'); R(c, sx, fy - 4, sw, 2, '#c9b48a');
    box(c, sx + sw + 8, fy - 10, 12, 3, '#d7c4a0'); R(c, sx + sw + 13, fy - 7, 2, 7, '#a08a60');
    if (w > 150) { R(c, sx + sw + 40, fy - 36, 1, 36, '#c9b48a'); poly(c, [[sx + sw + 24, fy - 32], [sx + sw + 58, fy - 32], [sx + sw + 48, fy - 38], [sx + sw + 34, fy - 38]]); c.fillStyle = '#f4d7c5'; c.fill(); }
  },
  sundeck(c, r, fy, K) {
    const n = Math.max(1, Math.floor((r.x2 - r.x1 - 20) / 50));
    for (let i = 0; i < n; i++) { const lx = r.x1 + 10 + i * 50; box(c, lx, fy - 7, 40, 4, '#f3efe6'); box(c, lx + 30, fy - 13, 10, 6, '#f3efe6'); R(c, lx + 2, fy - 3, 2, 3, '#9aa4ac'); R(c, lx + 36, fy - 3, 2, 3, '#9aa4ac'); R(c, lx + 2, fy - 7, 24, 1, '#7fb7c9'); }
  },
  flybridge(c, r, fy, K) { box(c, r.x2 - 66, fy - 12, 54, 6, '#f0ece4'); box(c, r.x2 - 66, fy - 18, 54, 6, '#e6e0d4'); box(c, r.x2 - 96, fy - 8, 16, 3, '#d7c4a0'); R(c, r.x2 - 89, fy - 5, 2, 5, '#a08a60'); },
  bow(c, r, fy, K) { box(c, r.x2 - 50, fy - 10, 18, 10, '#5a6067'); R(c, r.x2 - 46, fy - 14, 10, 4, '#7a848c'); box(c, r.x1 + 16, fy - 8, 16, 8, '#e9e2d6'); },
  foredeck(c, r, fy, K) {
    FURN.bow(c, r, fy, K);
    const p = PADS.find(p => p.room === r.id); if (p) { R(c, p.x1, fy - 3, p.x2 - p.x1, 3, '#7f8a86'); R(c, p.x1, fy - 3, p.x2 - p.x1, 1, '#e6c24a'); for (let x = p.x1; x <= p.x2; x += 20) R(c, x, fy - 4, 2, 1, '#9fe08a'); }
  },
  helideck(c, r, fy, K) {
    R(c, r.x1, fy - 3, r.x2 - r.x1, 1, '#e6c24a'); for (let x = r.x1 + 4; x < r.x2; x += 20) R(c, x, fy - 4, 2, 1, '#9fe08a');
    for (let x = r.x1 + 30; x < r.x2 - 20; x += 50) R(c, x, fy - 3, 3, 1, '#ffffff');
  },
  swim(c, r, fy, K) { box(c, r.x1, fy - 2, r.x2 - r.x1, 4, '#c89a62'); for (let x = r.x1 + 2; x < r.x2; x += 5) R(c, x, fy - 2, 1, 4, '#8e6a42'); },
  liferaft(c, r, fy, K) { const n = Math.floor((r.x2 - r.x1 - 16) / 14); for (let k = 0; k < n; k++) { box(c, r.x1 + 10 + k * 14, fy - 14, 12, 10, '#f2f2ee'); R(c, r.x1 + 10 + k * 14, fy - 10, 12, 1, '#d8463c'); R(c, r.x1 + 14 + k * 14, fy - 4, 4, 2, '#9aa4ac'); } box(c, r.x1 + 10, fy - 17, n * 14, 2, '#9aa4ac'); },
  lifeboat(c, r, fy, K) {
    // davit: two arms with sheaves, a falls winch and the cradle the boat rests in
    for (const ax of [r.x1 + 24, r.x2 - 24]) { box(c, ax - 2, fy - 38, 4, 36, '#d4d8db'); R(c, ax - 2, fy - 38, 10, 3, '#d4d8db'); R(c, ax + 6, fy - 37, 2, 2, '#59646e'); }
    box(c, r.x1 + 6, fy - 12, 12, 10, '#7a848c'); R(c, r.x1 + 8, fy - 10, 8, 2, '#e6b84a');
    R(c, r.x1 + 30, fy - 4, r.x2 - r.x1 - 60, 2, '#59646e');
  },
  mastdeck(c, r, fy, K) { box(c, r.x1 + 6, fy - 8, 12, 8, '#c9ced2'); },
  wing(c, r, fy, K) { box(c, r.x2 - 16, fy - 14, 10, 6, '#2c3036'); R(c, r.x2 - 14, fy - 12, 6, 2, '#3e86a8'); R(c, r.x2 - 12, fy - 8, 2, 8, '#9aa4ac'); },
};

/* ======================================================================= */
/*  Exterior shells                                                         */
/* ======================================================================= */
let winCtx = null;
function win(c, x, y, w, h, glass = '#2e3a44', hi = '#3e5260') {
  R(c, x, y, w, h, glass); R(c, x, y, w, Math.min(2, h), hi); if (w > 6) R(c, x + 2, y + 3, 1, Math.max(1, h - 5), hi);
}
function rails(c, P, x1, x2, y, h = 10) {
  R(c, x1, y - h, x2 - x1, 1, P.rails.color); R(c, x1, y - (h >> 1), x2 - x1, 1, shade(P.rails.color, -0.15));
  for (let x = x1; x <= x2; x += 8) R(c, x, y - h, 1, h, P.rails.color);
}
function outRails(c, P, skip = []) {
  for (const r of ROOMS) if (r.type === 'out' && !skip.includes(r.kind) && !skip.includes(r.id)) rails(c, P, r.x1, r.x2, LEVELS[r.level].y, r.kind === 'swim' ? 6 : 10);
}
function dome(c, x, y, r) { c.fillStyle = '#f6f6f4'; c.beginPath(); c.arc(x, y, r, 0, Math.PI * 2); c.fill(); c.fillStyle = '#d6d8d8'; c.fillRect(x - r, y + 1, r * 2, r - 1); c.fillStyle = '#ffffff'; c.fillRect(x - 2, y - r + 1, 3, 2); c.fillStyle = '#c0c4c6'; c.fillRect(x - r + 1, y + r - 1, 2 * r - 2, 2); }

export function hullPath(c) { SPEC.id === 'orcasia' ? orcasiaHull(c) : southHull(c); }
function southHull(c) { poly(c, [[40, 292], [380, 292], [440, 206], [950, 206], [985, 200], [985, 212], [958, 214], [960, 346], [930, 354], [70, 354], [48, 346], [40, 336]]); }
function orcasiaHull(c) { poly(c, [[60, 346], [300, 346], [306, 314], [1450, 314], [1600, 304], [1792, 288], [1800, 296], [1772, 330], [1720, 420], [1700, 462], [1650, 470], [140, 470], [92, 460], [60, 440]]); }

export function drawExterior(paint) {
  const [cv, c] = makeCanvas(YW, YH);
  if (SPEC.id === 'orcasia') drawOrcasia(c, paint); else drawSouthCozy(c, paint);
  return cv;
}

function drawSouthCozy(c, P) {
  const fill = (part, b) => makeFill(c, P[part], b); const sup = P.super.color, fr = P.frames.color;
  // superstructure blocks behind (cover every enclosed room that is not inside the hull)
  for (const r of ROOMS) if (r.type === 'in') { R(c, r.x1, roomTop(r) - 4, r.x2 - r.x1, 44, fill('super', [r.x1, roomTop(r), r.x2 - r.x1, 44])); }
  /* hull */
  c.save(); southHull(c); c.fillStyle = fill('hull', [40, 200, 945, 154]); c.fill(); c.clip();
  c.fillStyle = 'rgba(255,255,255,0.10)'; c.fillRect(0, 206, YW, 3); c.fillRect(0, 292, 400, 2);
  c.fillStyle = 'rgba(0,0,0,0.10)'; c.fillRect(0, 326, YW, 30);
  c.fillStyle = shade(P.trim.color, -0.2); c.fillRect(0, 338, YW, 20); c.fillStyle = P.trim.color2; c.fillRect(0, 336, YW, 2);
  c.restore();
  c.save(); southHull(c); c.strokeStyle = shade(P.hull.color, -0.45); c.translate(0.5, 0.5); c.stroke(); c.restore();
  /* lower deck */
  // tender-bay side shell door (garage) + rubbing strake along the lower deck
  { const g = roomById.garage; c.strokeStyle = shade(P.hull.color, -0.35); c.strokeRect(g.x1 + 14.5, 303.5, g.x2 - g.x1 - 30, 30); R(c, g.x1 + 16, 305, 2, 2, '#c0c6cc'); R(c, g.x2 - 18, 305, 2, 2, '#c0c6cc'); }
  R(c, 44, 336, 900, 1, shade(P.hull.color, -0.3));
  R(c, 40, 300, 4, 36, shade(P.hull.color, -0.25)); // stern garage door
  /* main deck */
  c.clearRect(821, 257, 132, 19); R(c, 820, 251, 165, 6, fill('hull', [820, 251, 165, 6])); R(c, 820, 256, 140, 1, shade(P.hull.color, -0.35));
  R(c, 820, 276, 140, 20, fill('hull', [820, 276, 140, 20])); R(c, 820, 276, 140, 1, shade(P.hull.color, 0.25));
  R(c, 36, 284, 154, 12, fill('hull', [36, 284, 154, 12])); R(c, 36, 284, 154, 1, shade(P.hull.color, 0.25)); // aft bulwark
  R(c, 36, 252, 360, 8, fill('roof', [36, 252, 360, 8])); R(c, 36, 259, 360, 1, shade(sup, -0.2)); // main deck roof fascia
  c.clearRect(821, 213, 124, 20); R(c, 820, 232, 140, 20, fill('hull', [820, 232, 140, 20])); R(c, 820, 232, 140, 1, shade(P.hull.color, 0.25)); R(c, 820, 212, 126, 1, shade(P.hull.color, -0.35));
  R(c, 936, 240, 6, 3, '#2a2e33'); box(c, 860, 300, 14, 24, shade(P.hull.color, 0.05));
  /* upper deck */
  R(c, 300, 212, 140, 40, fill('super', [300, 212, 140, 40])); R(c, 300, 212, 1, 40, shade(sup, -0.2));
  R(c, 36, 204, 300, 10, fill('roof', [36, 204, 300, 10])); R(c, 36, 213, 300, 1, shade(sup, -0.25)); for (let x = 60; x < 330; x += 60) R(c, x, 214, 3, 38, shade(sup, -0.08)); // helideck underside + pillars
  R(c, 36, 214, 300, 3, shade(sup, -0.12)); // safety net shadow
  /* bridge deck */
  R(c, 330, 168, 126, 40, fill('super', [330, 168, 126, 40]));
  R(c, 640, 168, 60, 40, fill('super', [640, 168, 60, 40]));
  R(c, 700, 196, 50, 12, fill('super', [700, 196, 50, 12]));
  poly(c, [[294, 160], [690, 160], [704, 164], [688, 169], [294, 169]]); c.fillStyle = fill('roof', [294, 160, 410, 9]); c.fill(); R(c, 294, 168, 396, 1, shade(P.roof.color, -0.25));
  /* sun deck */
  R(c, 420, 124, 36, 40, fill('super', [420, 124, 36, 40]));
  R(c, 456, 124, 144, 40, fill('super', [456, 124, 144, 40]));
  R(c, 600, 152, 40, 12, fill('super', [600, 152, 40, 12])); R(c, 600, 152, 40, 1, shade(sup, 0.2)); // bridge-wing bulwark
  R(c, 410, 116, 200, 8, fill('roof', [410, 116, 200, 8])); R(c, 410, 123, 200, 1, shade(P.roof.color, -0.25));
  R(c, 296, 164, 390, 4, fill('roof', [296, 164, 390, 4]));
  /* top deck: hardtop, mast, radomes */
  R(c, 470, 92, 120, 3, P.roof.color); for (const x of [474, 584]) R(c, x, 95, 2, 21, '#c0c6cc');
  R(c, 520, 30, 14, 86, fill('super', [520, 30, 14, 86])); R(c, 520, 30, 2, 86, shade(sup, 0.2)); R(c, 532, 30, 2, 86, shade(sup, -0.2));
  R(c, 496, 60, 60, 3, sup); R(c, 504, 78, 44, 3, sup);
  dome(c, 527, 22, 9); dome(c, 556, 54, 7); dome(c, 500, 50, 5);
  R(c, 526, 6, 1, 8, '#c0c6cc'); R(c, 470, 60, 1, 32, '#c0c6cc'); R(c, 604, 58, 1, 34, '#c0c6cc'); R(c, 330, 120, 1, 44, '#c0c6cc');
  drawRoomWindows(c, P);
  /* railings */
  outRails(c, P, ['helideck', 'bow']); rails(c, P, 36, 330, 208, 4); rails(c, P, 820, 944, 232, 6); rails(c, P, 820, 950, 276, 6);
  R(c, 30, 196 + 96, 4, 0, '#000');
  c.fillStyle = shade(P.hull.color, -0.5); c.font = '7px monospace'; c.fillText('SouthCozy SeaLife', 470, 333);
  R(c, 40, 292, 342, 1, P.trim.color2);
}

function drawOrcasia(c, P) {
  const fill = (part, b) => makeFill(c, P[part], b); const sup = P.super.color, fr = P.frames.color;
  for (const r of ROOMS) if (r.type === 'in') R(c, r.x1, roomTop(r) - 4, r.x2 - r.x1, 44, fill('super', [r.x1, roomTop(r), r.x2 - r.x1, 44]));
  /* hull */
  c.save(); orcasiaHull(c); c.fillStyle = fill('hull', [60, 288, 1740, 182]); c.fill(); c.clip();
  c.fillStyle = 'rgba(0,0,0,0.06)'; c.fillRect(0, 420, YW, 50);
  c.fillStyle = 'rgba(255,255,255,0.5)'; c.fillRect(0, 314, YW, 2);
  c.fillStyle = P.trim.color; c.fillRect(0, 444, YW, 30); c.fillStyle = P.trim.color2; c.fillRect(0, 442, YW, 2);
  c.restore();
  c.save(); orcasiaHull(c); c.strokeStyle = shade(P.hull.color, -0.3); c.translate(0.5, 0.5); c.stroke(); c.restore();
  // hull window rows: main deck rectangular pairs, lower deck portholes, tank deck small lights
  // side shell door of the tender bay + hull lines
  c.strokeStyle = shade(P.hull.color, -0.22); c.strokeRect(262.5, 364.5, 220, 30); R(c, 264, 366, 2, 2, '#c0c6cc'); R(c, 478, 366, 2, 2, '#c0c6cc');
  R(c, 60, 362, 4, 36, '#2e3a44'); // beach club glazing at the transom
  R(c, 300, 346, 6, 2, '#000'); R(c, 1770, 318, 6, 3, '#3a4046'); c.fillStyle = '#c0c6cc'; c.beginPath(); c.arc(1700, 432, 4, 0, 7); c.fill();
  c.fillStyle = shade(P.hull.color, -0.55); c.font = 'bold 8px monospace'; c.fillText('BIG ORCASIA', 1560, 352); c.font = '6px monospace'; c.fillText('BIG ORCASIA', 120, 400);
  // aft bulwark of the main deck + foredeck bulwark
  R(c, 60, 336, 244, 10, fill('hull', [60, 336, 244, 10])); R(c, 60, 336, 244, 1, '#ffffff');
  /* tiers: white fascia plates + continuous dark glazing bands (the long stacked look of the references) */
  const plate = (x1, x2, y, h = 8) => { c.fillStyle = fill('roof', [x1, y, x2 - x1, h]); rrect(c, x1, y, x2 - x1, h, 4); c.fill(); R(c, x1 + 4, y + h - 1, x2 - x1 - 8, 1, shade(P.roof.color, -0.22)); R(c, x1 + 4, y, x2 - x1 - 8, 1, '#ffffff'); };
  // raked superstructure front
  poly(c, [[1440, 278], [1470, 314], [1440, 314]]); c.fillStyle = sup; c.fill();
  R(c, 1400, 256, 44, 12, fill('super', [1400, 256, 44, 12]));
  drawRoomWindows(c, P);
  // fascia plates (deck edges) from bottom to top
  plate(110, 1462, 264); plate(290, 1452, 220); plate(400, 1272, 176); plate(810, 1182, 132); plate(890, 1162, 88, 6);
  // radar arch + mast + radomes (tall mast with the large dome, as in the references)
  R(c, 1060, 10, 14, 80, fill('super', [1060, 10, 14, 80])); R(c, 1060, 10, 2, 80, '#ffffff'); R(c, 1072, 10, 2, 80, shade(sup, -0.2));
  R(c, 1030, 34, 76, 3, sup); R(c, 1040, 54, 58, 3, sup); R(c, 1016, 70, 104, 4, sup);
  dome(c, 1098, 76, 12); dome(c, 1036, 26, 6); dome(c, 1104, 24, 5); dome(c, 1066, 4, 3);
  R(c, 1028, 44, 1, 26, '#c0c6cc'); R(c, 1112, 40, 1, 30, '#c0c6cc');
  // lifeboat recess frames
  for (const id of ['lifeboat1', 'lifeboat2']) { const r = roomById[id]; R(c, r.x1, 226, 2, 42, shade(sup, -0.25)); R(c, r.x2 - 2, 226, 2, 42, shade(sup, -0.25)); }
  // aft decks: stepped teak terraces read through the open sides; railings everywhere
  outRails(c, P, ['helideck', 'foredeck']);
  rails(c, P, 520, 820, 180, 4); rails(c, P, 1450, 1745, 312, 6);
  // foredeck bulwark rising to the raked bow
  poly(c, [[1450, 314], [1600, 304], [1792, 288], [1792, 296], [1600, 312], [1450, 318]]); c.fillStyle = fill('hull', [1450, 288, 342, 30]); c.fill();
}

/* ======================================================================= */
/*  Small sprites                                                           */
/* ======================================================================= */
// Limousine tender that doubles as the yacht's rescue boat (modelled on the reference photo: white hull, black rubbing
// strake over a teak cap-rail, teardrop glass cabin with two window rows, teak roof hatch, open teak aft deck with a
// swept stainless rail, rope swag on the topsides). Returned as layers so passengers can be drawn *inside* the cabin.
export const TENDER = { w: 124, h: 40, ax: 62, ay: 36, helm: 104, seats: [54, 66, 78, 90], deck: [16, 27], floor: 25, cap: 7 };
function tenderLayers() {
  const W = TENDER.w, H = TENDER.h;
  const hullPts = [[6, 23], [60, 22], [100, 21], [118, 19], [123, 18], [120, 24], [112, 32], [98, 37], [12, 37], [7, 34]];
  const cabinPts = [[34, 22], [38, 15], [46, 9], [58, 5], [100, 4], [108, 6], [113, 11], [118, 19], [116, 21]];
  const winLo = [[42, 19], [46, 14], [104, 13], [110, 14], [114, 19]];
  const winHi = [[52, 11], [58, 7], [100, 6], [106, 8], [109, 11]];
  const fillP = (c, pts, col) => { poly(c, pts); c.fillStyle = col; c.fill(); };
  // --- interior (behind passengers) ---
  const [back, bc] = makeCanvas(W, H);
  fillP(bc, cabinPts, '#efe6d6'); R(bc, 40, 12, 70, 1, '#d8c8b0');                                         // cabin back wall
  for (let x = 44; x < 110; x += 8) R(bc, x, 8, 1, 14, '#e2d6c2');
  R(bc, 38, 22, 78, 2, '#b8875a'); for (let x = 40; x < 114; x += 5) R(bc, x, 22, 1, 2, '#8e6a42');            // teak sole
  for (const sx of TENDER.seats) { box(bc, sx - 5, 13, 10, 8, '#f4efe6'); box(bc, sx - 6, 19, 12, 3, '#ece4d6'); R(bc, sx - 1, 22, 2, 1, '#9aa4ac'); } // leather seats
  box(bc, 98, 15, 14, 7, '#2c3036'); R(bc, 100, 16, 6, 3, '#3e86a8'); R(bc, 107, 16, 3, 2, '#5ac46e');        // helm console + screen
  bc.strokeStyle = '#c0c6cc'; bc.lineWidth = 1; bc.beginPath(); bc.arc(103.5, 13.5, 3, 0, Math.PI * 2); bc.stroke(); R(bc, 103, 13, 1, 1, '#c0c6cc'); // wheel
  // --- exterior (in front of passengers); glass opaque or see-through ---
  const front = (glassA) => {
    const [cv, c] = makeCanvas(W, H);
    // cabin shell with the two glazing rows cut out
    c.save(); poly(c, cabinPts); c.fillStyle = '#f6f6f4'; c.fill();
    c.globalCompositeOperation = 'destination-out'; poly(c, winLo); c.fill(); poly(c, winHi); c.fill(); c.restore();
    R(c, 36, 20, 2, 2, '#e0e2e2');
    // tinted glass + mullions
    c.save(); c.globalAlpha = glassA; fillP(c, winLo, '#3a3532'); fillP(c, winHi, '#3a3532'); c.restore();
    c.globalAlpha = Math.min(1, glassA + 0.35); for (let x = 58; x < 108; x += 14) { R(c, x, 13, 1, 6, '#1d2126'); R(c, x + 2, 6, 1, 5, '#1d2126'); } R(c, 46, 14, 64, 1, '#1d2126'); c.globalAlpha = 1;
    c.fillStyle = 'rgba(255,255,255,0.35)'; c.fillRect(60, 7, 12, 1); c.fillRect(64, 14, 16, 1);
    fillP(c, [[110, 9], [113, 11], [117, 18], [114, 18]], '#2e3a44');                                         // windscreen
    // teak roof hatch + white roof edge
    fillP(c, [[56, 5], [60, 3], [98, 2], [104, 4]], '#c86e3c'); R(c, 62, 3, 34, 1, '#e8935a'); R(c, 58, 5, 48, 1, '#ffffff');
    R(c, 60, 0, 1, 3, '#c0c6cc'); R(c, 59, 0, 3, 1, '#d8463c');                                                // mast light
    // hull
    poly(c, hullPts); c.fillStyle = '#f4f4f2'; c.fill(); R(c, 10, 33, 100, 4, 'rgba(0,0,0,0)');
    c.save(); poly(c, hullPts); c.clip(); c.fillStyle = '#e3e6e8'; c.fillRect(0, 33, W, 6);
    c.fillStyle = '#b8743c'; c.beginPath(); c.moveTo(6, 23); c.lineTo(123, 18); c.lineTo(123, 19); c.lineTo(6, 24); c.fill(); // teak cap-rail
    c.fillStyle = '#1f2328'; c.beginPath(); c.moveTo(6, 25); c.lineTo(122, 20); c.lineTo(121, 22); c.lineTo(6, 27); c.fill();   // black rubbing strake
    R(c, 10, 31, 52, 1, '#1f2328');                                                                            // aft side stripe
    for (let k = 0; k < 3; k++) { c.fillStyle = '#2a2e33'; c.beginPath(); c.moveTo(70 + k * 4, 35 - k); c.lineTo(112 - k * 2, 31 - k * 2); c.lineTo(112 - k * 2, 32 - k * 2); c.lineTo(70 + k * 4, 36 - k); c.fill(); } // bow boot stripes
    c.restore();
    for (let x = 64; x <= 96; x++) { const y = 31 + Math.round(Math.abs(Math.sin((x - 64) / 32 * Math.PI * 2)) * 2); R(c, x, y, 1, 1, '#2a2e33'); } // rope swag
    // open teak aft deck + swept stainless rail
    R(c, 8, 21, 28, 2, '#c89a62'); for (let x = 10; x < 36; x += 4) R(c, x, 21, 1, 2, '#8e6a42');
    c.strokeStyle = '#d8dde1'; c.beginPath(); c.moveTo(4.5, 30); c.quadraticCurveTo(6, 13, 40, 9.5); c.stroke();
    for (const x of [12, 20, 28]) R(c, x, 13 + Math.round((28 - x) / 6), 1, 21 - (13 + Math.round((28 - x) / 6)), '#c0c6cc');
    R(c, 10, 19, 2, 3, '#e6b84a'); R(c, 116, 16, 2, 3, '#e6b84a');                                              // bollards
    // rescue role: lifebuoy on the cabin aft end + reflective rescue strip
    c.fillStyle = '#ef7a2e'; c.beginPath(); c.arc(38, 17, 3, 0, Math.PI * 2); c.fill(); c.fillStyle = '#f6f6f4'; c.fillRect(37, 14, 2, 1); c.fillRect(37, 19, 2, 1); c.fillRect(35, 16, 1, 2); c.fillRect(40, 16, 1, 2); R(c, 37, 16, 2, 2, '#f6f6f4');
    R(c, 70, 27, 20, 1, '#ef7a2e');
    return cv;
  };
  return { back, front: front(0.92), clear: front(0.38) };
}
export function drawTender() { return tenderLayers(); }
export function drawLiferaft() {
  const [cv, c] = makeCanvas(40, 18);
  c.fillStyle = '#e8743a'; c.beginPath(); c.ellipse(20, 12, 19, 5, 0, 0, Math.PI * 2); c.fill();
  c.fillStyle = '#d8562a'; c.fillRect(2, 12, 36, 3);
  poly(c, [[6, 10], [20, 1], [34, 10]]); c.fillStyle = '#f08a4a'; c.fill(); R(c, 18, 4, 4, 4, '#2c3036');
  return cv;
}
// enclosed davit lifeboat (high-visibility orange canopy, white hull)
export function drawLifeboat() {
  const [cv, c] = makeCanvas(72, 22);
  poly(c, [[2, 12], [66, 12], [71, 9], [68, 16], [60, 21], [10, 21], [3, 17]]); c.fillStyle = '#f4f4f2'; c.fill();
  R(c, 4, 18, 60, 1, '#c9ced2');
  c.fillStyle = '#ef7a2e'; rrect(c, 8, 3, 54, 10, 4); c.fill(); R(c, 10, 3, 50, 1, '#ffa766'); R(c, 8, 11, 54, 1, '#c95e1c');
  for (let x = 14; x < 58; x += 9) R(c, x, 6, 5, 3, '#2e3a44');
  R(c, 34, 0, 2, 3, '#59646e'); R(c, 14, 1, 2, 2, '#59646e'); R(c, 54, 1, 2, 2, '#59646e');
  return cv;
}

export function drawProfileThumb(paint, w = 240, yachtId) {
  const prev = SPEC.id, savedWin = ROOM_WINDOWS; if (yachtId && yachtId !== prev) setYacht(yachtId);
  const ext = drawExterior(paint), int = drawInterior(paint);
  const s = w / YW; const [cv, c] = makeCanvas(w, Math.round(YH * s));
  c.imageSmoothingEnabled = true; c.drawImage(int, 0, 0, cv.width, cv.height); c.drawImage(ext, 0, 0, cv.width, cv.height);
  if (yachtId && yachtId !== prev) { setYacht(prev); }
  ROOM_WINDOWS = savedWin;
  return cv;
}
