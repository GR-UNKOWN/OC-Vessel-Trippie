export const maxSprite = 80 * 1024;

export function spriteValue(value) {
  if (value === null) return null;
  if (typeof value !== 'string' || value.length > maxSprite ||
      !/^data:image\/png;base64,[A-Za-z0-9+/]+=*$/.test(value)) return undefined;
  const header = Buffer.from(value.slice(22, 54), 'base64');
  if (header.length < 24 || header.toString('hex', 0, 8) !== '89504e470d0a1a0a' ||
      header.toString('ascii', 12, 16) !== 'IHDR') return undefined;
  const width = header.readUInt32BE(16);
  const height = header.readUInt32BE(20);
  if (width && height && width <= 200 && height <= 200) return value;
}

const roomId = value => typeof value === 'string' && /^[a-z0-9_:-]{1,48}$/i.test(value);
const yachtId = value => value === 'southcozy' || value === 'orcasia';
const number = (value, min, max) => Number.isFinite(value) && value >= min && value <= max;

function worldValue(w) {
  if (!w || !yachtId(w.y) || !number(w.la, -90, 90) || !number(w.lo, -180, 180) ||
      !number(w.hd, -360, 720) || !number(w.sp, -100, 100) || !number(w.hr, 0, 24) ||
      !number(w.utc, 0, 8640000000000000) || !number(w.tz, -14, 14)) return undefined;
  return {
    y: w.y, la: w.la, lo: w.lo, hd: w.hd, sp: w.sp, hr: w.hr, utc: w.utc, tz: w.tz,
    st: roomId(w.st) ? w.st : undefined, dock: roomId(w.dock) ? w.dock : null,
    L: typeof w.L === 'string' && /^[01]{1,512}$/.test(w.L) ? w.L : undefined,
    td: roomId(w.td) ? w.td : undefined,
    tx: number(w.tx, -10000, 10000) ? w.tx : undefined,
    ty: number(w.ty, -10000, 10000) ? w.ty : undefined,
    door: number(w.door, 0, 1) ? w.door : undefined,
    sk: number(w.sk, 0, 10000) ? w.sk : null,
  };
}


export function stateValue(s, pin) {
  if (!s || s.v !== 1 || typeof s.n !== 'string' || !Array.isArray(s.p) || s.p.length !== 5 ||
      !s.p.every(Number.isSafeInteger) || Math.abs(s.p[0]) > 10000 || Math.abs(s.p[1]) > 10000 ||
      ![-1, 1].includes(s.p[2]) || !number(s.p[3], 0, 11) || !yachtId(s.y)) return null;

  const state = {
    v: 1, pin, n: s.n.slice(0, 24).toWellFormed(), oc: typeof s.oc === 'string' ? s.oc.slice(0, 24).toWellFormed() : '',
    y: s.y, p: s.p, rtt: number(s.rtt, 0, 60000) ? s.rtt : 0,
  };
  if (Array.isArray(s.say) && (typeof s.say[0] === 'number' || typeof s.say[0] === 'string') &&
      typeof s.say[1] === 'string') state.say = [String(s.say[0]).slice(0, 32).toWellFormed(), s.say[1].slice(0, 80).toWellFormed()];
  if (s.w?.y === s.y) state.w = worldValue(s.w);
  if (s.lr && roomId(s.lr.r) && typeof s.lr.on === 'boolean' && Number.isSafeInteger(s.lr.q)) {
    state.lr = { r: s.lr.r, on: s.lr.on, q: s.lr.q };
  }
  return state;
}
