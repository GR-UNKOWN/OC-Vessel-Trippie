import { createHash } from 'node:crypto';

// One Redis hash per PIN. Membership and room changes are atomic across Vercel instances.
const roomScript = `
local key = KEYS[1]
local op = ARGV[1]
local now = tonumber(ARGV[2])
local args = cjson.decode(ARGV[3])
local lease = 45000
local ttl = 90000
local null = cjson.null

local function memberField(id) return 'm:' .. id end
local function member(id)
  local value = redis.call('HGET', key, memberField(id))
  if value then return cjson.decode(value) end
end
local function remove(id)
  redis.call('HDEL', key, memberField(id), 's:' .. id, 'g:' .. id)
end
local function saveMember(id, data)
  redis.call('HSET', key, memberField(id), cjson.encode(data))
end

local host = redis.call('HGET', key, 'host')
local captain = host and member(host)
if host and (not captain or captain[2] <= now) then
  redis.call('DEL', key)
  host = false
end

if op == 'create' then
  if host then return {'collision'} end
  redis.call('HSET', key, 'host', args.id)
  saveMember(args.id, {args.token, now + lease})
  redis.call('PEXPIRE', key, ttl)
  return {'ok', 1}
end
if not host then return {'unknown-room'} end

if op == 'join' then
  local count = 0
  for _, field in ipairs(redis.call('HKEYS', key)) do
    if string.sub(field, 1, 2) == 'm:' then
      local id = string.sub(field, 3)
      local data = member(id)
      if data[2] <= now then remove(id) else count = count + 1 end
    end
  end
  if count >= 12 then return {'room-full'} end
  saveMember(args.id, {args.token, now + lease})
  return {'ok', 0}
end

local id = args.id
local data = member(id)
if not data or data[2] <= now or data[1] ~= args.token then return {'expired'} end
if op == 'leave' then
  if id == host then redis.call('DEL', key) else remove(id) end
  return {'ok'}
end
if op ~= 'sync' then return {'invalid-request'} end

if data[2] < now + lease - 8000 then
  data[2] = now + lease
  saveMember(id, data)
  if id == host then redis.call('PEXPIRE', key, ttl) end
end
if args.state then
  local previousRaw = redis.call('HGET', key, 's:' .. id)
  local previous = previousRaw and cjson.decode(previousRaw)
  local state = args.state
  if not previous or previous.p[5] < state.p[5] then
    state.h = id == host and 1 or 0
    if id == host then state.lr = nil else state.w = nil end
    state.revision = state.p[5]
    state.spriteVersion = previous and previous.spriteVersion or 0
    if args.sprite ~= nil then
      redis.call('HSET', key, 'g:' .. id, args.sprite)
      state.spriteVersion = state.revision
    end
    redis.call('HSET', key, 's:' .. id, cjson.encode(state))
  end
end

local changed = {}
local present = {}
for _, field in ipairs(redis.call('HKEYS', key)) do
  if string.sub(field, 1, 2) == 'm:' then
    local peer = string.sub(field, 3)
    if peer ~= id then
      local info = member(peer)
      if info[2] <= now then
        remove(peer)
      else
        local raw = redis.call('HGET', key, 's:' .. peer)
        if raw then
          present[#present + 1] = peer
          local known = args.known[peer]
          local state = cjson.decode(raw)
          if not known or known[1] ~= state.revision then
            local sprite = null
            if not known or known[2] ~= state.spriteVersion then sprite = redis.call('HGET', key, 'g:' .. peer) or '' end
            changed[#changed + 1] = {peer, raw, sprite}
          end
        end
      end
    end
  end
end
return {'ok', cjson.encode({present, changed})}
`;

const scriptHash = createHash('sha1').update(roomScript).digest('hex');
const prefix = `oc-seatrip:2:${process.env.VERCEL_PROJECT_ID || 'local'}:${process.env.VERCEL_ENV || 'dev'}:`;

const restUrl = process.env.UPSTASH_REDIS_REST_URL || process.env.KV_REST_API_URL;
const restToken = process.env.UPSTASH_REDIS_REST_TOKEN || process.env.KV_REST_API_TOKEN;

export function storageConfigured() {
  return Boolean(restUrl && restToken);
}

async function redis(command) {
  const res = await fetch(restUrl, {
    method: 'POST',
    headers: {
      Authorization: 'Bearer ' + restToken,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(command),
    signal: AbortSignal.timeout(2800),
  });
  const data = await res.json();
  if (typeof data.error === 'string' && data.error.startsWith('NOSCRIPT')) return null;
  if (!res.ok || data.error) throw new Error('Redis request failed');
  return data.result;
}

export async function checkStorage() {
  return storageConfigured() && await redis(['PING']) === 'PONG';
}

export async function roomCommand(pin, op, args) {
  const tail = [1, prefix + pin, op, Date.now(), JSON.stringify(args)];
  return await redis(['EVALSHA', scriptHash, ...tail]) ?? await redis(['EVAL', roomScript, ...tail]);
}
